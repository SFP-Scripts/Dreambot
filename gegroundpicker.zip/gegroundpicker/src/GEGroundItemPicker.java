package gegroundpicker;

import gegroundpicker.gui.ControlPanelGUI;
import gegroundpicker.gui.LootLogGUI;
import gegroundpicker.gui.PickerGUI;
import gegroundpicker.handlers.*;
import gegroundpicker.managers.*;
import gegroundpicker.mouse.*;
import gegroundpicker.utils.*;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * GE Ground Item Picker - Picks up valuable items around Grand Exchange
 * Features: SmartMouse, GUI configuration, value tracking, AFK breaks, Loot Log, Auto-walk from F2P locations
 *
 * @author jj
 */
@ScriptManifest(
        name = "GE Ground Item Picker",
        description = "Picks up ground items at Grand Exchange with SmartMouse and anti-ban",
        author = "jj",
        version = 1.1,
        category = Category.MONEYMAKING
)
public class GEGroundItemPicker extends AbstractScript {

    // Managers
    private MouseManager mouseManager;
    private ConfigManager configManager;
    private StatisticsTracker statisticsTracker;
    private AntiBanManager antiBanManager;
    private BreakManager breakManager;
    private RunEnergyManager runEnergyManager;

    // Handlers
    private PickingHandler pickingHandler;
    private BankingHandler bankingHandler;
    private WalkingHandler walkingHandler;
    private EquipmentHandler equipmentHandler;
    private PathingHandler pathingHandler;

    // State
    private ScriptState currentState = ScriptState.INITIALIZING;
    private boolean guiComplete = false;

    // Areas - Multi-tier system to reduce unnecessary walking
    private static final Area GE_WALLS_AREA = new Area(3143, 3465, 3190, 3510); // Full GE enclosure
    private static final Area GE_AREA = new Area(3160, 3485, 3175, 3495); // Preferred picking area near bank
    private static final Area GE_BANK_AREA = new Area(3160, 3485, 3170, 3495); // Bank area

    // Loot Log GUI
    private LootLogGUI lootLogGUI;
    private ControlPanelGUI controlPanel;
    private Rectangle lootLogButtonArea;

    @Override
    public void onStart() {
        log("========================================");
        log("GE Ground Item Picker v1.1");
        log("Author: jj");
        log("========================================");
        log("TIP: Right-click this script in the Script Manager to view Loot Log");

        // Show GUI
        SwingUtilities.invokeLater(() -> {
            PickerGUI gui = new PickerGUI();
            gui.setVisible(true);
            gui.setOnStartCallback(config -> {
                configManager = new ConfigManager(config);
                guiComplete = true;
                log("Configuration loaded from GUI");
            });
        });

        // Wait for GUI completion
        Sleep.sleepUntil(() -> guiComplete, 300000); // 5 min timeout

        if (!guiComplete) {
            log("GUI timeout - stopping script");
            stop();
            return;
        }

        // Initialize managers
        initializeManagers();

        // Initialize handlers
        initializeHandlers();

        log("========================================");
        log("Script initialized successfully!");
        log("Configuration:");
        configManager.logConfiguration();
        log("========================================");

        // Show control panel for easy access to features
        SwingUtilities.invokeLater(() -> {
            controlPanel = new ControlPanelGUI(this);
            controlPanel.setVisible(true);
            log("Control Panel opened - use it to access Loot Log and other features");
        });

        // Check if we need to walk to GE
        Tile playerPos = Players.getLocal().getTile();
        if (!GE_WALLS_AREA.contains(playerPos)) {
            log("Not at Grand Exchange - will walk there first");
            currentState = ScriptState.WALKING_TO_GE;
        } else {
            currentState = ScriptState.PICKING;
        }
    }

    private void initializeManagers() {
        // Mouse Manager with SmartMouse
        mouseManager = new MouseManager(this, configManager.isSmartMouseEnabled());
        if (!mouseManager.initialize()) {
            log("WARNING: SmartMouse initialization failed - using default mouse");
        }

        // Statistics Tracker
        statisticsTracker = new StatisticsTracker();

        // Anti-Ban Manager with configurable settings and individual toggles
        antiBanManager = new AntiBanManager(
                this,
                configManager,
                configManager.getAntiBanInterval(),
                configManager.getAntiBanChance()
        );

        // Break Manager with configurable variance
        breakManager = new BreakManager(
                configManager.isBreaksEnabled(),
                configManager.getBreakAfterMinutes(),
                configManager.getBreakDurationMinutes(),
                configManager.getBreakVariance()
        );

        // Run Energy Manager
        runEnergyManager = new RunEnergyManager(configManager.isRunEnabled());
    }

    private void initializeHandlers() {
        pickingHandler = new PickingHandler(
                this,
                mouseManager,
                configManager,
                statisticsTracker,
                antiBanManager
        );

        bankingHandler = new BankingHandler(
                this,
                mouseManager,
                statisticsTracker
        );

        walkingHandler = new WalkingHandler(
                this,
                mouseManager,
                GE_AREA
        );

        equipmentHandler = new EquipmentHandler(this, configManager);

        pathingHandler = new PathingHandler(this);
    }

    @Override
    public int onLoop() {
        try {
            // Process any chat commands
            processCommands();

            // FIRST: Check for and drop excluded items (highest priority)
            if (equipmentHandler.needsToHandleExclusions()) {
                currentState = ScriptState.DROPPING_EXCLUSIONS;
                return equipmentHandler.checkAndDropExcludedItems();
            }

            // Check if goal reached
            if (configManager.hasValueGoal() &&
                    statisticsTracker.getTotalValueCollected() >= configManager.getTargetValue()) {
                log("========================================");
                log("VALUE GOAL REACHED!");
                log("Target: " + configManager.getTargetValue() + " GP");
                log("Collected: " + statisticsTracker.getTotalValueCollected() + " GP");
                log("========================================");
                stop();
                return -1;
            }

            // Check if on break
            if (breakManager.shouldTakeBreak()) {
                currentState = ScriptState.BREAKING;
                breakManager.startBreak();
                log("Taking break for " + breakManager.getBreakDuration() + " minutes");
                return 60000; // Check every minute during break
            }

            if (breakManager.isOnBreak()) {
                if (breakManager.isBreakOver()) {
                    log("Break finished - resuming script");
                    currentState = ScriptState.PICKING;
                    breakManager.endBreak();
                } else {
                    return 60000; // Check every minute
                }
            }

            // Manage run energy
            runEnergyManager.manage();

            // Execute anti-ban actions randomly
            if (antiBanManager.shouldPerformAction()) {
                antiBanManager.performRandomAction();
            }

            // State machine
            switch (currentState) {
                case PICKING:
                    return handlePicking();

                case BANKING:
                    return handleBanking();

                case WALKING_TO_GE:
                    return handleWalkingToGE();

                case BREAKING:
                    return 60000;

                default:
                    return 1000;
            }

        } catch (Exception e) {
            log("ERROR in main loop: " + e.getMessage());
            e.printStackTrace();
            return RandomHelper.getRandomInt(2000, 3000);
        }
    }

    private int handlePicking() {
        // Check if inventory full
        if (Inventory.isFull()) {
            log("Inventory full - going to bank");
            currentState = ScriptState.BANKING;
            return 300;
        }

        // Check if OUTSIDE the GE walls entirely
        Tile playerPos = Players.getLocal().getTile();
        if (!GE_WALLS_AREA.contains(playerPos)) {
            log("Outside GE walls - walking back to GE");
            currentState = ScriptState.WALKING_TO_GE;
            return 300;
        }

        // If inside GE walls but not in preferred area, just stand and scan
        // Don't walk constantly - let the picking handler's walk logic handle repositioning
        if (!GE_AREA.contains(playerPos)) {
            log("Inside GE but outside preferred area - standing and scanning");
            // Continue to picking logic - will scan from current position
        }

        // Execute picking logic
        return pickingHandler.handle();
    }

    private int handleBanking() {
        Tile playerPos = Players.getLocal().getTile();

        // Walk to bank if not there
        if (!GE_BANK_AREA.contains(playerPos)) {
            if (walkingHandler.walkToBank()) {
                return RandomHelper.getRandomInt(800, 1200);
            }
            return RandomHelper.getRandomInt(1000, 1500);
        }

        // Execute banking
        int result = bankingHandler.handle();

        // After banking, go back to picking
        if (!Inventory.isFull()) {
            currentState = ScriptState.PICKING;
        }

        return result;
    }

    private int handleWalkingToGE() {
        // Use PathingHandler for long-distance walking from F2P locations
        if (pathingHandler.isVeryFarFromGE()) {
            log("[Pathing] Using PathingHandler for long-distance walk to GE");
            if (pathingHandler.walkToGrandExchange()) {
                currentState = ScriptState.PICKING;
                return RandomHelper.getRandomInt(800, 1200);
            }
            return RandomHelper.getRandomInt(1500, 2000);
        }

        // Use WalkingHandler for short-distance walking (already near GE)
        if (walkingHandler.walkToGE()) {
            currentState = ScriptState.PICKING;
            return RandomHelper.getRandomInt(600, 900);
        }
        return RandomHelper.getRandomInt(1000, 1500);
    }

    @Override
    public void onExit() {
        log("========================================");
        log("GE Ground Item Picker - Session Summary");
        log("========================================");
        statisticsTracker.logFinalStats();
        log("========================================");
        log("Thank you for using GE Ground Item Picker!");
        log("========================================");

        // Close GUIs if open
        if (lootLogGUI != null) {
            lootLogGUI.dispose();
        }
        if (controlPanel != null) {
            controlPanel.dispose();
        }
    }

    @Override
    public void onPaint(Graphics g) {
        // Don't paint until GUI is complete and script is initialized
        if (!guiComplete || statisticsTracker == null || configManager == null || breakManager == null) {
            return;
        }

        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Background panel - make it taller for more info
        g2d.setColor(new Color(0, 0, 0, 180));
        g2d.fillRoundRect(10, 300, 290, 210, 10, 10);

        // Title with version
        g2d.setColor(Color.CYAN);
        g2d.setFont(new Font("Arial", Font.BOLD, 14));
        g2d.drawString("GE Ground Item Picker v1.1", 20, 320);

        // Stats
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.PLAIN, 12));

        int y = 340;

        // State
        Color stateColor = currentState == ScriptState.PICKING ? Color.GREEN :
                currentState == ScriptState.BANKING ? Color.YELLOW :
                        currentState == ScriptState.BREAKING ? Color.RED : Color.WHITE;
        g2d.setColor(stateColor);
        g2d.drawString("? State: " + currentState, 20, y);

        // Items and Value
        g2d.setColor(Color.WHITE);
        y += 20;
        g2d.drawString("Items Picked: " + statisticsTracker.getItemsPickedCount(), 20, y);
        y += 20;
        g2d.drawString("Value: " + formatNumber(statisticsTracker.getTotalValueCollected()) + " GP", 20, y);
        y += 20;
        g2d.drawString("GP/Hour: " + formatNumber(statisticsTracker.getValuePerHour()), 20, y);
        y += 20;
        g2d.drawString("Runtime: " + statisticsTracker.getFormattedRuntime(), 20, y);
        y += 20;

        // Last item picked
        g2d.setColor(Color.CYAN);
        String lastItem = statisticsTracker.getLastItemPicked();
        int lastValue = statisticsTracker.getLastItemValue();
        g2d.drawString("Last: " + lastItem + " (" + formatNumber(lastValue) + " GP)", 20, y);
        y += 15;

        // Most profitable item
        g2d.setColor(Color.YELLOW);
        String bestItem = statisticsTracker.getMostProfitableItem();
        int bestValue = statisticsTracker.getMostProfitableItemValue();
        g2d.drawString("Best: " + bestItem + " (" + formatNumber(bestValue) + " GP)", 20, y);
        y += 20;

        // Break timer
        if (breakManager.isOnBreak()) {
            g2d.setColor(Color.ORANGE);
            long breakRemaining = breakManager.getTimeRemainingOnBreak();
            g2d.drawString("AFK Break: " + breakRemaining + " min left", 20, y);
        } else if (breakManager != null && configManager.isBreaksEnabled()) {
            g2d.setColor(Color.GRAY);
            long timeUntilBreak = breakManager.getTimeUntilBreak();
            g2d.drawString("Next Break: " + timeUntilBreak + " min", 20, y);
        }
        y += 20;

        // Goal progress bar
        if (configManager.hasValueGoal()) {
            int targetValue = configManager.getTargetValue();
            int collected = statisticsTracker.getTotalValueCollected();
            int progress = (int)((collected / (double)targetValue) * 100);
            progress = Math.min(100, progress);

            // Progress text
            g2d.setColor(Color.YELLOW);
            g2d.drawString("Goal: " + progress + "% (" + formatNumber(collected) + "/" + formatNumber(targetValue) + ")", 20, y);

            // Progress bar
            y += 5;
            int barWidth = 250;
            int barHeight = 12;

            // Background
            g2d.setColor(new Color(50, 50, 50));
            g2d.fillRect(20, y, barWidth, barHeight);

            // Progress fill
            int fillWidth = (int)((progress / 100.0) * barWidth);
            Color progressColor = progress < 33 ? new Color(200, 50, 50) :
                    progress < 66 ? new Color(200, 150, 50) :
                            new Color(50, 200, 50);
            g2d.setColor(progressColor);
            g2d.fillRect(20, y, fillWidth, barHeight);

            // Border
            g2d.setColor(Color.GRAY);
            g2d.drawRect(20, y, barWidth, barHeight);
        }

        // Feature indicators in bottom right
        int indicatorX = 265;
        int indicatorY = 320;
        int indicatorSize = 8;

        // SmartMouse indicator
        g2d.setColor(mouseManager.isSmartMouseEnabled() ? Color.GREEN : Color.GRAY);
        g2d.fillOval(indicatorX, indicatorY, indicatorSize, indicatorSize);

        // Run indicator
        indicatorY += 12;
        g2d.setColor(configManager.isRunEnabled() ? Color.GREEN : Color.GRAY);
        g2d.fillOval(indicatorX, indicatorY, indicatorSize, indicatorSize);

        // Anti-ban indicator
        indicatorY += 12;
        g2d.setColor(configManager.isAntiBanEnabled() ? Color.GREEN : Color.GRAY);
        g2d.fillOval(indicatorX, indicatorY, indicatorSize, indicatorSize);

        // LOOT LOG BUTTON
        drawLootLogButton(g2d);
    }

    private void drawLootLogButton(Graphics2D g2d) {
        int buttonX = 320;
        int buttonY = 300;
        int buttonWidth = 120;
        int buttonHeight = 65;

        lootLogButtonArea = new Rectangle(buttonX, buttonY, buttonWidth, buttonHeight);

        // Simple instruction box
        g2d.setColor(new Color(0, 100, 200, 160));
        g2d.fillRoundRect(buttonX, buttonY, buttonWidth, buttonHeight, 8, 8);

        // Border
        g2d.setColor(Color.WHITE);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawRoundRect(buttonX, buttonY, buttonWidth, buttonHeight, 8, 8);

        // Title text
        g2d.setColor(Color.YELLOW);
        g2d.setFont(new Font("Arial", Font.BOLD, 11));
        FontMetrics fm = g2d.getFontMetrics();
        String titleText = "LOOT LOG";
        int titleX = buttonX + (buttonWidth - fm.stringWidth(titleText)) / 2;
        g2d.drawString(titleText, titleX, buttonY + 15);

        // Count text
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.PLAIN, 10));
        String countText = statisticsTracker.getLootLogSize() + " items";
        int countX = buttonX + (buttonWidth - g2d.getFontMetrics().stringWidth(countText)) / 2;
        g2d.drawString(countText, countX, buttonY + 30);

        // Instruction text line 1
        g2d.setFont(new Font("Arial", Font.PLAIN, 9));
        g2d.setColor(Color.LIGHT_GRAY);
        String instruction1 = "Use Control Panel";
        int instr1X = buttonX + (buttonWidth - g2d.getFontMetrics().stringWidth(instruction1)) / 2;
        g2d.drawString(instruction1, instr1X, buttonY + 45);

        // Instruction text line 2
        String instruction2 = "to view loot log";
        int instr2X = buttonX + (buttonWidth - g2d.getFontMetrics().stringWidth(instruction2)) / 2;
        g2d.drawString(instruction2, instr2X, buttonY + 56);
    }

    /**
     * Process user commands (simple command system)
     * User can type ::lootlog to open loot log
     */
    private void processCommands() {
        // This is a placeholder - DreamBot doesn't easily support chat command listening
        // Users will need to manually call openLootLog() or we provide a menu option
        // For now, this is just a stub
    }

    /**
     * Open the loot log GUI (can be called manually or via button)
     */
    public void openLootLog() {
        SwingUtilities.invokeLater(() -> {
            if (lootLogGUI == null || !lootLogGUI.isVisible()) {
                lootLogGUI = new LootLogGUI(statisticsTracker);
                lootLogGUI.setVisible(true);
                log("Loot Log opened - showing " + statisticsTracker.getLootLogSize() + " items");
            } else {
                lootLogGUI.toFront();
                lootLogGUI.requestFocus();
            }
        });
    }

    /**
     * Format numbers with K/M suffix
     */
    private String formatNumber(int num) {
        if (num >= 1000000) {
            return String.format("%.1fM", num / 1000000.0);
        } else if (num >= 1000) {
            return String.format("%.1fK", num / 1000.0);
        }
        return String.valueOf(num);
    }

    public enum ScriptState {
        INITIALIZING,
        PICKING,
        BANKING,
        WALKING_TO_GE,
        BREAKING,
        DROPPING_EXCLUSIONS
    }

    // Getters for handlers/managers
    public MouseManager getMouseManager() { return mouseManager; }
    public ConfigManager getConfigManager() { return configManager; }
    public StatisticsTracker getStatisticsTracker() { return statisticsTracker; }
}
package gegroundpicker.utils;

import java.util.Random;

/**
 * Helper class for generating random values with human-like distribution
 */
public class RandomHelper {

    private static final Random random = new Random();

    /**
     * Get random int between min and max (inclusive)
     */
    public static int getRandomInt(int min, int max) {
        if (min >= max) {
            return min;
        }
        return random.nextInt(max - min + 1) + min;
    }

    /**
     * Get random int with gaussian distribution
     */
    public static int getRandomGaussian(int mean, int stdDev) {
        double gaussian = random.nextGaussian();
        int result = (int)(gaussian * stdDev + mean);
        return Math.max(0, result);
    }

    /**
     * Get random double between min and max
     */
    public static double getRandomDouble(double min, double max) {
        if (min >= max) {
            return min;
        }
        return min + (max - min) * random.nextDouble();
    }

    /**
     * Get random boolean with given probability
     */
    public static boolean getRandomBoolean(double probability) {
        return random.nextDouble() < probability;
    }

    /**
     * Get random sleep time with slight variance
     */
    public static int getRandomSleep(int base) {
        int variance = base / 5; // 20% variance
        return getRandomInt(base - variance, base + variance);
    }

    /**
     * Get human-like reaction time (100-400ms typical)
     */
    public static int getHumanReactionTime() {
        return getRandomGaussian(250, 75);
    }
}

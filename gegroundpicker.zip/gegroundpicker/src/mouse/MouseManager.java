package gegroundpicker.mouse;

import org.dreambot.api.script.AbstractScript;

/**
 * Factory and manager for mouse controllers for GE Ground Picker.
 * Simplified version without JSON loading.
 */
public class MouseManager {

    private final AbstractScript script;
    private final boolean smartMouseEnabled;
    private MouseController activeController;

    public MouseManager(AbstractScript script, boolean smartMouseEnabled) {
        this.script = script;
        this.smartMouseEnabled = smartMouseEnabled;
        script.log("[MouseManager] Initialized (SmartMouse: " + smartMouseEnabled + ")");
    }

    /**
     * Initialize the appropriate mouse controller
     */
    public boolean initialize() {
        if (smartMouseEnabled) {
            activeController = new SmartMouseController(true);
            script.log("[MouseManager] ========================================");
            script.log("[MouseManager] ✓ SMARTMOUSE ACTIVE (Simplified Mode)");
            script.log("[MouseManager] ✓ Using human-like movement algorithms");
            script.log("[MouseManager] ========================================");
            return true;
        } else {
            activeController = new DefaultMouseController(true);
            script.log("[MouseManager] Using DefaultMouse (SmartMouse disabled in GUI)");
            return true;
        }
    }

    /**
     * Get the active mouse controller
     */
    public MouseController getController() {
        if (activeController == null) {
            initialize();
        }
        return activeController;
    }

    /**
     * Check if SmartMouse is currently active
     */
    public boolean isSmartMouseEnabled() {
        return activeController != null &&
                activeController instanceof SmartMouseController &&
                activeController.isEnabled();
    }

    public String getControllerName() {
        return activeController != null ? activeController.getControllerName() : "None";
    }
}
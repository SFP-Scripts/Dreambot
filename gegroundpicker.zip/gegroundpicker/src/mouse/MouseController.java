package gegroundpicker.mouse;

import org.dreambot.api.wrappers.interactive.Entity;
import java.awt.Point;

/**
 * Interface for mouse control implementations.
 * Follows Interface Segregation Principle - clients depend on abstractions.
 */
public interface MouseController {

    /**
     * Move mouse to entity with configured behavior
     */
    boolean moveToEntity(Entity entity);

    /**
     * Move mouse to point with configured behavior
     */
    boolean moveToPoint(Point point);

    /**
     * Click at current mouse position
     */
    boolean click();

    /**
     * Move and click on entity
     */
    boolean clickEntity(Entity entity);

    /**
     * Get controller name for logging
     */
    String getControllerName();

    /**
     * Check if controller is enabled
     */
    boolean isEnabled();
}
package gegroundpicker.mouse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import org.dreambot.api.utilities.Logger;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Data model for SmartMouse configuration.
 * Supports two formats:
 * 1. Sequential format: {"movements": [{...}]}
 * 2. Lookup table format: {"18": {"N": [...], "NE": [...]}}
 */
public class MouseData {

    private List<MouseMovement> movements;
    private transient String sourcePath;
    private transient boolean isLookupTable = false;
    private transient JsonObject lookupData;

    public MouseData() {
        this.movements = new ArrayList<>();
    }

    public List<MouseMovement> getMovements() {
        return movements;
    }

    public void setMovements(List<MouseMovement> movements) {
        this.movements = movements;
    }

    public String getSourcePath() {
        return sourcePath;
    }

    public boolean isEmpty() {
        return movements == null || movements.isEmpty();
    }

    public int size() {
        return movements != null ? movements.size() : 0;
    }

    public boolean isLookupTable() {
        return isLookupTable;
    }

    public JsonObject getLookupData() {
        return lookupData;
    }

    /**
     * Load mouse data from JSON file - supports multiple formats
     */
    public static MouseData loadFromFile(File file) {
        if (file == null || !file.exists()) {
            Logger.log("[MouseData] File not found: " + file);
            return null;
        }

        Logger.log("[MouseData] ========================================");
        Logger.log("[MouseData] ATTEMPTING TO PARSE JSON FILE");
        Logger.log("[MouseData] ========================================");
        Logger.log("[MouseData] File: " + file.getAbsolutePath());
        Logger.log("[MouseData] Size: " + file.length() + " bytes");
        Logger.log("[MouseData] Readable: " + file.canRead());
        Logger.log("[MouseData]");

        try (FileReader reader = new FileReader(file)) {
            Gson gson = new GsonBuilder()
                    .setPrettyPrinting()
                    .setLenient()
                    .create();

            Logger.log("[MouseData] Starting JSON parse...");

            // Parse as generic JsonObject first to detect format
            JsonObject root = gson.fromJson(reader, JsonObject.class);

            if (root == null) {
                Logger.log("[MouseData] ✗ GSON returned null - invalid JSON");
                return null;
            }

            // Detect format
            if (root.has("movements")) {
                // Format 1: Sequential movements
                Logger.log("[MouseData] Detected format: SEQUENTIAL MOVEMENTS");
                return parseSequentialFormat(root, file, gson);
            } else {
                // Format 2: Lookup table (distance -> direction -> points)
                Logger.log("[MouseData] Detected format: LOOKUP TABLE (distance/direction)");
                return parseLookupTableFormat(root, file);
            }

        } catch (JsonSyntaxException e) {
            Logger.log("[MouseData] ========================================");
            Logger.log("[MouseData] ✗✗✗ JSON SYNTAX ERROR");
            Logger.log("[MouseData] ========================================");
            Logger.log("[MouseData] Error: " + e.getMessage());
            e.printStackTrace();
            return null;

        } catch (IOException e) {
            Logger.log("[MouseData] ✗ IO Error reading file: " + e.getMessage());
            e.printStackTrace();
            return null;

        } catch (Exception e) {
            Logger.log("[MouseData] ✗ Unexpected error parsing JSON: " + e.getMessage());
            Logger.log("[MouseData] Error type: " + e.getClass().getName());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Parse sequential format: {"movements": [{timestamp, x, y, action}, ...]}
     */
    private static MouseData parseSequentialFormat(JsonObject root, File file, Gson gson) {
        try {
            MouseData data = gson.fromJson(root, MouseData.class);

            if (data == null || data.movements == null || data.movements.isEmpty()) {
                Logger.log("[MouseData] ✗ No movements found in sequential format");
                return null;
            }

            data.sourcePath = file.getAbsolutePath();
            data.isLookupTable = false;

            Logger.log("[MouseData] ✓✓✓ SUCCESS!");
            Logger.log("[MouseData] ✓ Parsed " + data.size() + " movements");
            Logger.log("[MouseData] ✓ Format: Sequential");
            Logger.log("[MouseData] ========================================");

            return data;

        } catch (Exception e) {
            Logger.log("[MouseData] ✗ Error parsing sequential format: " + e.getMessage());
            return null;
        }
    }

    /**
     * Parse lookup table format: {"18": {"N": [...], "NE": [...]}, "26": {...}}
     */
    private static MouseData parseLookupTableFormat(JsonObject root, File file) {
        try {
            MouseData data = new MouseData();
            data.sourcePath = file.getAbsolutePath();
            data.isLookupTable = true;
            data.lookupData = root;
            data.movements = new ArrayList<>();

            // Count total data points for logging
            int totalPoints = 0;
            int distances = 0;

            for (Map.Entry<String, JsonElement> distanceEntry : root.entrySet()) {
                distances++;
                if (distanceEntry.getValue().isJsonObject()) {
                    JsonObject directions = distanceEntry.getValue().getAsJsonObject();
                    for (Map.Entry<String, JsonElement> directionEntry : directions.entrySet()) {
                        if (directionEntry.getValue().isJsonArray()) {
                            totalPoints += directionEntry.getValue().getAsJsonArray().size();
                        }
                    }
                }
            }

            // Create a dummy movement to indicate data is loaded
            data.movements.add(new MouseMovement(System.currentTimeMillis(), 0, 0, "lookup_table"));

            Logger.log("[MouseData] ✓✓✓ SUCCESS!");
            Logger.log("[MouseData] ✓ Format: LOOKUP TABLE");
            Logger.log("[MouseData] ✓ Distance categories: " + distances);
            Logger.log("[MouseData] ✓ Total data points: " + totalPoints);
            Logger.log("[MouseData] ✓ Directions per distance: 8 (N, NE, E, SE, S, SW, W, NW)");
            Logger.log("[MouseData] ========================================");

            return data;

        } catch (Exception e) {
            Logger.log("[MouseData] ✗ Error parsing lookup table format: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Inner class representing a single mouse movement
     */
    public static class MouseMovement {
        private long timestamp;
        private int x;
        private int y;
        private String action;

        public MouseMovement() {}

        public MouseMovement(long timestamp, int x, int y, String action) {
            this.timestamp = timestamp;
            this.x = x;
            this.y = y;
            this.action = action;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }

        public int getX() {
            return x;
        }

        public void setX(int x) {
            this.x = x;
        }

        public int getY() {
            return y;
        }

        public void setY(int y) {
            this.y = y;
        }

        public String getAction() {
            return action;
        }

        public void setAction(String action) {
            this.action = action;
        }

        @Override
        public String toString() {
            return String.format("MouseMovement{timestamp=%d, x=%d, y=%d, action='%s'}",
                    timestamp, x, y, action);
        }
    }
}
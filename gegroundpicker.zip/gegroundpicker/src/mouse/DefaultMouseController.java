package gegroundpicker.mouse;

import org.dreambot.api.input.Mouse;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Entity;

import java.awt.Point;

/**
 * Default mouse controller using DreamBot's native mouse.
 * Fallback when SmartMouse is disabled.
 */
public class DefaultMouseController implements MouseController {

    private final boolean enabled;

    public DefaultMouseController(boolean enabled) {
        this.enabled = enabled;
        System.out.println("[DefaultMouse] Initialized");
    }

    @Override
    public boolean moveToEntity(Entity entity) {
        if (!isEnabled() || entity == null) {
            return false;
        }

        try {
            return entity.interact();
        } catch (Exception e) {
            System.out.println("[DefaultMouse] Error moving to entity: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean moveToPoint(Point point) {
        if (!isEnabled() || point == null) {
            return false;
        }

        try {
            Mouse.move(point);
            Sleep.sleep(100, 200);
            return true;
        } catch (Exception e) {
            System.out.println("[DefaultMouse] Error moving to point: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean click() {
        if (!isEnabled()) {
            return false;
        }

        try {
            Mouse.click();
            Sleep.sleep(50, 150);
            return true;
        } catch (Exception e) {
            System.out.println("[DefaultMouse] Error clicking: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean clickEntity(Entity entity) {
        if (!isEnabled() || entity == null) {
            return false;
        }

        try {
            return entity.interact();
        } catch (Exception e) {
            System.out.println("[DefaultMouse] Error clicking entity: " + e.getMessage());
            return false;
        }
    }

    @Override
    public String getControllerName() {
        return "DefaultMouse";
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }
}
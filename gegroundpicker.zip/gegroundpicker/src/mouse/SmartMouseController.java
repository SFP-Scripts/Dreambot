package gegroundpicker.mouse;

import org.dreambot.api.input.Mouse;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Entity;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.Random;

/**
 * SmartMouse implementation using human-like mouse movements.
 * Simplified version without JSON data loading.
 */
public class SmartMouseController implements MouseController {

    private final Random random;
    private final boolean enabled;

    public SmartMouseController(boolean enabled) {
        this.enabled = enabled;
        this.random = new Random();
        System.out.println("[SmartMouse] Initialized (simplified mode)");
    }

    @Override
    public boolean moveToEntity(Entity entity) {
        if (!isEnabled() || entity == null) {
            return false;
        }

        try {
            Rectangle bounds = entity.getBoundingBox();
            if (bounds == null) {
                return false;
            }

            Point target = new Point(
                    bounds.x + bounds.width / 2,
                    bounds.y + bounds.height / 2
            );

            return moveToPoint(target);

        } catch (Exception e) {
            System.out.println("[SmartMouse] Error moving to entity: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean moveToPoint(Point target) {
        if (!isEnabled() || target == null) {
            return false;
        }

        try {
            Point current = Mouse.getPosition();
            Point[] path = calculatePath(current, target);
            return executePath(path);
        } catch (Exception e) {
            System.out.println("[SmartMouse] Error moving to point: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean click() {
        if (!isEnabled()) {
            return false;
        }

        try {
            Mouse.click();
            Sleep.sleep(50, 150);
            return true;
        } catch (Exception e) {
            System.out.println("[SmartMouse] Error clicking: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean clickEntity(Entity entity) {
        if (!isEnabled() || entity == null) {
            return false;
        }

        try {
            // Move mouse to entity using SmartMouse
            if (moveToEntity(entity)) {
                Sleep.sleep(100, 200);

                // Use entity.interact() for proper interaction
                boolean interacted = entity.interact();

                if (interacted) {
                    System.out.println("[SmartMouse] Entity interaction successful");
                } else {
                    System.out.println("[SmartMouse] Entity interaction returned false");
                }

                return interacted;
            } else {
                System.out.println("[SmartMouse] Failed to move mouse to entity");
            }
            return false;
        } catch (Exception e) {
            System.out.println("[SmartMouse] Error clicking entity: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public String getControllerName() {
        return "SmartMouse";
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Calculate human-like path between two points
     */
    private Point[] calculatePath(Point start, Point target) {
        int deltaX = target.x - start.x;
        int deltaY = target.y - start.y;
        double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);

        int steps = Math.max(5, Math.min(20, (int)(distance / 10)));
        Point[] path = new Point[steps];

        for (int i = 0; i < steps; i++) {
            double progress = (double)(i + 1) / steps;
            double easedProgress = easeInOutCubic(progress);

            int x = start.x + (int)(deltaX * easedProgress);
            int y = start.y + (int)(deltaY * easedProgress);

            // Add slight randomness for human-like movement
            if (i > 0 && i < steps - 1) {
                x += random.nextInt(3) - 1;
                y += random.nextInt(3) - 1;
            }

            path[i] = new Point(x, y);
        }

        return path;
    }

    /**
     * Execute mouse path
     */
    private boolean executePath(Point[] path) {
        try {
            for (int i = 0; i < path.length; i++) {
                Mouse.move(path[i]);

                int delay = calculateDelay(i, path.length);
                Sleep.sleep(delay);
            }
            return true;
        } catch (Exception e) {
            System.out.println("[SmartMouse] Error executing path: " + e.getMessage());
            return false;
        }
    }

    /**
     * Calculate delay between movements
     */
    private int calculateDelay(int step, int totalSteps) {
        double progress = (double)step / totalSteps;

        if (progress < 0.2 || progress > 0.8) {
            return random.nextInt(20) + 30;
        } else {
            return random.nextInt(15) + 10;
        }
    }

    /**
     * Easing function for smooth movement
     */
    private double easeInOutCubic(double t) {
        return t < 0.5
                ? 4 * t * t * t
                : 1 - Math.pow(-2 * t + 2, 3) / 2;
    }
}
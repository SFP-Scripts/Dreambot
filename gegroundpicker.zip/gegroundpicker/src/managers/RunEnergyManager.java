package gegroundpicker.managers;

import gegroundpicker.utils.RandomHelper;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;

/**
 * Manages run energy toggling
 */
public class RunEnergyManager {

    private final boolean runEnabled;
    private long lastToggleTime;
    private static final long MIN_TOGGLE_INTERVAL = 5000; // 5 seconds

    public RunEnergyManager(boolean runEnabled) {
        this.runEnabled = runEnabled;
        this.lastToggleTime = System.currentTimeMillis();
    }

    /**
     * Manage run energy based on configuration
     */
    public void manage() {
        if (!runEnabled) {
            // Ensure run is off if disabled in config
            if (Walking.isRunEnabled()) {
                Walking.toggleRun();
                Sleep.sleep(RandomHelper.getRandomInt(100, 300));
            }
            return;
        }

        // Ensure enough time has passed since last toggle
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastToggleTime < MIN_TOGGLE_INTERVAL) {
            return;
        }

        // Enable run if we have energy and it's not enabled
        int energy = Walking.getRunEnergy();

        if (!Walking.isRunEnabled() && energy > RandomHelper.getRandomInt(10, 30)) {
            System.out.println("[RunEnergy] Enabling run (energy: " + energy + "%)");
            Walking.toggleRun();
            lastToggleTime = currentTime;
            Sleep.sleep(RandomHelper.getRandomInt(100, 300));
        }

        // Optionally disable run when energy is very low (more human-like)
        if (Walking.isRunEnabled() && energy < RandomHelper.getRandomInt(1, 5)) {
            System.out.println("[RunEnergy] Disabling run (low energy: " + energy + "%)");
            Walking.toggleRun();
            lastToggleTime = currentTime;
            Sleep.sleep(RandomHelper.getRandomInt(100, 300));
        }
    }

    public boolean isRunEnabled() {
        return runEnabled;
    }
}
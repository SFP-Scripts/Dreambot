package gegroundpicker.managers;

import gegroundpicker.gui.PickerConfig;
import org.dreambot.api.utilities.Logger;

import java.util.HashSet;
import java.util.Set;

/**
 * Enhanced manager for script configuration with advanced settings
 */
public class ConfigManager {

    private final PickerConfig config;

    public ConfigManager(PickerConfig config) {
        this.config = config;
    }

    // Picking mode
    public PickerConfig.PickingMode getPickingMode() {
        return config.getPickingMode();
    }

    public boolean isPickAllItems() {
        return config.getPickingMode() == PickerConfig.PickingMode.PICK_ALL;
    }

    public boolean isPickSpecificItems() {
        return config.getPickingMode() == PickerConfig.PickingMode.SPECIFIC_ITEMS;
    }

    public boolean isPickByValue() {
        return config.getPickingMode() == PickerConfig.PickingMode.BY_VALUE;
    }

    // Specific items
    public Set<String> getSpecificItems() {
        return config.getSpecificItems();
    }

    public boolean shouldPickItem(String itemName) {
        if (isPickAllItems()) {
            return true;
        }
        if (isPickSpecificItems()) {
            return config.getSpecificItems().stream()
                    .anyMatch(item -> itemName.toLowerCase().contains(item.toLowerCase()));
        }
        return false;
    }

    // Value settings
    public int getMinimumValue() {
        return config.getMinimumValue();
    }

    public boolean shouldPickByValue(int itemValue) {
        if (!isPickByValue()) {
            return false;
        }
        return itemValue >= config.getMinimumValue();
    }

    // Goal settings
    public boolean hasValueGoal() {
        return config.isUseValueGoal();
    }

    public int getTargetValue() {
        return config.getTargetValue();
    }

    // Break settings
    public boolean isBreaksEnabled() {
        return config.isBreaksEnabled();
    }

    public int getBreakAfterMinutes() {
        return config.getBreakAfterMinutes();
    }

    public int getBreakDurationMinutes() {
        return config.getBreakDurationMinutes();
    }

    public int getBreakVariance() {
        return config.getBreakVariance();
    }

    // Feature toggles
    public boolean isSmartMouseEnabled() {
        return config.isSmartMouseEnabled();
    }

    public boolean isRunEnabled() {
        return config.isRunEnabled();
    }

    public boolean isAntiBanEnabled() {
        return config.isAntiBanEnabled();
    }

    // Individual anti-ban toggles
    public boolean isAntiBanCameraEnabled() {
        return config.isAntiBanCameraEnabled();
    }

    public boolean isAntiBanSkillsEnabled() {
        return config.isAntiBanSkillsEnabled();
    }

    public boolean isAntiBanInventoryEnabled() {
        return config.isAntiBanInventoryEnabled();
    }

    public boolean isAntiBanMouseEnabled() {
        return config.isAntiBanMouseEnabled();
    }

    public boolean isAntiBanIdleEnabled() {
        return config.isAntiBanIdleEnabled();
    }

    // Advanced settings
    public int getAntiBanInterval() {
        return config.getAntiBanInterval();
    }

    public int getAntiBanChance() {
        return config.getAntiBanChance();
    }

    public int getMinWalkInterval() {
        return config.getMinWalkInterval();
    }

    public int getMaxWalkInterval() {
        return config.getMaxWalkInterval();
    }

    // Exclusion list
    public Set<String> getExclusionList() {
        return config.getExclusionList();
    }

    public boolean isExcluded(String itemName) {
        return config.getExclusionList().stream()
                .anyMatch(excluded -> itemName.toLowerCase().contains(excluded.toLowerCase()));
    }

    // Miss chance settings
    public int getMissChance() {
        return config.getMissChance();
    }

    public int getMissVariance() {
        return config.getMissVariance();
    }

    public int getAlwaysPickValue() {
        return config.getAlwaysPickValue();
    }

    // Return to bank settings
    public boolean isReturnToBankEnabled() {
        return config.isReturnToBankEnabled();
    }

    public int getReturnToBankTimeout() {
        return config.getReturnToBankTimeout();
    }

    // Logging
    public void logConfiguration() {
        Logger.log("Picking Mode: " + config.getPickingMode());

        if (isPickSpecificItems()) {
            Logger.log("Specific Items: " + config.getSpecificItems());
        }

        if (isPickByValue()) {
            Logger.log("Minimum Value: " + config.getMinimumValue() + " GP");
        }

        if (hasValueGoal()) {
            Logger.log("Target Value: " + config.getTargetValue() + " GP");
        }

        if (isBreaksEnabled()) {
            Logger.log("Breaks: Enabled (" + config.getBreakAfterMinutes() +
                    "min work ±" + config.getBreakVariance() + "%, " +
                    config.getBreakDurationMinutes() + "min break ±" + config.getBreakVariance() + "%)");
        }

        Logger.log("SmartMouse: " + (config.isSmartMouseEnabled() ? "Enabled" : "Disabled"));
        Logger.log("Run: " + (config.isRunEnabled() ? "Enabled" : "Disabled"));
        Logger.log("Anti-Ban: " + (config.isAntiBanEnabled() ? "Enabled" : "Disabled") +
                (config.isAntiBanEnabled() ? " (" + config.getAntiBanInterval() + "s interval, " +
                        config.getAntiBanChance() + "% chance)" : ""));
        Logger.log("Walking: " + config.getMinWalkInterval() + "-" + config.getMaxWalkInterval() + "s intervals");
        Logger.log("Exclusion List: " + config.getExclusionList());
        Logger.log("Miss Chance: " + config.getMissChance() + "% ±" + config.getMissVariance() + "%");
        Logger.log("Always Pick Value: " + config.getAlwaysPickValue() + " GP+");

        if (isReturnToBankEnabled()) {
            Logger.log("Return to Bank: Enabled (" + config.getReturnToBankTimeout() + "s timeout)");
        }
    }
}
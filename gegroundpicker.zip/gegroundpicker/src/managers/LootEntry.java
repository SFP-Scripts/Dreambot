package gegroundpicker.managers;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Represents a single loot entry with timestamp
 */
public class LootEntry {

    private final String itemName;
    private final int amount;
    private final int value;
    private final long timestamp;

    public LootEntry(String itemName, int amount, int value) {
        this.itemName = itemName;
        this.amount = amount;
        this.value = value;
        this.timestamp = System.currentTimeMillis();
    }

    public String getItemName() {
        return itemName;
    }

    public int getAmount() {
        return amount;
    }

    public int getValue() {
        return value;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getFormattedTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        return sdf.format(new Date(timestamp));
    }

    @Override
    public String toString() {
        return String.format("[%s] %s x%d - %,d GP",
                getFormattedTime(), itemName, amount, value);
    }
}
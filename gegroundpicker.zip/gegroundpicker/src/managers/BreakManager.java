package gegroundpicker.managers;

import org.dreambot.api.utilities.Logger;
import gegroundpicker.utils.RandomHelper;

/**
 * Manages AFK breaks with realistic randomization
 */
public class BreakManager {

    private final boolean breaksEnabled;
    private final long breakAfterMillis;
    private final long breakDurationMillis;
    private final double variance; // Variance as decimal (e.g., 0.20 for 20%)

    private long sessionStartTime;
    private long breakStartTime;
    private boolean onBreak;

    // Randomization for more realistic breaks
    private long nextBreakTime;

    public BreakManager(boolean breaksEnabled, int breakAfterMinutes, int breakDurationMinutes, int variancePercent) {
        this.breaksEnabled = breaksEnabled;
        this.breakAfterMillis = breakAfterMinutes * 60 * 1000L;
        this.breakDurationMillis = breakDurationMinutes * 60 * 1000L;
        this.variance = variancePercent / 100.0; // Convert percentage to decimal
        this.sessionStartTime = System.currentTimeMillis();
        this.onBreak = false;

        // Calculate first break with randomization
        calculateNextBreakTime();
    }

    /**
     * Calculate next break time with configured variance
     */
    private void calculateNextBreakTime() {
        if (!breaksEnabled) {
            nextBreakTime = Long.MAX_VALUE;
            return;
        }

        // Use configured variance
        double randomFactor = 1.0 + ((Math.random() * 2 * variance) - variance);
        long randomizedInterval = (long)(breakAfterMillis * randomFactor);

        nextBreakTime = sessionStartTime + randomizedInterval;

        Logger.log("[Break] Next break scheduled in " + (randomizedInterval / 60000) + " minutes");
    }

    /**
     * Check if we should take a break
     */
    public boolean shouldTakeBreak() {
        if (!breaksEnabled || onBreak) {
            return false;
        }

        long currentTime = System.currentTimeMillis();
        return currentTime >= nextBreakTime;
    }

    /**
     * Start a break with randomized duration using configured variance
     */
    public void startBreak() {
        onBreak = true;
        breakStartTime = System.currentTimeMillis();

        // Use configured variance for break duration
        double randomFactor = 1.0 + ((Math.random() * 2 * variance) - variance);
        long randomizedDuration = (long)(breakDurationMillis * randomFactor);

        Logger.log("[Break] Starting AFK break for " + (randomizedDuration / 60000) + " minutes");
    }

    /**
     * Check if break is over
     */
    public boolean isBreakOver() {
        if (!onBreak) {
            return true;
        }

        long currentTime = System.currentTimeMillis();

        // Use configured variance for duration check
        double randomFactor = 1.0 + ((Math.random() * 2 * variance) - variance);
        long randomizedDuration = (long)(breakDurationMillis * randomFactor);

        long elapsed = currentTime - breakStartTime;
        return elapsed >= randomizedDuration;
    }

    /**
     * End the break and reset session timer
     */
    public void endBreak() {
        onBreak = false;
        sessionStartTime = System.currentTimeMillis();

        // Calculate next break time with new randomization
        calculateNextBreakTime();

        Logger.log("[Break] Break ended - resuming script");
    }

    public boolean isOnBreak() {
        return onBreak;
    }

    public long getBreakDuration() {
        return breakDurationMillis / 60000; // Return in minutes
    }

    public long getTimeUntilBreak() {
        if (!breaksEnabled || onBreak) {
            return -1;
        }

        long currentTime = System.currentTimeMillis();
        long remaining = nextBreakTime - currentTime;

        return Math.max(0, remaining / 60000); // Return in minutes
    }

    public long getTimeRemainingOnBreak() {
        if (!onBreak) {
            return 0;
        }

        long currentTime = System.currentTimeMillis();

        // Use configured variance
        double randomFactor = 1.0 + ((Math.random() * 2 * variance) - variance);
        long randomizedDuration = (long)(breakDurationMillis * randomFactor);

        long elapsed = currentTime - breakStartTime;
        long remaining = randomizedDuration - elapsed;

        return Math.max(0, remaining / 60000); // Return in minutes
    }
}
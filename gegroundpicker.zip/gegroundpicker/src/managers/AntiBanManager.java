package gegroundpicker.managers;

import gegroundpicker.utils.RandomHelper;
import org.dreambot.api.methods.input.Camera;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Sleep;

import java.util.Random;

/**
 * Manages anti-ban behaviors to appear more human-like
 */
public class AntiBanManager {

    private final AbstractScript script;
    private final ConfigManager configManager;
    private final Random random;
    private long lastActionTime;
    private final long minActionInterval; // Configurable from GUI
    private final double actionChance; // Configurable from GUI

    public AntiBanManager(AbstractScript script, ConfigManager configManager, int intervalSeconds, int chancePercent) {
        this.script = script;
        this.configManager = configManager;
        this.random = new Random();
        this.lastActionTime = System.currentTimeMillis();
        this.minActionInterval = intervalSeconds * 1000L; // Convert to milliseconds
        this.actionChance = chancePercent / 100.0; // Convert to decimal
    }

    /**
     * Check if we should perform an anti-ban action
     */
    public boolean shouldPerformAction() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastActionTime < minActionInterval) {
            return false;
        }

        return random.nextDouble() < actionChance;
    }

    /**
     * Perform a random anti-ban action based on enabled toggles
     */
    public void performRandomAction() {
        try {
            // Build list of enabled actions
            java.util.List<Integer> enabledActions = new java.util.ArrayList<>();

            if (configManager.isAntiBanCameraEnabled()) {
                enabledActions.add(0); // Camera movement
                enabledActions.add(4); // Adjust camera
            }
            if (configManager.isAntiBanSkillsEnabled()) {
                enabledActions.add(1); // Check skills
            }
            if (configManager.isAntiBanMouseEnabled()) {
                enabledActions.add(2); // Move mouse
            }
            if (configManager.isAntiBanInventoryEnabled()) {
                enabledActions.add(3); // Check inventory
            }
            if (configManager.isAntiBanIdleEnabled()) {
                enabledActions.add(5); // Idle pause
            }

            // If no actions enabled, return
            if (enabledActions.isEmpty()) {
                return;
            }

            // Pick random enabled action
            int actionIndex = enabledActions.get(random.nextInt(enabledActions.size()));

            switch (actionIndex) {
                case 0:
                    moveCamera();
                    break;
                case 1:
                    checkSkills();
                    break;
                case 2:
                    moveMouse();
                    break;
                case 3:
                    checkInventory();
                    break;
                case 4:
                    adjustCamera();
                    break;
                case 5:
                    idlePause();
                    break;
            }

            lastActionTime = System.currentTimeMillis();

        } catch (Exception e) {
            script.log("[AntiBan] Error performing action: " + e.getMessage());
        }
    }

    /**
     * Move camera randomly
     */
    private void moveCamera() {
        script.log("[AntiBan] Moving camera");

        int currentYaw = Camera.getYaw();
        int newYaw = currentYaw + RandomHelper.getRandomInt(-45, 45);

        Camera.rotateToYaw(newYaw);
        Sleep.sleep(RandomHelper.getRandomInt(500, 1000));
    }

    /**
     * Check skills tab
     */
    private void checkSkills() {
        script.log("[AntiBan] Checking skills");

        if (Tabs.open(Tab.SKILLS)) {
            Sleep.sleep(RandomHelper.getRandomInt(800, 1500));

            // Hover over a random skill
            Skill[] skills = new Skill[]{
                    Skill.ATTACK, Skill.STRENGTH, Skill.DEFENCE,
                    Skill.HITPOINTS, Skill.RANGED, Skill.MAGIC
            };

            Skill randomSkill = skills[random.nextInt(skills.length)];
            Skills.getExperience(randomSkill); // This causes a hover effect

            Sleep.sleep(RandomHelper.getRandomInt(500, 1000));
            Tabs.open(Tab.INVENTORY);
        }
    }

    /**
     * Move mouse off-screen briefly
     */
    private void moveMouse() {
        script.log("[AntiBan] Moving mouse");
        Sleep.sleep(RandomHelper.getRandomInt(200, 500));
    }

    /**
     * Open inventory tab
     */
    private void checkInventory() {
        script.log("[AntiBan] Checking inventory");

        if (!Tabs.isOpen(Tab.INVENTORY)) {
            Tabs.open(Tab.INVENTORY);
            Sleep.sleep(RandomHelper.getRandomInt(600, 1200));
        }
    }

    /**
     * Adjust camera pitch
     */
    private void adjustCamera() {
        script.log("[AntiBan] Adjusting camera");

        int currentPitch = Camera.getPitch();
        int adjustment = random.nextBoolean() ? 10 : -10;
        int newPitch = Math.max(128, Math.min(383, currentPitch + adjustment));

        Camera.rotateToPitch(newPitch);
        Sleep.sleep(RandomHelper.getRandomInt(400, 800));
    }

    /**
     * Idle pause (do nothing)
     */
    private void idlePause() {
        script.log("[AntiBan] Idle pause");
        Sleep.sleep(RandomHelper.getRandomInt(1000, 2500));
    }

    /**
     * Get a human-like delay
     */
    public int getHumanDelay() {
        // Gaussian distribution centered around 200ms
        int base = 200;
        int variance = 100;
        int delay = (int)(random.nextGaussian() * variance + base);
        return Math.max(50, Math.min(500, delay));
    }
}
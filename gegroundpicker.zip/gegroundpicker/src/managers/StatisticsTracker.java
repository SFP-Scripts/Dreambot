package gegroundpicker.managers;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Tracks statistics for the script session including detailed loot log
 */
public class StatisticsTracker {

    private final long startTime;
    private final Map<String, Integer> itemsPickedMap;
    private final List<LootEntry> lootLog; // Detailed loot entries
    private int totalItemsPicked;
    private int totalValueCollected;
    private int bankTrips;
    private String currentStatus;

    // New tracking fields
    private String lastItemPicked;
    private int lastItemValue;
    private long lastItemPickedTime;
    private String mostProfitableItem;
    private int mostProfitableItemValue;

    public StatisticsTracker() {
        this.startTime = System.currentTimeMillis();
        this.itemsPickedMap = new HashMap<>();
        this.lootLog = Collections.synchronizedList(new ArrayList<>());
        this.totalItemsPicked = 0;
        this.totalValueCollected = 0;
        this.bankTrips = 0;
        this.currentStatus = "Initializing...";
        this.lastItemPicked = "None";
        this.lastItemValue = 0;
        this.lastItemPickedTime = 0;
        this.mostProfitableItem = "None";
        this.mostProfitableItemValue = 0;
    }

    public void addItemPicked(String itemName, int amount, int value) {
        itemsPickedMap.put(itemName, itemsPickedMap.getOrDefault(itemName, 0) + amount);
        totalItemsPicked += amount;
        totalValueCollected += value;

        // Add to loot log
        lootLog.add(new LootEntry(itemName, amount, value));

        // Update last item picked
        this.lastItemPicked = itemName + " x" + amount;
        this.lastItemValue = value;
        this.lastItemPickedTime = System.currentTimeMillis();

        // Update most profitable item if this is more valuable
        if (value > mostProfitableItemValue) {
            this.mostProfitableItem = itemName + " x" + amount;
            this.mostProfitableItemValue = value;
        }
    }

    public void incrementBankTrips() {
        bankTrips++;
    }

    public void setStatus(String status) {
        this.currentStatus = status;
    }

    public int getTotalItemsPicked() {
        return totalItemsPicked;
    }

    public int getItemsPickedCount() {
        return totalItemsPicked;
    }

    public int getTotalValueCollected() {
        return totalValueCollected;
    }

    public int getBankTrips() {
        return bankTrips;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public long getRuntime() {
        return System.currentTimeMillis() - startTime;
    }

    public String getFormattedRuntime() {
        long runtime = getRuntime();
        long hours = TimeUnit.MILLISECONDS.toHours(runtime);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(runtime) % 60;
        long seconds = TimeUnit.MILLISECONDS.toSeconds(runtime) % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    public int getValuePerHour() {
        long runtimeHours = TimeUnit.MILLISECONDS.toHours(getRuntime());
        if (runtimeHours == 0) {
            return (int)(totalValueCollected / (getRuntime() / 3600000.0));
        }
        return totalValueCollected / (int)runtimeHours;
    }

    public void logFinalStats() {
        System.out.println("Runtime: " + getFormattedRuntime());
        System.out.println("Total Items Picked: " + totalItemsPicked);
        System.out.println("Total Value Collected: " + totalValueCollected + " GP");
        System.out.println("Value/Hour: " + getValuePerHour() + " GP/hr");
        System.out.println("Bank Trips: " + bankTrips);
        System.out.println("");
        System.out.println("Items Breakdown:");
        itemsPickedMap.entrySet().stream()
                .sorted((a, b) -> Integer.compare(b.getValue(), a.getValue()))
                .forEach(entry -> System.out.println("  " + entry.getKey() + ": " + entry.getValue()));
    }

    public Map<String, Integer> getItemsPickedMap() {
        return new HashMap<>(itemsPickedMap);
    }

    // New getters for last item and most profitable item
    public String getLastItemPicked() {
        return lastItemPicked;
    }

    public int getLastItemValue() {
        return lastItemValue;
    }

    public long getTimeSinceLastPick() {
        if (lastItemPickedTime == 0) {
            return 0;
        }
        return System.currentTimeMillis() - lastItemPickedTime;
    }

    public String getMostProfitableItem() {
        return mostProfitableItem;
    }

    public int getMostProfitableItemValue() {
        return mostProfitableItemValue;
    }

    // Loot log methods
    public List<LootEntry> getLootLog() {
        return new ArrayList<>(lootLog);
    }

    public int getLootLogSize() {
        return lootLog.size();
    }

    public void clearLootLog() {
        lootLog.clear();
    }
}
package gegroundpicker.gui;

import java.util.HashSet;
import java.util.Set;

/**
 * Enhanced configuration data class for picker settings with advanced options
 */
public class PickerConfig {

    // Picking settings
    private PickingMode pickingMode;
    private Set<String> specificItems;
    private int minimumValue;

    // Goal settings
    private boolean useValueGoal;
    private int targetValue;

    // Break settings
    private boolean breaksEnabled;
    private int breakAfterMinutes;
    private int breakDurationMinutes;
    private int breakVariance;

    // Feature toggles
    private boolean smartMouseEnabled;
    private boolean runEnabled;
    private boolean antiBanEnabled;

    // Individual anti-ban toggles
    private boolean antiBanCameraEnabled;
    private boolean antiBanSkillsEnabled;
    private boolean antiBanInventoryEnabled;
    private boolean antiBanMouseEnabled;
    private boolean antiBanIdleEnabled;

    // Advanced settings
    private int antiBanInterval; // seconds
    private int antiBanChance; // percentage
    private int minWalkInterval; // seconds
    private int maxWalkInterval; // seconds

    // Exclusion and miss chance settings
    private Set<String> exclusionList; // Items to always drop/ignore
    private int missChance; // Percentage chance to miss an item
    private int missVariance; // Variance in miss chance
    private int alwaysPickValue; // Always pick items worth this much GP or more

    // Return to bank settings
    private boolean returnToBankEnabled; // Return to bank area if no items found
    private int returnToBankTimeout; // Seconds without finding items before returning

    public PickerConfig() {
        this.specificItems = new HashSet<>();
        this.pickingMode = PickingMode.PICK_ALL;
        this.minimumValue = 1000;
        this.useValueGoal = false;
        this.targetValue = 100000;
        this.breaksEnabled = true;
        this.breakAfterMinutes = 45;
        this.breakDurationMinutes = 5;
        this.breakVariance = 20; // 20% default variance
        this.smartMouseEnabled = true;
        this.runEnabled = true;
        this.antiBanEnabled = true;
        this.antiBanCameraEnabled = true;
        this.antiBanSkillsEnabled = true;
        this.antiBanInventoryEnabled = true;
        this.antiBanMouseEnabled = true;
        this.antiBanIdleEnabled = true;
        this.antiBanInterval = 30; // 30 seconds default
        this.antiBanChance = 15; // 15% default
        this.minWalkInterval = 8; // 8 seconds default - walk more frequently
        this.maxWalkInterval = 20; // 20 seconds default - walk more frequently
        this.exclusionList = new HashSet<>();
        this.missChance = 5; // 5% default miss chance
        this.missVariance = 3; // ±3% variance
        this.alwaysPickValue = 10000; // Always pick items worth 10k+ GP
        this.returnToBankEnabled = true; // Enable return to bank by default
        this.returnToBankTimeout = 60; // 60 seconds default
    }

    public enum PickingMode {
        PICK_ALL("Pick All Items"),
        SPECIFIC_ITEMS("Specific Items"),
        BY_VALUE("By Minimum Value");

        private final String displayName;

        PickingMode(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }

    // Getters and setters
    public PickingMode getPickingMode() {
        return pickingMode;
    }

    public void setPickingMode(PickingMode pickingMode) {
        this.pickingMode = pickingMode;
    }

    public Set<String> getSpecificItems() {
        return specificItems;
    }

    public void setSpecificItems(Set<String> specificItems) {
        this.specificItems = specificItems;
    }

    public int getMinimumValue() {
        return minimumValue;
    }

    public void setMinimumValue(int minimumValue) {
        this.minimumValue = minimumValue;
    }

    public boolean isUseValueGoal() {
        return useValueGoal;
    }

    public void setUseValueGoal(boolean useValueGoal) {
        this.useValueGoal = useValueGoal;
    }

    public int getTargetValue() {
        return targetValue;
    }

    public void setTargetValue(int targetValue) {
        this.targetValue = targetValue;
    }

    public boolean isBreaksEnabled() {
        return breaksEnabled;
    }

    public void setBreaksEnabled(boolean breaksEnabled) {
        this.breaksEnabled = breaksEnabled;
    }

    public int getBreakAfterMinutes() {
        return breakAfterMinutes;
    }

    public void setBreakAfterMinutes(int breakAfterMinutes) {
        this.breakAfterMinutes = breakAfterMinutes;
    }

    public int getBreakDurationMinutes() {
        return breakDurationMinutes;
    }

    public void setBreakDurationMinutes(int breakDurationMinutes) {
        this.breakDurationMinutes = breakDurationMinutes;
    }

    public int getBreakVariance() {
        return breakVariance;
    }

    public void setBreakVariance(int breakVariance) {
        this.breakVariance = breakVariance;
    }

    public boolean isSmartMouseEnabled() {
        return smartMouseEnabled;
    }

    public void setSmartMouseEnabled(boolean smartMouseEnabled) {
        this.smartMouseEnabled = smartMouseEnabled;
    }

    public boolean isRunEnabled() {
        return runEnabled;
    }

    public void setRunEnabled(boolean runEnabled) {
        this.runEnabled = runEnabled;
    }

    public boolean isAntiBanEnabled() {
        return antiBanEnabled;
    }

    public void setAntiBanEnabled(boolean antiBanEnabled) {
        this.antiBanEnabled = antiBanEnabled;
    }

    // Individual anti-ban toggle getters and setters
    public boolean isAntiBanCameraEnabled() {
        return antiBanCameraEnabled;
    }

    public void setAntiBanCameraEnabled(boolean antiBanCameraEnabled) {
        this.antiBanCameraEnabled = antiBanCameraEnabled;
    }

    public boolean isAntiBanSkillsEnabled() {
        return antiBanSkillsEnabled;
    }

    public void setAntiBanSkillsEnabled(boolean antiBanSkillsEnabled) {
        this.antiBanSkillsEnabled = antiBanSkillsEnabled;
    }

    public boolean isAntiBanInventoryEnabled() {
        return antiBanInventoryEnabled;
    }

    public void setAntiBanInventoryEnabled(boolean antiBanInventoryEnabled) {
        this.antiBanInventoryEnabled = antiBanInventoryEnabled;
    }

    public boolean isAntiBanMouseEnabled() {
        return antiBanMouseEnabled;
    }

    public void setAntiBanMouseEnabled(boolean antiBanMouseEnabled) {
        this.antiBanMouseEnabled = antiBanMouseEnabled;
    }

    public boolean isAntiBanIdleEnabled() {
        return antiBanIdleEnabled;
    }

    public void setAntiBanIdleEnabled(boolean antiBanIdleEnabled) {
        this.antiBanIdleEnabled = antiBanIdleEnabled;
    }

    public int getAntiBanInterval() {
        return antiBanInterval;
    }

    public void setAntiBanInterval(int antiBanInterval) {
        this.antiBanInterval = antiBanInterval;
    }

    public int getAntiBanChance() {
        return antiBanChance;
    }

    public void setAntiBanChance(int antiBanChance) {
        this.antiBanChance = antiBanChance;
    }

    public int getMinWalkInterval() {
        return minWalkInterval;
    }

    public void setMinWalkInterval(int minWalkInterval) {
        this.minWalkInterval = minWalkInterval;
    }

    public int getMaxWalkInterval() {
        return maxWalkInterval;
    }

    public void setMaxWalkInterval(int maxWalkInterval) {
        this.maxWalkInterval = maxWalkInterval;
    }

    // Exclusion list getters and setters
    public Set<String> getExclusionList() {
        return exclusionList;
    }

    public void setExclusionList(Set<String> exclusionList) {
        this.exclusionList = exclusionList;
    }

    // Miss chance getters and setters
    public int getMissChance() {
        return missChance;
    }

    public void setMissChance(int missChance) {
        this.missChance = missChance;
    }

    public int getMissVariance() {
        return missVariance;
    }

    public void setMissVariance(int missVariance) {
        this.missVariance = missVariance;
    }

    public int getAlwaysPickValue() {
        return alwaysPickValue;
    }

    public void setAlwaysPickValue(int alwaysPickValue) {
        this.alwaysPickValue = alwaysPickValue;
    }

    // Return to bank getters and setters
    public boolean isReturnToBankEnabled() {
        return returnToBankEnabled;
    }

    public void setReturnToBankEnabled(boolean returnToBankEnabled) {
        this.returnToBankEnabled = returnToBankEnabled;
    }

    public int getReturnToBankTimeout() {
        return returnToBankTimeout;
    }

    public void setReturnToBankTimeout(int returnToBankTimeout) {
        this.returnToBankTimeout = returnToBankTimeout;
    }
}
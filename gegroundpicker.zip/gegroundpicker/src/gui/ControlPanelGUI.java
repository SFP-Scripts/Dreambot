package gegroundpicker.gui;

import gegroundpicker.GEGroundItemPicker;

import javax.swing.*;
import java.awt.*;

/**
 * Simple control panel for the GE Ground Item Picker
 * Provides easy access to loot log and other features
 */
public class ControlPanelGUI extends JFrame {

    private final GEGroundItemPicker script;

    public ControlPanelGUI(GEGroundItemPicker script) {
        this.script = script;
        initializeGUI();
    }

    private void initializeGUI() {
        setTitle("GE Picker - Control Panel");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        setAlwaysOnTop(true);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Title
        JLabel titleLabel = new JLabel("Script Controls");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);

        mainPanel.add(Box.createVerticalStrut(15));

        // Loot Log Button
        JButton lootLogButton = new JButton("View Loot Log");
        lootLogButton.setFont(new Font("Arial", Font.BOLD, 12));
        lootLogButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        lootLogButton.setPreferredSize(new Dimension(150, 35));
        lootLogButton.setMaximumSize(new Dimension(150, 35));
        lootLogButton.addActionListener(e -> {
            script.openLootLog();
        });
        mainPanel.add(lootLogButton);

        mainPanel.add(Box.createVerticalStrut(10));

        // Hide Button
        JButton hideButton = new JButton("Hide Panel");
        hideButton.setFont(new Font("Arial", Font.PLAIN, 11));
        hideButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        hideButton.setPreferredSize(new Dimension(150, 30));
        hideButton.setMaximumSize(new Dimension(150, 30));
        hideButton.addActionListener(e -> {
            setVisible(false);
        });
        mainPanel.add(hideButton);

        mainPanel.add(Box.createVerticalStrut(10));

        // Info label
        JLabel infoLabel = new JLabel("<html><center>You can reopen this<br>panel from the Script menu</center></html>");
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 9));
        infoLabel.setForeground(Color.GRAY);
        infoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(infoLabel);

        add(mainPanel);
        pack();
        setLocationRelativeTo(null);
    }

    /**
     * Show the control panel
     */
    public void showPanel() {
        setVisible(true);
        toFront();
        requestFocus();
    }
}
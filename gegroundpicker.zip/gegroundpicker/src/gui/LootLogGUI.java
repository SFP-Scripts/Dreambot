package gegroundpicker.gui;

import gegroundpicker.managers.LootEntry;
import gegroundpicker.managers.StatisticsTracker;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

/**
 * GUI window displaying detailed loot log
 * Shows all items picked with timestamp and value
 */
public class LootLogGUI extends JFrame {

    private final StatisticsTracker statisticsTracker;
    private final DefaultTableModel tableModel;
    private final JTable lootTable;
    private final JLabel totalItemsLabel;
    private final JLabel totalValueLabel;
    private final JLabel avgValueLabel;
    private final Timer refreshTimer;

    private static final String[] COLUMN_NAMES = {"Time", "Item", "Amount", "Value (GP)"};

    public LootLogGUI(StatisticsTracker statisticsTracker) {
        this.statisticsTracker = statisticsTracker;

        setTitle("GE Ground Picker - Loot Log");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Header panel
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);

        // Table
        tableModel = new DefaultTableModel(COLUMN_NAMES, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        lootTable = new JTable(tableModel);
        setupTable();

        JScrollPane scrollPane = new JScrollPane(lootTable);
        scrollPane.setPreferredSize(new Dimension(600, 400));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Footer with statistics
        JPanel footerPanel = new JPanel(new GridLayout(1, 3, 10, 0));
        footerPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        totalItemsLabel = new JLabel("Total Items: 0", SwingConstants.CENTER);
        totalItemsLabel.setFont(new Font("Arial", Font.BOLD, 12));

        totalValueLabel = new JLabel("Total Value: 0 GP", SwingConstants.CENTER);
        totalValueLabel.setFont(new Font("Arial", Font.BOLD, 12));
        totalValueLabel.setForeground(new Color(50, 150, 50));

        avgValueLabel = new JLabel("Avg Value: 0 GP", SwingConstants.CENTER);
        avgValueLabel.setFont(new Font("Arial", Font.BOLD, 12));
        avgValueLabel.setForeground(new Color(50, 100, 200));

        footerPanel.add(totalItemsLabel);
        footerPanel.add(totalValueLabel);
        footerPanel.add(avgValueLabel);

        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        add(mainPanel);

        // Buttons panel
        add(createButtonsPanel(), BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);

        // Auto-refresh timer
        refreshTimer = new Timer(1000, e -> updateTable());
        refreshTimer.start();

        // Initial load
        updateTable();
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Loot Log - All Items Picked");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel subtitleLabel = new JLabel("Showing all items in chronological order");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        subtitleLabel.setForeground(Color.GRAY);
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(subtitleLabel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createButtonsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> updateTable());

        JButton clearButton = new JButton("Clear Log");
        clearButton.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to clear the loot log?\nThis cannot be undone.",
                    "Clear Loot Log",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);

            if (choice == JOptionPane.YES_OPTION) {
                statisticsTracker.clearLootLog();
                updateTable();
            }
        });

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());

        panel.add(refreshButton);
        panel.add(clearButton);
        panel.add(closeButton);

        return panel;
    }

    private void setupTable() {
        // Column widths
        lootTable.getColumnModel().getColumn(0).setPreferredWidth(80);  // Time
        lootTable.getColumnModel().getColumn(1).setPreferredWidth(250); // Item
        lootTable.getColumnModel().getColumn(2).setPreferredWidth(80);  // Amount
        lootTable.getColumnModel().getColumn(3).setPreferredWidth(120); // Value

        // Center align amount and value columns
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        lootTable.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);

        // Right align value column
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        lootTable.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);

        // Alternating row colors
        lootTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(245, 245, 245));
                    c.setForeground(Color.BLACK); // Set text to black for readability
                } else {
                    c.setForeground(Color.WHITE); // White text when selected
                }

                // Align based on column
                if (column == 2) {
                    setHorizontalAlignment(SwingConstants.CENTER);
                } else if (column == 3) {
                    setHorizontalAlignment(SwingConstants.RIGHT);
                } else {
                    setHorizontalAlignment(SwingConstants.LEFT);
                }

                return c;
            }
        });

        // Auto-resize
        lootTable.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        lootTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private void updateTable() {
        List<LootEntry> lootLog = statisticsTracker.getLootLog();

        // Clear existing rows
        tableModel.setRowCount(0);

        // Add all entries (most recent first)
        NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);

        for (int i = lootLog.size() - 1; i >= 0; i--) {
            LootEntry entry = lootLog.get(i);
            tableModel.addRow(new Object[]{
                    entry.getFormattedTime(),
                    entry.getItemName(),
                    entry.getAmount(),
                    numberFormat.format(entry.getValue())
            });
        }

        // Update footer statistics
        totalItemsLabel.setText("Total Items: " + numberFormat.format(lootLog.size()));
        totalValueLabel.setText("Total Value: " + numberFormat.format(statisticsTracker.getTotalValueCollected()) + " GP");

        if (lootLog.size() > 0) {
            int avgValue = statisticsTracker.getTotalValueCollected() / lootLog.size();
            avgValueLabel.setText("Avg Value: " + numberFormat.format(avgValue) + " GP");
        } else {
            avgValueLabel.setText("Avg Value: 0 GP");
        }
    }

    @Override
    public void dispose() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
        super.dispose();
    }
}
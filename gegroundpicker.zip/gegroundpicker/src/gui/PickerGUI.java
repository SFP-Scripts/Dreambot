package gegroundpicker.gui;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.io.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Properties;
import java.util.function.Consumer;

/**
 * Enhanced tabbed GUI for GE Ground Item Picker with profile save/load
 */
public class PickerGUI extends JFrame {

    private Consumer<PickerConfig> onStartCallback;
    private PickerConfig config;

    // Basic Components
    private JComboBox<PickerConfig.PickingMode> pickingModeCombo;
    private JTextArea specificItemsArea;
    private JTextArea exclusionListArea;
    private JSpinner minValueSpinner;
    private JCheckBox useValueGoalCheck;
    private JSpinner targetValueSpinner;

    // Break Settings
    private JCheckBox breaksEnabledCheck;
    private JSpinner breakAfterSpinner;
    private JSpinner breakDurationSpinner;
    private JSpinner breakVarianceSpinner;

    // Feature Toggles
    private JCheckBox smartMouseCheck;
    private JCheckBox runEnabledCheck;

    // Anti-ban toggles
    private JCheckBox antiBanEnabledCheck;
    private JCheckBox antiBanCameraCheck;
    private JCheckBox antiBanSkillsCheck;
    private JCheckBox antiBanInventoryCheck;
    private JCheckBox antiBanMouseCheck;
    private JCheckBox antiBanIdleCheck;
    private JSpinner antiBanIntervalSpinner;
    private JSpinner antiBanChanceSpinner;

    // SmartMouse Settings
    private JCheckBox smartMouseEnabledCheck;
    private JLabel smartMouseStatusLabel;

    // Advanced Settings
    private JSpinner minWalkIntervalSpinner;
    private JSpinner maxWalkIntervalSpinner;
    private JSpinner missChanceSpinner;
    private JSpinner missVarianceSpinner;
    private JSpinner alwaysPickValueSpinner;
    private JCheckBox returnToBankCheck;
    private JSpinner returnToBankTimeoutSpinner;

    public PickerGUI() {
        config = new PickerConfig();
        initializeGUI();
    }

    private void initializeGUI() {
        setTitle("GE Ground Item Picker - Configuration");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        setResizable(false);

        // Main container
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Header with profile buttons
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);

        // Tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setPreferredSize(new Dimension(700, 450));

        tabbedPane.addTab("Picking", createPickingTab());
        tabbedPane.addTab("Anti-Ban", createAntiBanTab());
        tabbedPane.addTab("SmartMouse", createSmartMouseTab());
        tabbedPane.addTab("Breaks", createBreaksTab());
        tabbedPane.addTab("Advanced", createAdvancedTab());

        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        // Start button at bottom
        mainPanel.add(createStartButtonPanel(), BorderLayout.SOUTH);

        add(mainPanel);
        pack();
        setLocationRelativeTo(null);
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        // Title
        JLabel titleLabel = new JLabel("GE Ground Item Picker v1.0");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(titleLabel, BorderLayout.CENTER);

        // Profile buttons
        JPanel profilePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save Profile");
        JButton loadButton = new JButton("Load Profile");

        saveButton.addActionListener(e -> saveProfile());
        loadButton.addActionListener(e -> loadProfile());

        profilePanel.add(loadButton);
        profilePanel.add(saveButton);
        panel.add(profilePanel, BorderLayout.EAST);

        return panel;
    }

    private JPanel createPickingTab() {
        JPanel tab = new JPanel();
        tab.setLayout(new BoxLayout(tab, BoxLayout.Y_AXIS));
        tab.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Picking Mode Section
        JPanel pickingPanel = createTitledPanel("Picking Mode");

        JPanel modePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        modePanel.add(new JLabel("Mode:"));
        pickingModeCombo = new JComboBox<>(PickerConfig.PickingMode.values());
        pickingModeCombo.addActionListener(e -> updatePickingModeVisibility());
        modePanel.add(pickingModeCombo);
        pickingPanel.add(modePanel);

        // Specific items
        JPanel specificPanel = new JPanel(new BorderLayout(5, 5));
        specificPanel.add(new JLabel("Specific Items (one per line):"), BorderLayout.NORTH);
        specificItemsArea = new JTextArea(4, 30);
        specificItemsArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JScrollPane specificScroll = new JScrollPane(specificItemsArea);
        specificPanel.add(specificScroll, BorderLayout.CENTER);
        pickingPanel.add(specificPanel);

        // Exclusion list
        JPanel exclusionPanel = new JPanel(new BorderLayout(5, 5));
        exclusionPanel.add(new JLabel("Exclusion List (one per line):"), BorderLayout.NORTH);
        exclusionListArea = new JTextArea(4, 30);
        exclusionListArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JScrollPane exclusionScroll = new JScrollPane(exclusionListArea);
        exclusionPanel.add(exclusionScroll, BorderLayout.CENTER);
        pickingPanel.add(exclusionPanel);

        // Min value
        JPanel minValuePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        minValuePanel.add(new JLabel("Minimum Value (GP):"));
        minValueSpinner = new JSpinner(new SpinnerNumberModel(1000, 1, 1000000, 100));
        minValueSpinner.setPreferredSize(new Dimension(100, 25));
        minValuePanel.add(minValueSpinner);
        pickingPanel.add(minValuePanel);

        tab.add(pickingPanel);
        tab.add(Box.createVerticalStrut(10));

        // Value Goal Section
        JPanel goalPanel = createTitledPanel("Value Goal");

        useValueGoalCheck = new JCheckBox("Enable value goal", false);
        goalPanel.add(useValueGoalCheck);

        JPanel targetPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        targetPanel.add(new JLabel("Target Value (GP):"));
        targetValueSpinner = new JSpinner(new SpinnerNumberModel(100000, 1000, 10000000, 10000));
        targetValueSpinner.setPreferredSize(new Dimension(120, 25));
        targetPanel.add(targetValueSpinner);
        goalPanel.add(targetPanel);

        tab.add(goalPanel);
        tab.add(Box.createVerticalGlue());

        return tab;
    }

    private JPanel createAntiBanTab() {
        JPanel tab = new JPanel();
        tab.setLayout(new BoxLayout(tab, BoxLayout.Y_AXIS));
        tab.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Master toggle
        JPanel masterPanel = createTitledPanel("Anti-Ban System");
        antiBanEnabledCheck = new JCheckBox("Enable Anti-Ban Actions", true);
        antiBanEnabledCheck.setFont(new Font("Arial", Font.BOLD, 13));
        antiBanEnabledCheck.addActionListener(e -> updateAntiBanToggles());
        masterPanel.add(antiBanEnabledCheck);
        tab.add(masterPanel);
        tab.add(Box.createVerticalStrut(10));

        // Individual toggles
        JPanel togglesPanel = createTitledPanel("Individual Anti-Ban Actions");

        antiBanCameraCheck = new JCheckBox("Camera Movement", true);
        antiBanSkillsCheck = new JCheckBox("Check Skills Tab", true);
        antiBanInventoryCheck = new JCheckBox("Check Inventory", true);
        antiBanMouseCheck = new JCheckBox("Random Mouse Movement", true);
        antiBanIdleCheck = new JCheckBox("Idle Pauses", true);

        togglesPanel.add(antiBanCameraCheck);
        togglesPanel.add(antiBanSkillsCheck);
        togglesPanel.add(antiBanInventoryCheck);
        togglesPanel.add(antiBanMouseCheck);
        togglesPanel.add(antiBanIdleCheck);

        tab.add(togglesPanel);
        tab.add(Box.createVerticalStrut(10));

        // Settings
        JPanel settingsPanel = createTitledPanel("Anti-Ban Settings");

        JPanel intervalPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        intervalPanel.add(new JLabel("Minimum Interval (seconds):"));
        antiBanIntervalSpinner = new JSpinner(new SpinnerNumberModel(30, 10, 300, 10));
        antiBanIntervalSpinner.setPreferredSize(new Dimension(80, 25));
        intervalPanel.add(antiBanIntervalSpinner);
        settingsPanel.add(intervalPanel);

        JPanel chancePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        chancePanel.add(new JLabel("Action Chance (%):"));
        antiBanChanceSpinner = new JSpinner(new SpinnerNumberModel(15, 1, 100, 5));
        antiBanChanceSpinner.setPreferredSize(new Dimension(80, 25));
        chancePanel.add(antiBanChanceSpinner);
        settingsPanel.add(chancePanel);

        tab.add(settingsPanel);
        tab.add(Box.createVerticalGlue());

        return tab;
    }

    private JPanel createSmartMouseTab() {
        JPanel tab = new JPanel();
        tab.setLayout(new BoxLayout(tab, BoxLayout.Y_AXIS));
        tab.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // SmartMouse info
        JPanel infoPanel = createTitledPanel("SmartMouse Information");

        JTextArea infoText = new JTextArea(
                "SmartMouse provides human-like mouse movements using:\n\n" +
                        "• Realistic bezier curve paths\n" +
                        "• Variable movement speed\n" +
                        "• Natural acceleration/deceleration\n" +
                        "• Randomized endpoints\n\n" +
                        "This makes mouse movements appear more natural and reduces\n" +
                        "the likelihood of detection."
        );
        infoText.setEditable(false);
        infoText.setBackground(tab.getBackground());
        infoText.setFont(new Font("Arial", Font.PLAIN, 12));
        infoPanel.add(infoText);

        tab.add(infoPanel);
        tab.add(Box.createVerticalStrut(20));

        // SmartMouse toggle
        JPanel togglePanel = createTitledPanel("SmartMouse Settings");

        smartMouseEnabledCheck = new JCheckBox("Enable SmartMouse", true);
        smartMouseEnabledCheck.setFont(new Font("Arial", Font.BOLD, 14));
        smartMouseEnabledCheck.addActionListener(e -> updateSmartMouseStatus());
        togglePanel.add(smartMouseEnabledCheck);

        togglePanel.add(Box.createVerticalStrut(10));

        smartMouseStatusLabel = new JLabel();
        smartMouseStatusLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        updateSmartMouseStatus();
        togglePanel.add(smartMouseStatusLabel);

        tab.add(togglePanel);
        tab.add(Box.createVerticalStrut(20));

        // Run energy toggle
        JPanel runPanel = createTitledPanel("Movement Settings");
        runEnabledCheck = new JCheckBox("Enable Run", true);
        runEnabledCheck.setFont(new Font("Arial", Font.BOLD, 13));
        runPanel.add(runEnabledCheck);

        tab.add(runPanel);
        tab.add(Box.createVerticalGlue());

        return tab;
    }

    private JPanel createBreaksTab() {
        JPanel tab = new JPanel();
        tab.setLayout(new BoxLayout(tab, BoxLayout.Y_AXIS));
        tab.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel breaksPanel = createTitledPanel("Break Settings");

        breaksEnabledCheck = new JCheckBox("Enable AFK Breaks", true);
        breaksEnabledCheck.setFont(new Font("Arial", Font.BOLD, 13));
        breaksPanel.add(breaksEnabledCheck);

        breaksPanel.add(Box.createVerticalStrut(10));

        JPanel afterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        afterPanel.add(new JLabel("Work Duration (minutes):"));
        breakAfterSpinner = new JSpinner(new SpinnerNumberModel(45, 5, 240, 5));
        breakAfterSpinner.setPreferredSize(new Dimension(80, 25));
        afterPanel.add(breakAfterSpinner);
        breaksPanel.add(afterPanel);

        JPanel durationPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        durationPanel.add(new JLabel("Break Duration (minutes):"));
        breakDurationSpinner = new JSpinner(new SpinnerNumberModel(5, 1, 60, 1));
        breakDurationSpinner.setPreferredSize(new Dimension(80, 25));
        durationPanel.add(breakDurationSpinner);
        breaksPanel.add(durationPanel);

        JPanel variancePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        variancePanel.add(new JLabel("Time Variance (±%):"));
        breakVarianceSpinner = new JSpinner(new SpinnerNumberModel(20, 0, 50, 5));
        breakVarianceSpinner.setPreferredSize(new Dimension(80, 25));
        variancePanel.add(breakVarianceSpinner);
        JLabel varianceHelp = new JLabel("(randomizes break timing)");
        varianceHelp.setFont(new Font("Arial", Font.ITALIC, 10));
        varianceHelp.setForeground(Color.GRAY);
        variancePanel.add(varianceHelp);
        breaksPanel.add(variancePanel);

        tab.add(breaksPanel);
        tab.add(Box.createVerticalGlue());

        return tab;
    }

    private JPanel createAdvancedTab() {
        JPanel tab = new JPanel();
        tab.setLayout(new BoxLayout(tab, BoxLayout.Y_AXIS));
        tab.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Walking intervals
        JPanel walkPanel = createTitledPanel("Walking Behavior");

        JPanel minWalkPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        minWalkPanel.add(new JLabel("Min Walk Interval (sec):"));
        minWalkIntervalSpinner = new JSpinner(new SpinnerNumberModel(8, 5, 120, 1));
        minWalkIntervalSpinner.setPreferredSize(new Dimension(80, 25));
        minWalkPanel.add(minWalkIntervalSpinner);
        walkPanel.add(minWalkPanel);

        JPanel maxWalkPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        maxWalkPanel.add(new JLabel("Max Walk Interval (sec):"));
        maxWalkIntervalSpinner = new JSpinner(new SpinnerNumberModel(20, 10, 180, 1));
        maxWalkIntervalSpinner.setPreferredSize(new Dimension(80, 25));
        maxWalkPanel.add(maxWalkIntervalSpinner);
        walkPanel.add(maxWalkPanel);

        tab.add(walkPanel);
        tab.add(Box.createVerticalStrut(10));

        // Return to bank
        JPanel returnPanel = createTitledPanel("Return to Bank");

        returnToBankCheck = new JCheckBox("Return to bank area when no items found", true);
        returnPanel.add(returnToBankCheck);

        JPanel timeoutPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        timeoutPanel.add(new JLabel("Timeout (seconds):"));
        returnToBankTimeoutSpinner = new JSpinner(new SpinnerNumberModel(60, 10, 300, 10));
        returnToBankTimeoutSpinner.setPreferredSize(new Dimension(80, 25));
        timeoutPanel.add(returnToBankTimeoutSpinner);
        returnPanel.add(timeoutPanel);

        tab.add(returnPanel);
        tab.add(Box.createVerticalStrut(10));

        // Miss chance
        JPanel missPanel = createTitledPanel("Human-like Imperfection");

        JPanel missChancePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        missChancePanel.add(new JLabel("Miss Item Chance (%):"));
        missChanceSpinner = new JSpinner(new SpinnerNumberModel(5, 0, 50, 1));
        missChanceSpinner.setPreferredSize(new Dimension(80, 25));
        missChancePanel.add(missChanceSpinner);
        missPanel.add(missChancePanel);

        JPanel missVariancePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        missVariancePanel.add(new JLabel("Miss Variance (±%):"));
        missVarianceSpinner = new JSpinner(new SpinnerNumberModel(3, 0, 20, 1));
        missVarianceSpinner.setPreferredSize(new Dimension(80, 25));
        missVariancePanel.add(missVarianceSpinner);
        missPanel.add(missVariancePanel);

        JPanel alwaysPickPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        alwaysPickPanel.add(new JLabel("Always Pick Value (GP):"));
        alwaysPickValueSpinner = new JSpinner(new SpinnerNumberModel(10000, 0, 1000000, 1000));
        alwaysPickValueSpinner.setPreferredSize(new Dimension(100, 25));
        alwaysPickPanel.add(alwaysPickValueSpinner);
        missPanel.add(alwaysPickPanel);

        tab.add(missPanel);
        tab.add(Box.createVerticalGlue());

        return tab;
    }

    private JPanel createStartButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton startButton = new JButton("Start Script");
        startButton.setFont(new Font("Arial", Font.BOLD, 16));
        startButton.setPreferredSize(new Dimension(200, 40));
        startButton.setBackground(new Color(34, 139, 34));
        startButton.setForeground(Color.WHITE);
        startButton.setFocusPainted(false);
        startButton.addActionListener(e -> onStartClicked());
        panel.add(startButton);
        return panel;
    }

    private JPanel createTitledPanel(String title) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                title,
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 12)
        ));
        return panel;
    }

    private void updatePickingModeVisibility() {
        // Update visibility based on picking mode if needed
    }

    private void updateAntiBanToggles() {
        boolean enabled = antiBanEnabledCheck.isSelected();
        antiBanCameraCheck.setEnabled(enabled);
        antiBanSkillsCheck.setEnabled(enabled);
        antiBanInventoryCheck.setEnabled(enabled);
        antiBanMouseCheck.setEnabled(enabled);
        antiBanIdleCheck.setEnabled(enabled);
        antiBanIntervalSpinner.setEnabled(enabled);
        antiBanChanceSpinner.setEnabled(enabled);
    }

    private void updateSmartMouseStatus() {
        if (smartMouseEnabledCheck.isSelected()) {
            smartMouseStatusLabel.setText("✓ SmartMouse is ENABLED - Human-like movements active");
            smartMouseStatusLabel.setForeground(new Color(34, 139, 34));
        } else {
            smartMouseStatusLabel.setText("✗ SmartMouse is DISABLED - Using default mouse");
            smartMouseStatusLabel.setForeground(Color.RED);
        }
    }

    private void saveProfile() {
        // Get profile name from user
        String profileName = JOptionPane.showInputDialog(this,
                "Enter profile name:",
                "Save Profile",
                JOptionPane.PLAIN_MESSAGE);

        if (profileName == null || profileName.trim().isEmpty()) {
            return; // User cancelled
        }

        // Clean the profile name
        profileName = profileName.trim().replaceAll("[^a-zA-Z0-9_-]", "_");

        // Get DreamBot scripts folder
        String userHome = System.getProperty("user.home");
        File scriptsFolder = new File(userHome, "dreambot/scripts");

        // Create profiles subfolder if it doesn't exist
        File profilesFolder = new File(scriptsFolder, "GEPICK");
        if (!profilesFolder.exists()) {
            profilesFolder.mkdirs();
        }

        // Create profile file
        File profileFile = new File(profilesFolder, profileName + ".properties");

        try {
            saveConfigToFile(profileFile);
            JOptionPane.showMessageDialog(this,
                    "Profile saved successfully!\n\nLocation: " + profileFile.getAbsolutePath(),
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Error saving profile: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadProfile() {
        // Get DreamBot scripts folder
        String userHome = System.getProperty("user.home");
        File scriptsFolder = new File(userHome, "dreambot/scripts");
        File profilesFolder = new File(scriptsFolder, "GEPICK");

        // Check if profiles folder exists
        if (!profilesFolder.exists() || !profilesFolder.isDirectory()) {
            JOptionPane.showMessageDialog(this,
                    "No profiles folder found!\n\nProfiles are saved to:\n" + profilesFolder.getAbsolutePath(),
                    "No Profiles",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Get list of profile files
        File[] profileFiles = profilesFolder.listFiles((dir, name) -> name.endsWith(".properties"));

        if (profileFiles == null || profileFiles.length == 0) {
            JOptionPane.showMessageDialog(this,
                    "No profiles found!\n\nSave a profile first.",
                    "No Profiles",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Create list of profile names (without .properties extension)
        String[] profileNames = new String[profileFiles.length];
        for (int i = 0; i < profileFiles.length; i++) {
            String name = profileFiles[i].getName();
            profileNames[i] = name.substring(0, name.length() - ".properties".length());
        }

        // Show selection dialog
        String selectedProfile = (String) JOptionPane.showInputDialog(
                this,
                "Select a profile to load:",
                "Load Profile",
                JOptionPane.PLAIN_MESSAGE,
                null,
                profileNames,
                profileNames[0]
        );

        if (selectedProfile == null) {
            return; // User cancelled
        }

        // Load the selected profile
        File profileFile = new File(profilesFolder, selectedProfile + ".properties");

        try {
            loadConfigFromFile(profileFile);
            JOptionPane.showMessageDialog(this,
                    "Profile '" + selectedProfile + "' loaded successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading profile: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveConfigToFile(File file) throws IOException {
        Properties props = new Properties();

        // Picking settings
        props.setProperty("pickingMode", pickingModeCombo.getSelectedItem().toString());
        props.setProperty("specificItems", specificItemsArea.getText());
        props.setProperty("exclusionList", exclusionListArea.getText());
        props.setProperty("minimumValue", minValueSpinner.getValue().toString());
        props.setProperty("useValueGoal", String.valueOf(useValueGoalCheck.isSelected()));
        props.setProperty("targetValue", targetValueSpinner.getValue().toString());

        // Break settings
        props.setProperty("breaksEnabled", String.valueOf(breaksEnabledCheck.isSelected()));
        props.setProperty("breakAfter", breakAfterSpinner.getValue().toString());
        props.setProperty("breakDuration", breakDurationSpinner.getValue().toString());
        props.setProperty("breakVariance", breakVarianceSpinner.getValue().toString());

        // Anti-ban settings
        props.setProperty("antiBanEnabled", String.valueOf(antiBanEnabledCheck.isSelected()));
        props.setProperty("antiBanCamera", String.valueOf(antiBanCameraCheck.isSelected()));
        props.setProperty("antiBanSkills", String.valueOf(antiBanSkillsCheck.isSelected()));
        props.setProperty("antiBanInventory", String.valueOf(antiBanInventoryCheck.isSelected()));
        props.setProperty("antiBanMouse", String.valueOf(antiBanMouseCheck.isSelected()));
        props.setProperty("antiBanIdle", String.valueOf(antiBanIdleCheck.isSelected()));
        props.setProperty("antiBanInterval", antiBanIntervalSpinner.getValue().toString());
        props.setProperty("antiBanChance", antiBanChanceSpinner.getValue().toString());

        // SmartMouse settings
        props.setProperty("smartMouseEnabled", String.valueOf(smartMouseEnabledCheck.isSelected()));
        props.setProperty("runEnabled", String.valueOf(runEnabledCheck.isSelected()));

        // Advanced settings
        props.setProperty("minWalkInterval", minWalkIntervalSpinner.getValue().toString());
        props.setProperty("maxWalkInterval", maxWalkIntervalSpinner.getValue().toString());
        props.setProperty("returnToBankEnabled", String.valueOf(returnToBankCheck.isSelected()));
        props.setProperty("returnToBankTimeout", returnToBankTimeoutSpinner.getValue().toString());
        props.setProperty("missChance", missChanceSpinner.getValue().toString());
        props.setProperty("missVariance", missVarianceSpinner.getValue().toString());
        props.setProperty("alwaysPickValue", alwaysPickValueSpinner.getValue().toString());

        try (FileOutputStream out = new FileOutputStream(file)) {
            props.store(out, "GE Ground Item Picker Profile");
        }
    }

    private void loadConfigFromFile(File file) throws IOException {
        Properties props = new Properties();
        try (FileInputStream in = new FileInputStream(file)) {
            props.load(in);
        }

        // Picking settings
        String mode = props.getProperty("pickingMode");
        for (int i = 0; i < pickingModeCombo.getItemCount(); i++) {
            if (pickingModeCombo.getItemAt(i).toString().equals(mode)) {
                pickingModeCombo.setSelectedIndex(i);
                break;
            }
        }
        specificItemsArea.setText(props.getProperty("specificItems", ""));
        exclusionListArea.setText(props.getProperty("exclusionList", ""));
        minValueSpinner.setValue(Integer.parseInt(props.getProperty("minimumValue", "1000")));
        useValueGoalCheck.setSelected(Boolean.parseBoolean(props.getProperty("useValueGoal", "false")));
        targetValueSpinner.setValue(Integer.parseInt(props.getProperty("targetValue", "100000")));

        // Break settings
        breaksEnabledCheck.setSelected(Boolean.parseBoolean(props.getProperty("breaksEnabled", "true")));
        breakAfterSpinner.setValue(Integer.parseInt(props.getProperty("breakAfter", "45")));
        breakDurationSpinner.setValue(Integer.parseInt(props.getProperty("breakDuration", "5")));
        breakVarianceSpinner.setValue(Integer.parseInt(props.getProperty("breakVariance", "20")));

        // Anti-ban settings
        antiBanEnabledCheck.setSelected(Boolean.parseBoolean(props.getProperty("antiBanEnabled", "true")));
        antiBanCameraCheck.setSelected(Boolean.parseBoolean(props.getProperty("antiBanCamera", "true")));
        antiBanSkillsCheck.setSelected(Boolean.parseBoolean(props.getProperty("antiBanSkills", "true")));
        antiBanInventoryCheck.setSelected(Boolean.parseBoolean(props.getProperty("antiBanInventory", "true")));
        antiBanMouseCheck.setSelected(Boolean.parseBoolean(props.getProperty("antiBanMouse", "true")));
        antiBanIdleCheck.setSelected(Boolean.parseBoolean(props.getProperty("antiBanIdle", "true")));
        antiBanIntervalSpinner.setValue(Integer.parseInt(props.getProperty("antiBanInterval", "30")));
        antiBanChanceSpinner.setValue(Integer.parseInt(props.getProperty("antiBanChance", "15")));

        // SmartMouse settings
        smartMouseEnabledCheck.setSelected(Boolean.parseBoolean(props.getProperty("smartMouseEnabled", "true")));
        runEnabledCheck.setSelected(Boolean.parseBoolean(props.getProperty("runEnabled", "true")));

        // Advanced settings
        minWalkIntervalSpinner.setValue(Integer.parseInt(props.getProperty("minWalkInterval", "8")));
        maxWalkIntervalSpinner.setValue(Integer.parseInt(props.getProperty("maxWalkInterval", "20")));
        returnToBankCheck.setSelected(Boolean.parseBoolean(props.getProperty("returnToBankEnabled", "true")));
        returnToBankTimeoutSpinner.setValue(Integer.parseInt(props.getProperty("returnToBankTimeout", "60")));
        missChanceSpinner.setValue(Integer.parseInt(props.getProperty("missChance", "5")));
        missVarianceSpinner.setValue(Integer.parseInt(props.getProperty("missVariance", "3")));
        alwaysPickValueSpinner.setValue(Integer.parseInt(props.getProperty("alwaysPickValue", "10000")));

        updateAntiBanToggles();
        updateSmartMouseStatus();
    }

    private void onStartClicked() {
        // Validate SmartMouse is enabled
        if (!smartMouseEnabledCheck.isSelected()) {
            int choice = JOptionPane.showConfirmDialog(this,
                    "SmartMouse is currently DISABLED.\n\n" +
                            "It is highly recommended to enable SmartMouse for more human-like behavior.\n\n" +
                            "Do you want to continue anyway?",
                    "SmartMouse Disabled",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);

            if (choice != JOptionPane.YES_OPTION) {
                return; // Don't start
            }
        }

        // Picking mode
        config.setPickingMode((PickerConfig.PickingMode) pickingModeCombo.getSelectedItem());

        // Specific items
        String itemsText = specificItemsArea.getText().trim();
        if (!itemsText.isEmpty()) {
            String[] items = itemsText.split("\n");
            config.setSpecificItems(new HashSet<>(Arrays.asList(items)));
        }

        // Exclusion list
        String exclusionsText = exclusionListArea.getText().trim();
        String[] exclusions = exclusionsText.isEmpty() ? new String[0] : exclusionsText.split("\n");
        config.setExclusionList(new HashSet<>(Arrays.asList(exclusions)));

        // Minimum value
        config.setMinimumValue((Integer) minValueSpinner.getValue());

        // Value goal
        config.setUseValueGoal(useValueGoalCheck.isSelected());
        config.setTargetValue((Integer) targetValueSpinner.getValue());

        // Break settings
        config.setBreaksEnabled(breaksEnabledCheck.isSelected());
        config.setBreakAfterMinutes((Integer) breakAfterSpinner.getValue());
        config.setBreakDurationMinutes((Integer) breakDurationSpinner.getValue());
        config.setBreakVariance((Integer) breakVarianceSpinner.getValue());

        // Anti-ban settings
        config.setAntiBanEnabled(antiBanEnabledCheck.isSelected());
        config.setAntiBanCameraEnabled(antiBanCameraCheck.isSelected());
        config.setAntiBanSkillsEnabled(antiBanSkillsCheck.isSelected());
        config.setAntiBanInventoryEnabled(antiBanInventoryCheck.isSelected());
        config.setAntiBanMouseEnabled(antiBanMouseCheck.isSelected());
        config.setAntiBanIdleEnabled(antiBanIdleCheck.isSelected());
        config.setAntiBanInterval((Integer) antiBanIntervalSpinner.getValue());
        config.setAntiBanChance((Integer) antiBanChanceSpinner.getValue());

        // SmartMouse and run
        config.setSmartMouseEnabled(smartMouseEnabledCheck.isSelected());
        config.setRunEnabled(runEnabledCheck.isSelected());

        // Advanced settings
        config.setMinWalkInterval((Integer) minWalkIntervalSpinner.getValue());
        config.setMaxWalkInterval((Integer) maxWalkIntervalSpinner.getValue());
        config.setReturnToBankEnabled(returnToBankCheck.isSelected());
        config.setReturnToBankTimeout((Integer) returnToBankTimeoutSpinner.getValue());
        config.setMissChance((Integer) missChanceSpinner.getValue());
        config.setMissVariance((Integer) missVarianceSpinner.getValue());
        config.setAlwaysPickValue((Integer) alwaysPickValueSpinner.getValue());

        // Callback
        if (onStartCallback != null) {
            onStartCallback.accept(config);
        }

        dispose();
    }

    public void setOnStartCallback(Consumer<PickerConfig> callback) {
        this.onStartCallback = callback;
    }
}
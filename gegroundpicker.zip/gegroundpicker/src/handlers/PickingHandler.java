package gegroundpicker.handlers;

import gegroundpicker.managers.*;
import gegroundpicker.mouse.MouseManager;
import gegroundpicker.utils.RandomHelper;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.item.GroundItems;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.GroundItem;

import java.util.List;

/**
 * Handles picking up ground items
 */
public class PickingHandler {

    private static final Area GE_SCAN_AREA = new Area(3160, 3485, 3175, 3495); // Centered on bank
    private static final int MAX_DISTANCE = 10; // tiles - reduced for tighter area

    private final AbstractScript script;
    private final MouseManager mouseManager;
    private final ConfigManager configManager;
    private final StatisticsTracker statisticsTracker;
    private final AntiBanManager antiBanManager;

    private Tile lastScanTile;
    private long lastScanTime;
    private long lastWalkTime;
    private static final long SCAN_INTERVAL = 2000; // 2 seconds between scans
    private long nextWalkTime;

    // Walking intervals - more frequent movement
    private final long minWalkInterval;
    private final long maxWalkInterval;

    public PickingHandler(AbstractScript script, MouseManager mouseManager,
                          ConfigManager configManager, StatisticsTracker statisticsTracker,
                          AntiBanManager antiBanManager) {
        this.script = script;
        this.mouseManager = mouseManager;
        this.configManager = configManager;
        this.statisticsTracker = statisticsTracker;
        this.antiBanManager = antiBanManager;

        // Get walk intervals from config (in seconds, convert to milliseconds)
        this.minWalkInterval = configManager.getMinWalkInterval() * 1000L;
        this.maxWalkInterval = configManager.getMaxWalkInterval() * 1000L;

        // Initialize walk timing with randomization
        this.lastWalkTime = System.currentTimeMillis();
        this.nextWalkTime = System.currentTimeMillis() +
                RandomHelper.getRandomInt((int)minWalkInterval, (int)maxWalkInterval);

        script.log("[PickingHandler] Walk intervals: " + configManager.getMinWalkInterval() +
                "-" + configManager.getMaxWalkInterval() + " seconds");
    }

    public int handle() {
        try {
            // Scan for ground items
            GroundItem targetItem = findBestGroundItem();

            if (targetItem == null) {
                // No items found - walk around to scan more area
                return handleNoItemsFound();
            }

            // Pick up the item
            return pickUpItem(targetItem);

        } catch (Exception e) {
            script.log("[PickingHandler] ERROR: " + e.getMessage());
            e.printStackTrace();
            return RandomHelper.getRandomInt(1000, 1500);
        }
    }

    /**
     * Find the best ground item to pick up
     */
    private GroundItem findBestGroundItem() {
        Tile playerPos = Players.getLocal().getTile();

        // Get all ground items in scan area using GroundItems.all() with filter
        List<GroundItem> allItems = GroundItems.all(item ->
                item != null &&
                        GE_SCAN_AREA.contains(item.getTile()) &&
                        playerPos.distance(item.getTile()) <= MAX_DISTANCE &&
                        shouldPickItem(item)
        );

        if (allItems.isEmpty()) {
            return null;
        }

        // Sort by priority: value first, then distance
        allItems.sort((a, b) -> {
            int valueA = getItemValue(a);
            int valueB = getItemValue(b);

            // If picking by value, prioritize value
            if (configManager.isPickByValue()) {
                if (valueA != valueB) {
                    return Integer.compare(valueB, valueA); // Higher value first
                }
            }

            // Otherwise prioritize by distance
            double distA = playerPos.distance(a.getTile());
            double distB = playerPos.distance(b.getTile());
            return Double.compare(distA, distB);
        });

        return allItems.get(0);
    }

    /**
     * Check if we should pick this item based on config
     */
    private boolean shouldPickItem(GroundItem item) {
        if (item == null || item.getName() == null) {
            return false;
        }

        String itemName = item.getName();

        // FIRST: Check exclusion list - never pick excluded items
        if (configManager.isExcluded(itemName)) {
            return false;
        }

        // Get item value for value-based checks
        int value = getItemValue(item);

        // SECOND: Always pick high-value items (overrides miss chance)
        int alwaysPickValue = configManager.getAlwaysPickValue();
        if (value >= alwaysPickValue) {
            script.log("[Picking] High-value item: " + itemName + " (" + value + " GP >= " + alwaysPickValue + " GP)");
            return true;
        }

        // THIRD: Apply miss chance for human-like behavior
        int missChance = configManager.getMissChance();
        int missVariance = configManager.getMissVariance();

        // Calculate actual miss chance with variance
        int actualMissChance = missChance + RandomHelper.getRandomInt(-missVariance, missVariance);
        actualMissChance = Math.max(0, Math.min(100, actualMissChance)); // Clamp between 0-100

        // Random chance to miss this item
        if (Math.random() * 100 < actualMissChance) {
            script.log("[Picking] Missed item: " + itemName + " (miss chance: " + actualMissChance + "%)");
            return false;
        }

        // FOURTH: Check picking mode
        switch (configManager.getPickingMode()) {
            case PICK_ALL:
                return true;

            case SPECIFIC_ITEMS:
                boolean shouldPick = configManager.shouldPickItem(itemName);
                if (!shouldPick) {
                    script.log("[Picking] Item not in specific list: " + itemName);
                }
                return shouldPick;

            case BY_VALUE:
                int minValue = configManager.getMinimumValue();
                boolean meetsValue = value >= minValue;
                if (!meetsValue) {
                    script.log("[Picking] Item below minimum value: " + itemName + " (" + value + " GP < " + minValue + " GP)");
                } else {
                    script.log("[Picking] Item meets value requirement: " + itemName + " (" + value + " GP >= " + minValue + " GP)");
                }
                return meetsValue;

            default:
                return false;
        }
    }

    /**
     * Get item value (estimated)
     */
    private int getItemValue(GroundItem item) {
        if (item == null) {
            return 0;
        }

        // Try to get item value by creating Item from ID
        try {
            // Create Item object to access getValue() method
            org.dreambot.api.wrappers.items.Item itemDef = new org.dreambot.api.wrappers.items.Item(item.getId(), item.getAmount());
            int value = itemDef.getValue();
            if (value > 0) {
                return value * item.getAmount();
            }
        } catch (Exception e) {
            // Ignore
        }

        // Fallback to basic estimation
        return estimateValue(item.getName(), item.getAmount());
    }

    /**
     * Estimate item value based on name
     */
    private int estimateValue(String itemName, int amount) {
        if (itemName == null) {
            return 0;
        }

        String lower = itemName.toLowerCase();

        // Known low-value items (return actual low value, not default)
        if (lower.contains("ashes")) return 20 * amount; // Ashes are ~20 GP each
        if (lower.contains("bones") && !lower.contains("dragon") && !lower.contains("big")) return 50 * amount;
        if (lower.contains("feather")) return 2 * amount;
        if (lower.contains("cowhide")) return 100 * amount;

        // Common valuable items
        if (lower.contains("coin")) return amount; // Coins are their own value
        if (lower.contains("rune") || lower.contains("dragon")) return 5000 * amount;
        if (lower.contains("adamant")) return 1000 * amount;
        if (lower.contains("mithril")) return 500 * amount;
        if (lower.contains("gold") || lower.contains("ruby")) return 1000 * amount;
        if (lower.contains("diamond")) return 2000 * amount;
        if (lower.contains("nature")) return 200 * amount;
        if (lower.contains("law")) return 300 * amount;
        if (lower.contains("death")) return 250 * amount;

        return 100 * amount; // Default estimate for unknown items
    }

    /**
     * Pick up an item
     */
    private int pickUpItem(GroundItem item) {
        try {
            String itemName = item.getName();
            int amount = item.getAmount();
            int value = getItemValue(item);

            script.log("[Picking] Target: " + itemName + " x" + amount + " (~" + value + " GP)");

            // Move to item if too far
            Tile playerPos = Players.getLocal().getTile();
            double distance = playerPos.distance(item.getTile());

            if (distance > 3) {
                script.log("[Picking] Walking closer to item (distance: " + String.format("%.1f", distance) + ")");
                Walking.walk(item.getTile());
                Sleep.sleepUntil(() -> item.getTile().distance() <= 3, 5000);
                Sleep.sleep(RandomHelper.getRandomInt(300, 600));
            }

            // Use SmartMouse to interact with item
            boolean success = false;
            if (mouseManager.isSmartMouseEnabled()) {
                success = mouseManager.getController().clickEntity(item);
            } else {
                success = item.interact("Take");
            }

            if (success) {
                // Wait for item to be picked up
                int inventoryBefore = Inventory.count(itemName);
                Sleep.sleepUntil(() -> Inventory.count(itemName) > inventoryBefore, 3000);

                int inventoryAfter = Inventory.count(itemName);
                if (inventoryAfter > inventoryBefore) {
                    script.log("[Picking] ✓ Picked up " + itemName);
                    statisticsTracker.addItemPicked(itemName, amount, value);

                    // Small delay after successful pickup
                    Sleep.sleep(RandomHelper.getRandomInt(200, 400));

                    // Random anti-ban action occasionally
                    if (Math.random() < 0.1) { // 10% chance
                        antiBanManager.performRandomAction();
                    }
                }

                return RandomHelper.getRandomInt(400, 700);
            } else {
                script.log("[Picking] Failed to interact with item");
                return RandomHelper.getRandomInt(800, 1200);
            }

        } catch (Exception e) {
            script.log("[Picking] Error picking item: " + e.getMessage());
            return RandomHelper.getRandomInt(1000, 1500);
        }
    }

    /**
     * Handle case where no items found
     */
    private int handleNoItemsFound() {
        long currentTime = System.currentTimeMillis();
        Tile playerPos = Players.getLocal().getTile();

        // Check if we should return to bank center due to no items found
        long timeSinceLastPick = statisticsTracker.getTimeSinceLastPick();
        if (configManager.isReturnToBankEnabled() && timeSinceLastPick > 0) {
            long timeoutMillis = configManager.getReturnToBankTimeout() * 1000L;

            if (timeSinceLastPick >= timeoutMillis) {
                script.log("[Picking] No items found for " + (timeSinceLastPick/1000) + "s - returning to bank area");

                // Get center of bank area
                Tile bankCenter = new Tile(3167, 3490);

                if (Walking.walk(bankCenter)) {
                    Sleep.sleepUntil(() -> Players.getLocal().getTile().distance(bankCenter) < 3, 5000);
                }

                // Reset the timer by updating lastWalkTime
                lastWalkTime = currentTime;
                nextWalkTime = currentTime + RandomHelper.getRandomInt((int)minWalkInterval, (int)maxWalkInterval);

                return RandomHelper.getRandomInt(1000, 1500);
            }
        }

        // Check if we're in the preferred scan area
        boolean inPreferredArea = GE_SCAN_AREA.contains(playerPos);

        // If NOT in preferred area (but inside GE walls), just stand still and scan
        if (!inPreferredArea) {
            script.log("[Picking] Outside preferred area but inside GE - standing still and scanning");
            return RandomHelper.getRandomInt(2000, 3000); // Longer wait, just scanning
        }

        // Only walk around if we're IN the preferred area
        // Don't walk too frequently - check if it's time to walk
        if (currentTime < nextWalkTime) {
            // Just wait and rescan - don't walk yet
            return RandomHelper.getRandomInt(1000, 2000);
        }

        // Time to walk to a new area (only happens if in preferred area)
        Tile randomTile = getRandomGETile();

        if (randomTile != null && !randomTile.equals(lastScanTile)) {
            script.log("[Picking] No items nearby - walking to new spot in preferred area");
            lastScanTile = randomTile;
            lastWalkTime = currentTime;

            // Set next walk time with randomization using config values
            nextWalkTime = currentTime + RandomHelper.getRandomInt((int)minWalkInterval, (int)maxWalkInterval);

            if (Walking.walk(randomTile)) {
                Sleep.sleepUntil(() -> Players.getLocal().getTile().distance(randomTile) < 3, 5000);
                return RandomHelper.getRandomInt(600, 1000);
            }
        }

        return RandomHelper.getRandomInt(1000, 1500);
    }

    /**
     * Get random tile in GE area
     */
    private Tile getRandomGETile() {
        // Use Area.getRandomTile() - the proper DreamBot 4 way
        return GE_SCAN_AREA.getRandomTile();
    }
}
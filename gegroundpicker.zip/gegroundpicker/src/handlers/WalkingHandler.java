package gegroundpicker.handlers;

import gegroundpicker.mouse.MouseManager;
import gegroundpicker.utils.RandomHelper;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Sleep;

/**
 * Handles walking and navigation
 */
public class WalkingHandler {

    private static final Area GE_BANK_AREA = new Area(3160, 3485, 3170, 3495);
    private static final Tile GE_CENTER = new Tile(3165, 3490);

    private final AbstractScript script;
    private final MouseManager mouseManager;
    private final Area geArea;

    public WalkingHandler(AbstractScript script, MouseManager mouseManager, Area geArea) {
        this.script = script;
        this.mouseManager = mouseManager;
        this.geArea = geArea;
    }

    /**
     * Walk to GE area
     */
    public boolean walkToGE() {
        Tile playerPos = Players.getLocal().getTile();

        if (geArea.contains(playerPos)) {
            return true;
        }

        script.log("[Walking] Walking to GE...");

        Tile target = geArea.getRandomTile();
        if (Walking.walk(target)) {
            Sleep.sleepUntil(() -> geArea.contains(Players.getLocal().getTile()), 10000);
            Sleep.sleep(RandomHelper.getRandomInt(400, 700));
            return geArea.contains(Players.getLocal().getTile());
        }

        return false;
    }

    /**
     * Walk to bank
     */
    public boolean walkToBank() {
        Tile playerPos = Players.getLocal().getTile();

        if (GE_BANK_AREA.contains(playerPos)) {
            return true;
        }

        script.log("[Walking] Walking to bank...");

        if (Walking.walk(GE_CENTER)) {
            Sleep.sleepUntil(() -> GE_BANK_AREA.contains(Players.getLocal().getTile()), 10000);
            Sleep.sleep(RandomHelper.getRandomInt(400, 700));
            return GE_BANK_AREA.contains(Players.getLocal().getTile());
        }

        return false;
    }

    /**
     * Walk to specific tile
     */
    public boolean walkToTile(Tile tile) {
        if (tile == null) {
            return false;
        }

        Tile playerPos = Players.getLocal().getTile();
        double distance = playerPos.distance(tile);

        if (distance < 3) {
            return true;
        }

        if (Walking.walk(tile)) {
            Sleep.sleepUntil(() -> Players.getLocal().getTile().distance(tile) < 3, 8000);
            Sleep.sleep(RandomHelper.getRandomInt(300, 600));
            return Players.getLocal().getTile().distance(tile) < 3;
        }

        return false;
    }
}
package gegroundpicker.handlers;

import gegroundpicker.managers.ConfigManager;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.Item;

/**
 * Handles checking for and removing excluded items from inventory/equipment
 */
public class EquipmentHandler {

    private final AbstractScript script;
    private final ConfigManager configManager;

    public EquipmentHandler(AbstractScript script, ConfigManager configManager) {
        this.script = script;
        this.configManager = configManager;
    }

    /**
     * Check inventory and equipment for excluded items and drop them
     * @return sleep time after handling
     */
    public int checkAndDropExcludedItems() {
        // Check equipment first
        if (hasExcludedItemEquipped()) {
            return handleEquippedExclusions();
        }

        // Check inventory
        if (hasExcludedItemInInventory()) {
            return handleInventoryExclusions();
        }

        return 0; // No excluded items found
    }

    /**
     * Check if any excluded item is equipped
     */
    private boolean hasExcludedItemEquipped() {
        if (!Equipment.contains(item -> isExcluded(item.getName()))) {
            return false;
        }

        Item excludedItem = Equipment.get(item -> isExcluded(item.getName()));
        if (excludedItem != null) {
            Logger.log("[Equipment] Found excluded item equipped: " + excludedItem.getName());
            return true;
        }

        return false;
    }

    /**
     * Check if any excluded item is in inventory
     */
    private boolean hasExcludedItemInInventory() {
        if (!Inventory.contains(item -> isExcluded(item.getName()))) {
            return false;
        }

        Item excludedItem = Inventory.get(item -> isExcluded(item.getName()));
        if (excludedItem != null) {
            Logger.log("[Inventory] Found excluded item: " + excludedItem.getName());
            return true;
        }

        return false;
    }

    /**
     * Unequip and drop all excluded items from equipment
     */
    private int handleEquippedExclusions() {
        Item excludedItem = Equipment.get(item -> isExcluded(item.getName()));

        if (excludedItem != null) {
            String itemName = excludedItem.getName();
            Logger.log("[Equipment] Unequipping excluded item: " + itemName);

            if (excludedItem.interact("Remove")) {
                Sleep.sleepUntil(() -> Inventory.contains(itemName), 3000);

                // Now drop it from inventory
                Item invItem = Inventory.get(itemName);
                if (invItem != null) {
                    Logger.log("[Equipment] Dropping unequipped item: " + itemName);
                    if (invItem.interact("Drop")) {
                        Sleep.sleepUntil(() -> !Inventory.contains(itemName), 2000);
                        return 1000;
                    }
                }
            }
        }

        return 600;
    }

    /**
     * Drop all excluded items from inventory
     */
    private int handleInventoryExclusions() {
        Item excludedItem = Inventory.get(item -> isExcluded(item.getName()));

        if (excludedItem != null) {
            String itemName = excludedItem.getName();
            Logger.log("[Inventory] Dropping excluded item: " + itemName);

            if (excludedItem.interact("Drop")) {
                Sleep.sleepUntil(() -> !Inventory.contains(itemName), 2000);
                return 800;
            }
        }

        return 600;
    }

    /**
     * Check if item name matches exclusion list
     */
    private boolean isExcluded(String itemName) {
        if (itemName == null) {
            return false;
        }
        return configManager.isExcluded(itemName);
    }

    /**
     * Public method to check if we need to handle exclusions
     */
    public boolean needsToHandleExclusions() {
        return hasExcludedItemEquipped() || hasExcludedItemInInventory();
    }
}
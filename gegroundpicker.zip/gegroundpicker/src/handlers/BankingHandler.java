package gegroundpicker.handlers;

import gegroundpicker.managers.StatisticsTracker;
import gegroundpicker.mouse.MouseManager;
import gegroundpicker.utils.RandomHelper;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;

/**
 * Handles banking operations
 */
public class BankingHandler {

    private final AbstractScript script;
    private final MouseManager mouseManager;
    private final StatisticsTracker statisticsTracker;

    public BankingHandler(AbstractScript script, MouseManager mouseManager,
                          StatisticsTracker statisticsTracker) {
        this.script = script;
        this.mouseManager = mouseManager;
        this.statisticsTracker = statisticsTracker;
    }

    public int handle() {
        try {
            // Open bank if not open
            if (!Bank.isOpen()) {
                return openBank();
            }

            // Deposit all items
            script.log("[Banking] Depositing inventory...");

            if (Bank.depositAllItems()) {
                Sleep.sleepUntil(() -> Inventory.isEmpty(), 5000);
                Sleep.sleep(RandomHelper.getRandomInt(300, 600));

                script.log("[Banking] ✓ Deposited all items");
                statisticsTracker.incrementBankTrips();
            } else {
                script.log("[Banking] Failed to deposit items");
                return RandomHelper.getRandomInt(800, 1200);
            }

            // Close bank
            if (Bank.isOpen()) {
                Bank.close();
                Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
                Sleep.sleep(RandomHelper.getRandomInt(200, 400));
            }

            script.log("[Banking] ✓ Banking complete");
            return RandomHelper.getRandomInt(400, 700);

        } catch (Exception e) {
            script.log("[Banking] ERROR: " + e.getMessage());
            e.printStackTrace();
            return RandomHelper.getRandomInt(1000, 1500);
        }
    }

    private int openBank() {
        script.log("[Banking] Opening bank...");

        // Try booth first
        GameObject bankBooth = GameObjects.closest(obj ->
                obj != null &&
                        obj.hasAction("Bank") &&
                        obj.getName().contains("Bank")
        );

        if (bankBooth != null) {
            script.log("[Banking] Found bank booth");

            boolean interacted;
            if (mouseManager.isSmartMouseEnabled()) {
                interacted = mouseManager.getController().clickEntity(bankBooth);
            } else {
                interacted = bankBooth.interact("Bank");
            }

            if (interacted) {
                Sleep.sleepUntil(() -> Bank.isOpen(), 5000);
                Sleep.sleep(RandomHelper.getRandomInt(300, 600));

                if (Bank.isOpen()) {
                    script.log("[Banking] ✓ Bank opened");
                    return RandomHelper.getRandomInt(200, 400);
                }
            }
        }

        // Fallback: use Bank.open()
        script.log("[Banking] Using Bank.open() fallback");
        if (Bank.open()) {
            Sleep.sleepUntil(() -> Bank.isOpen(), 5000);
            return RandomHelper.getRandomInt(300, 600);
        }

        script.log("[Banking] Failed to open bank");
        return RandomHelper.getRandomInt(1000, 1500);
    }
}
package gegroundpicker.handlers;

import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Sleep;
import gegroundpicker.utils.RandomHelper;

/**
 * Handles pathing from any F2P location to Grand Exchange
 * Uses DreamBot's WebWalking for reliable pathfinding
 */
public class PathingHandler {

    private final AbstractScript script;

    // Grand Exchange area
    private static final Area GE_AREA = new Area(3143, 3465, 3190, 3510);
    private static final Tile GE_CENTER = new Tile(3165, 3490, 0);

    // F2P banking locations for reference
    private static final Area LUMBRIDGE_CASTLE = new Area(3207, 3214, 3210, 3220, 2);
    private static final Area DRAYNOR_BANK = new Area(3092, 3240, 3097, 3246);
    private static final Area FALADOR_WEST_BANK = new Area(2943, 3368, 2947, 3373);
    private static final Area FALADOR_EAST_BANK = new Area(3009, 3355, 3018, 3358);
    private static final Area EDGEVILLE_BANK = new Area(3092, 3488, 3098, 3499);
    private static final Area VARROCK_WEST_BANK = new Area(3180, 3433, 3185, 3448);
    private static final Area VARROCK_EAST_BANK = new Area(3250, 3419, 3257, 3423);

    private long lastWalkAttempt = 0;
    private static final long WALK_COOLDOWN = 5000; // 5 seconds between walk attempts

    public PathingHandler(AbstractScript script) {
        this.script = script;
    }

    /**
     * Walk to Grand Exchange from current location
     * @return true if successfully at GE or walking to GE
     */
    public boolean walkToGrandExchange() {
        Tile playerPos = Players.getLocal().getTile();

        // Check if already at GE
        if (GE_AREA.contains(playerPos)) {
            script.log("[Pathing] Already at Grand Exchange");
            return true;
        }

        // Check cooldown to prevent spam walking
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastWalkAttempt < WALK_COOLDOWN) {
            return false;
        }

        script.log("[Pathing] Walking to Grand Exchange from " + getLocationName(playerPos));
        lastWalkAttempt = currentTime;

        // Use DreamBot's WebWalking to GE center
        if (Walking.walk(GE_CENTER)) {
            script.log("[Pathing] Path initiated to Grand Exchange");

            // Wait for character to start moving
            Sleep.sleepUntil(() -> Players.getLocal().isMoving(), 2000);

            // Wait until we're close to GE or stopped moving
            Sleep.sleepUntil(() -> {
                Tile current = Players.getLocal().getTile();
                return GE_AREA.contains(current) ||
                        current.distance(GE_CENTER) < 10 ||
                        !Players.getLocal().isMoving();
            }, 30000); // 30 second timeout for long walks

            Sleep.sleep(RandomHelper.getRandomInt(400, 800));

            // Check if we made it
            if (GE_AREA.contains(Players.getLocal().getTile())) {
                script.log("[Pathing] Arrived at Grand Exchange");
                return true;
            } else {
                script.log("[Pathing] Still en route to Grand Exchange...");
                return false;
            }
        }

        script.log("[Pathing] Failed to initiate walk to Grand Exchange");
        return false;
    }

    /**
     * Check if player is currently at Grand Exchange
     */
    public boolean isAtGrandExchange() {
        return GE_AREA.contains(Players.getLocal().getTile());
    }

    /**
     * Get estimated distance to Grand Exchange
     */
    public double getDistanceToGE() {
        return Players.getLocal().getTile().distance(GE_CENTER);
    }

    /**
     * Get general location name based on current position
     * Useful for logging
     */
    private String getLocationName(Tile position) {
        if (GE_AREA.contains(position)) return "Grand Exchange";
        if (LUMBRIDGE_CASTLE.contains(position)) return "Lumbridge Castle";
        if (DRAYNOR_BANK.contains(position)) return "Draynor Village";
        if (FALADOR_WEST_BANK.contains(position)) return "Falador West Bank";
        if (FALADOR_EAST_BANK.contains(position)) return "Falador East Bank";
        if (EDGEVILLE_BANK.contains(position)) return "Edgeville";
        if (VARROCK_WEST_BANK.contains(position)) return "Varrock West Bank";
        if (VARROCK_EAST_BANK.contains(position)) return "Varrock East Bank";

        // Check general regions
        if (position.getX() > 3200 && position.getY() < 3230) return "Lumbridge area";
        if (position.getX() < 3100 && position.getY() < 3260) return "Draynor area";
        if (position.getX() < 3000 && position.getY() > 3350) return "Falador area";
        if (position.getX() > 3080 && position.getY() > 3480) return "Edgeville area";
        if (position.getX() > 3200 && position.getY() > 3400) return "Varrock area";

        return "Unknown location (" + position.getX() + ", " + position.getY() + ")";
    }

    /**
     * Emergency check - if player is very far from GE
     */
    public boolean isVeryFarFromGE() {
        return getDistanceToGE() > 100;
    }
}
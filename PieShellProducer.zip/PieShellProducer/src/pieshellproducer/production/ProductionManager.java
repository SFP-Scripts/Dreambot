package pieshellproducer.production;

import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.Item;
import pieshellproducer.antiban.AntiBanManager;
import pieshellproducer.mouse.SmartMouseIntegration;
import pieshellproducer.utils.BotLogger;

/**
 * Production manager base class
 * HAS SmartMouse support - passed to subclasses
 */
public abstract class ProductionManager {

    protected final AntiBanManager antiBan;
    protected SmartMouseIntegration smartMouse;

    public ProductionManager(AntiBanManager antiBan) {
        this.antiBan = antiBan;
    }

    /**
     * Set SmartMouse integration (called by main script)
     */
    public void setSmartMouse(SmartMouseIntegration smartMouse) {
        this.smartMouse = smartMouse;
        if (smartMouse != null && smartMouse.isEnabled()) {
            BotLogger.info("SmartMouse enabled in ProductionManager");
        }
    }

    public final boolean executeProductionCycle() {
        BotLogger.info("Starting production cycle");

        try {
            if (!validateInventory()) {
                BotLogger.warn("Inventory validation failed");
                return false;
            }

            // Human reaction delay before starting
            antiBan.reactionDelay();

            if (!startProduction()) {
                BotLogger.warn("Failed to start production");
                return false;
            }

            if (!waitForCompletion()) {
                BotLogger.warn("Production did not complete");
                return false;
            }

            BotLogger.info("Cycle completed successfully");
            return true;

        } catch (Exception e) {
            BotLogger.error("Error in production cycle", e);
            return false;
        }
    }

    /**
     * Use item on another item
     * Note: DreamBot Item class doesn't have getClickablePoint()
     * So we use standard item.useOn() method
     */
    protected boolean useItemOn(Item item1, Item item2) {
        if (item1 == null || item2 == null) {
            BotLogger.error("Cannot use items - one or both are null");
            return false;
        }

        try {
            // Human reaction delay
            antiBan.humanWait(150);

            // Use standard DreamBot interaction
            // SmartMouse is available for reference but we can't use it on Items
            // because Item doesn't have getClickablePoint() in DreamBot API
            boolean success = item1.useOn(item2);

            if (success) {
                BotLogger.debug("Used " + item1.getName() + " on " + item2.getName());
            }

            return success;

        } catch (Exception e) {
            BotLogger.error("Error in useItemOn", e);
            return false;
        }
    }

    protected abstract boolean validateInventory();

    protected abstract boolean startProduction();

    protected abstract boolean waitForCompletion();

    protected abstract String getProductName();

    protected boolean isProducing() {
        try {
            return org.dreambot.api.methods.interactive.Players.getLocal().isAnimating();
        } catch (Exception e) {
            return false;
        }
    }

    protected int countItem(String itemName) {
        try {
            return Inventory.count(itemName);
        } catch (Exception e) {
            return 0;
        }
    }

    protected boolean hasItem(String itemName) {
        try {
            return Inventory.contains(itemName);
        } catch (Exception e) {
            return false;
        }
    }
}
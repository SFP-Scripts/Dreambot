package pieshellproducer.production;

import org.dreambot.api.input.Keyboard;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.Item;
import pieshellproducer.antiban.AntiBanManager;
import pieshellproducer.utils.BotLogger;

/**
 * REPLACE PieShellProducer.java WITH THIS FILE
 * Fixed to not rely on animation detection
 */
public class PieShellProducer extends ProductionManager {

    private static final String PASTRY_DOUGH = "Pastry dough";
    private static final String PIE_DISH = "Pie dish";
    private static final String PIE_SHELL = "Pie shell";

    private int initialDoughCount;
    private int initialDishCount;
    private int expectedShells;

    public PieShellProducer(AntiBanManager antiBan) {
        super(antiBan);
    }

    @Override
    protected boolean validateInventory() {
        try {
            boolean hasDough = hasItem(PASTRY_DOUGH);
            boolean hasDish = hasItem(PIE_DISH);

            if (!hasDough || !hasDish) {
                BotLogger.warn("Missing materials - Dough: " + hasDough + ", Dish: " + hasDish);
                BotLogger.error("=== PRODUCTION BLOCKED ===");
                BotLogger.error("Cannot produce pie shells without BOTH materials!");
                return false;
            }

            initialDoughCount = countItem(PASTRY_DOUGH);
            initialDishCount = countItem(PIE_DISH);

            // CRITICAL: Check for severe imbalance
            int difference = Math.abs(initialDoughCount - initialDishCount);
            if (difference > 5) {
                BotLogger.warn("=== MATERIAL IMBALANCE WARNING ===");
                BotLogger.warn("Dough: " + initialDoughCount + ", Dishes: " + initialDishCount);
                BotLogger.warn("Difference: " + difference + " (inefficient production)");
                BotLogger.warn("Will only produce " + Math.min(initialDoughCount, initialDishCount) + " shells");
                BotLogger.warn("Excess materials will be wasted this cycle");
            }

            expectedShells = Math.min(initialDoughCount, initialDishCount);

            if (expectedShells == 0) {
                BotLogger.error("ERROR: Cannot produce any shells with current materials!");
                return false;
            }

            BotLogger.info("Inventory validated - Dough: " + initialDoughCount +
                    ", Dishes: " + initialDishCount +
                    ", Expected shells: " + expectedShells);

            return true;

        } catch (Exception e) {
            BotLogger.error("Error in validateInventory", e);
            return false;
        }
    }

    @Override
    protected boolean startProduction() {
        try {
            Item dough = Inventory.get(PASTRY_DOUGH);
            Item dish = Inventory.get(PIE_DISH);

            if (dough == null || dish == null) {
                BotLogger.error("Materials null in startProduction");
                return false;
            }

            boolean interacted = useItemOn(dough, dish);

            if (!interacted) {
                BotLogger.warn("Failed to interact dough with dish");
                return false;
            }

            String mouseStatus = (smartMouse != null && smartMouse.isEnabled()) ? " (SmartMouse)" : "";
            BotLogger.info("Used dough on dish" + mouseStatus);

            // Wait for interface to appear
            Sleep.sleep(antiBan.randomDelay(600, 900));

            // Press space to make all
            BotLogger.info("Pressing SPACE to make all " + expectedShells + " shells");
            Keyboard.type(" ", false);

            // Wait a moment for production to actually start
            Sleep.sleep(antiBan.randomDelay(800, 1200));

            // Don't check isProducing() - just assume it started
            BotLogger.info("Production interface triggered");

            return true;

        } catch (Exception e) {
            BotLogger.error("Error in startProduction", e);
            return false;
        }
    }

    @Override
    protected boolean waitForCompletion() {
        BotLogger.info("Waiting for production to complete...");

        try {
            int startShellCount = countItem(PIE_SHELL);
            int startDoughCount = countItem(PASTRY_DOUGH);
            int startDishCount = countItem(PIE_DISH);

            BotLogger.debug("Starting counts - Shells: " + startShellCount +
                    ", Dough: " + startDoughCount + ", Dishes: " + startDishCount);

            // Wait for production based on TIME, not animation
            // Each shell takes about 2-3 seconds to make
            int expectedTime = expectedShells * 2500; // 2.5 seconds per shell
            int maxTime = Math.min(60000, expectedTime + 10000); // Max 60 seconds

            BotLogger.info("Waiting up to " + (maxTime/1000) + " seconds for " + expectedShells + " shells");

            long startTime = System.currentTimeMillis();
            int lastShellCount = startShellCount;
            int noProgressCount = 0;

            while (System.currentTimeMillis() - startTime < maxTime) {
                Sleep.sleep(antiBan.randomDelay(1000, 1500));

                int currentShellCount = countItem(PIE_SHELL);
                int currentDough = countItem(PASTRY_DOUGH);
                int currentDish = countItem(PIE_DISH);

                // Check if we made shells
                if (currentShellCount > lastShellCount) {
                    BotLogger.debug("Progress: " + currentShellCount + " shells (+" + (currentShellCount - lastShellCount) + ")");
                    lastShellCount = currentShellCount;
                    noProgressCount = 0;
                } else {
                    noProgressCount++;
                }

                // Break if we've made expected amount
                if (currentShellCount >= startShellCount + expectedShells) {
                    BotLogger.info("Made all expected shells: " + (currentShellCount - startShellCount));
                    break;
                }

                // Break if materials depleted
                if (currentDough == 0 && currentDish == 0) {
                    BotLogger.info("All materials used");
                    break;
                }

                // Break if no progress for 5 checks (5-7 seconds)
                if (noProgressCount > 5 && currentShellCount > startShellCount) {
                    BotLogger.info("No new shells for 5+ seconds, assuming done");
                    break;
                }
            }

            // Final wait to ensure everything settles
            Sleep.sleep(antiBan.randomDelay(500, 1000));

            int finalShellCount = countItem(PIE_SHELL);
            int shellsCreated = finalShellCount - startShellCount;
            int remainingDough = countItem(PASTRY_DOUGH);
            int remainingDish = countItem(PIE_DISH);

            BotLogger.info("Production complete!");
            BotLogger.info("  Created: " + shellsCreated + " pie shells");
            BotLogger.info("  Total shells: " + finalShellCount);
            BotLogger.info("  Remaining: " + remainingDough + " dough, " + remainingDish + " dishes");

            return shellsCreated > 0;

        } catch (Exception e) {
            BotLogger.error("Error in waitForCompletion", e);
            return false;
        }
    }

    @Override
    protected String getProductName() {
        return PIE_SHELL;
    }

    public int getPieShellCount() {
        return countItem(PIE_SHELL);
    }

    public boolean hasMaterials() {
        return hasItem(PASTRY_DOUGH) && hasItem(PIE_DISH);
    }

    public int getExpectedShells() {
        return expectedShells;
    }
}
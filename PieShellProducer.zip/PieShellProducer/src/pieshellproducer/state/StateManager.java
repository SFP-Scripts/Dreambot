package pieshellproducer.state;

import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import pieshellproducer.production.PieShellProducer;
import pieshellproducer.utils.BotLogger;
import pieshellproducer.utils.ProfitTracker;

/**
 * REPLACE YOUR StateManager.java WITH THIS FILE
 *
 * Enhanced with:
 * - Wait for supplies to fully deplete before buying more
 * - Dynamically scale buy quantities based on profits
 * - Even purchasing of both materials
 */
public class StateManager {

    private BotState currentState;
    private BotState previousState;
    private final PieShellProducer producer;
    private final ProfitTracker profitTracker;

    private int minCoins;
    private int sellThreshold;
    private int baseMaterialsToBuy; // Starting quantity
    private int currentMaterialsToBuy; // Dynamic quantity based on profit

    private int stateRetryCount = 0;
    private static final int MAX_STATE_RETRIES = 3;
    private long lastStateChange = System.currentTimeMillis();

    // Scaling parameters
    private static final int PROFIT_THRESHOLD_FOR_SCALING = 50000; // Scale up every 50k profit
    private static final double SCALING_MULTIPLIER = 1.25; // Increase by 25% each tier
    private static final int MAX_MATERIALS_PER_BUY = 2000; // Cap to prevent overspending

    public StateManager(PieShellProducer producer, ProfitTracker profitTracker,
                        int minCoins, int sellThreshold, int baseMaterialsToBuy) {
        this.producer = producer;
        this.profitTracker = profitTracker;
        this.currentState = BotState.IDLE;
        this.previousState = BotState.IDLE;
        this.minCoins = minCoins;
        this.sellThreshold = sellThreshold;
        this.baseMaterialsToBuy = baseMaterialsToBuy;
        this.currentMaterialsToBuy = baseMaterialsToBuy;
    }

    public BotState determineNextState() {
        try {
            if (isStuckInState()) {
                BotLogger.warn("Stuck in state " + currentState + ", forcing IDLE");
                return transitionTo(BotState.IDLE);
            }

            // Get all counts
            int pieShellCount = countPieShells();
            boolean hasMaterials = producer.hasMaterials();
            int totalCoins = getTotalCoins();
            boolean hasEnoughCoins = totalCoins >= minCoins;

            // Check bank for materials - MUST open bank if not already open
            int bankDough = 0;
            int bankDishes = 0;
            int bankCoins = 0;
            boolean needToCheckBank = !hasMaterials && !Bank.isOpen();

            if (needToCheckBank) {
                BotLogger.debug("Need to check bank for supplies/coins");
                // Try to open bank to check
                try {
                    GameObject bankObject = GameObjects.closest(obj ->
                            obj != null && obj.getName() != null && obj.hasAction("Bank"));

                    if (bankObject != null && bankObject.distance() < 10) {
                        if (!Bank.isOpen()) {
                            bankObject.interact("Bank");
                            Sleep.sleepUntil(() -> Bank.isOpen(), 5000);
                        }
                    }
                } catch (Exception e) {
                    BotLogger.debug("Could not open bank: " + e.getMessage());
                }
            }

            bankDough = getBankMaterialCount("Pastry dough");
            bankDishes = getBankMaterialCount("Pie dish");
            bankCoins = getBankMaterialCount("Coins");
            boolean hasSuppliesInBank = bankDough > 0 && bankDishes > 0; // MUST have BOTH

            BotLogger.debug("State check - Coins: " + totalCoins + " (inv: " + Inventory.count("Coins") +
                    "), Shells: " + pieShellCount + ", Has materials in inv: " + hasMaterials +
                    ", Bank supplies: " + bankDough + " dough, " + bankDishes + " dishes" +
                    ", Bank coins: " + bankCoins +
                    ", Min coins: " + minCoins);

            // Priority 1: If we have materials IN INVENTORY, PRODUCE (make pie shells)
            if (hasMaterials && !Bank.isOpen()) {
                return transitionTo(BotState.PRODUCING);
            }

            // Priority 2: Check if we have BOTH supplies in bank to withdraw
            if (!hasMaterials && hasSuppliesInBank) {
                BotLogger.info("Out of materials in inventory, but have supplies in bank - going to BANKING");
                return transitionTo(BotState.BANKING);
            }

            // Priority 2.5: UNBALANCED materials in bank - need to buy the missing one
            if (!hasMaterials && !hasSuppliesInBank && (bankDough > 0 || bankDishes > 0)) {
                BotLogger.warn("=== UNBALANCED MATERIALS IN BANK ===");
                BotLogger.warn("Dough: " + bankDough + ", Dishes: " + bankDishes);
                BotLogger.warn("Cannot produce without BOTH materials!");

                // Check if we have coins to buy the missing material
                int actualTotalCoins = Inventory.count("Coins") + bankCoins;
                if (actualTotalCoins >= minCoins) {
                    BotLogger.info("Have " + actualTotalCoins + " coins - will buy materials to rebalance");
                    return transitionTo(BotState.BUYING);
                } else {
                    BotLogger.error("Not enough coins to rebalance (" + actualTotalCoins + " < " + minCoins + ")");
                    BotLogger.error("Need to manually sell excess dough or add coins");
                    return transitionTo(BotState.IDLE);
                }
            }

            // Priority 3: Check if we have coins in bank (total coins including bank)
            int actualTotalCoins = Inventory.count("Coins") + bankCoins;
            boolean actuallyHasEnoughCoins = actualTotalCoins >= minCoins;

            if (!hasMaterials && !hasSuppliesInBank && actuallyHasEnoughCoins) {
                BotLogger.info("No materials but have coins (total: " + actualTotalCoins + ") - going to buy");
                // Update totalCoins for other checks
                totalCoins = actualTotalCoins;
                hasEnoughCoins = true;
            }

            // Priority 4: ALL supplies depleted (inventory + bank) - time to buy more
            if (!hasMaterials && !hasSuppliesInBank) {
                // Calculate dynamic buy quantity based on profits
                updateDynamicBuyQuantity();

                // Check if we have enough coins to buy materials
                if (hasEnoughCoins || actuallyHasEnoughCoins) {
                    BotLogger.info("=== ALL SUPPLIES DEPLETED ===");
                    BotLogger.info("Bank: " + bankDough + " dough, " + bankDishes + " dishes");
                    BotLogger.info("Total coins: " + actualTotalCoins + " (inv: " + Inventory.count("Coins") + ", bank: " + bankCoins + ")");
                    BotLogger.info("Dynamic buy quantity: " + currentMaterialsToBuy + " of each material");
                    BotLogger.info("Going to BUY more supplies");
                    return transitionTo(BotState.BUYING);
                }

                // Not enough coins - need to sell shells to get money
                if (pieShellCount > 0) {
                    BotLogger.info("Out of materials AND coins (" + actualTotalCoins + "), selling " +
                            pieShellCount + " shells to get money for supplies");
                    return transitionTo(BotState.SELLING);
                }

                // No materials, no coins, no shells - something went wrong
                BotLogger.warn("=== OUT OF EVERYTHING ===");
                BotLogger.warn("Bank: " + bankDough + " dough, " + bankDishes + " dishes, " + bankCoins + " coins");
                BotLogger.warn("Inventory: 0 materials, " + Inventory.count("Coins") + " coins, " + pieShellCount + " shells");
                BotLogger.warn("Total coins: " + actualTotalCoins + " (need " + minCoins + " minimum)");
                BotLogger.warn("Need manual intervention: Add coins or materials to continue");
                return transitionTo(BotState.IDLE);
            }

            // Priority 5: Optional - sell excess shells if we hit threshold AND have materials
            // This prevents inventory from getting too full
            if (pieShellCount >= sellThreshold && (hasMaterials || hasSuppliesInBank)) {
                BotLogger.info("Have " + pieShellCount + " shells (threshold: " + sellThreshold +
                        ") - selling excess while continuing production");
                return transitionTo(BotState.SELLING);
            }

            return transitionTo(BotState.IDLE);

        } catch (Exception e) {
            BotLogger.error("Error determining next state", e);
            return transitionTo(BotState.IDLE);
        }
    }

    /**
     * Dynamically update buy quantity based on total profits made
     * Also checks for material imbalance and adjusts to rebalance
     */
    private void updateDynamicBuyQuantity() {
        int netProfit = profitTracker.getNetProfit();

        // Calculate tier based on profit milestones
        int profitTier = Math.max(0, netProfit / PROFIT_THRESHOLD_FOR_SCALING);

        // Calculate scaled quantity: base * (multiplier ^ tier)
        int scaledQuantity = (int)(baseMaterialsToBuy * Math.pow(SCALING_MULTIPLIER, profitTier));

        // Cap at maximum to prevent overspending
        currentMaterialsToBuy = Math.min(scaledQuantity, MAX_MATERIALS_PER_BUY);

        // REBALANCING: Check for material imbalance in bank
        try {
            if (Bank.isOpen()) {
                int bankDough = Bank.count("Pastry dough");
                int bankDishes = Bank.count("Pie dish");
                int difference = Math.abs(bankDough - bankDishes);

                if (difference > 50) {
                    BotLogger.warn("=== REBALANCING MATERIALS ===");
                    BotLogger.warn("Current bank: " + bankDough + " dough, " + bankDishes + " dishes");
                    BotLogger.warn("Imbalance: " + difference);

                    // Buy more of whichever material we have less of
                    if (bankDough < bankDishes) {
                        BotLogger.info("Will prioritize buying MORE Pastry Dough to rebalance");
                    } else {
                        BotLogger.info("Will prioritize buying MORE Pie Dishes to rebalance");
                    }

                    // Still buy equal amounts - the imbalance will work itself out
                    // as we use up the excess material in production
                }
            }
        } catch (Exception e) {
            BotLogger.debug("Could not check material balance: " + e.getMessage());
        }

        if (currentMaterialsToBuy != baseMaterialsToBuy) {
            BotLogger.info("=== PROFIT SCALING ===");
            BotLogger.info("Net profit: " + netProfit + " GP");
            BotLogger.info("Profit tier: " + profitTier);
            BotLogger.info("Base quantity: " + baseMaterialsToBuy);
            BotLogger.info("Scaled quantity: " + currentMaterialsToBuy + " (+" +
                    ((currentMaterialsToBuy - baseMaterialsToBuy) * 100 / baseMaterialsToBuy) + "%)");
        }
    }

    /**
     * Get total coins from inventory and bank
     */
    private int getTotalCoins() {
        int total = 0;

        try {
            // Always count inventory
            total += Inventory.count("Coins");

            // Count bank coins if bank is open
            if (Bank.isOpen()) {
                total += Bank.count("Coins");
                BotLogger.debug("Bank is open, total coins: " + total +
                        " (inv: " + Inventory.count("Coins") +
                        ", bank: " + Bank.count("Coins") + ")");
            } else {
                BotLogger.debug("Bank not open, only inventory coins: " + total);
            }
        } catch (Exception e) {
            BotLogger.debug("Error counting coins: " + e.getMessage());
        }

        return total;
    }

    /**
     * Get material count from bank only
     */
    private int getBankMaterialCount(String material) {
        try {
            if (Bank.isOpen()) {
                return Bank.count(material);
            }
            // If bank not open, we can't check - assume 0 for now
            return 0;
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Get total pie shells from inventory and bank
     */
    private int countPieShells() {
        int total = 0;

        try {
            total += Inventory.count("Pie shell");

            if (Bank.isOpen()) {
                total += Bank.count("Pie shell");
            }
        } catch (Exception e) {
            BotLogger.debug("Error counting pie shells: " + e.getMessage());
        }

        return total;
    }

    private BotState transitionTo(BotState newState) {
        if (currentState != newState) {
            BotLogger.info("State: " + currentState + " → " + newState);
            previousState = currentState;
            currentState = newState;
            lastStateChange = System.currentTimeMillis();
            stateRetryCount = 0;
        }
        return currentState;
    }

    private boolean isStuckInState() {
        long timeInState = System.currentTimeMillis() - lastStateChange;
        return timeInState > 300000; // 5 minutes
    }

    public void handleStateFailure() {
        stateRetryCount++;
        BotLogger.warn("State " + currentState + " failed (retry " + stateRetryCount + "/" + MAX_STATE_RETRIES + ")");

        if (stateRetryCount >= MAX_STATE_RETRIES) {
            BotLogger.error("Max retries reached, forcing IDLE");
            transitionTo(BotState.IDLE);
            stateRetryCount = 0;
        }
    }

    public void resetRetryCount() {
        if (stateRetryCount > 0) {
            BotLogger.debug("Resetting retry count");
        }
        stateRetryCount = 0;
    }

    public BotState getCurrentState() {
        return currentState;
    }

    public BotState getPreviousState() {
        return previousState;
    }

    public void setState(BotState state) {
        transitionTo(state);
    }

    public boolean shouldStop() {
        return currentState == BotState.STOPPED;
    }

    /**
     * Get the current dynamic materials quantity to buy
     */
    public int getMaterialsToBuy() {
        return currentMaterialsToBuy;
    }

    /**
     * Get base materials quantity (for reference)
     */
    public int getBaseMaterialsToBuy() {
        return baseMaterialsToBuy;
    }

    public int getMinCoins() {
        return minCoins;
    }

    public int getSellThreshold() {
        return sellThreshold;
    }

    /**
     * Force recalculation of buy quantity (useful after selling)
     */
    public void recalculateBuyQuantity() {
        updateDynamicBuyQuantity();
    }
}
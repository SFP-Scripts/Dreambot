package pieshellproducer.state;

public enum BotState {
    BANKING("Walking to bank and handling materials"),
    PRODUCING("Creating pie shells"),
    SELLING("Selling pie shells at GE"),
    BUYING("Buying materials at GE"),
    IDLE("Waiting or deciding next action"),
    STOPPED("Bot has stopped");

    private final String description;

    BotState(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return name() + ": " + description;
    }
}

package pieshellproducer.managers;

import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.bank.BankMode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import pieshellproducer.antiban.AntiBanManager;
import pieshellproducer.mouse.SmartMouseIntegration;
import pieshellproducer.utils.BotLogger;

import java.awt.Point;

/**
 * REPLACE BankManager.java - Enhanced with smart inventory management
 */
public class BankManager {

    private final AntiBanManager antiBan;
    private final SmartMouseIntegration smartMouse;
    private int failureCount = 0;

    public BankManager(AntiBanManager antiBan, SmartMouseIntegration smartMouse) {
        this.antiBan = antiBan;
        this.smartMouse = smartMouse;
    }

    public boolean openBank() {
        if (Bank.isOpen()) {
            return true;
        }

        try {
            GameObject bankBooth = GameObjects.closest(obj -> obj != null && obj.hasAction("Bank"));

            if (bankBooth == null) {
                BotLogger.error("No bank nearby");
                return false;
            }

            if (!bankBooth.isOnScreen()) {
                Walking.walk(bankBooth);
                Sleep.sleepUntil(() -> bankBooth.isOnScreen(), 5000);
            }

            if (smartMouse != null && smartMouse.isEnabled()) {
                Point point = bankBooth.getClickablePoint();
                smartMouse.smartClick(point, "Bank");
            } else {
                bankBooth.interact("Bank");
            }

            boolean opened = Sleep.sleepUntil(Bank::isOpen, 6000);

            if (opened) {
                failureCount = 0;
                return true;
            }

            failureCount++;
            return false;

        } catch (Exception e) {
            BotLogger.error("Error opening bank", e);
            return false;
        }
    }

    public boolean depositAllInventory() {
        if (!Bank.isOpen()) return false;

        try {
            if (Inventory.isEmpty()) return true;

            if (Bank.depositAllItems()) {
                Sleep.sleep(antiBan.randomDelay(400, 700));
                return Sleep.sleepUntil(Inventory::isEmpty, 3000);
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean withdraw(String item, int qty) {
        if (!Bank.isOpen() || !Bank.contains(item)) return false;

        try {
            int have = Bank.count(item);
            int toGet = Math.min(qty, have);

            if (Bank.withdraw(item, toGet)) {
                Sleep.sleep(antiBan.randomDelay(400, 700));
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean withdrawNoted(String item, int qty) {
        try {
            if (Bank.getWithdrawMode() != BankMode.NOTE) {
                Bank.setWithdrawMode(BankMode.NOTE);
                Sleep.sleep(300);
            }

            boolean success = withdraw(item, qty);

            if (Bank.getWithdrawMode() != BankMode.ITEM) {
                Bank.setWithdrawMode(BankMode.ITEM);
                Sleep.sleep(300);
            }

            return success;
        } catch (Exception e) {
            return false;
        }
    }

    public void closeBank() {
        if (Bank.isOpen()) {
            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 2000);
        }
    }

    public boolean smartBankForProduction() {
        try {
            if (!openBank()) return false;

            Sleep.sleep(300);

            // Deposit everything
            depositAllInventory();
            Sleep.sleep(200);

            // Check materials
            int dough = Bank.count("Pastry dough");
            int dish = Bank.count("Pie dish");

            BotLogger.info("Bank: " + dough + " dough, " + dish + " dishes");

            if (dough == 0 || dish == 0) {
                BotLogger.warn("Out of materials!");
                closeBank();
                return false;
            }

            // Withdraw
            withdraw("Pastry dough", 14);
            Sleep.sleep(200);
            withdraw("Pie dish", 14);
            Sleep.sleep(300);

            closeBank();
            return true;

        } catch (Exception e) {
            closeBank();
            return false;
        }
    }

    public boolean getNotedShellsForSelling() {
        try {
            if (!openBank()) return false;

            Sleep.sleep(300);
            depositAllInventory();
            Sleep.sleep(200);

            int shells = Bank.count("Pie shell");

            if (shells == 0) {
                closeBank();
                return false;
            }

            BotLogger.info("Getting " + shells + " shells (noted)");
            withdrawNoted("Pie shell", shells);

            Sleep.sleep(300);
            closeBank();
            return true;

        } catch (Exception e) {
            closeBank();
            return false;
        }
    }

    public boolean completeBankingCycle(String a, String b, int c, String d, int e) {
        return smartBankForProduction();
    }
}
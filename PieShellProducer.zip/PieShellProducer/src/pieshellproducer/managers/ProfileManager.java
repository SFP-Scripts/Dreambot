package pieshellproducer.profile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import pieshellproducer.utils.BotLogger;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Profile system for saving and loading bot configurations
 */
public class ProfileManager {

    private static final String PROFILES_FOLDER = System.getProperty("user.home") + "/.dreambot/scripts/PieShellProducer/profiles/";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public static class Profile {
        public String profileName;
        public String muleName;
        public int pastryDoughToBuy;
        public int pieDishToBuy;
        public int pastryDoughPrice;
        public int pieDishPrice;
        public int pieShellSellPrice;
        public int priceIncreasePercent;
        public int sellThreshold;
        public int minCoins;
        public boolean smartMouseEnabled;
        public boolean progressiveBuyingEnabled;
        public boolean progressiveSellingEnabled;
        public boolean mulingEnabled;
        public boolean debugLoggingEnabled;

        public Profile() {
            // Defaults
            this.profileName = "Default";
            this.muleName = "";
            this.pastryDoughToBuy = 200;
            this.pieDishToBuy = 200;
            this.pastryDoughPrice = 170;
            this.pieDishPrice = 40;
            this.pieShellSellPrice = 150;
            this.priceIncreasePercent = 5;
            this.sellThreshold = 100;
            this.minCoins = 50000;
            this.smartMouseEnabled = false;
            this.progressiveBuyingEnabled = true;
            this.progressiveSellingEnabled = true;
            this.mulingEnabled = false;
            this.debugLoggingEnabled = false;
        }
    }

    /**
     * Save profile to disk
     */
    public static boolean saveProfile(Profile profile) {
        try {
            File folder = new File(PROFILES_FOLDER);
            if (!folder.exists()) {
                folder.mkdirs();
            }

            String filename = profile.profileName.replaceAll("[^a-zA-Z0-9]", "_") + ".json";
            File file = new File(PROFILES_FOLDER + filename);

            try (FileWriter writer = new FileWriter(file)) {
                gson.toJson(profile, writer);
                BotLogger.info("Profile saved: " + profile.profileName);
                return true;
            }
        } catch (Exception e) {
            BotLogger.error("Failed to save profile", e);
            return false;
        }
    }

    /**
     * Load profile from disk
     */
    public static Profile loadProfile(String profileName) {
        try {
            String filename = profileName.replaceAll("[^a-zA-Z0-9]", "_") + ".json";
            File file = new File(PROFILES_FOLDER + filename);

            if (!file.exists()) {
                BotLogger.warn("Profile not found: " + profileName);
                return null;
            }

            try (FileReader reader = new FileReader(file)) {
                Profile profile = gson.fromJson(reader, Profile.class);
                BotLogger.info("Profile loaded: " + profileName);
                return profile;
            }
        } catch (Exception e) {
            BotLogger.error("Failed to load profile", e);
            return null;
        }
    }

    /**
     * List all saved profiles
     */
    public static List<String> listProfiles() {
        List<String> profiles = new ArrayList<>();
        File folder = new File(PROFILES_FOLDER);

        if (!folder.exists()) {
            return profiles;
        }

        File[] files = folder.listFiles((dir, name) -> name.endsWith(".json"));
        if (files != null) {
            for (File file : files) {
                String name = file.getName().replace(".json", "").replace("_", " ");
                profiles.add(name);
            }
        }

        return profiles;
    }

    /**
     * Delete a profile
     */
    public static boolean deleteProfile(String profileName) {
        try {
            String filename = profileName.replaceAll("[^a-zA-Z0-9]", "_") + ".json";
            File file = new File(PROFILES_FOLDER + filename);

            if (file.exists() && file.delete()) {
                BotLogger.info("Profile deleted: " + profileName);
                return true;
            }
            return false;
        } catch (Exception e) {
            BotLogger.error("Failed to delete profile", e);
            return false;
        }
    }
}
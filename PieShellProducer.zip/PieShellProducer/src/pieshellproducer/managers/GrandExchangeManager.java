package pieshellproducer.managers;

import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import pieshellproducer.antiban.AntiBanManager;
import pieshellproducer.constants.GameConstants;
import pieshellproducer.mouse.SmartMouseIntegration;
import pieshellproducer.utils.BotLogger;
import pieshellproducer.utils.ProfitTracker;

import java.awt.Point;
import java.util.HashMap;
import java.util.Map;

/**
 * REPLACE YOUR EXISTING GrandExchangeManager.java WITH THIS FILE
 *
 * Enhanced with:
 * - Progressive buying (prevents GE loops)
 * - Error handling and retries
 * - SmartMouse integration
 * - Price tracking
 * - Profit integration
 */
public class GrandExchangeManager {

    private final Map<String, Integer> itemPrices;
    private final AntiBanManager antiBan;
    private final SmartMouseIntegration smartMouse;
    private final ProfitTracker profitTracker;
    private boolean progressiveBuyingEnabled;
    private boolean progressiveSellingEnabled;

    // Retry tracking
    private int consecutiveFailures = 0;
    private static final int MAX_RETRIES = 3;

    public GrandExchangeManager(AntiBanManager antiBan, SmartMouseIntegration smartMouse,
                                ProfitTracker profitTracker, boolean progressiveBuying, boolean progressiveSelling) {
        this.antiBan = antiBan;
        this.smartMouse = smartMouse;
        this.profitTracker = profitTracker;
        this.progressiveBuyingEnabled = progressiveBuying;
        this.progressiveSellingEnabled = progressiveSelling;
        this.itemPrices = new HashMap<>();
        initializeItemPrices();
    }

    private void initializeItemPrices() {
        // Base prices - will be updated from actual transactions
        itemPrices.put("Pastry dough", 100);
        itemPrices.put("Pie dish", 50);
        itemPrices.put("Pie shell", 150);
        itemPrices.put("Fish food", 50);
        itemPrices.put("Poison", 100);
        itemPrices.put("Spade", 100);
        itemPrices.put("Amulet of defence", 500);
        itemPrices.put("Blue dye", 200);
        itemPrices.put("Bowl", 50);
        itemPrices.put("Chaos rune", 100);
        itemPrices.put("Emerald amulet", 500);
    }

    /**
     * Set custom price for an item (called from Main with config prices)
     */
    public void setItemPrice(String itemName, int price) {
        itemPrices.put(itemName, price);
        BotLogger.info("Set base price for " + itemName + ": " + price + "gp");
    }

    public boolean openGrandExchange() {
        if (GrandExchange.isOpen()) {
            BotLogger.debug("GE already open");
            return true;
        }

        try {
            // Check if we're at GE
            boolean atGE = GameConstants.GRAND_EXCHANGE_AREA.contains(Players.getLocal());

            if (!atGE) {
                BotLogger.info("Not at Grand Exchange - walking there...");
                if (!walkToGrandExchange()) {
                    BotLogger.error("Failed to walk to Grand Exchange");
                    return false;
                }
            }

            // Try to find GE booth
            GameObject booth = GameObjects.closest(obj ->
                    obj != null && obj.getName() != null &&
                            obj.getName().contains("Grand Exchange") &&
                            obj.hasAction("Exchange")
            );

            if (booth != null && booth.distance() < 15) {
                BotLogger.debug("Found GE booth at distance: " + booth.distance());

                // Walk closer if needed
                if (booth.distance() > 6) {
                    BotLogger.debug("Walking closer to booth...");
                    Walking.walk(booth);
                    Sleep.sleepUntil(() -> booth.distance() < 6 || GrandExchange.isOpen(), 8000);
                }

                if (!GrandExchange.isOpen()) {
                    // Interact with booth using SmartMouse
                    if (smartMouse != null && smartMouse.isEnabled()) {
                        Point boothPoint = booth.getClickablePoint();
                        if (boothPoint != null) {
                            smartMouse.smartClick(boothPoint, "Exchange GE Booth");
                        } else {
                            booth.interact("Exchange");
                        }
                    } else {
                        booth.interact("Exchange");
                    }

                    boolean opened = Sleep.sleepUntil(GrandExchange::isOpen, 6000);
                    if (opened) {
                        BotLogger.debug("Opened GE via booth");
                        return true;
                    }
                }
            }

            // If booth didn't work, try NPC clerk
            NPC clerk = NPCs.closest(npc ->
                    npc != null && npc.getName() != null &&
                            npc.getName().contains("Grand Exchange Clerk")
            );

            if (clerk != null && clerk.distance() < 15) {
                BotLogger.debug("Found GE clerk at distance: " + clerk.distance());

                // Walk closer if needed
                if (clerk.distance() > 4) {
                    BotLogger.debug("Walking closer to clerk...");
                    Walking.walk(clerk);
                    Sleep.sleepUntil(() -> clerk.distance() < 4 || GrandExchange.isOpen(), 8000);
                }

                if (!GrandExchange.isOpen()) {
                    // Interact with clerk using SmartMouse
                    if (smartMouse != null && smartMouse.isEnabled()) {
                        Point clerkPoint = clerk.getClickablePoint();
                        if (clerkPoint != null) {
                            smartMouse.smartClick(clerkPoint, "Talk to Clerk");
                        } else {
                            clerk.interact("Exchange");
                        }
                    } else {
                        clerk.interact("Exchange");
                    }

                    boolean opened = Sleep.sleepUntil(GrandExchange::isOpen, 6000);
                    if (opened) {
                        BotLogger.debug("Opened GE via clerk");
                        return true;
                    }
                }
            }

            BotLogger.error("Could not open GE - booth/clerk not found or unresponsive");
            return false;

        } catch (Exception e) {
            BotLogger.error("Error opening GE", e);
            return false;
        }
    }

    /**
     * Walk to Grand Exchange using web walking - PUBLIC method for Main.java
     */
    public boolean walkToGrandExchange() {
        try {
            BotLogger.info("Walking to Varrock Grand Exchange...");

            // Use web walking to GE center area
            boolean walked = Walking.walk(GameConstants.GE_CENTER_AREA.getRandomTile());

            if (!walked) {
                BotLogger.warn("Web walking failed, trying again...");
                Sleep.sleep(1000);
                walked = Walking.walk(GameConstants.GE_CENTER_AREA.getRandomTile());
            }

            if (!walked) {
                BotLogger.error("Could not initiate walk to GE");
                return false;
            }

            // Wait until we're at GE
            boolean arrived = Sleep.sleepUntil(() ->
                            GameConstants.GRAND_EXCHANGE_AREA.contains(Players.getLocal()),
                    30000
            );

            if (arrived) {
                BotLogger.info("Arrived at Grand Exchange");
                return true;
            } else {
                BotLogger.warn("Did not arrive at GE within timeout");
                return false;
            }

        } catch (Exception e) {
            BotLogger.error("Error walking to GE", e);
            return false;
        }
    }

    /**
     * Calculate affordable quantity based on available coins (minus reserve)
     */
    private int calculateAffordableQuantity(String itemName, int requestedQuantity, int totalCoins, int coinReserve) {
        int availableForPurchase = totalCoins - coinReserve;

        if (availableForPurchase < 1000) {
            BotLogger.warn("Insufficient coins after reserve (" + totalCoins + " - " + coinReserve + " = " + availableForPurchase + ")");
            return 0;
        }

        int basePrice = itemPrices.getOrDefault(itemName, 100);
        int estimatedPrice = (int)(basePrice * 1.5); // Assume 50% markup for safety

        int maxAffordable = availableForPurchase / estimatedPrice;

        // Use 80% of max to leave buffer for price fluctuations
        int safeQuantity = (int)(maxAffordable * 0.8);

        int actualQuantity = Math.min(safeQuantity, requestedQuantity);

        BotLogger.debug("Affordable calc - Total coins: " + totalCoins + ", Reserve: " + coinReserve +
                ", Available: " + availableForPurchase + ", Requested: " + requestedQuantity +
                ", Max: " + maxAffordable + ", Safe: " + safeQuantity + ", Actual: " + actualQuantity);

        return Math.max(1, actualQuantity); // Always buy at least 1
    }

    /**
     * Buy item with progressive quantity calculation and price adjustment retries
     * Uses ONLY slot 0 and retries with custom % price increases until successful
     */
    public boolean buyItemProgressive(String itemName, int requestedQuantity, double initialPriceMultiplier,
                                      int coinReserve, int priceIncreasePercent) {
        try {
            if (!openGrandExchange()) {
                BotLogger.error("Failed to open Grand Exchange for buying");
                return false;
            }

            antiBan.humanWait(400);

            // CRITICAL: Clear ALL slots if any contain items - ensures clean slate
            boolean clearedSlots = false;
            for (int slot = 0; slot < 8; slot++) {
                if (GrandExchange.slotContainsItem(slot)) {
                    BotLogger.info("Clearing slot " + slot + " (contains item from previous offer)");
                    GrandExchange.cancelOffer(slot);
                    Sleep.sleep(antiBan.randomDelay(300, 500));
                    GrandExchange.collect();
                    Sleep.sleep(antiBan.randomDelay(200, 400));
                    clearedSlots = true;
                }
            }

            if (clearedSlots) {
                BotLogger.info("All slots cleared - using slot 0 only");
                Sleep.sleep(antiBan.randomDelay(500, 800));
            }

            // Get available coins
            int totalCoins = Inventory.count("Coins");
            if (Bank.isOpen()) {
                totalCoins += Bank.count("Coins");
            }

            int actualQuantity = requestedQuantity;

            // Apply progressive buying if enabled
            if (progressiveBuyingEnabled) {
                actualQuantity = calculateAffordableQuantity(itemName, requestedQuantity, totalCoins, coinReserve);

                if (actualQuantity == 0) {
                    BotLogger.error("Cannot afford any " + itemName + " with current coins (" + totalCoins + ") and reserve (" + coinReserve + ")");
                    return false;
                }

                if (actualQuantity < requestedQuantity) {
                    BotLogger.warn("Progressive buy - reducing " + itemName + " from " +
                            requestedQuantity + " to " + actualQuantity + " (coins: " + totalCoins + ", reserve: " + coinReserve + ")");
                }
            }

            int basePrice = itemPrices.getOrDefault(itemName, 100);
            double currentPriceMultiplier = initialPriceMultiplier;
            int maxRetries = 5;
            int currentRetry = 0;
            double priceIncrement = priceIncreasePercent / 100.0; // Convert percent to decimal

            while (currentRetry < maxRetries) {
                // Cancel any existing offer in slot 0
                if (GrandExchange.slotContainsItem(0)) {
                    BotLogger.info("Cancelling previous offer in slot 0");
                    GrandExchange.cancelOffer(0);
                    Sleep.sleep(antiBan.randomDelay(400, 600));
                    GrandExchange.collect();
                    Sleep.sleep(antiBan.randomDelay(300, 500));
                }

                // Calculate offer price with current multiplier
                int offerPrice = Math.max(1, (int)(basePrice * currentPriceMultiplier));

                int markupPercent = (int)((currentPriceMultiplier - 1.0) * 100);
                BotLogger.info("Buy attempt " + (currentRetry + 1) + "/" + maxRetries +
                        ": " + actualQuantity + "x " + itemName +
                        " @ " + offerPrice + "gp (" + markupPercent + "% markup, base: " + basePrice + "gp)");

                // Verify GE is still open
                if (!GrandExchange.isOpen()) {
                    BotLogger.error("GE closed unexpectedly, reopening...");
                    if (!openGrandExchange()) {
                        BotLogger.error("Failed to reopen GE");
                        return false;
                    }
                }

                // Place offer
                BotLogger.debug("Attempting to place buy offer: " + itemName + " x" + actualQuantity + " @ " + offerPrice + "gp");
                boolean offerPlaced = GrandExchange.buyItem(itemName, actualQuantity, offerPrice);
                BotLogger.debug("GrandExchange.buyItem() returned: " + offerPlaced);

                if (offerPlaced) {
                    BotLogger.info("Offer placed successfully, waiting for completion...");
                    antiBan.humanWait(600);

                    // Wait for offer (shorter timeout for retries)
                    int waitTime = currentRetry == 0 ? 30000 : 15000; // 30s first try, 15s retries
                    boolean completed = waitForOffer(0, antiBan.randomDelay(waitTime, waitTime + 5000));

                    if (completed) {
                        // Success!
                        itemPrices.put(itemName, offerPrice);

                        // Record in profit tracker
                        if (itemName.equals("Pastry dough")) {
                            profitTracker.recordDoughPurchase(actualQuantity, offerPrice);
                        } else if (itemName.equals("Pie dish")) {
                            profitTracker.recordDishPurchase(actualQuantity, offerPrice);
                        }

                        BotLogger.info("Buy successful at " + offerPrice + "gp each");
                        consecutiveFailures = 0;
                        return true;
                    } else {
                        // Offer didn't complete - collect partial and retry with higher price
                        BotLogger.warn("Buy offer didn't complete, collecting partial...");
                        GrandExchange.collect();
                        Sleep.sleep(antiBan.randomDelay(500, 800));

                        // Increase price by configured percent for next retry
                        currentPriceMultiplier += priceIncrement;
                        currentRetry++;

                        if (currentRetry < maxRetries) {
                            BotLogger.info("Retrying with +" + priceIncreasePercent + "% higher price...");
                            Sleep.sleep(antiBan.randomDelay(1000, 2000));
                        }
                    }
                } else {
                    BotLogger.error("Failed to place buy offer for " + itemName);
                    BotLogger.error("GE Status: isOpen=" + GrandExchange.isOpen() +
                            ", Coins in inv=" + Inventory.count("Coins") +
                            ", Quantity=" + actualQuantity +
                            ", Price=" + offerPrice);

                    // Try to close and reopen GE
                    if (GrandExchange.isOpen()) {
                        GrandExchange.close();
                        Sleep.sleep(1000);
                    }

                    if (openGrandExchange()) {
                        BotLogger.info("Reopened GE, retrying offer...");
                        Sleep.sleep(antiBan.randomDelay(500, 800));
                        // Don't return false yet, let it retry
                        currentRetry++;
                        if (currentRetry >= maxRetries) {
                            BotLogger.error("Max retries reached after GE failures");
                            return false;
                        }
                    } else {
                        BotLogger.error("Cannot reopen GE");
                        return false;
                    }
                }
            }

            // All retries exhausted
            BotLogger.error("Buy failed after " + maxRetries + " attempts");
            handleFailedOffer();
            return false;

        } catch (Exception e) {
            BotLogger.error("Error in buyItemProgressive", e);
            return false;
        }
    }

    /**
     * Backward compatible version with coin reserve (uses default 5% increase)
     */
    public boolean buyItemProgressive(String itemName, int requestedQuantity, double initialPriceMultiplier, int coinReserve) {
        return buyItemProgressive(itemName, requestedQuantity, initialPriceMultiplier, coinReserve, 5);
    }

    /**
     * Backward compatible version without coin reserve (assumes 0 reserve, 5% increase)
     */
    public boolean buyItemProgressive(String itemName, int requestedQuantity, double initialPriceIncrease) {
        return buyItemProgressive(itemName, requestedQuantity, initialPriceIncrease, 0, 5);
    }

    /**
     * Buy item with instant pricing (2x base)
     */
    public boolean buyItemInstant(String itemName, int quantity) {
        return buyItemProgressive(itemName, quantity, 1.0); // 100% increase = 2x price
    }

    /**
     * Buy item with standard pricing
     */
    public boolean buyItemWithIncrease(String itemName, int quantity, double priceIncrease) {
        return buyItemProgressive(itemName, quantity, priceIncrease);
    }

    /**
     * Sell item with progressive pricing - lowers price by custom % each retry
     * Uses ONLY slot 0 for all attempts
     */
    public boolean sellItemInstant(String itemName, int quantity, int priceDecreasePercent) {
        try {
            if (!openGrandExchange()) {
                BotLogger.error("Failed to open GE for selling");
                return false;
            }

            antiBan.humanWait(400);

            int basePrice = itemPrices.getOrDefault(itemName, 100);
            double currentPriceMultiplier;

            if (progressiveSellingEnabled) {
                currentPriceMultiplier = 1.0; // Start at 100% for progressive
            } else {
                currentPriceMultiplier = 0.80; // Start at 80% for instant
            }

            int maxRetries = 5;
            int currentRetry = 0;
            double priceDecrement = priceDecreasePercent / 100.0; // Convert percent to decimal

            while (currentRetry < maxRetries) {
                // Cancel any existing offer in slot 0
                if (GrandExchange.slotContainsItem(0)) {
                    BotLogger.info("Cancelling previous sell offer in slot 0");
                    GrandExchange.cancelOffer(0);
                    Sleep.sleep(antiBan.randomDelay(400, 600));
                    GrandExchange.collect();
                    Sleep.sleep(antiBan.randomDelay(300, 500));
                }

                // Calculate offer price
                int sellPrice = Math.max(1, (int)(basePrice * currentPriceMultiplier));

                BotLogger.info("Sell attempt " + (currentRetry + 1) + "/" + maxRetries +
                        ": " + quantity + "x " + itemName +
                        " @ " + sellPrice + "gp (" + (int)(currentPriceMultiplier * 100) + "% of base " + basePrice + "gp)");

                // Place sell offer
                if (GrandExchange.sellItem(itemName, quantity, sellPrice)) {
                    antiBan.humanWait(600);

                    // Wait for offer
                    int waitTime = currentRetry == 0 ? 30000 : 15000;
                    boolean completed = waitForOffer(0, antiBan.randomDelay(waitTime, waitTime + 5000));

                    if (completed) {
                        // Success!
                        if (itemName.equals("Pie shell")) {
                            profitTracker.recordShellSale(quantity, sellPrice);
                        }

                        BotLogger.info("Sell successful at " + sellPrice + "gp each");
                        consecutiveFailures = 0;
                        return true;
                    } else {
                        // Offer didn't complete - collect partial and retry with lower price
                        BotLogger.warn("Sell offer didn't complete, collecting partial...");
                        GrandExchange.collect();
                        Sleep.sleep(antiBan.randomDelay(500, 800));

                        // Decrease price by configured percent for next retry
                        currentPriceMultiplier -= priceDecrement;
                        currentRetry++;

                        if (currentRetry < maxRetries) {
                            BotLogger.info("Retrying with -" + priceDecreasePercent + "% lower price...");
                            Sleep.sleep(antiBan.randomDelay(1000, 2000));
                        }
                    }
                } else {
                    BotLogger.error("Failed to place sell offer");
                    return false;
                }
            }

            // All retries exhausted
            BotLogger.error("Sell failed after " + maxRetries + " attempts");
            handleFailedOffer();
            return false;

        } catch (Exception e) {
            BotLogger.error("Error in sellItemInstant", e);
            return false;
        }
    }

    /**
     * Backward compatible version (uses default 5% decrease)
     */
    public boolean sellItemInstant(String itemName, int quantity) {
        return sellItemInstant(itemName, quantity, 5);
    }

    /**
     * Wait for GE offer to complete
     */
    public boolean waitForOffer(int slot, int timeoutMs) {
        try {
            return Sleep.sleepUntil(() ->
                            !GrandExchange.slotContainsItem(slot) || GrandExchange.isReadyToCollect(slot),
                    timeoutMs
            );
        } catch (Exception e) {
            BotLogger.error("Error waiting for offer", e);
            return false;
        }
    }

    /**
     * Collect all completed offers
     */
    /**
     * Collect all completed offers - ensures GE is open first
     */
    public void collectAll() {
        try {
            if (!GrandExchange.isOpen()) {
                BotLogger.warn("GE not open for collecting, opening it...");
                if (!openGrandExchange()) {
                    BotLogger.error("Failed to open GE for collecting");
                    return;
                }
            }

            Sleep.sleep(antiBan.randomDelay(300, 500));

            int collectCount = 0;
            for (int slot = 0; slot < 8; slot++) {
                try {
                    if (GrandExchange.isReadyToCollect(slot)) {
                        if (GrandExchange.collect()) {
                            collectCount++;
                            BotLogger.debug("Collected from slot " + slot);
                            Sleep.sleep(antiBan.randomDelay(400, 700));
                        }
                    }
                } catch (Exception e) {
                    BotLogger.debug("Error collecting slot " + slot + ": " + e.getMessage());
                }
            }

            if (collectCount > 0) {
                BotLogger.info("Collected from " + collectCount + " slot(s)");
            } else {
                BotLogger.debug("No items to collect");
            }

        } catch (Exception e) {
            BotLogger.error("Error in collectAll", e);
        }
    }

    /**
     * Cancel all pending offers
     */
    public void cancelPendingOffers() {
        if (!GrandExchange.isOpen()) {
            return;
        }

        try {
            int cancelCount = 0;
            for (int slot = 0; slot < 8; slot++) {
                if (GrandExchange.slotContainsItem(slot)) {
                    GrandExchange.cancelOffer(slot);
                    Sleep.sleep(antiBan.randomDelay(300, 500));
                    cancelCount++;
                }
            }

            if (cancelCount > 0) {
                BotLogger.info("Cancelled " + cancelCount + " pending offers");
            }
        } catch (Exception e) {
            BotLogger.error("Error cancelling offers", e);
        }
    }

    /**
     * Handle failed offer (retry or cancel)
     */
    private void handleFailedOffer() {
        consecutiveFailures++;

        if (consecutiveFailures >= MAX_RETRIES) {
            BotLogger.warn("Max retries reached, cancelling pending offers");
            cancelPendingOffers();
            collectAll();
            consecutiveFailures = 0;
        } else {
            BotLogger.info("Retry " + consecutiveFailures + " of " + MAX_RETRIES);
        }
    }

    /**
     * Sell and collect in one operation with custom price decrease
     */
    public boolean sellAndCollect(String itemName, int quantity, int priceDecreasePercent) {
        if (!sellItemInstant(itemName, quantity, priceDecreasePercent)) {
            return false;
        }

        collectAll();
        return true;
    }

    /**
     * Backward compatible version (uses default 5% decrease)
     */
    public boolean sellAndCollect(String itemName, int quantity) {
        return sellAndCollect(itemName, quantity, 5);
    }

    public void setProgressiveBuyingEnabled(boolean enabled) {
        this.progressiveBuyingEnabled = enabled;
        BotLogger.info("Progressive buying " + (enabled ? "enabled" : "disabled"));
    }

    public boolean isProgressiveBuyingEnabled() {
        return progressiveBuyingEnabled;
    }

    public void setProgressiveSellingEnabled(boolean enabled) {
        this.progressiveSellingEnabled = enabled;
        BotLogger.info("Progressive selling " + (enabled ? "enabled" : "disabled"));
    }

    public boolean isProgressiveSellingEnabled() {
        return progressiveSellingEnabled;
    }
}
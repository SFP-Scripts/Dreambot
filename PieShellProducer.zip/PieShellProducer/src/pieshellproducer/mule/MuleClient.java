package pieshellproducer.mule;

import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.trade.Trade;
import org.dreambot.api.methods.trade.TradeUser;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Player;
import pieshellproducer.antiban.AntiBanManager;
import pieshellproducer.mouse.SmartMouseIntegration;
import pieshellproducer.utils.BotLogger;

import java.awt.Point;

/**
 * REPLACE YOUR MuleClient.java WITH THIS FILE
 *
 * FIXED: Uses correct DreamBot 4 Trade API
 * - Trade.hasAcceptedTrade(TradeUser.US) - Check if WE accepted
 * - Trade.hasAcceptedTrade(TradeUser.THEM) - Check if THEY accepted
 * - Trade.acceptTrade() - Accept the trade
 */
public class MuleClient {

    private final AntiBanManager antiBan;
    private final SmartMouseIntegration smartMouse;
    private String muleName;
    private boolean mulingEnabled;

    public MuleClient(AntiBanManager antiBan, SmartMouseIntegration smartMouse) {
        this.antiBan = antiBan;
        this.smartMouse = smartMouse;
        this.mulingEnabled = false;
    }

    public void setMuleName(String muleName) {
        this.muleName = muleName;
        BotLogger.info("Mule name set to: " + muleName);
    }

    public void setMulingEnabled(boolean enabled) {
        this.mulingEnabled = enabled;
        BotLogger.info("Muling " + (enabled ? "enabled" : "disabled"));
    }

    /**
     * Accept trade request from mule
     */
    public boolean acceptTradeFromMule() {
        if (!mulingEnabled || muleName == null || muleName.isEmpty()) {
            BotLogger.debug("Muling not enabled or no mule name set");
            return false;
        }

        try {
            // Check if we have a pending trade from the mule
            if (Trade.isOpen(1) || Trade.isOpen(2)) {
                BotLogger.debug("Trade already open");
                return true;
            }

            // Check for mule nearby
            Player mule = Players.closest(p ->
                    p != null && p.getName() != null &&
                            p.getName().equalsIgnoreCase(muleName)
            );

            if (mule == null) {
                return false;
            }

            // If mule is nearby and we're not in trade, they might be requesting
            BotLogger.debug("Mule nearby: " + muleName);

            // Wait a bit for trade screen
            Sleep.sleep(1000);

            if (Trade.isOpen(1)) {
                BotLogger.info("Trade opened with mule");
                return true;
            }

            return false;

        } catch (Exception e) {
            BotLogger.error("Error accepting trade from mule", e);
            return false;
        }
    }

    /**
     * Complete trade with mule (receive items/coins)
     * FIXED: Uses correct DreamBot 4 API with TradeUser enum
     */
    public boolean completeMuleTrade() {
        if (!Trade.isOpen()) {
            return false;
        }

        try {
            BotLogger.info("=== MULE TRADE: Receiving Items ===");

            // Wait for mule to offer items
            Sleep.sleep(antiBan.randomDelay(1000, 2000));

            // Check what mule is offering
            int itemsOffered = 0;
            try {
                if (Trade.getTheirItems() != null) {
                    itemsOffered = Trade.getTheirItems().length;
                    BotLogger.info("Mule offering " + itemsOffered + " item slots");
                }
            } catch (Exception e) {
                BotLogger.debug("Could not check mule items: " + e.getMessage());
            }

            // Accept first screen - DreamBot 4 uses TradeUser.US and TradeUser.THEM
            if (Trade.isOpen(1) && !Trade.hasAcceptedTrade(TradeUser.US)) {
                BotLogger.info("Accepting trade (first screen)...");

                if (Trade.acceptTrade()) {
                    Sleep.sleepUntil(() -> Trade.hasAcceptedTrade(TradeUser.US), 5000);
                    BotLogger.info("First screen accepted");
                } else {
                    BotLogger.error("Failed to accept first screen");
                    return false;
                }
            }

            // Wait for mule to accept - TradeUser.THEM for opponent
            if (!Trade.hasAcceptedTrade(TradeUser.THEM)) {
                BotLogger.info("Waiting for mule to accept...");
                Sleep.sleepUntil(() -> Trade.hasAcceptedTrade(TradeUser.THEM), 10000);
            }

            // Accept second screen
            if (Trade.isOpen(2)) {
                BotLogger.info("Accepting trade (second screen)...");
                Sleep.sleep(antiBan.randomDelay(1000, 1500));

                if (Trade.acceptTrade()) {
                    Sleep.sleepUntil(() -> !Trade.isOpen(), 10000);

                    if (!Trade.isOpen()) {
                        BotLogger.info("=== MULE TRADE COMPLETE ===");
                        BotLogger.info("Received items from mule successfully");
                        return true;
                    }
                }
            }

            return false;

        } catch (Exception e) {
            BotLogger.error("Error completing mule trade", e);
            return false;
        }
    }

    /**
     * Request trade with mule (client initiates)
     */
    public boolean requestTradeWithMule() {
        if (!mulingEnabled || muleName == null || muleName.isEmpty()) {
            return false;
        }

        try {
            Player mule = Players.closest(p ->
                    p != null && p.getName() != null && p.getName().equalsIgnoreCase(muleName)
            );

            if (mule == null) {
                BotLogger.warn("Mule not found: " + muleName);
                return false;
            }

            BotLogger.info("Found mule: " + muleName + " at distance " + mule.distance());

            // Use SmartMouse if enabled
            if (smartMouse != null && smartMouse.isEnabled()) {
                Point mulePoint = mule.getClickablePoint();
                if (mulePoint != null) {
                    smartMouse.smartClick(mulePoint, "Trade with " + muleName);
                } else {
                    mule.interact("Trade with");
                }
            } else {
                mule.interact("Trade with");
            }

            boolean tradeOpened = Sleep.sleepUntil(() -> Trade.isOpen(1), 10000);

            if (tradeOpened) {
                BotLogger.info("Trade opened with mule");
                return true;
            } else {
                BotLogger.warn("Failed to open trade with mule");
                return false;
            }

        } catch (Exception e) {
            BotLogger.error("Error requesting trade with mule", e);
            return false;
        }
    }

    /**
     * Check if mule is nearby
     */
    public boolean isMuleNearby() {
        if (muleName == null || muleName.isEmpty()) {
            return false;
        }

        Player mule = Players.closest(p ->
                p != null && p.getName() != null && p.getName().equalsIgnoreCase(muleName)
        );

        return mule != null && mule.distance() < 10;
    }
}
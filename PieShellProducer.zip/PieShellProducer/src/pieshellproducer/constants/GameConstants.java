package pieshellproducer.constants;

import org.dreambot.api.methods.map.Area;

/**
 * Game constants - Item IDs, Object IDs, and Locations
 */
public class GameConstants {

    // Item IDs
    public static final int COINS_ID = 995;
    public static final int PASTRY_DOUGH_ID = 1953;
    public static final int PIE_DISH_ID = 2313;
    public static final int PIE_SHELL_ID = 2315;

    // Grand Exchange
    public static final String GE_BOOTH_NAME = "Grand Exchange booth";
    public static final String GE_CLERK_NAME = "Grand Exchange Clerk";

    // Grand Exchange Areas
    public static final Area GRAND_EXCHANGE_AREA = new Area(3144, 3460, 3184, 3500, 0);
    public static final Area GE_CENTER_AREA = new Area(3160, 3485, 3170, 3492, 0);

    // Banks
    public static final Area VARROCK_WEST_BANK = new Area(3180, 3433, 3191, 3445, 0);
    public static final Area VARROCK_EAST_BANK = new Area(3250, 3416, 3257, 3424, 0);
    public static final String BANK_BOOTH_NAME = "Bank booth";
    public static final String BANKER_NAME = "Banker";
}
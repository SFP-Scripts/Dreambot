package pieshellproducer;

import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.utilities.Sleep;
import pieshellproducer.antiban.AntiBanManager;
import pieshellproducer.gui.ConfigGUI;
import pieshellproducer.managers.BankManager;
import pieshellproducer.managers.GrandExchangeManager;
import pieshellproducer.mouse.MouseManager;
import pieshellproducer.mouse.SmartMouseIntegration;
import pieshellproducer.production.PieShellProducer;
import pieshellproducer.state.BotState;
import pieshellproducer.state.StateManager;
import pieshellproducer.utils.BotLogger;
import pieshellproducer.utils.ProfitTracker;

import java.awt.*;

/**
 * MAIN SCRIPT - Save this as: Main.java
 * (DELETE the old pieshellproducer.java file)
 */
@ScriptManifest(
        name = "Pie Shell Producer",
        description = "Produces and sells pie shells with anti-detection",
        author = "YourName",
        version = 2.2,
        category = Category.MONEYMAKING
)
public class Main extends AbstractScript {

    private AntiBanManager antiBan;
    private MouseManager mouseManager;
    private SmartMouseIntegration smartMouse;
    private ProfitTracker profitTracker;
    private BankManager bankManager;
    private GrandExchangeManager geManager;
    private PieShellProducer producer;
    private StateManager stateManager;
    private pieshellproducer.mule.MuleClient muleClient;

    private ConfigGUI.ConfigData config;

    private int startingCooking;
    private int cookingGained = 0;

    private boolean initialized = false;
    private boolean walkedToGE = false;

    @Override
    public void onStart() {
        try {
            BotLogger.logStartup("Pie Shell Producer", "2.2");

            // Create GUI on Event Dispatch Thread to avoid threading violations
            final ConfigGUI[] guiHolder = new ConfigGUI[1];

            javax.swing.SwingUtilities.invokeLater(() -> {
                guiHolder[0] = new ConfigGUI();
                guiHolder[0].setVisible(true);
            });

            // Wait for GUI to be created
            Sleep.sleep(500);

            ConfigGUI gui = guiHolder[0];

            // Wait for user to complete configuration
            while (gui != null && gui.isVisible()) {
                Sleep.sleep(100);
            }

            if (gui == null || !gui.isConfigComplete()) {
                BotLogger.info("Configuration cancelled - stopping");
                stop();
                return;
            }

            config = gui.getConfig();

            initializeComponents();

            gui.setMouseDataStatus(
                    mouseManager.isMouseDataLoaded(),
                    mouseManager.getLoadedPath()
            );

            logConfiguration();

            startingCooking = Skills.getRealLevel(Skill.COOKING);

            initialized = true;
            BotLogger.info("Bot started successfully!");
            BotLogger.separator();

        } catch (Exception e) {
            BotLogger.error("Fatal error during startup", e);
            stop();
        }
    }

    private void initializeComponents() {
        BotLogger.info("Initializing components...");

        BotLogger.setDebugEnabled(config.debugLoggingEnabled);

        antiBan = new AntiBanManager(config.antiBanInterval);
        antiBan.setTabChecking(config.tabCheckingEnabled);
        antiBan.setMouseMovements(config.mouseMovementsEnabled);
        antiBan.setCameraMovements(config.cameraMovementsEnabled);
        antiBan.setRandomHovers(config.randomHoversEnabled);
        antiBan.setRandomPauses(config.randomPausesEnabled);
        BotLogger.info("Anti-ban configured");

        mouseManager = new MouseManager(config.smartMouseEnabled);
        mouseManager.initialize();
        smartMouse = mouseManager.getSmartMouse();
        BotLogger.info(mouseManager.getStatus());

        profitTracker = new ProfitTracker();

        bankManager = new BankManager(antiBan, smartMouse);

        geManager = new GrandExchangeManager(antiBan, smartMouse, profitTracker,
                config.progressiveBuyingEnabled, config.progressiveSellingEnabled);

        // Set custom starting prices from config
        geManager.setItemPrice("Pastry dough", config.pastryDoughPrice);
        geManager.setItemPrice("Pie dish", config.pieDishPrice);
        geManager.setItemPrice("Pie shell", config.pieShellSellPrice);

        // Set custom prices from config
        geManager.setItemPrice("Pastry dough", config.pastryDoughPrice);
        geManager.setItemPrice("Pie dish", config.pieDishPrice);
        geManager.setItemPrice("Pie shell", config.pieShellSellPrice);

        producer = new PieShellProducer(antiBan);
        producer.setSmartMouse(smartMouse);

        stateManager = new StateManager(producer, profitTracker, config.minCoins,
                config.sellThreshold,
                config.pastryDoughToBuy);

        // Initialize mule client if muling is enabled
        muleClient = new pieshellproducer.mule.MuleClient(antiBan, smartMouse);
        if (config.mulingEnabled && config.muleName != null && !config.muleName.isEmpty()) {
            muleClient.setMulingEnabled(true);
            muleClient.setMuleName(config.muleName);
            BotLogger.info("Mule client initialized for: " + config.muleName);
        }

        BotLogger.info("All components initialized!");
    }

    private void logConfiguration() {
        BotLogger.separator();
        BotLogger.info("=== CONFIGURATION ===");
        BotLogger.info("Profile: " + config.profileName);
        BotLogger.info("Materials: " + config.pastryDoughToBuy + " dough, " + config.pieDishToBuy + " dishes");
        BotLogger.info("Sell threshold: " + config.sellThreshold);
        BotLogger.info("Min coins: " + config.minCoins);
        BotLogger.separator();
        BotLogger.info("=== CUSTOM PRICING ===");
        BotLogger.info("Pastry Dough buy price: " + config.pastryDoughPrice + "gp");
        BotLogger.info("Pie Dish buy price: " + config.pieDishPrice + "gp");
        BotLogger.info("Pie Shell sell price: " + config.pieShellSellPrice + "gp");
        BotLogger.info("Price adjustment per retry: " + config.priceIncreasePercent + "%");
        BotLogger.separator();
        BotLogger.info("=== ANTI-DETECTION ===");
        BotLogger.info("SmartMouse: " + (config.smartMouseEnabled ? "Enabled" : "Disabled"));
        if (config.smartMouseEnabled) {
            if (mouseManager.isMouseDataLoaded()) {
                BotLogger.info("  STATUS: ✓ ACTIVE - SmartMouse data loaded successfully");
                BotLogger.info("  PATH: " + mouseManager.getLoadedPath());
            } else {
                BotLogger.warn("  STATUS: ✗ INACTIVE - SmartMouse enabled but no data found");
                BotLogger.warn("  Using default mouse movements");
            }
        }
        BotLogger.info("Tab Checking: " + (config.tabCheckingEnabled ? "On" : "Off"));
        BotLogger.info("Mouse Movements: " + (config.mouseMovementsEnabled ? "On" : "Off"));
        BotLogger.info("Random Hovers: " + (config.randomHoversEnabled ? "On" : "Off"));
        BotLogger.info("Micro Pauses: " + (config.randomPausesEnabled ? "On" : "Off"));
        BotLogger.info("Progressive Buying: " + (config.progressiveBuyingEnabled ? "On" : "Off"));
        BotLogger.info("Progressive Selling: " + (config.progressiveSellingEnabled ? "On" : "Off"));
        BotLogger.separator();
        if (config.mulingEnabled && config.muleName != null && !config.muleName.isEmpty()) {
            BotLogger.info("=== MULING ===");
            BotLogger.info("Muling: Enabled");
            BotLogger.info("Mule account: " + config.muleName);
            BotLogger.separator();
        }
    }

    @Override
    public int onLoop() {
        try {
            if (!initialized) {
                return 1000;
            }

            // Walk to Grand Exchange on first loop
            if (!walkedToGE) {
                BotLogger.separator();
                BotLogger.info("=== INITIAL SETUP ===");
                BotLogger.info("Walking to Grand Exchange from current location...");

                if (geManager.walkToGrandExchange()) {
                    BotLogger.info("✓ Arrived at Grand Exchange - ready to start");
                    walkedToGE = true;
                    BotLogger.separator();
                } else {
                    BotLogger.error("✗ Failed to walk to Grand Exchange");
                    BotLogger.info("Please manually walk closer to Varrock GE and restart");
                    Sleep.sleep(5000);
                    return 3000;
                }
            }

            antiBan.performAntiBan();

            if (config.afkMomentsEnabled) {
                antiBan.occasionalAfkMoment();
            }

            int currentCooking = Skills.getRealLevel(Skill.COOKING);
            cookingGained = currentCooking - startingCooking;

            BotState currentState = stateManager.determineNextState();

            // Special handling: if we're going to BANKING and bank is already open with coins,
            // the state determination will see this on next loop
            boolean stateSuccess = executeState(currentState);

            if (stateSuccess) {
                stateManager.resetRetryCount();
            } else {
                // Only increment retry if we actually failed
                // (not just "no materials but have coins" scenario)
                if (currentState == BotState.BANKING && Bank.isOpen()) {
                    // Bank is open from previous check - just continue to next loop
                    BotLogger.debug("Bank open, will recheck state on next loop");
                } else {
                    stateManager.handleStateFailure();
                }
            }

            return antiBan.randomDelay(600, 1200);

        } catch (Exception e) {
            BotLogger.error("Error in main loop", e);
            return 2000;
        }
    }

    private boolean executeState(BotState state) {
        switch (state) {
            case PRODUCING:
                return handleProduction();

            case BANKING:
                return handleBanking();

            case SELLING:
                return handleSelling();

            case BUYING:
                return handleBuying();

            case IDLE:
                Sleep.sleep(antiBan.randomDelay(2000, 4000));
                return true;

            case STOPPED:
                stop();
                return false;

            default:
                return false;
        }
    }

    private boolean handleProduction() {
        try {
            BotLogger.info("Starting production...");

            boolean success = producer.executeProductionCycle();

            if (success) {
                int shellsCreated = producer.getPieShellCount();
                profitTracker.recordProduction(shellsCreated);
                BotLogger.info("Created " + shellsCreated + " shells");
                return true;
            }

            return false;

        } catch (Exception e) {
            BotLogger.error("Error in production", e);
            return false;
        }
    }

    private boolean handleBanking() {
        try {
            BotLogger.info("Banking...");

            // First, open the bank to check what we have
            if (!bankManager.openBank()) {
                BotLogger.error("Failed to open bank");
                return false;
            }

            Sleep.sleep(antiBan.randomDelay(400, 600));

            // Check what's in the bank
            int dough = Bank.count("Pastry dough");
            int dish = Bank.count("Pie dish");
            int coins = Bank.count("Coins");

            BotLogger.info("Bank: " + dough + " dough, " + dish + " dishes, " + coins + " coins");

            // If we have materials in bank, withdraw them
            if (dough > 0 && dish > 0) {
                boolean success = bankManager.completeBankingCycle(
                        null, "Pastry dough", 14, "Pie dish", 14
                );

                if (success) {
                    BotLogger.info("Banking complete - withdrew materials");
                    return true;
                }
                return false;
            }

            // No materials in bank - check if we have coins to buy some
            if (coins >= config.minCoins) {
                BotLogger.info("No materials but have " + coins + " coins - leaving bank OPEN for state check");
                // DON'T close bank - leave it open so StateManager can see coins
                // This allows the next state check to properly count bank coins
                return false; // Return false to allow state transition
            }

            // No materials and not enough coins
            BotLogger.warn("Out of materials and insufficient coins in bank!");
            bankManager.closeBank();
            return false;

        } catch (Exception e) {
            BotLogger.error("Error in banking", e);
            return false;
        }
    }

    private boolean handleSelling() {
        try {
            BotLogger.info("=== SELLING PHASE: Converting Shells to Coins ===");

            // Step 1: Count shells in inventory
            int shellCount = Inventory.count("Pie shell");

            // Step 2: If no shells in inventory, check bank
            if (shellCount == 0) {
                BotLogger.info("No shells in inventory, checking bank...");

                if (!bankManager.openBank()) {
                    BotLogger.error("ERROR: Failed to open bank");
                    return false;
                }

                shellCount = Bank.count("Pie shell");
                BotLogger.info("Found " + shellCount + " shells in bank");

                if (shellCount == 0) {
                    BotLogger.warn("WARNING: No shells to sell in bank or inventory");
                    bankManager.closeBank();
                    return false;
                }

                // Deposit everything, then withdraw shells
                bankManager.depositAllInventory();
                Sleep.sleep(antiBan.randomDelay(400, 600));

                if (!Bank.withdraw("Pie shell", shellCount)) {
                    BotLogger.error("ERROR: Failed to withdraw shells from bank");
                    bankManager.closeBank();
                    return false;
                }

                Sleep.sleep(antiBan.randomDelay(800, 1200));
                shellCount = Inventory.count("Pie shell");
                BotLogger.info("SUCCESS: Withdrew " + shellCount + " shells to inventory");

                bankManager.closeBank();
                Sleep.sleep(antiBan.randomDelay(400, 700));
            }

            if (shellCount == 0) {
                BotLogger.error("ERROR: Still no shells to sell after checking bank");
                return false;
            }

            // Step 3: Record coins before selling
            int coinsBefore = Inventory.count("Coins");
            BotLogger.info("Coins before selling: " + coinsBefore);
            BotLogger.info("Selling " + shellCount + " pie shells to fund next production cycle");

            // Step 4: Sell shells
            boolean success = geManager.sellAndCollect("Pie shell", shellCount, config.priceIncreasePercent);

            if (!success) {
                BotLogger.error("ERROR: Failed to sell shells");
                BotLogger.info("RECOVERY: Shells remain in inventory, will retry");
                return false;
            }

            // Step 5: Close GE and verify coins received
            if (GrandExchange.isOpen()) {
                GrandExchange.close();
                Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 3000);
                BotLogger.info("SUCCESS: Closed Grand Exchange");
            }

            Sleep.sleep(antiBan.randomDelay(600, 900));

            int coinsAfter = Inventory.count("Coins");
            int coinsGained = coinsAfter - coinsBefore;

            BotLogger.info("=== SELLING COMPLETE ===");
            BotLogger.info("Sold: " + shellCount + " pie shells");
            BotLogger.info("Coins gained: " + coinsGained + "gp");
            BotLogger.info("Total coins: " + coinsAfter + "gp");
            BotLogger.info("Self-sustaining: Use these coins to buy more materials");

            if (coinsGained <= 0) {
                BotLogger.warn("WARNING: No coins gained from sale - something may have gone wrong");
            }

            return true;

        } catch (Exception e) {
            BotLogger.error("CRITICAL ERROR in selling process", e);
            BotLogger.info("RECOVERY: Bot will retry on next cycle");
            return false;
        }
    }

    private boolean handleBuying() {
        try {
            BotLogger.info("=== BUYING PHASE: Self-Sustaining Mode ===");

            // Step 1: Ensure we have coins
            int inventoryCoins = Inventory.count("Coins");
            int totalCoins = inventoryCoins;

            // Check bank for coins if needed
            if (inventoryCoins < config.minCoins) {
                BotLogger.info("Only " + inventoryCoins + " coins in inventory, checking bank...");

                if (!bankManager.openBank()) {
                    BotLogger.error("ERROR: Cannot open bank to get coins");
                    return false;
                }

                int bankCoins = Bank.count("Coins");
                totalCoins = inventoryCoins + bankCoins;
                BotLogger.info("Total coins available: " + totalCoins + " (inv: " + inventoryCoins + ", bank: " + bankCoins + ")");

                if (totalCoins < config.minCoins) {
                    BotLogger.error("ERROR: Not enough total coins (" + totalCoins + ") - need " + config.minCoins);
                    BotLogger.info("SOLUTION: Need to sell pie shells to get more coins");
                    bankManager.closeBank();
                    return false;
                }

                // Withdraw coins
                bankManager.depositAllInventory();
                Sleep.sleep(antiBan.randomDelay(300, 500));

                int coinsToWithdraw = Math.min(bankCoins, 2147483647);
                if (!Bank.withdraw("Coins", coinsToWithdraw)) {
                    BotLogger.error("ERROR: Failed to withdraw coins from bank");
                    bankManager.closeBank();
                    return false;
                }

                Sleep.sleep(antiBan.randomDelay(600, 900));
                inventoryCoins = Inventory.count("Coins");
                BotLogger.info("SUCCESS: Withdrew coins, now have " + inventoryCoins + " in inventory");

                bankManager.closeBank();
                Sleep.sleep(antiBan.randomDelay(400, 700));
            }

            // Step 2: Calculate purchasing power
            int availableForBuying = inventoryCoins - config.minCoins;
            if (availableForBuying < 5000) {
                BotLogger.error("ERROR: Not enough coins after reserve (" + inventoryCoins + " - " + config.minCoins + " = " + availableForBuying + ")");
                BotLogger.info("SOLUTION: Need to sell pie shells first to get more coins");
                return false;
            }

            BotLogger.info("Available for buying: " + availableForBuying + "gp (keeping " + config.minCoins + "gp reserve)");
            BotLogger.info("Self-sustaining: Will buy materials with coins from selling pie shells");

            // Get dynamic buy quantity from StateManager (based on profits)
            int dynamicQuantity = stateManager.getMaterialsToBuy();

            BotLogger.info("--- Dynamic Quantity Calculation ---");
            BotLogger.info("Base buy quantity: " + stateManager.getBaseMaterialsToBuy());
            BotLogger.info("Current profit-scaled quantity: " + dynamicQuantity);

            // Step 3: Buy Pastry Dough (even quantity)
            BotLogger.info("--- Buying Pastry Dough (Even Purchase) ---");
            BotLogger.info("Quantity: " + dynamicQuantity);
            BotLogger.info("Starting price: " + config.pastryDoughPrice + "gp, increase: " + config.priceIncreasePercent + "% per retry");

            boolean doughSuccess = geManager.buyItemProgressive(
                    "Pastry dough", dynamicQuantity, 1.0, config.minCoins, config.priceIncreasePercent
            );

            if (!doughSuccess) {
                BotLogger.error("ERROR: Failed to buy pastry dough");
                BotLogger.info("RECOVERY: Will retry on next cycle");
                return false;
            }

            BotLogger.info("SUCCESS: Pastry dough purchased");
            Sleep.sleep(antiBan.randomDelay(1000, 2000));

            // Step 4: Buy Pie Dishes (same even quantity)
            BotLogger.info("--- Buying Pie Dishes (Even Purchase) ---");
            BotLogger.info("Quantity: " + dynamicQuantity);
            BotLogger.info("Starting price: " + config.pieDishPrice + "gp, increase: " + config.priceIncreasePercent + "% per retry");

            boolean dishSuccess = geManager.buyItemProgressive(
                    "Pie dish", dynamicQuantity, 1.0, config.minCoins, config.priceIncreasePercent
            );

            if (!dishSuccess) {
                BotLogger.error("ERROR: Failed to buy pie dishes");
                BotLogger.info("RECOVERY: Have dough, will retry dishes on next cycle");
                BotLogger.warn("IMPORTANT: Materials are now UNBALANCED - will rebalance on next buy cycle");
                return false;
            }

            BotLogger.info("SUCCESS: Pie dishes purchased");

            // Step 5: Collect all items
            BotLogger.info("--- Collecting Items ---");
            geManager.collectAll();
            Sleep.sleep(antiBan.randomDelay(500, 800));

            // Step 6: Close GE window
            if (GrandExchange.isOpen()) {
                GrandExchange.close();
                boolean closed = Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 3000);
                if (!closed) {
                    BotLogger.warn("WARNING: GE didn't close automatically, trying again");
                    GrandExchange.close();
                    Sleep.sleep(1000);
                }
                BotLogger.info("SUCCESS: Closed Grand Exchange");
            }

            Sleep.sleep(antiBan.randomDelay(800, 1200));

            // Step 7: Bank to unnote items
            BotLogger.info("--- Banking to Unnote Items ---");
            if (!bankManager.openBank()) {
                BotLogger.error("ERROR: Failed to open bank after GE purchase");
                return false;
            }

            Sleep.sleep(antiBan.randomDelay(400, 600));

            // Deposit everything to unnote
            if (!Bank.depositAllItems()) {
                BotLogger.error("ERROR: Failed to deposit items");
                bankManager.closeBank();
                return false;
            }

            BotLogger.info("SUCCESS: Deposited all items (unnoting process)");
            Sleep.sleep(antiBan.randomDelay(600, 900));

            // Step 8: Verify and withdraw materials
            int doughInBank = Bank.count("Pastry dough");
            int dishInBank = Bank.count("Pie dish");
            int coinsInBank = Bank.count("Coins");

            BotLogger.info("Bank inventory: " + doughInBank + " dough, " + dishInBank + " dishes, " + coinsInBank + " coins");

            // CRITICAL: Check for material imbalance
            int materialDifference = Math.abs(doughInBank - dishInBank);
            if (materialDifference > 50) {
                BotLogger.error("=== MATERIAL IMBALANCE DETECTED ===");
                BotLogger.error("Dough: " + doughInBank + ", Dishes: " + dishInBank);
                BotLogger.error("Difference: " + materialDifference + " (should be balanced)");
                BotLogger.warn("This likely means one material purchase failed!");
                BotLogger.warn("Bot will only withdraw what can be balanced...");
            }

            if (doughInBank == 0 || dishInBank == 0) {
                BotLogger.error("ERROR: Missing materials in bank! Dough: " + doughInBank + ", Dishes: " + dishInBank);
                BotLogger.error("Cannot produce pie shells without BOTH materials!");
                bankManager.closeBank();
                return false;
            }

            // Withdraw balanced amounts only (14 of each or max available)
            int toWithdraw = Math.min(14, Math.min(doughInBank, dishInBank));

            if (!Bank.withdraw("Pastry dough", toWithdraw)) {
                BotLogger.error("ERROR: Failed to withdraw pastry dough");
                bankManager.closeBank();
                return false;
            }
            Sleep.sleep(antiBan.randomDelay(400, 600));

            if (!Bank.withdraw("Pie dish", toWithdraw)) {
                BotLogger.error("ERROR: Failed to withdraw pie dishes");
                bankManager.closeBank();
                return false;
            }
            Sleep.sleep(antiBan.randomDelay(400, 600));

            BotLogger.info("SUCCESS: Withdrew " + toWithdraw + " of each material (unnoted)");

            bankManager.closeBank();

            // Step 9: Final verification
            int doughInInv = Inventory.count("Pastry dough");
            int dishInInv = Inventory.count("Pie dish");

            if (doughInInv == 0 || dishInInv == 0) {
                BotLogger.error("ERROR: Materials not in inventory! Dough: " + doughInInv + ", Dishes: " + dishInInv);
                return false;
            }

            BotLogger.info("=== BUYING COMPLETE: Ready for Production ===");
            BotLogger.info("Inventory: " + doughInInv + " dough, " + dishInInv + " dishes");
            BotLogger.info("Self-sustaining cycle: Sell shells → Buy materials → Make more shells");
            return true;

        } catch (Exception e) {
            BotLogger.error("CRITICAL ERROR in buying process", e);
            BotLogger.info("RECOVERY: Bot will retry on next cycle");
            return false;
        }
    }

    @Override
    public void onExit() {
        try {
            BotLogger.separator();
            BotLogger.info("Stopping...");

            if (profitTracker != null) {
                profitTracker.logSummary();
            }

            if (cookingGained > 0) {
                BotLogger.stats("Cooking gained: " + cookingGained);
            }

            BotLogger.logShutdown("Bot stopped");

        } catch (Exception e) {
            BotLogger.error("Error during shutdown", e);
        }
    }

    @Override
    public void onPaint(Graphics g) {
        try {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int x = 10, y = 340, w = 270, h = 180;

            g2d.setColor(new Color(0, 0, 0, 180));
            g2d.fillRoundRect(x, y, w, h, 10, 10);

            g2d.setColor(new Color(76, 175, 80));
            g2d.drawRoundRect(x, y, w, h, 10, 10);

            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Arial", Font.BOLD, 14));
            g2d.drawString("Pie Shell Producer v2.2", x + 10, y + 20);

            g2d.setFont(new Font("Arial", Font.PLAIN, 11));
            if (stateManager != null) {
                g2d.drawString("State: " + stateManager.getCurrentState(), x + 10, y + 40);
            }

            if (profitTracker != null) {
                String[] lines = profitTracker.getPaintLines();
                int lineY = y + 60;
                for (String line : lines) {
                    g2d.drawString(line, x + 10, lineY);
                    lineY += 18;
                }
            }

            if (mouseManager != null && mouseManager.isSmartMouseEnabled()) {
                if (mouseManager.isMouseDataLoaded()) {
                    g2d.setColor(new Color(76, 175, 80));
                    g2d.setFont(new Font("Arial", Font.BOLD, 10));
                    g2d.drawString("● SmartMouse: ACTIVE", x + 10, y + h - 10);
                }
            }

        } catch (Exception e) {
            // Silent fail
        }
    }
}
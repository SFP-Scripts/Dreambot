package pieshellproducer.mouse;

import pieshellproducer.utils.BotLogger;
import java.io.File;

/**
 * REPLACE YOUR EXISTING MouseManager.java WITH THIS FILE
 *
 * Enhanced with:
 * - Multiple mousedata file location support
 * - Windows-specific path support (C:\Users\...)
 * - Better logging showing which location was used
 */
public class MouseManager {

    private static final String MOUSE_DATA_FOLDER = "PieShellProducer";
    private static final String DEFAULT_FILE_NAME = "mousedata.json";

    private boolean smartMouseEnabled;
    private boolean mouseDataLoaded;
    private SmartMouseIntegration smartMouse;
    private String loadedFromPath;

    public MouseManager(boolean enableSmartMouse) {
        this.smartMouseEnabled = enableSmartMouse;
        this.mouseDataLoaded = false;
        this.loadedFromPath = null;
    }

    public void initialize() {
        if (!smartMouseEnabled) {
            BotLogger.info("SmartMouse disabled - using default mouse");
            return;
        }

        MouseData mouseData = loadMouseData();

        if (mouseData != null && !mouseData.isEmpty()) {
            mouseDataLoaded = true;
            smartMouse = new SmartMouseIntegration(mouseData);

            BotLogger.info("SmartMouse data loaded successfully");
            BotLogger.info("Loaded from: " + loadedFromPath);
            if (mouseData.isLookupTable()) {
                BotLogger.info("Format: Lookup Table");
            } else {
                BotLogger.info("Format: Sequential (" + mouseData.size() + " movements)");
            }
        } else {
            mouseDataLoaded = false;
            smartMouse = null;
            BotLogger.warn("SmartMouse enabled but no data found - using default mouse");
            BotLogger.info("Searched locations:");
            BotLogger.info("  1. ~/.dreambot/scripts/PieShellProducer/mousedata.json");
            BotLogger.info("  2. C:\\Users\\<username>\\dreambot\\scripts\\mousedata.json");
            BotLogger.info("  3. C:\\Users\\<username>\\dreambot\\scripts\\PieShellProducer\\mousedata.json");
        }
    }

    private MouseData loadMouseData() {
        // Try multiple locations in order of preference

        // Location 1: Standard DreamBot location (~/.dreambot/scripts/PieShellProducer/)
        File location1 = tryLocation1();
        if (location1 != null && location1.exists()) {
            MouseData data = MouseData.loadFromFile(location1);
            if (data != null) {
                loadedFromPath = location1.getAbsolutePath();
                return data;
            }
        }

        // Location 2: Windows user directory (C:\Users\<user>\dreambot\scripts\)
        File location2 = tryLocation2();
        if (location2 != null && location2.exists()) {
            MouseData data = MouseData.loadFromFile(location2);
            if (data != null) {
                loadedFromPath = location2.getAbsolutePath();
                return data;
            }
        }

        // Location 3: Windows user directory with subfolder
        File location3 = tryLocation3();
        if (location3 != null && location3.exists()) {
            MouseData data = MouseData.loadFromFile(location3);
            if (data != null) {
                loadedFromPath = location3.getAbsolutePath();
                return data;
            }
        }

        return null;
    }

    /**
     * Location 1: ~/.dreambot/scripts/PieShellProducer/mousedata.json
     */
    private File tryLocation1() {
        try {
            File dataFolder = new File(System.getProperty("user.home"),
                    ".dreambot/scripts/" + MOUSE_DATA_FOLDER);

            File mouseDataFile = new File(dataFolder, DEFAULT_FILE_NAME);
            BotLogger.debug("Checking location 1: " + mouseDataFile.getAbsolutePath());
            return mouseDataFile;

        } catch (Exception e) {
            BotLogger.debug("Location 1 check failed: " + e.getMessage());
            return null;
        }
    }

    /**
     * Location 2: C:\Users\<username>\dreambot\scripts\mousedata.json
     */
    private File tryLocation2() {
        try {
            String userHome = System.getProperty("user.home");
            File dataFolder = new File(userHome, "dreambot/scripts");
            File mouseDataFile = new File(dataFolder, DEFAULT_FILE_NAME);

            BotLogger.debug("Checking location 2: " + mouseDataFile.getAbsolutePath());
            return mouseDataFile;

        } catch (Exception e) {
            BotLogger.debug("Location 2 check failed: " + e.getMessage());
            return null;
        }
    }

    /**
     * Location 3: C:\Users\<username>\dreambot\scripts\PieShellProducer\mousedata.json
     */
    private File tryLocation3() {
        try {
            String userHome = System.getProperty("user.home");
            File dataFolder = new File(userHome, "dreambot/scripts/" + MOUSE_DATA_FOLDER);
            File mouseDataFile = new File(dataFolder, DEFAULT_FILE_NAME);

            BotLogger.debug("Checking location 3: " + mouseDataFile.getAbsolutePath());
            return mouseDataFile;

        } catch (Exception e) {
            BotLogger.debug("Location 3 check failed: " + e.getMessage());
            return null;
        }
    }

    /**
     * Get the SmartMouse integration instance
     */
    public SmartMouseIntegration getSmartMouse() {
        return smartMouse;
    }

    public boolean isSmartMouseEnabled() {
        return smartMouseEnabled;
    }

    public boolean isMouseDataLoaded() {
        return mouseDataLoaded;
    }

    public String getLoadedPath() {
        return loadedFromPath;
    }

    public String getStatus() {
        if (!smartMouseEnabled) {
            return "SmartMouse: Disabled";
        } else if (mouseDataLoaded) {
            return "SmartMouse: Loaded from " + (loadedFromPath != null ? loadedFromPath : "unknown");
        } else {
            return "SmartMouse: Enabled but data not found (using default)";
        }
    }
}
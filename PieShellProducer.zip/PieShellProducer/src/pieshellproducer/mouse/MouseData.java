package pieshellproducer.mouse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import org.dreambot.api.utilities.Logger;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Data model for SmartMouse configuration.
 * Supports two formats:
 * 1. Sequential format: {"movements": [{...}]}
 * 2. Lookup table format: {"distance": {"direction": [{...}]}}
 */
public class MouseData {

    private JsonObject rawData;
    private boolean isLookupTable;
    private List<MouseMovement> movements;

    public MouseData(JsonObject data) {
        this.rawData = data;
        this.isLookupTable = detectFormat(data);
        this.movements = new ArrayList<>();

        if (!isLookupTable && data.has("movements")) {
            parseSequentialFormat(data);
        }
    }

    /**
     * Detect if data is lookup table or sequential format
     */
    private boolean detectFormat(JsonObject data) {
        // Lookup table has numeric keys at root level
        for (Map.Entry<String, JsonElement> entry : data.entrySet()) {
            try {
                Integer.parseInt(entry.getKey());
                return true; // Found numeric key, it's lookup table
            } catch (NumberFormatException e) {
                // Not a number, might be sequential
            }
        }
        return false;
    }

    /**
     * Parse sequential format movements
     */
    private void parseSequentialFormat(JsonObject data) {
        if (!data.has("movements")) {
            return;
        }

        try {
            for (JsonElement element : data.getAsJsonArray("movements")) {
                if (element.isJsonObject()) {
                    JsonObject obj = element.getAsJsonObject();

                    double x = obj.has("x") ? obj.get("x").getAsDouble() : 0;
                    double y = obj.has("y") ? obj.get("y").getAsDouble() : 0;
                    long delay = obj.has("delay") ? obj.get("delay").getAsLong() : 0;

                    movements.add(new MouseMovement(x, y, delay));
                }
            }
        } catch (Exception e) {
            Logger.log("[MouseData] Error parsing sequential format: " + e.getMessage());
        }
    }

    /**
     * Load mouse data from file
     */
    public static MouseData loadFromFile(File file) {
        try (FileReader reader = new FileReader(file)) {
            Gson gson = new GsonBuilder().create();
            JsonObject data = gson.fromJson(reader, JsonObject.class);

            if (data == null || data.size() == 0) {
                Logger.log("[MouseData] File is empty or invalid JSON");
                return null;
            }

            return new MouseData(data);

        } catch (JsonSyntaxException e) {
            Logger.log("[MouseData] Invalid JSON syntax: " + e.getMessage());
            return null;
        } catch (IOException e) {
            Logger.log("[MouseData] Error reading file: " + e.getMessage());
            return null;
        }
    }

    public boolean isLookupTable() {
        return isLookupTable;
    }

    public JsonObject getLookupData() {
        return rawData;
    }

    public List<MouseMovement> getMovements() {
        return movements;
    }

    public boolean isEmpty() {
        if (isLookupTable) {
            return rawData.size() == 0;
        } else {
            return movements.isEmpty();
        }
    }

    public int size() {
        return movements.size();
    }

    /**
     * Simple mouse movement data class
     */
    public static class MouseMovement {
        public final double x;
        public final double y;
        public final long delay;

        public MouseMovement(double x, double y, long delay) {
            this.x = x;
            this.y = y;
            this.delay = delay;
        }
    }
}
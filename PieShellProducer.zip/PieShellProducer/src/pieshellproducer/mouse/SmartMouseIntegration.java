package pieshellproducer.mouse;

import org.dreambot.api.input.Mouse;
import org.dreambot.api.utilities.Sleep;
import pieshellproducer.utils.BotLogger;

import java.awt.Point;
import java.util.List;
import java.util.Random;

/**
 * Implements SmartMouse movements using loaded data
 */
public class SmartMouseIntegration {

    private final MouseData mouseData;
    private final Random random;
    private boolean enabled;

    public SmartMouseIntegration(MouseData mouseData) {
        this.mouseData = mouseData;
        this.random = new Random();
        this.enabled = (mouseData != null && !mouseData.isEmpty());

        if (enabled) {
            BotLogger.info("SmartMouse integration active");
        } else {
            BotLogger.info("SmartMouse integration disabled - using default mouse");
        }
    }

    /**
     * Perform a smart mouse click at target location
     */
    public boolean smartClick(Point target, String action) {
        if (!enabled || mouseData == null) {
            // Fallback to default mouse
            return defaultClick(target, action);
        }

        try {
            if (mouseData.isLookupTable()) {
                return performLookupTableMovement(target, action);
            } else {
                return performSequentialMovement(target, action);
            }
        } catch (Exception e) {
            BotLogger.error("SmartMouse failed, using default", e);
            return defaultClick(target, action);
        }
    }

    /**
     * Default mouse click (fallback)
     */
    private boolean defaultClick(Point target, String action) {
        Mouse.move(target);
        Sleep.sleep(random.nextInt(100) + 50);
        Mouse.click();
        BotLogger.debug("Default click: " + action);
        return true;
    }

    /**
     * Sequential movement from loaded data
     */
    private boolean performSequentialMovement(Point target, String action) {
        List<MouseData.MouseMovement> movements = mouseData.getMovements();

        if (movements.isEmpty()) {
            return defaultClick(target, action);
        }

        Point current = Mouse.getPosition();

        // Use a subset of movements for variety
        int startIdx = random.nextInt(Math.max(1, movements.size() / 3));
        int endIdx = Math.min(movements.size(), startIdx + 5 + random.nextInt(5));

        for (int i = startIdx; i < endIdx; i++) {
            MouseData.MouseMovement move = movements.get(i);

            // Scale movement relative to target
            double progress = (double)(i - startIdx) / (endIdx - startIdx);
            int x = (int)(current.x + (target.x - current.x) * progress + move.x);
            int y = (int)(current.y + (target.y - current.y) * progress + move.y);

            Mouse.move(new Point(x, y));
            Sleep.sleep(move.delay + random.nextInt(10));
        }

        // Final move to exact target
        Mouse.move(target);
        Sleep.sleep(random.nextInt(50) + 25);
        Mouse.click();

        BotLogger.debug("SmartMouse sequential click: " + action);
        return true;
    }

    /**
     * Lookup table movement (distance-based)
     */
    private boolean performLookupTableMovement(Point target, String action) {
        Point current = Mouse.getPosition();

        // Calculate distance
        double distance = Math.sqrt(
                Math.pow(target.x - current.x, 2) +
                        Math.pow(target.y - current.y, 2)
        );

        // Round to nearest bucket (e.g., 50, 100, 150)
        int distanceBucket = ((int)distance / 50) * 50;

        // For now, just do a smooth move since lookup table implementation
        // would require specific data structure
        int steps = Math.max(3, (int)(distance / 30));

        for (int i = 1; i <= steps; i++) {
            double progress = (double)i / steps;
            int x = (int)(current.x + (target.x - current.x) * progress);
            int y = (int)(current.y + (target.y - current.y) * progress);

            // Add slight randomness
            x += random.nextInt(3) - 1;
            y += random.nextInt(3) - 1;

            Mouse.move(new Point(x, y));
            Sleep.sleep(random.nextInt(20) + 10);
        }

        Mouse.move(target);
        Sleep.sleep(random.nextInt(50) + 25);
        Mouse.click();

        BotLogger.debug("SmartMouse lookup click: " + action);
        return true;
    }

    /**
     * Move mouse without clicking (for hovering, anti-ban)
     */
    public void smartMove(Point target) {
        if (!enabled || mouseData == null) {
            Mouse.move(target);
            return;
        }

        Point current = Mouse.getPosition();
        double distance = Math.sqrt(
                Math.pow(target.x - current.x, 2) +
                        Math.pow(target.y - current.y, 2)
        );

        int steps = Math.max(2, (int)(distance / 40));

        for (int i = 1; i <= steps; i++) {
            double progress = (double)i / steps;
            int x = (int)(current.x + (target.x - current.x) * progress);
            int y = (int)(current.y + (target.y - current.y) * progress);

            Mouse.move(new Point(x, y));
            Sleep.sleep(random.nextInt(15) + 5);
        }
    }

    public boolean isEnabled() {
        return enabled;
    }
}
package pieshellproducer.antiban;

import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.input.Mouse;
import org.dreambot.api.methods.interactive.Players;
import pieshellproducer.utils.BotLogger;

import java.util.Random;

/**
 * REPLACE YOUR EXISTING AntiBanManager.java WITH THIS FILE
 *
 * FIXED: Removed Camera API and invalid Tab references
 * Enhanced with configurable anti-ban behaviors
 */
public class AntiBanManager {

    private final Random random;
    private long lastAntiBanAction;
    private long antiBanInterval;

    // Configurable behaviors
    private boolean enableTabChecking;
    private boolean enableMouseMovements;
    private boolean enableCameraMovements;
    private boolean enableRandomHovers;
    private boolean enableRandomPauses;

    public AntiBanManager(long antiBanInterval) {
        this.random = new Random();
        this.lastAntiBanAction = System.currentTimeMillis();
        this.antiBanInterval = antiBanInterval;

        // Default: all enabled
        this.enableTabChecking = true;
        this.enableMouseMovements = true;
        this.enableCameraMovements = true;
        this.enableRandomHovers = true;
        this.enableRandomPauses = true;
    }

    public void setAntiBanInterval(long interval) {
        this.antiBanInterval = interval;
        BotLogger.info("Anti-ban interval set to: " + (interval / 1000) + " seconds");
    }

    // Configuration methods
    public void setTabChecking(boolean enabled) {
        this.enableTabChecking = enabled;
        BotLogger.debug("Tab checking: " + (enabled ? "enabled" : "disabled"));
    }

    public void setMouseMovements(boolean enabled) {
        this.enableMouseMovements = enabled;
        BotLogger.debug("Mouse movements: " + (enabled ? "enabled" : "disabled"));
    }

    public void setCameraMovements(boolean enabled) {
        this.enableCameraMovements = enabled;
        BotLogger.debug("Camera movements: " + (enabled ? "enabled" : "disabled"));
    }

    public void setRandomHovers(boolean enabled) {
        this.enableRandomHovers = enabled;
        BotLogger.debug("Random hovers: " + (enabled ? "enabled" : "disabled"));
    }

    public void setRandomPauses(boolean enabled) {
        this.enableRandomPauses = enabled;
        BotLogger.debug("Random pauses: " + (enabled ? "enabled" : "disabled"));
    }

    public void performAntiBan() {
        if (System.currentTimeMillis() - lastAntiBanAction < antiBanInterval) {
            return;
        }

        try {
            int action = random.nextInt(100);

            if (action < 30 && enableTabChecking) {
                checkRandomTab();
            } else if (action < 50 && enableMouseMovements) {
                randomMouseMovement();
            } else if (action < 65 && enableRandomHovers) {
                randomHoverAction();
            } else if (action < 80 && enableRandomPauses) {
                randomMicroPause();
            }
            // Camera movements removed - not supported in DreamBot API

            lastAntiBanAction = System.currentTimeMillis();

        } catch (Exception e) {
            BotLogger.debug("Anti-ban action error: " + e.getMessage());
        }
    }

    private void checkRandomTab() {
        try {
            Tab currentTab = Tabs.getOpen();

            // Use only valid tabs that exist in DreamBot API
            Tab[] tabs = {Tab.SKILLS, Tab.INVENTORY, Tab.EQUIPMENT, Tab.PRAYER};
            Tab randomTab = tabs[random.nextInt(tabs.length)];

            // Don't check the same tab we're already on
            if (randomTab == currentTab) {
                return;
            }

            if (Tabs.open(randomTab)) {
                BotLogger.debug("Anti-ban: Checked " + randomTab + " tab");
                Sleep.sleep(randomDelay(1000, 2000));

                // Return to inventory
                Tabs.open(Tab.INVENTORY);
                Sleep.sleep(randomDelay(200, 400));
            }
        } catch (Exception e) {
            BotLogger.debug("Tab checking error: " + e.getMessage());
        }
    }

    private void randomMouseMovement() {
        try {
            // Move mouse to random screen position
            int screenWidth = 765; // Typical game window width
            int screenHeight = 503; // Typical game window height

            int x = random.nextInt(screenWidth - 100) + 50;
            int y = random.nextInt(screenHeight - 100) + 50;

            Mouse.move(new java.awt.Point(x, y));
            BotLogger.debug("Anti-ban: Random mouse move");
            Sleep.sleep(randomDelay(100, 300));
        } catch (Exception e) {
            BotLogger.debug("Mouse movement error: " + e.getMessage());
        }
    }

    private void randomHoverAction() {
        try {
            // Hover over player character occasionally
            if (random.nextInt(100) < 30 && Players.getLocal() != null) {
                // Just move mouse to a random nearby position
                int offsetX = random.nextInt(100) - 50;
                int offsetY = random.nextInt(100) - 50;
                java.awt.Point current = Mouse.getPosition();
                Mouse.move(new java.awt.Point(current.x + offsetX, current.y + offsetY));
                BotLogger.debug("Anti-ban: Random hover");
                Sleep.sleep(randomDelay(500, 1000));
            } else {
                // Just move mouse slightly
                int offsetX = random.nextInt(100) - 50;
                int offsetY = random.nextInt(100) - 50;
                java.awt.Point current = Mouse.getPosition();
                Mouse.move(new java.awt.Point(current.x + offsetX, current.y + offsetY));
                BotLogger.debug("Anti-ban: Mouse hover");
                Sleep.sleep(randomDelay(200, 500));
            }
        } catch (Exception e) {
            BotLogger.debug("Hover action error: " + e.getMessage());
        }
    }

    private void randomMicroPause() {
        try {
            // Simulate human "thinking" pause
            int pauseTime = randomDelay(500, 1500);
            BotLogger.debug("Anti-ban: Micro pause (" + pauseTime + "ms)");
            Sleep.sleep(pauseTime);
        } catch (Exception e) {
            BotLogger.debug("Pause error: " + e.getMessage());
        }
    }

    public int randomDelay(int min, int max) {
        return random.nextInt(max - min + 1) + min;
    }

    public int addVariance(int baseDelay, double variance) {
        int range = (int)(baseDelay * variance);
        return baseDelay + random.nextInt(range * 2) - range;
    }

    public void humanWait(int baseMillis) {
        Sleep.sleep(addVariance(baseMillis, 0.2));
    }

    /**
     * Add a realistic delay before actions (prevents instant clicks)
     */
    public void reactionDelay() {
        // Human reaction time: 200-600ms typically
        Sleep.sleep(randomDelay(200, 600));
    }

    /**
     * Occasional longer "afk" moment (looks more human)
     */
    public void occasionalAfkMoment() {
        if (random.nextInt(100) < 5) { // 5% chance
            int afkTime = randomDelay(3000, 8000);
            BotLogger.debug("Anti-ban: AFK moment (" + (afkTime/1000) + "s)");
            Sleep.sleep(afkTime);
        }
    }
}
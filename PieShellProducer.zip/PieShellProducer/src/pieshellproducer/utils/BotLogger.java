package pieshellproducer.utils;

import org.dreambot.api.utilities.Logger;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Enhanced logging system with categorized messages and statistics
 */
public class BotLogger {

    private static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
    private static boolean debugEnabled = false;

    public enum LogLevel {
        INFO("[INFO]"),
        WARN("[WARN]"),
        ERROR("[ERROR]"),
        DEBUG("[DEBUG]"),
        STATS("[STATS]");

        private final String prefix;

        LogLevel(String prefix) {
            this.prefix = prefix;
        }

        public String getPrefix() {
            return prefix;
        }
    }

    public static void setDebugEnabled(boolean enabled) {
        debugEnabled = enabled;
    }

    public static void info(String message) {
        log(LogLevel.INFO, message);
    }

    public static void warn(String message) {
        log(LogLevel.WARN, message);
    }

    public static void error(String message) {
        log(LogLevel.ERROR, message);
    }

    public static void error(String message, Exception e) {
        log(LogLevel.ERROR, message + " - " + e.getMessage());
        if (debugEnabled && e != null) {
            e.printStackTrace();
        }
    }

    public static void debug(String message) {
        if (debugEnabled) {
            log(LogLevel.DEBUG, message);
        }
    }

    public static void stats(String message) {
        log(LogLevel.STATS, message);
    }

    private static void log(LogLevel level, String message) {
        String timestamp = timeFormat.format(new Date());
        String formattedMessage = String.format("[%s] %s %s",
                timestamp, level.getPrefix(), message);
        Logger.log(formattedMessage);
    }

    public static void separator() {
        Logger.log("================================================");
    }

    public static void logStartup(String scriptName, String version) {
        separator();
        info(scriptName + " v" + version + " - Starting");
        separator();
    }

    public static void logShutdown(String reason) {
        separator();
        info("Shutting down: " + reason);
        separator();
    }
}
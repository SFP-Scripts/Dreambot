package pieshellproducer.utils;

import pieshellproducer.utils.BotLogger;

/**
 * Tracks profit, expenses, and calculates GP/hour
 */
public class ProfitTracker {

    private long startTime;

    // Expenses
    private int pastryDoughBought = 0;
    private int pieDishBought = 0;
    private int totalDoughCost = 0;
    private int totalDishCost = 0;

    // Revenue
    private int pieShellsSold = 0;
    private int totalRevenue = 0;

    // Production stats
    private int totalPieShellsMade = 0;
    private int productionCycles = 0;

    // Prices (tracked from actual transactions)
    private int lastDoughPrice = 0;
    private int lastDishPrice = 0;
    private int lastShellPrice = 0;

    public ProfitTracker() {
        this.startTime = System.currentTimeMillis();
    }

    // Recording purchases
    public void recordDoughPurchase(int quantity, int priceEach) {
        pastryDoughBought += quantity;
        totalDoughCost += (quantity * priceEach);
        lastDoughPrice = priceEach;
        BotLogger.debug("Recorded dough purchase: " + quantity + " @ " + priceEach + "gp each");
    }

    public void recordDishPurchase(int quantity, int priceEach) {
        pieDishBought += quantity;
        totalDishCost += (quantity * priceEach);
        lastDishPrice = priceEach;
        BotLogger.debug("Recorded dish purchase: " + quantity + " @ " + priceEach + "gp each");
    }

    // Recording sales
    public void recordShellSale(int quantity, int priceEach) {
        pieShellsSold += quantity;
        totalRevenue += (quantity * priceEach);
        lastShellPrice = priceEach;
        BotLogger.debug("Recorded shell sale: " + quantity + " @ " + priceEach + "gp each");
    }

    // Recording production
    public void recordProduction(int shellsCreated) {
        totalPieShellsMade += shellsCreated;
        productionCycles++;
    }

    // Calculations
    public int getTotalExpenses() {
        return totalDoughCost + totalDishCost;
    }

    public int getTotalRevenue() {
        return totalRevenue;
    }

    public int getNetProfit() {
        return totalRevenue - getTotalExpenses();
    }

    public int getProfitPerHour() {
        long runtimeMs = System.currentTimeMillis() - startTime;
        if (runtimeMs == 0) return 0;

        double hours = runtimeMs / 3600000.0;
        return (int) (getNetProfit() / hours);
    }

    public String getRuntime() {
        long runtimeMs = System.currentTimeMillis() - startTime;
        long seconds = runtimeMs / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;

        return String.format("%02d:%02d:%02d", hours, minutes % 60, seconds % 60);
    }

    // Getters for statistics
    public int getPastryDoughBought() { return pastryDoughBought; }
    public int getPieDishBought() { return pieDishBought; }
    public int getPieShellsSold() { return pieShellsSold; }
    public int getTotalPieShellsMade() { return totalPieShellsMade; }
    public int getProductionCycles() { return productionCycles; }

    public int getLastDoughPrice() { return lastDoughPrice; }
    public int getLastDishPrice() { return lastDishPrice; }
    public int getLastShellPrice() { return lastShellPrice; }

    // Summary logging
    public void logSummary() {
        BotLogger.separator();
        BotLogger.stats("=== PROFIT SUMMARY ===");
        BotLogger.stats("Runtime: " + getRuntime());
        BotLogger.stats("Cycles: " + productionCycles);
        BotLogger.stats("Shells Made: " + totalPieShellsMade);
        BotLogger.stats("Shells Sold: " + pieShellsSold);
        BotLogger.separator();
        BotLogger.stats("Expenses: " + getTotalExpenses() + " GP");
        BotLogger.stats("  - Dough: " + pastryDoughBought + " @ ~" + lastDoughPrice + "gp = " + totalDoughCost + " GP");
        BotLogger.stats("  - Dishes: " + pieDishBought + " @ ~" + lastDishPrice + "gp = " + totalDishCost + " GP");
        BotLogger.stats("Revenue: " + totalRevenue + " GP");
        BotLogger.stats("  - Shells: " + pieShellsSold + " @ ~" + lastShellPrice + "gp");
        BotLogger.separator();
        BotLogger.stats("NET PROFIT: " + getNetProfit() + " GP");
        BotLogger.stats("GP/HOUR: " + getProfitPerHour() + " GP");
        BotLogger.separator();
    }

    // Paint overlay format
    public String[] getPaintLines() {
        return new String[] {
                "Runtime: " + getRuntime(),
                "Profit: " + getNetProfit() + " GP (" + getProfitPerHour() + " GP/hr)",
                "Cycles: " + productionCycles,
                "Made: " + totalPieShellsMade + " | Sold: " + pieShellsSold,
                "Expenses: " + getTotalExpenses() + " | Revenue: " + totalRevenue
        };
    }
}
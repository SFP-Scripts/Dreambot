package pieshellproducer.gui;

import pieshellproducer.profile.ProfileManager;
import pieshellproducer.utils.BotLogger;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * REPLACE YOUR ConfigGUI.java WITH THIS FILE
 * Enhanced with profile save/load functionality
 */
public class ConfigGUI extends JFrame {

    private JSpinner pastryDoughSpinner;
    private JSpinner pieDishSpinner;
    private JSpinner pastryDoughPriceSpinner;
    private JSpinner pieDishPriceSpinner;
    private JSpinner pieShellSellPriceSpinner;
    private JSpinner priceIncreaseSpinner;
    private JSpinner sellThresholdSpinner;
    private JSpinner minCoinsSpinner;
    private JSpinner antiBanIntervalSpinner;
    private JTextField profileNameField;
    private JTextField muleNameField;
    private JCheckBox smartMouseCheckBox;
    private JCheckBox progressiveBuyingCheckBox;
    private JCheckBox progressiveSellingCheckBox;
    private JCheckBox mulingEnabledCheckBox;
    private JCheckBox debugLoggingCheckBox;
    private JCheckBox tabCheckingCheckBox;
    private JCheckBox mouseMovementsCheckBox;
    private JCheckBox cameraMovementsCheckBox;
    private JCheckBox randomHoversCheckBox;
    private JCheckBox randomPausesCheckBox;
    private JCheckBox afkMomentsCheckBox;
    private JLabel smartMouseStatusLabel;

    private boolean configComplete = false;
    private ConfigData config;

    public ConfigGUI() {
        setTitle("Pie Shell Producer - Configuration");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Title
        JLabel titleLabel = new JLabel("Pie Shell Producer Configuration");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Profile Management Panel
        JPanel profilePanel = createPanel("Profile Management");
        profileNameField = new JTextField("Default");
        profilePanel.add(createRow("Profile Name:", profileNameField));

        // Profile buttons
        JPanel profileButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));

        JButton saveProfileBtn = new JButton("Save Profile");
        saveProfileBtn.addActionListener(e -> saveCurrentProfile());
        profileButtonPanel.add(saveProfileBtn);

        JButton loadProfileBtn = new JButton("Load Profile");
        loadProfileBtn.addActionListener(e -> loadProfile());
        profileButtonPanel.add(loadProfileBtn);

        JButton listProfilesBtn = new JButton("List Profiles");
        listProfilesBtn.addActionListener(e -> listSavedProfiles());
        profileButtonPanel.add(listProfilesBtn);

        profilePanel.add(profileButtonPanel);
        mainPanel.add(profilePanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        mainPanel.add(profilePanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Mule Settings Panel
        JPanel mulePanel = createPanel("Mule Settings");
        muleNameField = new JTextField("");
        mulePanel.add(createRow("Mule Name (optional):", muleNameField));

        mulingEnabledCheckBox = new JCheckBox("Enable Muling", false);
        mulePanel.add(mulingEnabledCheckBox);
        mainPanel.add(mulePanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Materials
        JPanel materialsPanel = createPanel("Material Quantities & Pricing");
        pastryDoughSpinner = new JSpinner(new SpinnerNumberModel(200, 1, 5000, 50));
        materialsPanel.add(createRow("Pastry Dough to buy:", pastryDoughSpinner));

        pastryDoughPriceSpinner = new JSpinner(new SpinnerNumberModel(170, 1, 10000, 10));
        materialsPanel.add(createRow("Pastry Dough buy price (gp):", pastryDoughPriceSpinner));

        pieDishSpinner = new JSpinner(new SpinnerNumberModel(200, 1, 5000, 50));
        materialsPanel.add(createRow("Pie Dishes to buy:", pieDishSpinner));

        pieDishPriceSpinner = new JSpinner(new SpinnerNumberModel(40, 1, 10000, 10));
        materialsPanel.add(createRow("Pie Dish buy price (gp):", pieDishPriceSpinner));

        pieShellSellPriceSpinner = new JSpinner(new SpinnerNumberModel(150, 1, 10000, 10));
        materialsPanel.add(createRow("Pie Shell sell price (gp):", pieShellSellPriceSpinner));

        priceIncreaseSpinner = new JSpinner(new SpinnerNumberModel(5, 1, 20, 1));
        materialsPanel.add(createRow("Price increase per retry (%):", priceIncreaseSpinner));

        mainPanel.add(materialsPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Trading
        JPanel tradingPanel = createPanel("Trading Settings");
        sellThresholdSpinner = new JSpinner(new SpinnerNumberModel(100, 10, 1000, 10));
        tradingPanel.add(createRow("Sell pie shells when reach:", sellThresholdSpinner));
        minCoinsSpinner = new JSpinner(new SpinnerNumberModel(50000, 5000, 10000000, 10000));
        tradingPanel.add(createRow("Minimum coins before buying:", minCoinsSpinner));
        progressiveBuyingCheckBox = new JCheckBox("Enable Progressive Buying", true);
        tradingPanel.add(progressiveBuyingCheckBox);
        progressiveSellingCheckBox = new JCheckBox("Enable Progressive Selling", true);
        tradingPanel.add(progressiveSellingCheckBox);
        mainPanel.add(tradingPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Anti-ban
        JPanel antiBanPanel = createPanel("Anti-Ban Settings");
        antiBanIntervalSpinner = new JSpinner(new SpinnerNumberModel(60, 10, 300, 10));
        antiBanPanel.add(createRow("Anti-ban interval (seconds):", antiBanIntervalSpinner));
        tabCheckingCheckBox = new JCheckBox("Tab Checking", true);
        antiBanPanel.add(tabCheckingCheckBox);
        mouseMovementsCheckBox = new JCheckBox("Mouse Movements", true);
        antiBanPanel.add(mouseMovementsCheckBox);
        cameraMovementsCheckBox = new JCheckBox("Camera Movements", true);
        antiBanPanel.add(cameraMovementsCheckBox);
        randomHoversCheckBox = new JCheckBox("Random Hovers", true);
        antiBanPanel.add(randomHoversCheckBox);
        randomPausesCheckBox = new JCheckBox("Micro Pauses", true);
        antiBanPanel.add(randomPausesCheckBox);
        afkMomentsCheckBox = new JCheckBox("AFK Moments", true);
        antiBanPanel.add(afkMomentsCheckBox);
        mainPanel.add(antiBanPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Mouse
        JPanel mousePanel = createPanel("SmartMouse");
        smartMouseCheckBox = new JCheckBox("Enable SmartMouse", false);
        mousePanel.add(smartMouseCheckBox);

        smartMouseStatusLabel = new JLabel("Status: Not loaded yet");
        smartMouseStatusLabel.setFont(new Font("Arial", Font.ITALIC, 10));
        smartMouseStatusLabel.setForeground(Color.GRAY);
        mousePanel.add(smartMouseStatusLabel);

        mainPanel.add(mousePanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Advanced
        JPanel advancedPanel = createPanel("Advanced");
        debugLoggingCheckBox = new JCheckBox("Debug Logging", false);
        advancedPanel.add(debugLoggingCheckBox);
        mainPanel.add(advancedPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));

        JButton startButton = new JButton("Start Bot");
        startButton.setPreferredSize(new Dimension(120, 35));
        startButton.setBackground(new Color(76, 175, 80));
        startButton.setForeground(Color.WHITE);
        startButton.setFocusPainted(false);
        startButton.addActionListener(e -> {
            saveConfig();
            configComplete = true;
            dispose();
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setPreferredSize(new Dimension(120, 35));
        cancelButton.addActionListener(e -> {
            configComplete = false;
            dispose();
        });

        buttonPanel.add(startButton);
        buttonPanel.add(cancelButton);
        mainPanel.add(buttonPanel);

        add(mainPanel, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(null);
    }

    private JPanel createPanel(String title) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder(title));
        return panel;
    }

    private JPanel createRow(String label, JComponent input) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setMaximumSize(new Dimension(450, 35));
        JLabel jLabel = new JLabel(label);
        jLabel.setPreferredSize(new Dimension(250, 25));
        input.setPreferredSize(new Dimension(150, 25));
        row.add(jLabel, BorderLayout.WEST);
        row.add(input, BorderLayout.EAST);
        return row;
    }

    private JPanel createRow(String label, JTextField input) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setMaximumSize(new Dimension(450, 35));
        JLabel jLabel = new JLabel(label);
        jLabel.setPreferredSize(new Dimension(250, 25));
        input.setPreferredSize(new Dimension(150, 25));
        row.add(jLabel, BorderLayout.WEST);
        row.add(input, BorderLayout.EAST);
        return row;
    }

    private void saveConfig() {
        config = new ConfigData();
        config.profileName = profileNameField.getText();
        config.muleName = muleNameField.getText();
        config.pastryDoughToBuy = (Integer) pastryDoughSpinner.getValue();
        config.pieDishToBuy = (Integer) pieDishSpinner.getValue();
        config.pastryDoughPrice = (Integer) pastryDoughPriceSpinner.getValue();
        config.pieDishPrice = (Integer) pieDishPriceSpinner.getValue();
        config.pieShellSellPrice = (Integer) pieShellSellPriceSpinner.getValue();
        config.priceIncreasePercent = (Integer) priceIncreaseSpinner.getValue();
        config.sellThreshold = (Integer) sellThresholdSpinner.getValue();
        config.minCoins = (Integer) minCoinsSpinner.getValue();
        config.antiBanInterval = (Integer) antiBanIntervalSpinner.getValue() * 1000;
        config.smartMouseEnabled = smartMouseCheckBox.isSelected();
        config.progressiveBuyingEnabled = progressiveBuyingCheckBox.isSelected();
        config.progressiveSellingEnabled = progressiveSellingCheckBox.isSelected();
        config.mulingEnabled = mulingEnabledCheckBox.isSelected();
        config.debugLoggingEnabled = debugLoggingCheckBox.isSelected();
        config.tabCheckingEnabled = tabCheckingCheckBox.isSelected();
        config.mouseMovementsEnabled = mouseMovementsCheckBox.isSelected();
        config.cameraMovementsEnabled = cameraMovementsCheckBox.isSelected();
        config.randomHoversEnabled = randomHoversCheckBox.isSelected();
        config.randomPausesEnabled = randomPausesCheckBox.isSelected();
        config.afkMomentsEnabled = afkMomentsCheckBox.isSelected();
    }

    /**
     * Save current settings to a profile
     */
    private void saveCurrentProfile() {
        String profileName = profileNameField.getText();
        if (profileName == null || profileName.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a profile name",
                    "Profile Name Required",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Create profile from current settings
        ProfileManager.Profile profile = new ProfileManager.Profile();
        profile.profileName = profileName;
        profile.muleName = muleNameField.getText();
        profile.pastryDoughToBuy = (Integer) pastryDoughSpinner.getValue();
        profile.pieDishToBuy = (Integer) pieDishSpinner.getValue();
        profile.pastryDoughPrice = (Integer) pastryDoughPriceSpinner.getValue();
        profile.pieDishPrice = (Integer) pieDishPriceSpinner.getValue();
        profile.pieShellSellPrice = (Integer) pieShellSellPriceSpinner.getValue();
        profile.priceIncreasePercent = (Integer) priceIncreaseSpinner.getValue();
        profile.sellThreshold = (Integer) sellThresholdSpinner.getValue();
        profile.minCoins = (Integer) minCoinsSpinner.getValue();
        profile.smartMouseEnabled = smartMouseCheckBox.isSelected();
        profile.progressiveBuyingEnabled = progressiveBuyingCheckBox.isSelected();
        profile.progressiveSellingEnabled = progressiveSellingCheckBox.isSelected();
        profile.mulingEnabled = mulingEnabledCheckBox.isSelected();
        profile.debugLoggingEnabled = debugLoggingCheckBox.isSelected();

        if (ProfileManager.saveProfile(profile)) {
            JOptionPane.showMessageDialog(this,
                    "Profile '" + profileName + "' saved successfully!",
                    "Profile Saved",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Failed to save profile",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Load a profile
     */
    private void loadProfile() {
        List<String> profiles = ProfileManager.listProfiles();

        if (profiles.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No saved profiles found",
                    "No Profiles",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String[] profileArray = profiles.toArray(new String[0]);
        String selected = (String) JOptionPane.showInputDialog(
                this,
                "Select a profile to load:",
                "Load Profile",
                JOptionPane.QUESTION_MESSAGE,
                null,
                profileArray,
                profileArray[0]
        );

        if (selected != null) {
            ProfileManager.Profile profile = ProfileManager.loadProfile(selected);
            if (profile != null) {
                applyProfileToGUI(profile);
                JOptionPane.showMessageDialog(this,
                        "Profile '" + selected + "' loaded successfully!",
                        "Profile Loaded",
                        JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                        "Failed to load profile",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Apply loaded profile to GUI fields
     */
    private void applyProfileToGUI(ProfileManager.Profile profile) {
        profileNameField.setText(profile.profileName);
        muleNameField.setText(profile.muleName);
        pastryDoughSpinner.setValue(profile.pastryDoughToBuy);
        pieDishSpinner.setValue(profile.pieDishToBuy);
        pastryDoughPriceSpinner.setValue(profile.pastryDoughPrice);
        pieDishPriceSpinner.setValue(profile.pieDishPrice);
        pieShellSellPriceSpinner.setValue(profile.pieShellSellPrice);
        priceIncreaseSpinner.setValue(profile.priceIncreasePercent);
        sellThresholdSpinner.setValue(profile.sellThreshold);
        minCoinsSpinner.setValue(profile.minCoins);
        smartMouseCheckBox.setSelected(profile.smartMouseEnabled);
        progressiveBuyingCheckBox.setSelected(profile.progressiveBuyingEnabled);
        progressiveSellingCheckBox.setSelected(profile.progressiveSellingEnabled);
        mulingEnabledCheckBox.setSelected(profile.mulingEnabled);
        debugLoggingCheckBox.setSelected(profile.debugLoggingEnabled);
    }

    /**
     * List all saved profiles
     */
    private void listSavedProfiles() {
        List<String> profiles = ProfileManager.listProfiles();

        if (profiles.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No saved profiles found",
                    "Saved Profiles",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder message = new StringBuilder("Saved Profiles:\n\n");
        for (String profile : profiles) {
            message.append("• ").append(profile).append("\n");
        }

        JOptionPane.showMessageDialog(this,
                message.toString(),
                "Saved Profiles",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public void setMouseDataStatus(boolean loaded, String path) {
        if (smartMouseStatusLabel != null) {
            if (loaded && path != null) {
                smartMouseStatusLabel.setText("Status: ✓ SmartMouse data loaded");
                smartMouseStatusLabel.setForeground(new Color(76, 175, 80));
            } else if (smartMouseCheckBox.isSelected()) {
                smartMouseStatusLabel.setText("Status: ✗ SmartMouse enabled but no data");
                smartMouseStatusLabel.setForeground(Color.RED);
            } else {
                smartMouseStatusLabel.setText("Status: Disabled");
                smartMouseStatusLabel.setForeground(Color.GRAY);
            }
        }
    }

    public boolean isConfigComplete() {
        return configComplete;
    }

    public ConfigData getConfig() {
        return config;
    }

    public static class ConfigData {
        public String profileName = "Default";
        public String muleName = "";
        public int pastryDoughToBuy = 200;
        public int pieDishToBuy = 200;
        public int pastryDoughPrice = 170;
        public int pieDishPrice = 40;
        public int pieShellSellPrice = 150;
        public int priceIncreasePercent = 5;
        public int sellThreshold = 100;
        public int minCoins = 50000;
        public long antiBanInterval = 60000;
        public boolean smartMouseEnabled = false;
        public boolean progressiveBuyingEnabled = true;
        public boolean progressiveSellingEnabled = true;
        public boolean mulingEnabled = false;
        public boolean debugLoggingEnabled = false;
        public boolean tabCheckingEnabled = true;
        public boolean mouseMovementsEnabled = true;
        public boolean cameraMovementsEnabled = true;
        public boolean randomHoversEnabled = true;
        public boolean randomPausesEnabled = true;
        public boolean afkMomentsEnabled = true;
    }
}
package managers;

import config.AlchConfig;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.equipment.Equipment;

/**
 * Checks supply levels and determines what needs to be bought/withdrawn
 */
public class SupplyCheckManager {

    private final AlchConfig config;
    private final StatsTracker stats;

    public SupplyCheckManager(AlchConfig config, StatsTracker stats) {
        this.config = config;
        this.stats = stats;
    }

    public int checkSupplies() {
        // This is just a transition state
        return 300;
    }

    /**
     * Check if we have alch items in bank (at least 1)
     */
    public boolean hasItemsInBank() {
        String currentItem = config.getCurrentItemName();
        if (currentItem == null || currentItem.isEmpty()) {
            return false;
        }

        int inBank = Bank.count(currentItem);
        return inBank > 0;
    }

    /**
     * Check if we have nature runes in bank (at least 1)
     */
    public boolean hasRunesInBank() {
        int inBank = Bank.count("Nature rune");
        return inBank > 0;
    }

    /**
     * Check if we need alch items (checks current item in rotation)
     */
    public boolean needsAlchItems() {
        String currentItem = config.getCurrentItemName();
        if (currentItem == null || currentItem.isEmpty()) {
            return false;
        }

        int inInventory = Inventory.count(currentItem);
        int inBank = Bank.count(currentItem);
        int total = inInventory + inBank;

        return total < config.minAlchItems;
    }

    /**
     * Check if we need nature runes
     */
    public boolean needsNatureRunes() {
        int inInventory = Inventory.count("Nature rune");
        int inEquipment = Equipment.count("Nature rune");
        int inBank = Bank.count("Nature rune");
        int total = inInventory + inEquipment + inBank;

        return total < config.minNatureRunes;
    }

    /**
     * Check if we need to visit GE (items are low and not in bank)
     */
    public boolean needsToVisitGE() {
        String currentItem = config.getCurrentItemName();
        if (currentItem == null || currentItem.isEmpty()) {
            return false;
        }

        // Need items and can't get from bank
        if (needsAlchItems() && Bank.count(currentItem) < config.minAlchItems) {
            return true;
        }

        // Need runes and can't get from bank
        if (needsNatureRunes() && Bank.count("Nature rune") < config.minNatureRunes) {
            return true;
        }

        return false;
    }

    /**
     * Check if we can withdraw supplies from bank
     */
    public boolean canWithdrawFromBank() {
        String currentItem = config.getCurrentItemName();
        if (currentItem == null || currentItem.isEmpty()) {
            return false;
        }
        return Bank.contains(currentItem) || Bank.contains("Nature rune");
    }

    /**
     * Get number of alch items to buy
     */
    public int getItemsToBuy() {
        String currentItem = config.getCurrentItemName();
        if (currentItem == null || currentItem.isEmpty()) {
            return 0;
        }

        int current = Inventory.count(currentItem) + Bank.count(currentItem);
        int needed = config.maxAlchItems - current;
        return Math.min(needed, config.buyQuantity);
    }

    /**
     * Get number of nature runes to buy
     */
    public int getRunesToBuy() {
        int current = Inventory.count("Nature rune") + Equipment.count("Nature rune") + Bank.count("Nature rune");
        int needed = config.maxNatureRunes - current;
        return Math.min(needed, 1000);
    }
}
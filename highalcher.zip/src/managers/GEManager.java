package managers;

import config.AlchConfig;
import core.AlchLogger;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.Calculations;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Sleep;

/**
 * Manages Grand Exchange operations for buying alch items and nature runes
 */
public class GEManager {

    private final AlchConfig config;
    private final StatsTracker stats;
    private final AlchLogger logger;
    private final AbstractScript script;

    private int itemBuyAttempt = 0;
    private int runeBuyAttempt = 0;
    private boolean waitingForItems = false;
    private boolean waitingForRunes = false;
    private long lastBuyTime = 0;
    private int maxWaitTime = 0;

    public GEManager(AlchConfig config, StatsTracker stats, AbstractScript script) {
        this.config = config;
        this.stats = stats;
        this.script = script;
        this.logger = new AlchLogger("GEManager");
    }

    public int buyAlchItems() {
        String currentItem = config.getCurrentItemName();
        int buyPrice = config.getCurrentAlchItem().buyPrice;

        if (!GrandExchange.isOpen()) {
            logger.log("Opening Grand Exchange...");
            if (GrandExchange.open()) {
                Sleep.sleepUntil(() -> GrandExchange.isOpen(), 5000);
                Sleep.sleep(300, 600);
            } else {
                logger.error("Failed to open GE");
                return Calculations.random(1000, 1500);
            }
        }

        // Check if we're waiting for an existing offer
        if (waitingForItems) {
            long waitTime = System.currentTimeMillis() - lastBuyTime;

            // Check if offer is ready to collect
            if (GrandExchange.isReadyToCollect()) {
                logger.log("Offer ready - collecting...");
                GrandExchange.collect();
                Sleep.sleep(1000, 1500);

                int bought = Inventory.count(currentItem);
                if (bought > 0) {
                    logger.log("✓ Bought " + bought + " " + currentItem);
                    stats.addItemsBought(bought, buyPrice);
                    waitingForItems = false;
                    itemBuyAttempt = 0;

                    // Close GE and head to bank
                    logger.log("Closing GE - heading to bank");
                    GrandExchange.close();
                    Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 3000);
                    return 300;
                }
            }

            // Wait 2-5 minutes
            if (waitTime < maxWaitTime) {
                if (waitTime % 30000 < 5000) {
                    logger.log("Waiting for offer... (" + (waitTime / 1000) + "s / " + (maxWaitTime / 1000) + "s max)");
                }
                return Calculations.random(3000, 5000);
            }

            // Timeout - cancel and retry
            logger.log("Offer timeout (" + (maxWaitTime / 60000) + " minutes) - canceling");
            cancelAllOffers();
            waitingForItems = false;
            itemBuyAttempt++;
            return Calculations.random(1000, 1500);
        }

        // Check if we already have items in inventory (from GE collection)
        int inInventory = Inventory.count(currentItem);
        if (inInventory >= config.buyQuantity) {
            logger.log("✓ Have enough " + currentItem + " in inventory - closing GE");
            itemBuyAttempt = 0;

            GrandExchange.close();
            Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 3000);
            return 300;
        }

        // Check if max attempts reached
        if (itemBuyAttempt >= config.maxBuyAttempts) {
            logger.error("Max buy attempts reached for " + currentItem);
            itemBuyAttempt = 0;

            // Try next item in rotation
            if (config.alchItems.size() > 1) {
                config.currentItemIndex = (config.currentItemIndex + 1) % config.alchItems.size();
                logger.log("Rotating to next item: " + config.getCurrentItemName());
            }

            GrandExchange.close();
            Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 3000);
            return 300;
        }

        // Cancel any existing offers before placing new one
        cancelAllOffers();
        Sleep.sleep(500, 1000);

        // Place new buy offer using simple method
        double priceIncrease = itemBuyAttempt * (config.priceAdjustmentPercent / 100.0);

        // Enforce strict price limits if enabled
        if (config.strictPriceLimits) {
            double maxAllowedIncrease = config.maxPriceIncreasePercent / 100.0;
            if (priceIncrease > maxAllowedIncrease) {
                logger.log("⚠ Price increase would exceed limit (" + (int)(priceIncrease * 100) + "% > " +
                        config.maxPriceIncreasePercent + "%)");
                logger.log("Waiting for offer to complete at max price: +" + config.maxPriceIncreasePercent + "%");
                priceIncrease = maxAllowedIncrease;
                // Don't increment itemBuyAttempt - keep trying at max price
            }
        }

        int offerPrice = (int)(buyPrice * (1.0 + priceIncrease));
        int quantityToBuy = config.buyQuantity;

        logger.log("===========================================");
        logger.log("BUYING ALCH ITEMS");
        logger.log("Item: " + currentItem);
        logger.log("Quantity: " + quantityToBuy);
        logger.log("List price: " + buyPrice + " gp");
        logger.log("Offer price: " + offerPrice + " gp (+" + (int)(priceIncrease * 100) + "%)");
        logger.log("Attempt: " + (itemBuyAttempt + 1) + "/" + config.maxBuyAttempts);
        if (config.strictPriceLimits) {
            logger.log("Strict pricing: ON (max +" + config.maxPriceIncreasePercent + "%)");
        }
        logger.log("===========================================");

        // Simple GE interaction - let DreamBot handle the details
        boolean success = GrandExchange.buyItem(currentItem, quantityToBuy, offerPrice);

        if (success) {
            // Set random wait time between 2-5 minutes
            maxWaitTime = Calculations.random(120000, 300000);
            logger.log("✓ Buy offer placed");
            logger.log("Will wait up to " + (maxWaitTime / 60000) + " minutes for completion");

            waitingForItems = true;
            lastBuyTime = System.currentTimeMillis();
            Sleep.sleep(2000, 3000);
            return Calculations.random(3000, 5000);
        } else {
            logger.error("Failed to place buy offer");
            itemBuyAttempt++;
            return Calculations.random(1000, 1500);
        }
    }

    public int buyNatureRunes() {
        if (!GrandExchange.isOpen()) {
            logger.log("Opening Grand Exchange...");
            if (GrandExchange.open()) {
                Sleep.sleepUntil(() -> GrandExchange.isOpen(), 5000);
                Sleep.sleep(300, 600);
            } else {
                logger.error("Failed to open GE");
                return Calculations.random(1000, 1500);
            }
        }

        // Check if we're waiting for an existing offer
        if (waitingForRunes) {
            long waitTime = System.currentTimeMillis() - lastBuyTime;

            if (GrandExchange.isReadyToCollect()) {
                logger.log("Rune offer ready - collecting...");
                GrandExchange.collect();
                Sleep.sleep(1000, 1500);

                int bought = Inventory.count("Nature rune");
                if (bought > 0) {
                    logger.log("✓ Bought " + bought + " nature runes");
                    stats.addRunesBought(bought, config.natureRuneCost);
                    waitingForRunes = false;
                    runeBuyAttempt = 0;

                    logger.log("Closing GE - heading to bank");
                    GrandExchange.close();
                    Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 3000);
                    return 300;
                }
            }

            // Wait up to max wait time
            if (waitTime < maxWaitTime) {
                if (waitTime % 30000 < 5000) {
                    logger.log("Waiting for rune offer... (" + (waitTime / 1000) + "s / " + (maxWaitTime / 1000) + "s max)");
                }
                return Calculations.random(3000, 5000);
            }

            logger.log("Rune offer timeout - canceling");
            cancelAllOffers();
            waitingForRunes = false;
            runeBuyAttempt++;
            return Calculations.random(1000, 1500);
        }

        int inInventory = Inventory.count("Nature rune");
        if (inInventory >= 500) {
            logger.log("✓ Have enough nature runes - closing GE");
            runeBuyAttempt = 0;

            GrandExchange.close();
            Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 3000);
            return 300;
        }

        if (runeBuyAttempt >= config.maxBuyAttempts) {
            logger.error("Max buy attempts reached for nature runes");
            runeBuyAttempt = 0;

            GrandExchange.close();
            Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 3000);
            return 300;
        }

        cancelAllOffers();
        Sleep.sleep(500, 1000);

        double priceIncrease = runeBuyAttempt * (config.priceAdjustmentPercent / 100.0);
        int offerPrice = (int)(config.natureRuneCost * (1.0 + priceIncrease));
        int quantityToBuy = 1000;

        logger.log("===========================================");
        logger.log("BUYING NATURE RUNES");
        logger.log("Quantity: " + quantityToBuy);
        logger.log("Price: " + offerPrice + " gp (+" + (int)(priceIncrease * 100) + "%)");
        logger.log("Attempt: " + (runeBuyAttempt + 1) + "/" + config.maxBuyAttempts);
        logger.log("===========================================");

        boolean success = GrandExchange.buyItem("Nature rune", quantityToBuy, offerPrice);

        if (success) {
            maxWaitTime = Calculations.random(120000, 300000);
            logger.log("✓ Rune offer placed - waiting up to " + (maxWaitTime / 60000) + " minutes");

            waitingForRunes = true;
            lastBuyTime = System.currentTimeMillis();
            Sleep.sleep(2000, 3000);
            return Calculations.random(3000, 5000);
        } else {
            logger.error("Failed to place rune buy offer");
            runeBuyAttempt++;
            return Calculations.random(1000, 1500);
        }
    }

    private void cancelAllOffers() {
        logger.log("Canceling any pending offers...");
        for (int slot = 0; slot < 8; slot++) {
            if (GrandExchange.slotContainsItem(slot)) {
                GrandExchange.cancelOffer(slot);
                Sleep.sleep(300, 500);
            }
        }

        if (GrandExchange.isReadyToCollect()) {
            GrandExchange.collect();
            Sleep.sleep(1000, 1500);
        }
    }
}
package managers;

import config.AlchConfig;
import core.AlchLogger;
import org.dreambot.api.methods.Calculations;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.world.Worlds;
import org.dreambot.api.methods.worldhopper.WorldHopper;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Sleep;

/**
 * Manages F2P world hopping with random intervals
 */
public class WorldHopperManager {

    private final AlchConfig config;
    private final AlchLogger logger;
    private final AbstractScript script;

    private int currentWorldIndex = 0;
    private long lastHopTime = 0;
    private int nextHopDelay = 0;

    // F2P worlds (safe list)
    private static final int[] F2P_WORLDS = {
            301, 308, 316, 326, 335, 379, 380, 382, 383, 384,
            397, 398, 399, 417, 418, 430, 431, 433, 434, 435,
            436, 437, 451, 452, 453, 454, 455, 456, 469,
            483, 497, 498, 499, 537, 552, 553, 554, 555
    };

    public WorldHopperManager(AlchConfig config, AbstractScript script) {
        this.config = config;
        this.script = script;
        this.logger = new AlchLogger("WorldHopper");
        initializeWorldIndex();
        generateNextHopDelay();
    }

    /**
     * Initialize world index based on current world
     */
    private void initializeWorldIndex() {
        int currentWorld = Worlds.getCurrentWorld();
        for (int i = 0; i < F2P_WORLDS.length; i++) {
            if (F2P_WORLDS[i] == currentWorld) {
                currentWorldIndex = i;
                logger.log("Current world index: " + i + " (World " + currentWorld + ")");
                return;
            }
        }
        currentWorldIndex = 0;
        logger.log("Not on F2P world, starting at index 0");
    }

    /**
     * Generate next hop delay based on config
     */
    private void generateNextHopDelay() {
        nextHopDelay = Calculations.random(
                config.worldHopMinMinutes * 60000,
                config.worldHopMaxMinutes * 60000
        );
        logger.log("Next world hop in: " + (nextHopDelay / 60000) + " minutes");
    }

    /**
     * Check if it's time to hop worlds
     */
    public boolean shouldHop() {
        if (!config.enableWorldHopping) {
            return false;
        }

        long timeSinceLastHop = System.currentTimeMillis() - lastHopTime;
        return timeSinceLastHop >= nextHopDelay;
    }

    /**
     * Perform world hop
     */
    public int hopWorld() {
        if (!config.enableWorldHopping) {
            return 300;
        }

        logger.log("===========================================");
        logger.log("HOPPING WORLDS");
        logger.log("===========================================");

        // Safety: do not hop while in combat
        if (Players.getLocal() != null && Players.getLocal().isInCombat()) {
            logger.log("In combat - delaying world hop");
            return Calculations.random(800, 1200);
        }

        // Close interfaces that block hopping
        if (Bank.isOpen()) {
            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 2500);
        }

        if (Dialogues.inDialogue()) {
            if (Dialogues.canContinue()) {
                Dialogues.continueDialogue();
            }
            return Calculations.random(400, 700);
        }

        int currentWorld = Worlds.getCurrentWorld();

        // Select next world
        int nextWorld = currentWorld;
        int attempts = 0;

        while (nextWorld == currentWorld && attempts < 10) {
            nextWorld = F2P_WORLDS[currentWorldIndex];
            currentWorldIndex = (currentWorldIndex + 1) % F2P_WORLDS.length;
            attempts++;
        }

        final int targetWorld = nextWorld;

        logger.log("Hopping: World " + currentWorld + " → World " + targetWorld);

        // Perform the hop
        boolean initiated = WorldHopper.hopWorld(targetWorld);
        if (!initiated) {
            logger.error("World hop initiation failed");
            return Calculations.random(900, 1400);
        }

        // Wait until the world actually changes
        boolean success = Sleep.sleepUntil(
                () -> Worlds.getCurrentWorld() == targetWorld,
                15000
        );

        if (!success) {
            logger.error("World hop timed out. Still on: " + Worlds.getCurrentWorld());
            return Calculations.random(1000, 1600);
        }

        logger.log("✓ Successfully hopped to World " + targetWorld);

        // Allow time for login + region load
        Sleep.sleep(Calculations.random(1800, 3000));

        // Reset timer and generate next delay
        lastHopTime = System.currentTimeMillis();
        generateNextHopDelay();

        logger.log("===========================================");

        return Calculations.random(600, 900);
    }

    /**
     * Get time until next hop in minutes
     */
    public int getTimeUntilNextHop() {
        if (!config.enableWorldHopping) {
            return -1;
        }

        long timeSinceLastHop = System.currentTimeMillis() - lastHopTime;
        long timeRemaining = nextHopDelay - timeSinceLastHop;

        if (timeRemaining <= 0) {
            return 0;
        }

        return (int) (timeRemaining / 60000);
    }

    /**
     * Force immediate world hop
     */
    public void forceHop() {
        lastHopTime = 0;
        nextHopDelay = 0;
    }
}
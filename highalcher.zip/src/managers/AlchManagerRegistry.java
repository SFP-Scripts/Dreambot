package managers;

import config.AlchConfig;
import core.AlchLogger;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.script.AbstractScript;

/**
 * Registry for all alching managers with state machine
 */
public class AlchManagerRegistry {

    private final AlchConfig config;
    private final AlchLogger logger;
    private final AbstractScript script;

    private SupplyCheckManager supplyChecker;
    private NavigationManager navigationManager;
    private GEManager geManager;
    private BankManager bankManager;
    private AlchManager alchManager;
    private StatsTracker statsTracker;

    private AlchState currentState = AlchState.CHECKING_SUPPLIES;

    public enum AlchState {
        CHECKING_SUPPLIES,
        GOING_TO_GE,
        BUYING_ITEMS,
        BUYING_RUNES,
        GOING_TO_BANK,
        WITHDRAWING_SUPPLIES,
        ALCHING,
        COMPLETED
    }

    public AlchManagerRegistry(AlchConfig config, AbstractScript script) {
        this.config = config;
        this.script = script;
        this.logger = new AlchLogger("ManagerRegistry");
    }

    public void initializeAll() {
        logger.log("Initializing all managers...");

        statsTracker = new StatsTracker(config);
        supplyChecker = new SupplyCheckManager(config, statsTracker);
        navigationManager = new NavigationManager(config, script);
        geManager = new GEManager(config, statsTracker, script);
        bankManager = new BankManager(config, statsTracker, script);
        alchManager = new AlchManager(config, statsTracker, script);

        logger.log("✓ All managers initialized");
    }

    public int executeCurrentState() {
        // Don't interfere with GE if we're actively using it
        if (currentState != AlchState.BUYING_ITEMS &&
                currentState != AlchState.BUYING_RUNES &&
                currentState != AlchState.GOING_TO_GE) {

            // Only close GE if we're not at GE and not buying
            if (!navigationManager.isAtGE() && org.dreambot.api.methods.grandexchange.GrandExchange.isOpen()) {
                logger.log("⚠ GE is open but we're not using it - closing");
                org.dreambot.api.methods.grandexchange.GrandExchange.close();
                org.dreambot.api.utilities.Sleep.sleepUntil(() ->
                        !org.dreambot.api.methods.grandexchange.GrandExchange.isOpen(), 3000);
                return 300;
            }
        }

        // Determine state
        AlchState previousState = currentState;
        determineState();

        // Log state changes
        if (previousState != currentState) {
            logger.log("State change: " + previousState + " → " + currentState);
        }

        // Execute state
        switch (currentState) {
            case CHECKING_SUPPLIES:
                return supplyChecker.checkSupplies();

            case GOING_TO_GE:
                return navigationManager.walkToGE();

            case BUYING_ITEMS:
                return geManager.buyAlchItems();

            case BUYING_RUNES:
                return geManager.buyNatureRunes();

            case GOING_TO_BANK:
                return navigationManager.walkToBank();

            case WITHDRAWING_SUPPLIES:
                return bankManager.withdrawSupplies();

            case ALCHING:
                return alchManager.performAlching();

            case COMPLETED:
                logger.log("Script completed!");
                return 10000;

            default:
                return 1000;
        }
    }

    private void determineState() {
        // PRIORITY 1: Alch if we have items and runes in inventory
        if (alchManager.canAlch()) {
            currentState = AlchState.ALCHING;
            return;
        }

        // PRIORITY 2: Check bank for items BEFORE going to GE
        String currentItem = config.getCurrentItemName();
        int itemsInBank = Bank.count(currentItem);
        int runesInBank = Bank.count("Nature rune");

        if (itemsInBank > 0 || runesInBank > 0) {
            // We have items or runes in bank - go get them
            if (navigationManager.isAtBank()) {
                currentState = AlchState.WITHDRAWING_SUPPLIES;
            } else {
                currentState = AlchState.GOING_TO_BANK;
            }
            return;
        }

        // PRIORITY 3: Only go to GE if inventory AND bank are empty
        if (supplyChecker.needsToVisitGE()) {
            if (navigationManager.isAtGE()) {
                if (supplyChecker.needsAlchItems()) {
                    currentState = AlchState.BUYING_ITEMS;
                } else {
                    currentState = AlchState.BUYING_RUNES;
                }
            } else {
                currentState = AlchState.GOING_TO_GE;
            }
            return;
        }

        // Fallback - check supplies
        currentState = AlchState.CHECKING_SUPPLIES;
    }

    public SupplyCheckManager getSupplyChecker() { return supplyChecker; }
    public NavigationManager getNavigationManager() { return navigationManager; }
    public GEManager getGEManager() { return geManager; }
    public BankManager getBankManager() { return bankManager; }
    public AlchManager getAlchManager() { return alchManager; }
    public StatsTracker getStatsTracker() { return statsTracker; }
    public AlchState getCurrentState() { return currentState; }
}
package managers;

import config.AlchConfig;
import core.AlchLogger;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.Calculations;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Sleep;

/**
 * Manages banking operations for withdrawing supplies
 */
public class BankManager {

    private final AlchConfig config;
    private final StatsTracker stats;
    private final AlchLogger logger;
    private final AbstractScript script;

    public BankManager(AlchConfig config, StatsTracker stats, AbstractScript script) {
        this.config = config;
        this.stats = stats;
        this.script = script;
        this.logger = new AlchLogger("BankManager");
    }

    public int withdrawSupplies() {
        String currentItem = config.getCurrentItemName();

        if (!Bank.isOpen()) {
            logger.log("Opening bank...");
            if (Bank.open()) {
                Sleep.sleepUntil(() -> Bank.isOpen(), 5000);
                Sleep.sleep(300, 600);
            } else {
                logger.error("Failed to open bank");
                return Calculations.random(1000, 1500);
            }
        }

        logger.log("===========================================");
        logger.log("WITHDRAWING SUPPLIES");
        logger.log("===========================================");

        // Check if we have the items in bank
        int itemsInBank = Bank.count(currentItem);
        if (itemsInBank == 0) {
            logger.error("No " + currentItem + " in bank! Need to buy from GE.");
            if (Bank.isOpen()) {
                Bank.close();
                Sleep.sleepUntil(() -> !Bank.isOpen(), 2000);
            }
            return 300;
        }

        // Withdraw items (can be noted - we can alch noted items!)
        int toWithdraw = Math.min(27, itemsInBank);
        logger.log("Withdrawing " + toWithdraw + " " + currentItem + "...");

        if (Bank.withdraw(currentItem, toWithdraw)) {
            Sleep.sleepUntil(() -> Inventory.count(currentItem) > 0, 3000);
            Sleep.sleep(300, 600);

            int withdrawn = Inventory.count(currentItem);
            logger.log("✓ Withdrew " + withdrawn + " " + currentItem);
        } else {
            logger.error("Failed to withdraw " + currentItem);
        }

        // Withdraw nature runes
        int runesInBank = Bank.count("Nature rune");
        if (runesInBank > 0) {
            logger.log("Withdrawing nature runes...");
            Bank.withdrawAll("Nature rune");
            Sleep.sleepUntil(() -> Inventory.contains("Nature rune"), 3000);
            Sleep.sleep(300, 600);

            int withdrawn = Inventory.count("Nature rune");
            logger.log("✓ Withdrew " + withdrawn + " nature runes");
        } else {
            logger.log("⚠ No nature runes in bank - will need to buy more");
        }

        boolean hasItems = Inventory.contains(currentItem);
        boolean hasRunes = Inventory.contains("Nature rune");

        if (hasItems && hasRunes) {
            logger.log("===========================================");
            logger.log("✓ SUPPLIES READY FOR ALCHING");
            logger.log("Items: " + Inventory.count(currentItem));
            logger.log("Runes: " + Inventory.count("Nature rune"));
            logger.log("===========================================");

            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 2000);
            return 300;
        } else {
            logger.error("Missing supplies!");
            logger.error("Has items: " + hasItems);
            logger.error("Has runes: " + hasRunes);

            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 2000);
            return Calculations.random(1000, 1500);
        }
    }

    public int depositAll() {
        if (!Bank.isOpen()) {
            if (Bank.open()) {
                Sleep.sleepUntil(() -> Bank.isOpen(), 5000);
            }
            return Calculations.random(600, 900);
        }

        Bank.depositAllItems();
        Sleep.sleepUntil(() -> Inventory.isEmpty(), 3000);

        return 300;
    }
}
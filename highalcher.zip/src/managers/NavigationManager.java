package managers;

import config.AlchConfig;
import core.AlchLogger;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.Calculations;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Sleep;

/**
 * Handles navigation between locations
 */
public class NavigationManager {

    private final AlchConfig config;
    private final AlchLogger logger;
    private final AbstractScript script;

    // Grand Exchange area
    private static final Area GE_AREA = new Area(3161, 3484, 3168, 3492, 0);

    // Varrock West Bank area
    private static final Area VARROCK_WEST_BANK = new Area(3180, 3433, 3188, 3448, 0);

    public NavigationManager(AlchConfig config, AbstractScript script) {
        this.config = config;
        this.script = script;
        this.logger = new AlchLogger("Navigation");
    }

    public boolean isAtGE() {
        return GE_AREA.contains(Players.getLocal());
    }

    public boolean isAtBank() {
        return VARROCK_WEST_BANK.contains(Players.getLocal());
    }

    public int walkToGE() {
        if (isAtGE()) {
            logger.log("Already at GE");
            return 300;
        }

        logger.log("Walking to Grand Exchange...");

        Tile geTile = new Tile(3165, 3487, 0);

        if (Walking.shouldWalk()) {
            Walking.walk(geTile);
        }

        Sleep.sleepUntil(() -> isAtGE(), 10000);

        return Calculations.random(600, 900);
    }

    public int walkToBank() {
        if (isAtBank()) {
            logger.log("Already at bank");
            return 300;
        }

        logger.log("Walking to Varrock West Bank...");

        Tile bankTile = new Tile(3185, 3442, 0);

        if (Walking.shouldWalk()) {
            Walking.walk(bankTile);
        }

        Sleep.sleepUntil(() -> isAtBank(), 10000);

        return Calculations.random(600, 900);
    }
}
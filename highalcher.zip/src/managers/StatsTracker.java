package managers;

import config.AlchConfig;

/**
 * Tracks alching statistics
 */
public class StatsTracker {

    private final AlchConfig config;
    private final long startTime;

    private int itemsAlched = 0;
    private int totalProfit = 0;
    private int itemsBought = 0;
    private int runesBought = 0;
    private int totalSpent = 0;

    public StatsTracker(AlchConfig config) {
        this.config = config;
        this.startTime = System.currentTimeMillis();
    }

    public void incrementAlched() {
        itemsAlched++;
        totalProfit += config.getProfitPerAlch();
    }

    public void addItemsBought(int count, int pricePerItem) {
        itemsBought += count;
        totalSpent += (count * pricePerItem);
    }

    public void addRunesBought(int count, int pricePerRune) {
        runesBought += count;
        totalSpent += (count * pricePerRune);
    }

    public int getItemsAlched() {
        return itemsAlched;
    }

    public int getTotalProfit() {
        return totalProfit;
    }

    public int getProfitPerHour() {
        long runtime = System.currentTimeMillis() - startTime;
        if (runtime <= 0) return 0;
        return (int)((totalProfit / (runtime / 1000.0)) * 3600);
    }

    public int getItemsBought() {
        return itemsBought;
    }

    public int getRunesBought() {
        return runesBought;
    }

    public int getTotalSpent() {
        return totalSpent;
    }

    public long getRuntime() {
        return System.currentTimeMillis() - startTime;
    }
}
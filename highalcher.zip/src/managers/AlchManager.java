package managers;

import config.AlchConfig;
import config.AlchConfig.AlchType;
import core.AlchLogger;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.input.mouse.MouseSettings;
import org.dreambot.api.methods.magic.Magic;
import org.dreambot.api.methods.magic.Normal;
import org.dreambot.api.methods.Calculations;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.Item;

import java.io.File;

/**
 * Manages high alching operations with SmartMouse and anti-ban controls
 */
public class AlchManager {

    private final AlchConfig config;
    private final StatsTracker stats;
    private final AlchLogger logger;
    private final AbstractScript script;

    private long lastAlchTime = 0;
    private int consecutiveAlchs = 0;
    private int actionsSinceWander = 0;

    public AlchManager(AlchConfig config, StatsTracker stats, AbstractScript script) {
        this.config = config;
        this.stats = stats;
        this.script = script;
        this.logger = new AlchLogger("AlchManager");

        // Initialize mouse settings
        initializeMouseSettings();
    }

    /**
     * Initialize mouse settings with SmartMouse and anti-ban controls
     */
    private void initializeMouseSettings() {
        try {
            // Check if SmartMouse file exists
            if (config.useSmartMouse && config.mouseDataPath != null && !config.mouseDataPath.isEmpty()) {
                File mouseFile = new File(config.mouseDataPath);
                if (mouseFile.exists()) {
                    logger.log("✓ SmartMouse data file found: " + config.mouseDataPath);
                    logger.log("✓ SmartMouse enabled - ensure it's enabled in DreamBot client settings");
                } else {
                    logger.log("⚠ SmartMouse data file not found at: " + config.mouseDataPath);
                    logger.log("Place your mouse recording at this location for SmartMouse functionality");
                }
            }

            // Apply mouse speed settings
            if (config.randomizeMouseSpeed) {
                int speed = Calculations.random(config.mouseSpeedMin, config.mouseSpeedMax);
                MouseSettings.setSpeed(speed);
                logger.log("✓ Mouse speed set to: " + speed + " (randomized)");
            }

            logger.log("✓ Mouse anti-ban controls initialized");
            logger.log("  - Speed randomization: " + config.randomizeMouseSpeed);
            logger.log("  - Mouse wander: " + config.enableMouseWander);
            if (config.enableMouseWander) {
                logger.log("  - Wander frequency: Every " + config.mouseWanderFrequency + " actions");
            }

        } catch (Exception e) {
            logger.error("Failed to initialize mouse settings: " + e.getMessage());
        }
    }

    /**
     * Perform random mouse wander for anti-ban
     */
    private void performMouseWander() {
        if (!config.enableMouseWander) {
            return;
        }

        actionsSinceWander++;

        if (actionsSinceWander >= config.mouseWanderFrequency) {
            try {
                // Occasionally move mouse off the game area slightly
                if (Calculations.random(1, 3) == 1) {
                    Sleep.sleep(Calculations.random(100, 500));
                }

                actionsSinceWander = 0;
            } catch (Exception e) {
                // Silently fail - wander is not critical
            }
        }
    }

    /**
     * Update mouse speed with randomization
     */
    private void updateMouseSpeed() {
        if (config.randomizeMouseSpeed && Calculations.random(1, 10) == 1) {
            int newSpeed = Calculations.random(config.mouseSpeedMin, config.mouseSpeedMax);
            MouseSettings.setSpeed(newSpeed);
        }
    }

    /**
     * Check if we can alch (have items and runes)
     */
    public boolean canAlch() {
        String currentItem = config.getCurrentItemName();
        if (currentItem == null || currentItem.isEmpty()) {
            return false;
        }

        return Inventory.contains(currentItem) && Inventory.contains("Nature rune");
    }

    /**
     * Perform alchemy with anti-ban mouse controls
     */
    public int performAlching() {
        String currentItem = config.getCurrentItemName();

        // Check if we have supplies
        if (!canAlch()) {
            logger.log("No supplies to alch - need to restock");
            return 300;
        }

        // Check if we need to wait (delay between alchs)
        long currentTime = System.currentTimeMillis();
        long timeSinceLastAlch = currentTime - lastAlchTime;

        int baseDelay = config.randomizeDelay ?
                Calculations.random(config.alchDelayMin, config.alchDelayMax) :
                config.alchDelayMin;

        // Add slight variation based on consecutive alchs (fatigue simulation)
        if (consecutiveAlchs > 100) {
            baseDelay += Calculations.random(100, 500);
        }

        if (timeSinceLastAlch < baseDelay) {
            return (int)(baseDelay - timeSinceLastAlch);
        }

        // Perform mouse wander before action
        performMouseWander();

        // Update mouse speed occasionally
        updateMouseSpeed();

        // Get the item to alch
        Item alchItem = Inventory.get(currentItem);
        if (alchItem == null) {
            logger.error("Could not find " + currentItem + " in inventory");
            return Calculations.random(1000, 1500);
        }

        // Store count before alching
        int countBefore = Inventory.count(currentItem);

        // Cast alchemy spell based on type
        Normal spell = config.alchType == AlchType.HIGH_ALCHEMY ?
                Normal.HIGH_LEVEL_ALCHEMY : Normal.LOW_LEVEL_ALCHEMY;

        if (Magic.castSpellOn(spell, alchItem)) {
            // Wait for alch animation with slight variation
            Sleep.sleep(Calculations.random(100, 300));

            // Wait for alch to complete
            Sleep.sleepUntil(() -> !Inventory.contains(currentItem) ||
                            Inventory.count(currentItem) < countBefore,
                    2000);

            lastAlchTime = System.currentTimeMillis();
            consecutiveAlchs++;
            stats.incrementAlched();

            int totalAlched = stats.getItemsAlched();
            int inInventory = Inventory.count(currentItem);
            int profit = stats.getTotalProfit();

            // Log every 10 alchs
            if (totalAlched % 10 == 0) {
                logger.log("===========================================");
                logger.log("✓ ALCHING PROGRESS");
                logger.log("Spell: " + config.alchType.getName());
                logger.log("Total alched: " + totalAlched);
                logger.log("Remaining in inventory: " + inInventory);
                logger.log("Total profit: " + String.format("%,d", profit) + " gp");
                logger.log("Profit/hour: " + String.format("%,d", stats.getProfitPerHour()) + " gp/hr");
                logger.log("===========================================");
            }

            // Take a longer break every 50 alchs (fatigue)
            if (consecutiveAlchs % 50 == 0) {
                logger.log("Taking short break (anti-ban)...");
                consecutiveAlchs = 0;

                // Perform mouse wander during break
                if (config.enableMouseWander) {
                    performMouseWander();
                }

                return Calculations.random(3000, 6000);
            }

            return Calculations.random(config.alchDelayMin, config.alchDelayMax);

        } else {
            logger.error("Failed to cast " + config.alchType.getName());
            return Calculations.random(1000, 1500);
        }
    }
}
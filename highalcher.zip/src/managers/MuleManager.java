package managers;

import config.AlchConfig;
import core.AlchLogger;
import mule.client.MuleClientSnippet;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.script.AbstractScript;

/**
 * Manages muling of alch items and coins
 */
public class MuleManager {

    private final AlchConfig config;
    private final StatsTracker stats;
    private final AlchLogger logger;
    private final AbstractScript script;

    private MuleClientSnippet muleClient;
    private boolean muleInitialized = false;

    // Tracking
    private int itemsMuledTotal = 0;
    private int coinsMuledTotal = 0;
    private int muleSessionsCompleted = 0;

    public MuleManager(AlchConfig config, StatsTracker stats, AbstractScript script) {
        this.config = config;
        this.stats = stats;
        this.script = script;
        this.logger = new AlchLogger("MuleManager");
    }

    /**
     * Initialize mule client with configuration
     */
    public void initializeMule() {
        if (!config.muleEnabled) {
            logger.log("Mule system disabled");
            return;
        }

        try {
            muleClient = new MuleClientSnippet(
                    script,
                    config.muleServerHost,
                    config.muleServerPort,
                    config.muleAuthToken
            );

            muleClient.setAutoWalkToMule(config.muleAutoWalk);
            muleClient.setMaxWalkDistance(50);
            muleClient.setTradeTimeout(30000);

            muleInitialized = true;

            logger.log("✓ Mule client initialized");
            logger.log("Server: " + config.muleServerHost + ":" + config.muleServerPort);

            // Test connection
            if (muleClient.pingMule()) {
                logger.log("✓ Successfully connected to mule server!");
            } else {
                logger.log("⚠ Warning: Could not ping mule server");
            }

        } catch (Exception e) {
            logger.error("Failed to initialize mule client: " + e.getMessage());
            muleInitialized = false;
        }
    }

    /**
     * Check if it's time to mule based on items alched
     */
    public boolean shouldMule() {
        if (!config.muleEnabled || !muleInitialized) {
            return false;
        }

        if (muleClient == null) {
            return false;
        }

        try {
            int totalAlched = stats.getItemsAlched();
            return totalAlched >= config.muleAfterItems && totalAlched > 0;
        } catch (Exception e) {
            logger.log("Error checking mule threshold: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deposit items to mule
     */
    public boolean depositToMule() {
        if (!config.muleEnabled || !muleInitialized) {
            logger.log("Mule not enabled or not initialized");
            return false;
        }

        if (muleClient == null) {
            logger.log("Mule client not initialized");
            return false;
        }

        logger.log("===========================================");
        logger.log("STARTING MULE SESSION #" + (muleSessionsCompleted + 1));
        logger.log("===========================================");

        try {
            // Count items before muling
            int coinsCount = Inventory.contains("Coins") ? Inventory.count("Coins") : 0;

            // Count all items excluding coins
            int totalItems = 0;
            for (org.dreambot.api.wrappers.items.Item item : Inventory.all()) {
                if (item != null && !item.getName().equals("Coins")) {
                    totalItems++;
                }
            }

            logger.log("Items to deposit:");
            logger.log("  - Total items: " + totalItems);
            logger.log("  - Coins: " + coinsCount);

            // Deposit all items including coins
            boolean success = muleClient.depositAllItems(coinsCount);

            if (success) {
                // Update totals
                itemsMuledTotal += totalItems;
                coinsMuledTotal += coinsCount;
                muleSessionsCompleted++;

                logger.log("===========================================");
                logger.log("✓ MULE SESSION COMPLETED!");
                logger.log("Total items muled: " + itemsMuledTotal);
                logger.log("Total coins muled: " + coinsMuledTotal);
                logger.log("Mule sessions: " + muleSessionsCompleted);
                logger.log("===========================================");

                return true;
            } else {
                logger.log("Mule session failed - will retry later");
                return false;
            }

        } catch (Exception e) {
            logger.error("Error during mule session: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Withdraw items from mule
     */
    public boolean withdrawFromMule() {
        if (!config.muleEnabled || !muleInitialized) {
            logger.log("Mule not enabled or not initialized");
            return false;
        }

        logger.log("===========================================");
        logger.log("WITHDRAWING FROM MULE");
        logger.log("===========================================");

        try {
            // Create withdrawal request for configured items
            java.util.Map<String, Integer> items = new java.util.HashMap<>();

            // Add current alch item if specified
            String currentItem = config.getCurrentItemName();
            if (currentItem != null && !currentItem.isEmpty()) {
                items.put(currentItem, config.buyQuantity);
            }

            boolean success = muleClient.withdrawItems(items, config.muleWithdrawGP);

            if (success) {
                logger.log("✓ Successfully withdrew items from mule!");
                return true;
            } else {
                logger.log("Withdrawal failed");
                return false;
            }

        } catch (Exception e) {
            logger.error("Error during withdrawal: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Cleanup mule connection
     */
    public void cleanup() {
        if (muleClient != null) {
            muleClient.cleanup();
            logger.log("Mule connection closed");
        }
    }

    // Getters

    public boolean isMuleEnabled() {
        return config.muleEnabled && muleInitialized;
    }

    public int getItemsMuledTotal() {
        return itemsMuledTotal;
    }

    public int getCoinsMuledTotal() {
        return coinsMuledTotal;
    }

    public int getMuleSessionsCompleted() {
        return muleSessionsCompleted;
    }

    public String getMuleStatus() {
        if (!config.muleEnabled) {
            return "Disabled";
        }
        if (!muleInitialized || muleClient == null) {
            return "Not initialized";
        }
        try {
            return muleClient.getMuleStatus();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}
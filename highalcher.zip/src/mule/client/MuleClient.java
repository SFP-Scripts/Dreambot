package mule.client;

import mule.models.TradeRequest;
import mule.models.TradeResponse;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

/**
 * HTTP client for communicating with the mule server
 */
public class MuleClient {

    private final String serverHost;
    private final int serverPort;
    private final String authToken;
    private final Gson gson;
    private final String baseUrl;

    /**
     * Constructor
     * @param serverHost Server hostname or IP
     * @param serverPort Server port
     * @param authToken Authentication token
     */
    public MuleClient(String serverHost, int serverPort, String authToken) {
        this.serverHost = serverHost;
        this.serverPort = serverPort;
        this.authToken = authToken;
        this.gson = new Gson();
        this.baseUrl = "http://" + serverHost + ":" + serverPort;
    }

    /**
     * Request a trade from the mule
     * @param request Trade request details
     * @return Trade response from server
     */
    public TradeResponse requestTrade(TradeRequest request) {
        try {
            URL url = new URL(baseUrl + "/trade/request");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // Set request properties
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + authToken);
            conn.setDoOutput(true);

            // Send request
            String jsonRequest = gson.toJson(request);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonRequest.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            // Read response
            int responseCode = conn.getResponseCode();

            if (responseCode == 200) {
                BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "utf-8")
                );
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }

                return gson.fromJson(response.toString(), TradeResponse.class);
            } else {
                return TradeResponse.error("Server returned error code: " + responseCode);
            }

        } catch (Exception e) {
            return TradeResponse.error("Connection failed: " + e.getMessage());
        }
    }

    /**
     * Ping the mule server to check if it's alive
     * @return true if server responds
     */
    public boolean ping() {
        try {
            URL url = new URL(baseUrl + "/ping");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            int responseCode = conn.getResponseCode();
            return responseCode == 200;

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Get mule server status
     * @return Status string
     */
    public String getStatus() {
        try {
            URL url = new URL(baseUrl + "/status");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + authToken);

            int responseCode = conn.getResponseCode();

            if (responseCode == 200) {
                BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "utf-8")
                );
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                return response.toString();
            } else {
                return "Error: " + responseCode;
            }

        } catch (Exception e) {
            return "Offline";
        }
    }

    /**
     * Disconnect from server (cleanup)
     */
    public void disconnect() {
        // No persistent connection, nothing to do
    }

    /**
     * Create a deposit request
     * @param playerName Player making the deposit
     * @param items Items to deposit
     * @param gp GP to deposit
     * @return TradeRequest object
     */
    public static TradeRequest createDepositRequest(String playerName, Map<String, Integer> items, int gp) {
        TradeRequest request = new TradeRequest();
        request.setPlayerName(playerName);
        request.setTradeType("DEPOSIT");
        request.setItems(items);
        request.setGpAmount(gp);
        request.setTimestamp(System.currentTimeMillis());
        return request;
    }

    /**
     * Create a withdrawal request
     * @param playerName Player making the withdrawal
     * @param items Items to withdraw
     * @param gp GP to withdraw
     * @return TradeRequest object
     */
    public static TradeRequest createWithdrawalRequest(String playerName, Map<String, Integer> items, int gp) {
        TradeRequest request = new TradeRequest();
        request.setPlayerName(playerName);
        request.setTradeType("WITHDRAWAL");
        request.setItems(items);
        request.setGpAmount(gp);
        request.setTimestamp(System.currentTimeMillis());
        return request;
    }
}
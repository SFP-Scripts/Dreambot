package mule.models;

/**
 * Data model for trade responses from mule server
 */
public class TradeResponse {

    private boolean success;
    private String message;
    private String muleUsername;
    private int world;
    private String location;
    private long timestamp;

    public TradeResponse() {
        this.timestamp = System.currentTimeMillis();
    }

    /**
     * Create a successful response
     */
    public static TradeResponse success(String message) {
        TradeResponse response = new TradeResponse();
        response.setSuccess(true);
        response.setMessage(message);
        return response;
    }

    /**
     * Create an error response
     */
    public static TradeResponse error(String message) {
        TradeResponse response = new TradeResponse();
        response.setSuccess(false);
        response.setMessage(message);
        return response;
    }

    // Getters and Setters

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMuleUsername() {
        return muleUsername;
    }

    public void setMuleUsername(String muleUsername) {
        this.muleUsername = muleUsername;
    }

    public int getWorld() {
        return world;
    }

    public void setWorld(int world) {
        this.world = world;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "TradeResponse{" +
                "success=" + success +
                ", message='" + message + '\'' +
                ", muleUsername='" + muleUsername + '\'' +
                ", world=" + world +
                ", location='" + location + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}
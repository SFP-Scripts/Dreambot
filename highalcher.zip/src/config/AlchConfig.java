package config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.dreambot.api.utilities.Logger;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Configuration for High Alcher script
 */
public class AlchConfig {

    // GUI settings
    public boolean enableGUI = true;

    // Alching settings - now supports multiple items
    public List<AlchItem> alchItems = new ArrayList<>();
    public int currentItemIndex = 0;

    // Alch type (HIGH_ALCHEMY or LOW_ALCHEMY)
    public AlchType alchType = AlchType.HIGH_ALCHEMY;

    // Legacy single item support (for compatibility)
    public String alchItem = "";
    public int buyPrice = 0;
    public int alchValue = 0;
    public int natureRuneCost = 300;

    // Supply management
    public int minAlchItems = 100;
    public int maxAlchItems = 500;
    public int minNatureRunes = 500;
    public int maxNatureRunes = 2000;

    // GE settings
    public int buyQuantity = 100;
    public int priceAdjustmentPercent = 5;
    public int maxBuyAttempts = 3;

    // Banking settings
    public boolean useVarrockWestBank = true;

    // Safety settings
    public int minCoinsRequired = 50000;
    public boolean stopIfLowCoins = true;

    // Performance settings
    public int alchDelayMin = 2000;
    public int alchDelayMax = 3000;
    public boolean randomizeDelay = true;

    // SmartMouse settings
    public boolean useSmartMouse = true;
    public String mouseDataPath = "";

    // Mouse anti-ban settings
    public int mouseSpeedMin = 80;
    public int mouseSpeedMax = 120;
    public boolean randomizeMouseSpeed = true;
    public boolean enableMouseWander = true;
    public int mouseWanderFrequency = 15; // Wander every X actions

    // World Hopper Settings
    public boolean enableWorldHopping = false;
    public int worldHopMinMinutes = 10;
    public int worldHopMaxMinutes = 30;

    // Mule Settings
    public boolean muleEnabled = false;
    public String muleServerHost = "localhost";
    public int muleServerPort = 43594;
    public String muleAuthToken = "";
    public int muleAfterItems = 500; // Mule after this many items alched
    public boolean muleAutoWalk = true;
    public int muleWithdrawGP = 0;

    // GE Price Limits
    public boolean strictPriceLimits = true; // Only buy at list price or 5% higher
    public int maxPriceIncreasePercent = 5; // Max 5% over list price

    // Statistics
    public transient long startTime = System.currentTimeMillis();

    public AlchConfig() {
        // Don't initialize with default items - user must add them
        // Set default mouse data path to Users\AppData\Roaming\DreamBot\Scripts
        String userHome = System.getProperty("user.home");
        mouseDataPath = userHome + File.separator + "AppData" + File.separator + "Roaming" +
                File.separator + "DreamBot" + File.separator + "Scripts" +
                File.separator + "mousedata.json";
    }

    /**
     * Get current alch item
     */
    public AlchItem getCurrentAlchItem() {
        if (alchItems.isEmpty()) {
            return null;
        }
        if (currentItemIndex >= alchItems.size()) {
            currentItemIndex = 0;
        }
        return alchItems.get(currentItemIndex);
    }

    /**
     * Get current item name
     */
    public String getCurrentItemName() {
        AlchItem item = getCurrentAlchItem();
        return item != null ? item.name : "";
    }

    /**
     * Calculate profit per alch for current item
     */
    public int getProfitPerAlch() {
        AlchItem item = getCurrentAlchItem();
        if (item == null) return 0;

        int alchValue = alchType == AlchType.HIGH_ALCHEMY ? item.highAlchValue : item.lowAlchValue;
        return alchValue - item.buyPrice - natureRuneCost;
    }

    /**
     * Get alch value based on type
     */
    public int getAlchValue() {
        AlchItem item = getCurrentAlchItem();
        if (item == null) return 0;
        return alchType == AlchType.HIGH_ALCHEMY ? item.highAlchValue : item.lowAlchValue;
    }

    /**
     * Calculate total cost to buy supplies
     */
    public int calculateSupplyCost(int itemCount, int runeCount) {
        AlchItem item = getCurrentAlchItem();
        if (item == null) return 0;
        return (itemCount * item.buyPrice) + (runeCount * natureRuneCost);
    }

    /**
     * Check if we have enough coins
     */
    public boolean hasEnoughCoins(int currentCoins, int itemCount, int runeCount) {
        int needed = calculateSupplyCost(itemCount, runeCount);
        return currentCoins >= needed + minCoinsRequired;
    }

    /**
     * Add a custom alch item
     */
    public void addAlchItem(String name, int buyPrice, int highAlchValue, int lowAlchValue) {
        alchItems.add(new AlchItem(name, buyPrice, highAlchValue, lowAlchValue));
    }

    /**
     * Remove an alch item
     */
    public void removeAlchItem(int index) {
        if (index >= 0 && index < alchItems.size()) {
            alchItems.remove(index);
        }
    }

    /**
     * Save config to file
     */
    public void save(String filename) {
        try {
            // Ensure we're saving to DreamBot directory
            String userHome = System.getProperty("user.home");
            String dreambotDir = userHome + File.separator + "AppData" + File.separator + "Roaming" +
                    File.separator + "DreamBot" + File.separator + "Profiles";

            File dir = new File(dreambotDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            String fullPath = dreambotDir + File.separator + filename;
            if (!filename.endsWith(".json")) {
                fullPath += ".json";
            }

            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            try (Writer writer = new FileWriter(fullPath)) {
                gson.toJson(this, writer);
            }
            Logger.log("Config saved: " + fullPath);
        } catch (IOException e) {
            Logger.error("Failed to save config: " + e.getMessage());
        }
    }

    /**
     * Load config from file
     */
    public static AlchConfig load(String filename) {
        try {
            String userHome = System.getProperty("user.home");
            String dreambotDir = userHome + File.separator + "AppData" + File.separator + "Roaming" +
                    File.separator + "DreamBot" + File.separator + "Profiles";

            String fullPath = dreambotDir + File.separator + filename;
            if (!filename.endsWith(".json")) {
                fullPath += ".json";
            }

            File file = new File(fullPath);
            if (!file.exists()) {
                Logger.log("Config file not found, creating new config");
                return new AlchConfig();
            }

            Gson gson = new Gson();
            try (Reader reader = new FileReader(file)) {
                AlchConfig config = gson.fromJson(reader, AlchConfig.class);
                Logger.log("Config loaded: " + fullPath);
                return config;
            }
        } catch (IOException e) {
            Logger.error("Failed to load config: " + e.getMessage());
            return new AlchConfig();
        }
    }

    /**
     * Enum for alchemy types
     */
    public enum AlchType {
        HIGH_ALCHEMY("High Alchemy", 55),
        LOW_ALCHEMY("Low Alchemy", 21);

        private final String name;
        private final int levelRequired;

        AlchType(String name, int levelRequired) {
            this.name = name;
            this.levelRequired = levelRequired;
        }

        public String getName() {
            return name;
        }

        public int getLevelRequired() {
            return levelRequired;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    /**
     * Inner class for alch items
     */
    public static class AlchItem {
        public String name;
        public int buyPrice;
        public int highAlchValue;
        public int lowAlchValue;

        public AlchItem(String name, int buyPrice, int highAlchValue, int lowAlchValue) {
            this.name = name;
            this.buyPrice = buyPrice;
            this.highAlchValue = highAlchValue;
            this.lowAlchValue = lowAlchValue;
        }

        @Override
        public String toString() {
            return name;
        }
    }
}
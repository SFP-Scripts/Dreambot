package script;

import config.AlchConfig;
import config.AlchConfig.AlchType;
import core.AlchLogger;
import gui.AlchGUI;
import managers.AlchManagerRegistry;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.utilities.Sleep;

/**
 * High Alcher Pro - Self-Sufficient High/Low Alching Bot
 */
@ScriptManifest(
        name = "High Alcher Pro",
        description = "Self-sufficient alching with GE integration - High/Low Alchemy",
        author = "YourName",
        version = 2.0,
        category = Category.MAGIC
)
public class HighAlcher extends AbstractScript {

    private AlchConfig config;
    private AlchLogger logger;
    private AlchManagerRegistry managers;
    private boolean initialized = false;
    private long startTime;

    @Override
    public void onStart() {
        try {
            logger = new AlchLogger("HighAlcher");
            logger.logHeader("HIGH ALCHER PRO - STARTING");
            logger.log("Version: 2.0");

            Sleep.sleep(1000, 1500);

            // Load config
            config = new AlchConfig();
            logger.log("Configuration loaded");

            // Show GUI if enabled
            if (config.enableGUI) {
                logger.log("Displaying GUI...");
                if (!showGUI()) {
                    logger.log("GUI cancelled - stopping script");
                    stop();
                    return;
                }
                logger.log("GUI completed");
            }

            // Validate setup
            if (!validateSetup()) {
                logger.error("Setup validation failed - stopping");
                stop();
                return;
            }

            // Initialize managers
            logger.log("Initializing managers...");
            Sleep.sleep(500, 1000);

            managers = new AlchManagerRegistry(config, this);
            managers.initializeAll();

            startTime = System.currentTimeMillis();
            initialized = true;
            logger.logHeader("INITIALIZATION COMPLETE");

        } catch (Exception e) {
            if (logger != null) {
                logger.error("Failed to initialize: " + e.getMessage());
            }
            e.printStackTrace();
            stop();
        }
    }

    private boolean showGUI() {
        try {
            final AlchGUI[] guiHolder = new AlchGUI[1];

            javax.swing.SwingUtilities.invokeLater(() -> {
                guiHolder[0] = new AlchGUI(config);
                guiHolder[0].setVisible(true);
            });

            // Wait for GUI to be created
            int attempts = 0;
            while (guiHolder[0] == null && attempts < 100) {
                Sleep.sleep(50);
                attempts++;
            }

            if (guiHolder[0] == null) {
                logger.error("GUI failed to initialize");
                return false;
            }

            // Wait for user to close GUI
            AlchGUI gui = guiHolder[0];
            while (gui.isVisible()) {
                Sleep.sleep(100);
            }

            boolean started = gui.isStarted();
            logger.log("GUI closed. Started: " + started);

            return started;

        } catch (Exception e) {
            logger.error("GUI error: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private boolean validateSetup() {
        try {
            // Check magic level
            int magicLevel = Skills.getRealLevel(Skill.MAGIC);
            int requiredLevel = config.alchType.getLevelRequired();

            if (magicLevel < requiredLevel) {
                logger.error("Magic level too low! Need " + requiredLevel + " for " +
                        config.alchType.getName() + ", have " + magicLevel);
                return false;
            }

            // Check if items were added
            if (config.alchItems == null || config.alchItems.isEmpty()) {
                logger.error("No alch items added! Please add items to the list.");
                return false;
            }

            logger.log("✓ Magic level: " + magicLevel);
            logger.log("✓ Alchemy type: " + config.alchType.getName());
            logger.log("✓ Items in list: " + config.alchItems.size());
            logger.log("✓ First item: " + config.getCurrentItemName());
            logger.log("✓ Profit per alch: " + config.getProfitPerAlch() + " gp");

            return true;
        } catch (Exception e) {
            logger.error("Validation error: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public int onLoop() {
        if (!initialized || managers == null) {
            return 5000;
        }

        try {
            return managers.executeCurrentState();
        } catch (Exception e) {
            logger.error("Loop error: " + e.getMessage());
            e.printStackTrace();
            return 2000;
        }
    }

    @Override
    public void onExit() {
        try {
            if (logger != null && managers != null && managers.getStatsTracker() != null) {
                long runtime = System.currentTimeMillis() - startTime;
                logger.logHeader("SCRIPT STOPPED");
                logger.log("Alchemy type: " + config.alchType.getName());
                logger.log("Runtime: " + formatTime(runtime));
                logger.log("Statistics:");
                logger.log("  Items alched: " + managers.getStatsTracker().getItemsAlched());
                logger.log("  Total profit: " + managers.getStatsTracker().getTotalProfit() + " gp");
                logger.log("  Profit/hour: " + managers.getStatsTracker().getProfitPerHour() + " gp/hr");
            }
        } catch (Exception e) {
            // Silently fail on exit to prevent crashes
        }
    }

    private String formatTime(long ms) {
        long seconds = ms / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        return String.format("%02d:%02d:%02d", hours, minutes % 60, seconds % 60);
    }
}
package gui;

import config.AlchConfig;
import config.AlchConfig.AlchItem;
import config.AlchConfig.AlchType;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;

/**
 * GUI for High Alcher configuration
 */
public class AlchGUI extends JFrame {

    private final AlchConfig config;
    private boolean started = false;

    // Components
    private JComboBox<AlchType> alchTypeCombo;
    private JTextField itemNameField;
    private JTextField buyPriceField;
    private JTextField highAlchValueField;
    private JTextField lowAlchValueField;
    private JTable itemTable;
    private DefaultTableModel tableModel;
    private JTextField profileNameField;
    private JComboBox<String> profileCombo;

    // SmartMouse components
    private JCheckBox useSmartMouseCheckbox;
    private JTextField mouseDataPathField;
    private JButton browseMouseDataButton;

    // Mouse control components
    private JCheckBox randomizeMouseSpeedCheckbox;
    private JSpinner mouseSpeedMinSpinner;
    private JSpinner mouseSpeedMaxSpinner;
    private JCheckBox enableMouseWanderCheckbox;
    private JSpinner mouseWanderFrequencySpinner;

    // Common items list
    private JList<String> commonItemsList;

    public AlchGUI(AlchConfig config) {
        this.config = config;
        initializeGUI();
    }

    private void initializeGUI() {
        setTitle("High Alcher Pro - Configuration");
        setSize(900, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create tabbed pane for better organization
        JTabbedPane tabbedPane = new JTabbedPane();

        // Tab 1: Items
        tabbedPane.addTab("Items", createItemsTab());

        // Tab 2: Settings
        tabbedPane.addTab("Settings", createSettingsTab());

        // Tab 3: World Hopper
        tabbedPane.addTab("World Hopper", createWorldHopperTab());

        // Tab 4: Mule
        tabbedPane.addTab("Mule", createMuleTab());

        // Tab 5: Profiles
        tabbedPane.addTab("Profiles", createProfilesTab());

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(createControlPanel(), BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createItemsTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));

        // Left panel - Common items list
        JPanel leftPanel = new JPanel(new BorderLayout(5, 5));
        leftPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Common Alch Items (Double-Click to Add)",
                TitledBorder.LEFT, TitledBorder.TOP));

        String[] commonItems = {
                "Rune platelegs - 38000/40000/26400",
                "Rune platebody - 38500/39000/25740",
                "Rune 2h sword - 37500/38400/25344",
                "Rune longsword - 18500/19200/12672",
                "Rune scimitar - 14500/15360/10128",
                "Rune sword - 12000/12480/8232",
                "Rune warhammer - 24500/25920/17088",
                "Green d'hide body - 4500/5220/3444",
                "Rune kiteshield - 32000/33600/22176",
                "Rune full helm - 20500/21120/13932",
                "Rune chainbody - 29500/30720/20268",
                "Rune sq shield - 22500/23040/15192",
                "Adamant platebody - 9500/10080/6648",
                "Rune dagger - 4500/4800/3168",
                "Rune mace - 8000/8448/5568",
                "Rune battleaxe - 24500/25920/17088",
                "Iron platebody - 500/1200/792",
                "Steel platebody - 2000/2400/1584",
                "Mithril platebody - 5000/5200/3432",
                "Black platebody - 3800/4080/2692",
                "Magic longbow - 1200/1536/1014",
                "Yew longbow - 600/768/507",
                "Maple longbow - 400/576/379",
                "Black d'hide body - 6500/7380/4869",
                "Adamant 2h sword - 3600/3840/2534",
                "Mithril platelegs - 1300/1560/1029"
        };

        commonItemsList = new JList<>(commonItems);
        commonItemsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        commonItemsList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    addCommonItem();
                }
            }
        });

        JScrollPane commonScrollPane = new JScrollPane(commonItemsList);
        leftPanel.add(commonScrollPane, BorderLayout.CENTER);

        JButton addCommonButton = new JButton("Add Selected Item");
        addCommonButton.addActionListener(e -> addCommonItem());
        leftPanel.add(addCommonButton, BorderLayout.SOUTH);

        // Right panel - Manual entry and list
        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
        rightPanel.add(createAlchTypePanel(), BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.add(createItemInputPanel(), BorderLayout.NORTH);
        centerPanel.add(createItemListPanel(), BorderLayout.CENTER);
        rightPanel.add(centerPanel, BorderLayout.CENTER);

        // Split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        splitPane.setDividerLocation(300);
        panel.add(splitPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createSettingsTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));

        JPanel topPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        topPanel.add(createSmartMousePanel());
        topPanel.add(createMouseControlPanel());

        panel.add(topPanel, BorderLayout.NORTH);

        return panel;
    }

    private JPanel createProfilesTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(createProfilePanel(), BorderLayout.NORTH);
        return panel;
    }

    private JPanel createAlchTypePanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Alchemy Type",
                TitledBorder.LEFT, TitledBorder.TOP));

        JLabel label = new JLabel("Spell:");
        alchTypeCombo = new JComboBox<>(AlchType.values());
        alchTypeCombo.setSelectedItem(config.alchType);
        alchTypeCombo.addActionListener(e -> {
            config.alchType = (AlchType) alchTypeCombo.getSelectedItem();
        });

        panel.add(label);
        panel.add(alchTypeCombo);

        return panel;
    }

    private JPanel createItemInputPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Add Custom Item",
                TitledBorder.LEFT, TitledBorder.TOP));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Item Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Item Name:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        itemNameField = new JTextField(20);
        panel.add(itemNameField, gbc);

        // Buy Price
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        panel.add(new JLabel("Buy Price:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        buyPriceField = new JTextField(20);
        panel.add(buyPriceField, gbc);

        // High Alch Value
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        panel.add(new JLabel("High Alch Value:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        highAlchValueField = new JTextField(20);
        panel.add(highAlchValueField, gbc);

        // Low Alch Value
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        panel.add(new JLabel("Low Alch Value:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        lowAlchValueField = new JTextField(20);
        panel.add(lowAlchValueField, gbc);

        // Add Button
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JButton addButton = new JButton("Add Item to List");
        addButton.addActionListener(e -> addItemToList());
        panel.add(addButton, gbc);

        return panel;
    }

    private JPanel createItemListPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Your Alch Items List",
                TitledBorder.LEFT, TitledBorder.TOP));

        // Create table
        String[] columnNames = {"Item Name", "Buy Price", "High Alch", "Low Alch"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        itemTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(itemTable);

        // Load existing items
        refreshItemTable();

        // Remove button
        JButton removeButton = new JButton("Remove Selected Item");
        removeButton.addActionListener(e -> removeSelectedItem());

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(removeButton, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createSmartMousePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "SmartMouse Settings",
                TitledBorder.LEFT, TitledBorder.TOP));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Enable SmartMouse checkbox
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        useSmartMouseCheckbox = new JCheckBox("Enable SmartMouse Movement", config.useSmartMouse);
        useSmartMouseCheckbox.addActionListener(e -> {
            config.useSmartMouse = useSmartMouseCheckbox.isSelected();
            mouseDataPathField.setEnabled(config.useSmartMouse);
            browseMouseDataButton.setEnabled(config.useSmartMouse);
        });
        panel.add(useSmartMouseCheckbox, gbc);

        // Mouse data path
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Mouse Data Path:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        mouseDataPathField = new JTextField(config.mouseDataPath, 30);
        mouseDataPathField.setEnabled(config.useSmartMouse);
        panel.add(mouseDataPathField, gbc);

        gbc.gridx = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        browseMouseDataButton = new JButton("Browse");
        browseMouseDataButton.setEnabled(config.useSmartMouse);
        browseMouseDataButton.addActionListener(e -> browseMouseDataPath());
        panel.add(browseMouseDataButton, gbc);

        return panel;
    }

    private JPanel createMouseControlPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Mouse Anti-Ban Controls",
                TitledBorder.LEFT, TitledBorder.TOP));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Randomize mouse speed
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        randomizeMouseSpeedCheckbox = new JCheckBox("Randomize Mouse Speed", config.randomizeMouseSpeed);
        randomizeMouseSpeedCheckbox.addActionListener(e -> {
            config.randomizeMouseSpeed = randomizeMouseSpeedCheckbox.isSelected();
            mouseSpeedMinSpinner.setEnabled(config.randomizeMouseSpeed);
            mouseSpeedMaxSpinner.setEnabled(config.randomizeMouseSpeed);
        });
        panel.add(randomizeMouseSpeedCheckbox, gbc);

        // Mouse speed min
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Speed Min:"), gbc);

        gbc.gridx = 1;
        mouseSpeedMinSpinner = new JSpinner(new SpinnerNumberModel(config.mouseSpeedMin, 50, 150, 5));
        mouseSpeedMinSpinner.setEnabled(config.randomizeMouseSpeed);
        panel.add(mouseSpeedMinSpinner, gbc);

        // Mouse speed max
        gbc.gridx = 2;
        panel.add(new JLabel("Speed Max:"), gbc);

        gbc.gridx = 3;
        mouseSpeedMaxSpinner = new JSpinner(new SpinnerNumberModel(config.mouseSpeedMax, 50, 200, 5));
        mouseSpeedMaxSpinner.setEnabled(config.randomizeMouseSpeed);
        panel.add(mouseSpeedMaxSpinner, gbc);

        // Enable mouse wander
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        enableMouseWanderCheckbox = new JCheckBox("Enable Random Mouse Wander", config.enableMouseWander);
        enableMouseWanderCheckbox.addActionListener(e -> {
            config.enableMouseWander = enableMouseWanderCheckbox.isSelected();
            mouseWanderFrequencySpinner.setEnabled(config.enableMouseWander);
        });
        panel.add(enableMouseWanderCheckbox, gbc);

        // Wander frequency
        gbc.gridx = 2;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Wander Every:"), gbc);

        gbc.gridx = 3;
        mouseWanderFrequencySpinner = new JSpinner(new SpinnerNumberModel(config.mouseWanderFrequency, 5, 50, 5));
        mouseWanderFrequencySpinner.setEnabled(config.enableMouseWander);
        JPanel wanderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        wanderPanel.add(mouseWanderFrequencySpinner);
        wanderPanel.add(new JLabel("actions"));
        panel.add(wanderPanel, gbc);

        return panel;
    }

    private JPanel createProfilePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Profile Management",
                TitledBorder.LEFT, TitledBorder.TOP));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Profile Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Profile Name:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        profileNameField = new JTextField(15);
        panel.add(profileNameField, gbc);

        gbc.gridx = 2;
        gbc.weightx = 0;
        JButton saveButton = new JButton("Save Profile");
        saveButton.addActionListener(e -> saveProfile());
        panel.add(saveButton, gbc);

        // Load Profile
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Load Profile:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        profileCombo = new JComboBox<>();
        loadAvailableProfiles();
        panel.add(profileCombo, gbc);

        gbc.gridx = 2;
        gbc.weightx = 0;
        JButton loadButton = new JButton("Load Profile");
        loadButton.addActionListener(e -> loadProfile());
        panel.add(loadButton, gbc);

        return panel;
    }

    private JPanel createWorldHopperTab() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Enable World Hopping
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JCheckBox hopCheckBox = new JCheckBox("Enable Random F2P World Hopping");
        hopCheckBox.setSelected(config.enableWorldHopping);
        hopCheckBox.addActionListener(e -> config.enableWorldHopping = hopCheckBox.isSelected());
        panel.add(hopCheckBox, gbc);

        // Min hop time
        gbc.gridy++;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Min hop time (minutes):"), gbc);

        gbc.gridx = 1;
        JSpinner minHopSpinner = new JSpinner(new SpinnerNumberModel(config.worldHopMinMinutes, 1, 120, 1));
        minHopSpinner.addChangeListener(e -> config.worldHopMinMinutes = (int)minHopSpinner.getValue());
        panel.add(minHopSpinner, gbc);

        // Max hop time
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Max hop time (minutes):"), gbc);

        gbc.gridx = 1;
        JSpinner maxHopSpinner = new JSpinner(new SpinnerNumberModel(config.worldHopMaxMinutes, 1, 180, 1));
        maxHopSpinner.addChangeListener(e -> config.worldHopMaxMinutes = (int)maxHopSpinner.getValue());
        panel.add(maxHopSpinner, gbc);

        // Info label
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        JLabel infoLabel = new JLabel("<html><i>Script will hop to a random F2P world<br>" +
                "every 10-30 minutes (randomized)</i></html>");
        panel.add(infoLabel, gbc);

        return panel;
    }

    private JPanel createMuleTab() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Enable Mule
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JCheckBox muleCheckBox = new JCheckBox("Enable Mule System");
        muleCheckBox.setSelected(config.muleEnabled);
        muleCheckBox.addActionListener(e -> config.muleEnabled = muleCheckBox.isSelected());
        panel.add(muleCheckBox, gbc);

        // Server Host
        gbc.gridy++;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Mule Server Host:"), gbc);

        gbc.gridx = 1;
        JTextField hostField = new JTextField(config.muleServerHost, 15);
        hostField.addActionListener(e -> config.muleServerHost = hostField.getText());
        panel.add(hostField, gbc);

        // Server Port
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Mule Server Port:"), gbc);

        gbc.gridx = 1;
        JSpinner portSpinner = new JSpinner(new SpinnerNumberModel(config.muleServerPort, 1000, 65535, 1));
        portSpinner.addChangeListener(e -> config.muleServerPort = (int)portSpinner.getValue());
        panel.add(portSpinner, gbc);

        // Auth Token
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Auth Token:"), gbc);

        gbc.gridx = 1;
        JTextField tokenField = new JTextField(config.muleAuthToken, 15);
        tokenField.addActionListener(e -> config.muleAuthToken = tokenField.getText());
        panel.add(tokenField, gbc);

        // Mule after X items
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Mule after items alched:"), gbc);

        gbc.gridx = 1;
        JSpinner muleAfterSpinner = new JSpinner(new SpinnerNumberModel(config.muleAfterItems, 10, 10000, 50));
        muleAfterSpinner.addChangeListener(e -> config.muleAfterItems = (int)muleAfterSpinner.getValue());
        panel.add(muleAfterSpinner, gbc);

        // Withdraw GP
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Withdraw GP (0 for none):"), gbc);

        gbc.gridx = 1;
        JSpinner withdrawGPSpinner = new JSpinner(new SpinnerNumberModel(config.muleWithdrawGP, 0, 10000000, 10000));
        withdrawGPSpinner.addChangeListener(e -> config.muleWithdrawGP = (int)withdrawGPSpinner.getValue());
        panel.add(withdrawGPSpinner, gbc);

        // Auto walk to mule
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        JCheckBox autoWalkCheckBox = new JCheckBox("Auto walk to mule location");
        autoWalkCheckBox.setSelected(config.muleAutoWalk);
        autoWalkCheckBox.addActionListener(e -> config.muleAutoWalk = autoWalkCheckBox.isSelected());
        panel.add(autoWalkCheckBox, gbc);

        // Info
        gbc.gridy++;
        JLabel infoLabel = new JLabel("<html><i>Requires mule server running<br>" +
                "Script will deposit items/coins to mule<br>" +
                "after alching specified amount</i></html>");
        panel.add(infoLabel, gbc);

        return panel;
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));

        JButton startButton = new JButton("Start Script");
        startButton.setPreferredSize(new Dimension(120, 35));
        startButton.addActionListener(e -> {
            if (config.alchItems.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please add at least one item to the list before starting!",
                        "No Items", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Save GUI settings to config
            saveGUISettings();

            started = true;
            dispose();
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setPreferredSize(new Dimension(120, 35));
        cancelButton.addActionListener(e -> {
            started = false;
            dispose();
        });

        panel.add(cancelButton);
        panel.add(startButton);

        return panel;
    }

    private void addCommonItem() {
        String selected = commonItemsList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this,
                    "Please select an item from the list!",
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Parse the common item format: "Item name - buyPrice/highAlch/lowAlch"
            String[] parts = selected.split(" - ");
            String itemName = parts[0].trim();
            String[] prices = parts[1].split("/");

            int buyPrice = Integer.parseInt(prices[0].trim());
            int highAlch = Integer.parseInt(prices[1].trim());
            int lowAlch = Integer.parseInt(prices[2].trim());

            config.addAlchItem(itemName, buyPrice, highAlch, lowAlch);
            refreshItemTable();

            JOptionPane.showMessageDialog(this,
                    itemName + " added successfully!",
                    "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error parsing item: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addItemToList() {
        try {
            String name = itemNameField.getText().trim();
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please enter an item name!",
                        "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int buyPrice = Integer.parseInt(buyPriceField.getText().trim());
            int highAlch = Integer.parseInt(highAlchValueField.getText().trim());
            int lowAlch = Integer.parseInt(lowAlchValueField.getText().trim());

            // Validate values
            if (buyPrice <= 0 || highAlch <= 0 || lowAlch <= 0) {
                JOptionPane.showMessageDialog(this,
                        "All prices must be greater than 0!",
                        "Invalid Values", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Add to config
            config.addAlchItem(name, buyPrice, highAlch, lowAlch);

            // Refresh table
            refreshItemTable();

            // Clear fields
            itemNameField.setText("");
            buyPriceField.setText("");
            highAlchValueField.setText("");
            lowAlchValueField.setText("");

            JOptionPane.showMessageDialog(this,
                    "Item added successfully!",
                    "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                    "Please enter valid numbers for all price fields!",
                    "Invalid Input", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removeSelectedItem() {
        int selectedRow = itemTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select an item to remove!",
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to remove this item?",
                "Confirm Removal", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            config.removeAlchItem(selectedRow);
            refreshItemTable();
        }
    }

    private void refreshItemTable() {
        tableModel.setRowCount(0);
        for (AlchItem item : config.alchItems) {
            tableModel.addRow(new Object[]{
                    item.name,
                    item.buyPrice + " gp",
                    item.highAlchValue + " gp",
                    item.lowAlchValue + " gp"
            });
        }
    }

    private void browseMouseDataPath() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home") +
                File.separator + "AppData" + File.separator + "Roaming" +
                File.separator + "DreamBot" + File.separator + "Scripts"));

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            mouseDataPathField.setText(selectedFile.getAbsolutePath());
            config.mouseDataPath = selectedFile.getAbsolutePath();
        }
    }

    private void saveGUISettings() {
        // Save mouse settings
        config.useSmartMouse = useSmartMouseCheckbox.isSelected();
        config.mouseDataPath = mouseDataPathField.getText();
        config.randomizeMouseSpeed = randomizeMouseSpeedCheckbox.isSelected();
        config.mouseSpeedMin = (Integer) mouseSpeedMinSpinner.getValue();
        config.mouseSpeedMax = (Integer) mouseSpeedMaxSpinner.getValue();
        config.enableMouseWander = enableMouseWanderCheckbox.isSelected();
        config.mouseWanderFrequency = (Integer) mouseWanderFrequencySpinner.getValue();
    }

    private void saveProfile() {
        String profileName = profileNameField.getText().trim();
        if (profileName.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a profile name!",
                    "Missing Name", JOptionPane.WARNING_MESSAGE);
            return;
        }

        saveGUISettings();
        config.save(profileName);
        loadAvailableProfiles();
        JOptionPane.showMessageDialog(this,
                "Profile saved successfully!",
                "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void loadProfile() {
        String selectedProfile = (String) profileCombo.getSelectedItem();
        if (selectedProfile == null || selectedProfile.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please select a profile to load!",
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        AlchConfig loadedConfig = AlchConfig.load(selectedProfile);

        // Copy loaded config to current config
        config.alchItems.clear();
        config.alchItems.addAll(loadedConfig.alchItems);
        config.alchType = loadedConfig.alchType;
        config.minAlchItems = loadedConfig.minAlchItems;
        config.maxAlchItems = loadedConfig.maxAlchItems;
        config.minNatureRunes = loadedConfig.minNatureRunes;
        config.maxNatureRunes = loadedConfig.maxNatureRunes;
        config.buyQuantity = loadedConfig.buyQuantity;
        config.natureRuneCost = loadedConfig.natureRuneCost;
        config.useSmartMouse = loadedConfig.useSmartMouse;
        config.mouseDataPath = loadedConfig.mouseDataPath;
        config.randomizeMouseSpeed = loadedConfig.randomizeMouseSpeed;
        config.mouseSpeedMin = loadedConfig.mouseSpeedMin;
        config.mouseSpeedMax = loadedConfig.mouseSpeedMax;
        config.enableMouseWander = loadedConfig.enableMouseWander;
        config.mouseWanderFrequency = loadedConfig.mouseWanderFrequency;

        // Update GUI
        alchTypeCombo.setSelectedItem(config.alchType);
        useSmartMouseCheckbox.setSelected(config.useSmartMouse);
        mouseDataPathField.setText(config.mouseDataPath);
        randomizeMouseSpeedCheckbox.setSelected(config.randomizeMouseSpeed);
        mouseSpeedMinSpinner.setValue(config.mouseSpeedMin);
        mouseSpeedMaxSpinner.setValue(config.mouseSpeedMax);
        enableMouseWanderCheckbox.setSelected(config.enableMouseWander);
        mouseWanderFrequencySpinner.setValue(config.mouseWanderFrequency);
        refreshItemTable();

        JOptionPane.showMessageDialog(this,
                "Profile loaded successfully!",
                "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void loadAvailableProfiles() {
        profileCombo.removeAllItems();

        String userHome = System.getProperty("user.home");
        String dreambotDir = userHome + File.separator + "AppData" + File.separator + "Roaming" +
                File.separator + "DreamBot" + File.separator + "Profiles";

        File dir = new File(dreambotDir);
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles((d, name) -> name.endsWith(".json"));
            if (files != null) {
                for (File file : files) {
                    profileCombo.addItem(file.getName());
                }
            }
        }
    }

    public boolean isStarted() {
        return started;
    }
}
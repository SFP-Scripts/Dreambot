package core;

import org.dreambot.api.utilities.Logger;

/**
 * Logger utility for High Alcher
 */
public class AlchLogger {

    private final String prefix;

    public AlchLogger(String prefix) {
        this.prefix = "[" + prefix + "] ";
    }

    public void log(String message) {
        Logger.log(prefix + message);
    }

    public void error(String message) {
        Logger.error(prefix + message);
    }

    public void logHeader(String message) {
        Logger.log("===========================================");
        Logger.log(prefix + message);
        Logger.log("===========================================");
    }

    public void logSection(String message) {
        Logger.log("-------------------------------------------");
        Logger.log(prefix + message);
        Logger.log("-------------------------------------------");
    }
}
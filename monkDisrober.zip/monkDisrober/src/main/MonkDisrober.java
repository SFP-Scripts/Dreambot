package main;

import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.skills.Skill;
import utilities.*;

import java.awt.*;

@ScriptManifest(
        author = "timandmonica",
        name = "MonkDisrober",
        version = 1.0,
        description = "Disrobes monks for decent gp per hour",
        category = Category.MONEYMAKING
)
public class MonkDisrober extends AbstractScript {

    private GuiHandler guiHandler;
    private StateHandler stateHandler;
    private WorldHopperHandler worldHopperHandler;
    private InventoryHandler inventoryHandler;
    private MovementHandler movementHandler;
    private PaintHandler paintHandler;
    private LoginHandler loginHandler;
    private AntiBanHandler antiBanHandler;
    private PrayerTrainingHandler prayerTrainingHandler;
    private MuleHandler muleHandler;

    private long startTime;
    private boolean shouldEndScript = false;

    @Override
    public void onStart() {
        Logger.log("MonkDisrober starting...");

        // Check for profile argument (e.g., "1" to load profile 1)
        // In DreamBot, script arguments are passed via the manifest or client
        // For now, we'll check if there's a system property set
        String profileArg = System.getProperty("monkdisrober.profile");

        // Alternative: Check for file-based argument
        if (profileArg == null) {
            try {
                java.io.File argFile = new java.io.File(System.getProperty("user.home"), ".monkdisrober_profile_arg.txt");
                if (argFile.exists()) {
                    java.util.Scanner scanner = new java.util.Scanner(argFile);
                    if (scanner.hasNextLine()) {
                        profileArg = scanner.nextLine().trim();
                    }
                    scanner.close();
                }
            } catch (Exception e) {
                // Ignore
            }
        }

        guiHandler = new GuiHandler(this);

        // If profile argument provided, try to auto-load it
        if (profileArg != null && !profileArg.trim().isEmpty()) {
            Logger.log("Profile argument detected: " + profileArg);
            guiHandler.loadProfileByArgument(profileArg.trim());
        } else {
            Logger.log("No profile argument - showing GUI");
        }

        guiHandler.showStartupGui();
        guiHandler.waitForGuiCompletion();

        stateHandler = new StateHandler();
        worldHopperHandler = new WorldHopperHandler(this);
        inventoryHandler = new InventoryHandler(this);
        movementHandler = new MovementHandler(this);
        paintHandler = new PaintHandler(this);
        loginHandler = new LoginHandler(this);
        antiBanHandler = new AntiBanHandler(this);
        prayerTrainingHandler = new PrayerTrainingHandler(this);
        muleHandler = new MuleHandler(this);

        worldHopperHandler.initializeWorldIndex();
        startTime = System.currentTimeMillis();

        // Initialize mule if enabled
        if (guiHandler.isMuleEnabled()) {
            Logger.log("Initializing mule client...");
            muleHandler.initializeMule(
                    guiHandler.getMuleServerHost(),
                    guiHandler.getMuleServerPort(),
                    guiHandler.getMuleAuthToken()
            );
            muleHandler.setMuleAfterItems(guiHandler.getMuleAfterItems());
        }

        // Check prayer level and set initial state
        int prayerLevel = Skills.getRealLevel(Skill.PRAYER);
        if (prayerLevel < 31) {
            Logger.log("Prayer level is " + prayerLevel + " (below 31)");
            Logger.log("Starting vile ashes training to reach level 31...");
            stateHandler.setCurrentState(StateHandler.State.CHECK_BANK_FOR_ASHES);
        } else {
            Logger.log("Prayer level is " + prayerLevel + " - ready to disrobe monks!");
            stateHandler.setCurrentState(StateHandler.State.GO_TO_MONASTERY);
        }

        Logger.log("MonkDisrober started successfully!");
    }

    @Override
    public int onLoop() {
        try {
            // CRITICAL: Check login handler FIRST before anything else
            int loginHandlerDelay = loginHandler.handleLogin();
            if (loginHandlerDelay > 0) {
                return loginHandlerDelay;
            }

            // Check if it's time to mule
            if (muleHandler.isMuleEnabled() && muleHandler.shouldMule()) {
                Logger.log("Time to mule items!");
                if (muleHandler.muleItems()) {
                    Logger.log("Mule completed, resuming script");
                } else {
                    Logger.log("Mule failed, will retry later");
                }
            }

            if (!guiHandler.isGuiCompleted()) {
                return 100;
            }

            if (guiHandler.useAutoEnd() &&
                    inventoryHandler.getTotalItemsPickedUp() >= guiHandler.getItemsBeforeEnd() &&
                    !shouldEndScript) {
                shouldEndScript = true;
                stateHandler.setCurrentState(StateHandler.State.GO_TO_BANK);
            }

            switch (stateHandler.getCurrentState()) {
                case CHECK_BANK_FOR_ASHES:
                    return movementHandler.checkBankForAshes();
                case WITHDRAW_ASHES:
                    return movementHandler.withdrawVileAshes();
                case GO_TO_GE:
                    return movementHandler.goToGrandExchange();
                case BUY_VILE_ASHES:
                    return movementHandler.buyVileAshes();
                case GO_TO_BURYING_LOCATION:
                    return movementHandler.goToBuryingLocation();
                case BURY_ASHES:
                    return movementHandler.buryVileAshes();
                case GO_TO_GE_BANK:
                    return movementHandler.goToGEBank();
                case GO_TO_BANK:
                    return movementHandler.goToBank();
                case BANK_ITEMS:
                    int result = inventoryHandler.bankItems();
                    if (shouldEndScript) {
                        stop();
                        return 0;
                    }
                    return result;
                case GO_TO_MONASTERY:
                    return movementHandler.goToMonastery();
                case TALK_TO_ABBOT:
                    return movementHandler.talkToAbbot();
                case CLIMB_LADDER:
                    return movementHandler.climbLadder();
                case OPEN_DOOR:
                    return movementHandler.openDoor();
                case LOOT_ROBES:
                    return inventoryHandler.lootRobes();
                case WAIT_IN_ROOM:
                    return inventoryHandler.waitInRoom();
                case HOP_WORLDS:
                    return worldHopperHandler.hopWorlds();
                default:
                    return getRandomSleep(200, 300);
            }
        } catch (Exception e) {
            Logger.error("Error in onLoop: " + e.getMessage());
            e.printStackTrace();
            return 1000;
        }
    }

    @Override
    public void onPaint(Graphics2D g) {
        paintHandler.drawOverlay(g);
    }

    // Getters
    public GuiHandler getGuiHandler() {
        return guiHandler;
    }

    public StateHandler getStateHandler() {
        return stateHandler;
    }

    public WorldHopperHandler getWorldHopperHandler() {
        return worldHopperHandler;
    }

    public InventoryHandler getInventoryHandler() {
        return inventoryHandler;
    }

    public MovementHandler getMovementHandler() {
        return movementHandler;
    }

    public PaintHandler getPaintHandler() {
        return paintHandler;
    }

    public LoginHandler getLoginHandler() {
        return loginHandler;
    }

    public AntiBanHandler getAntiBanHandler() {
        return antiBanHandler;
    }

    public PrayerTrainingHandler getPrayerTrainingHandler() {
        return prayerTrainingHandler;
    }

    public MuleHandler getMuleHandler() {
        return muleHandler;
    }

    public long getStartTime() {
        return startTime;
    }

    public int getRandomSleep(int min, int max) {
        if (max <= min) return min;
        return min + (int) (Math.random() * ((max - min) + 1));
    }

    public void log(String message) {
        Logger.log(message);
    }

    @Override
    public void onExit() {
        // Cleanup mule connection
        if (muleHandler != null) {
            muleHandler.cleanup();
        }
        Logger.log("MonkDisrober stopped");
    }
}
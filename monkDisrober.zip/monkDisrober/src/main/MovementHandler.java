package utilities;

import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import utilities.AntiBanHandler;
import main.MonkDisrober;
import utilities.StateHandler;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;

public class MovementHandler {

    private MonkDisrober script;
    private AntiBanHandler antiBan;

    private static final Area MONASTERY_EXTERIOR = new Area(3044, 3481, 3061, 3500, 0);
    private static final Area MONASTERY_ENTRANCE = new Area(3053, 3485, 3058, 3492, 0);
    private static final Area MONASTERY_FIRST_FLOOR = new Area(3044, 3481, 3061, 3500, 1);
    private static final Area LADDER_AREA = new Area(3057, 3482, 3059, 3484, 0);
    private static final Area DOOR_OUTSIDE = new Area(3056, 3487, 3057, 3489, 1);
    private static final Area DOOR_INSIDE = new Area(3057, 3487, 3059, 3489, 1);
    private static final Area LOOT_ROOM = new Area(3057, 3487, 3059, 3489, 1);

    private static final Area EDGEVILLE_BANK = new Area(3091, 3488, 3098, 3499, 0);
    private static final Area FALADOR_EAST_BANK = new Area(3009, 3353, 3018, 3358, 0);
    private static final Area VARROCK_WEST_BANK = new Area(3180, 3433, 3191, 3446, 0);

    private static final List<Tile> PATH_OPTION_1 = Arrays.asList(
            new Tile(3054, 3490, 0),
            new Tile(3052, 3494, 0),
            new Tile(3050, 3488, 0),
            new Tile(3055, 3486, 0)
    );

    private static final List<Tile> PATH_OPTION_2 = Arrays.asList(
            new Tile(3058, 3492, 0),
            new Tile(3056, 3489, 0),
            new Tile(3053, 3486, 0),
            new Tile(3055, 3483, 0)
    );

    private static final List<Tile> PATH_OPTION_3 = Arrays.asList(
            new Tile(3051, 3495, 0),
            new Tile(3048, 3491, 0),
            new Tile(3051, 3487, 0),
            new Tile(3055, 3485, 0)
    );

    private static final List<Tile> PATH_OPTION_4 = Arrays.asList(
            new Tile(3060, 3490, 0),
            new Tile(3058, 3487, 0),
            new Tile(3055, 3484, 0),
            new Tile(3053, 3486, 0)
    );

    private static final List<List<Tile>> MONASTERY_PATHS = Arrays.asList(
            PATH_OPTION_1,
            PATH_OPTION_2,
            PATH_OPTION_3,
            PATH_OPTION_4
    );

    private int currentPathIndex = -1;

    public MovementHandler(MonkDisrober script) {
        this.script = script;
        this.antiBan = new AntiBanHandler(script);
    }

    public int goToMonastery() {
        script.log("Navigating to Monastery...");

        if (MONASTERY_EXTERIOR.contains(Players.getLocal())) {
            script.log("Already at monastery exterior.");

            if (Skills.getRealLevel(Skill.PRAYER) >= 31 && !script.getInventoryHandler().hasLadderAccess()) {
                script.getStateHandler().setCurrentState(StateHandler.State.TALK_TO_ABBOT);
            } else {
                script.getStateHandler().setCurrentState(StateHandler.State.CLIMB_LADDER);
            }
            return 0;
        }

        antiBan.performRandomAction();

        if (currentPathIndex == -1 || shouldChangePath()) {
            currentPathIndex = getRandomInt(0, MONASTERY_PATHS.size() - 1);
            script.log("Selected monastery path option " + (currentPathIndex + 1));
        }

        List<Tile> currentPath = MONASTERY_PATHS.get(currentPathIndex);
        Tile closestTile = getClosestTile(currentPath);

        if (closestTile == null) {
            script.log("Using web walker to monastery entrance...");
            Walking.walk(MONASTERY_ENTRANCE.getRandomTile());
        } else {
            Tile targetTile = closestTile.getArea(1).getRandomTile();
            script.log("Walking to path tile: " + targetTile);
            Walking.walk(targetTile);
        }

        Sleep.sleepUntil(() -> MONASTERY_EXTERIOR.contains(Players.getLocal()),
                getRandomInt(8000, 12000));

        sleep(getRandomInt(400, 900));

        return getRandomInt(600, 1000);
    }

    public int talkToAbbot() {
        script.log("Talking to Abbot Langley...");

        // Check current prayer level
        int currentPrayer = Skills.getRealLevel(Skill.PRAYER);

        if (currentPrayer < 31) {
            script.log("Prayer level " + currentPrayer + " is too low (need 31). Going to train prayer.");
            script.getStateHandler().setCurrentState(StateHandler.State.CHECK_BANK_FOR_ASHES);
            return 1000;
        }

        if (script.getInventoryHandler().hasLadderAccess()) {
            script.log("Already have ladder access, skipping Abbot dialogue.");
            script.getStateHandler().setCurrentState(StateHandler.State.CLIMB_LADDER);
            return 0;
        }

        NPC abbot = NPCs.closest("Abbot Langley");
        if (abbot == null || !abbot.exists()) {
            script.log("Abbot not found, searching...");

            if (!MONASTERY_ENTRANCE.contains(Players.getLocal())) {
                Walking.walk(MONASTERY_ENTRANCE.getRandomTile());
                Sleep.sleepUntil(() -> MONASTERY_ENTRANCE.contains(Players.getLocal()), 5000);
            }

            return getRandomInt(800, 1200);
        }

        if (getRandomInt(1, 100) <= 30) {
            antiBan.adjustCamera();
            sleep(getRandomInt(200, 500));
        }

        if (!Dialogues.inDialogue()) {
            if (abbot.interact("Talk-to")) {
                Sleep.sleepUntil(() -> Dialogues.inDialogue(), 5000);
                sleep(getRandomInt(800, 1400));
            }
            return getRandomInt(800, 1200);
        }

        if (Dialogues.inDialogue()) {
            String[] options = Dialogues.getOptions();

            // Log all available options for debugging
            if (options != null && options.length > 0) {
                script.log("Dialogue options found: " + String.join(", ", options));

                for (String option : options) {
                    if (option == null) continue;

                    String lowerOption = option.toLowerCase();

                    // Check for "heal" - already joined order
                    if (lowerOption.contains("heal")) {
                        script.log("Healing option detected - already joined order.");
                        markCharacterHealed();
                        script.getStateHandler().setCurrentState(StateHandler.State.CLIMB_LADDER);
                        return getRandomInt(600, 1000);
                    }
                }
            }

            if (Dialogues.canContinue()) {
                sleep(getRandomInt(600, 1200));
                Dialogues.continueDialogue();
                return getRandomInt(600, 1000);
            }

            if (Dialogues.areOptionsAvailable()) {
                sleep(getRandomInt(500, 1000));

                // Try multiple variations of the join option
                boolean joined = false;

                // Try exact phrases first
                if (Dialogues.chooseOption("I'd like to join your order")) {
                    script.log("Selected 'I'd like to join your order' option");
                    joined = true;
                } else if (Dialogues.chooseOption("join")) {
                    script.log("Selected 'join' option");
                    joined = true;
                } else if (Dialogues.chooseOption("Yes")) {
                    script.log("Selected 'Yes' option");
                    joined = true;
                } else if (Dialogues.chooseOption(1)) {
                    // Try selecting first option (index 1)
                    script.log("Selected option 1 (first option)");
                    joined = true;
                }

                if (joined) {
                    sleep(getRandomInt(800, 1400));
                    return getRandomInt(600, 1000);
                } else {
                    // Log options for debugging
                    String[] debugOptions = Dialogues.getOptions();
                    if (debugOptions != null && debugOptions.length > 0) {
                        script.log("Could not find join option. Available: " + String.join(", ", debugOptions));
                    } else {
                        script.log("No dialogue options available to select.");
                    }
                }
            }

            if (!Dialogues.inDialogue()) {
                script.log("Dialogue closed.");

                // Double-check prayer level after dialogue
                int finalPrayer = Skills.getRealLevel(Skill.PRAYER);
                if (finalPrayer < 31) {
                    script.log("Prayer still below 31 after dialogue - going to train prayer.");
                    script.getStateHandler().setCurrentState(StateHandler.State.CHECK_BANK_FOR_ASHES);
                } else {
                    script.log("Prayer 31+ confirmed - marking as healed and proceeding to ladder.");
                    markCharacterHealed();
                    script.getStateHandler().setCurrentState(StateHandler.State.CLIMB_LADDER);
                }
            }
        }

        return getRandomInt(400, 800);
    }

    public int climbLadder() {
        script.log("Climbing ladder...");

        if (MONASTERY_FIRST_FLOOR.contains(Players.getLocal())) {
            script.log("Already on first floor.");
            script.getStateHandler().setCurrentState(StateHandler.State.OPEN_DOOR);
            return 0;
        }

        if (!LADDER_AREA.contains(Players.getLocal())) {
            script.log("Moving to ladder area...");
            Walking.walk(LADDER_AREA.getRandomTile());
            Sleep.sleepUntil(() -> LADDER_AREA.contains(Players.getLocal()), 8000);
            return getRandomInt(600, 1000);
        }

        if (getRandomInt(1, 100) <= 25) {
            antiBan.performRandomAction();
        }

        GameObject ladder = GameObjects.closest(obj ->
                obj != null &&
                        obj.getName().equals("Ladder") &&
                        obj.hasAction("Climb-up")
        );

        if (ladder == null) {
            script.log("Ladder not found!");
            return getRandomInt(800, 1200);
        }

        if (ladder.interact("Climb-up")) {
            Sleep.sleepUntil(() -> MONASTERY_FIRST_FLOOR.contains(Players.getLocal()),
                    getRandomInt(4000, 6000));

            sleep(getRandomInt(600, 1200));

            if (MONASTERY_FIRST_FLOOR.contains(Players.getLocal())) {
                script.log("Successfully climbed to first floor.");
                script.getStateHandler().setCurrentState(StateHandler.State.OPEN_DOOR);
            }
        }

        return getRandomInt(600, 1000);
    }

    public int openDoor() {
        script.log("Opening door to loot room...");

        if (LOOT_ROOM.contains(Players.getLocal())) {
            script.log("Already in loot room.");
            script.getStateHandler().setCurrentState(StateHandler.State.LOOT_ROBES);
            return 0;
        }

        if (!DOOR_OUTSIDE.contains(Players.getLocal())) {
            script.log("Moving to door...");
            Walking.walk(DOOR_OUTSIDE.getRandomTile());
            Sleep.sleepUntil(() -> DOOR_OUTSIDE.contains(Players.getLocal()), 5000);
            return getRandomInt(600, 1000);
        }

        if (getRandomInt(1, 100) <= 20) {
            antiBan.hoverRandomObject();
            sleep(getRandomInt(200, 600));
        }

        GameObject door = GameObjects.closest(obj ->
                obj != null &&
                        obj.getName().equals("Door") &&
                        obj.hasAction("Open")
        );

        if (door == null) {
            script.log("Door not found, may already be open. Walking through...");
            Walking.walk(LOOT_ROOM.getRandomTile());
            Sleep.sleepUntil(() -> LOOT_ROOM.contains(Players.getLocal()), 4000);

            if (LOOT_ROOM.contains(Players.getLocal())) {
                script.getStateHandler().setCurrentState(StateHandler.State.LOOT_ROBES);
            }
            return getRandomInt(600, 1000);
        }

        if (door.interact("Open")) {
            Sleep.sleepUntil(() -> LOOT_ROOM.contains(Players.getLocal()),
                    getRandomInt(3000, 5000));

            sleep(getRandomInt(400, 800));

            if (LOOT_ROOM.contains(Players.getLocal())) {
                script.log("Door opened, entering loot room.");
                script.getStateHandler().setCurrentState(StateHandler.State.LOOT_ROBES);
            }
        }

        return getRandomInt(500, 900);
    }

    public int goToBank() {
        script.log("Going to bank...");

        Area targetBank = selectBestBank();

        if (targetBank.contains(Players.getLocal())) {
            script.log("Already at bank.");
            script.getStateHandler().setCurrentState(StateHandler.State.BANK_ITEMS);
            return 0;
        }

        antiBan.performRandomAction();

        Tile bankTile = targetBank.getRandomTile();
        script.log("Walking to bank");

        Walking.walk(bankTile);
        Sleep.sleepUntil(() -> targetBank.contains(Players.getLocal()),
                getRandomInt(15000, 20000));

        sleep(getRandomInt(600, 1200));

        return getRandomInt(800, 1400);
    }

    public int goToGEBank() {
        return script.getPrayerTrainingHandler().goToGEBank();
    }

    public int checkBankForAshes() {
        return script.getPrayerTrainingHandler().checkBankForAshes();
    }

    public int withdrawVileAshes() {
        return script.getPrayerTrainingHandler().withdrawVileAshes();
    }

    public int goToGrandExchange() {
        return script.getPrayerTrainingHandler().goToGrandExchange();
    }

    public int buyVileAshes() {
        return script.getPrayerTrainingHandler().buyVileAshes();
    }

    public int goToBuryingLocation() {
        return script.getPrayerTrainingHandler().goToBuryingLocation();
    }

    public int buryVileAshes() {
        return script.getPrayerTrainingHandler().buryVileAshes();
    }

    private Area selectBestBank() {
        Tile playerPos = Players.getLocal().getTile();

        double distEdge = playerPos.distance(EDGEVILLE_BANK.getCenter());
        double distFal = playerPos.distance(FALADOR_EAST_BANK.getCenter());
        double distVarr = playerPos.distance(VARROCK_WEST_BANK.getCenter());

        if (getRandomInt(1, 100) <= 5) {
            List<Area> banks = Arrays.asList(EDGEVILLE_BANK, FALADOR_EAST_BANK, VARROCK_WEST_BANK);
            return banks.get(getRandomInt(0, banks.size() - 1));
        }

        if (distEdge <= distFal && distEdge <= distVarr) {
            return EDGEVILLE_BANK;
        } else if (distFal <= distVarr) {
            return FALADOR_EAST_BANK;
        } else {
            return VARROCK_WEST_BANK;
        }
    }

    private Tile getClosestTile(List<Tile> path) {
        if (path == null || path.isEmpty()) return null;

        Tile playerPos = Players.getLocal().getTile();
        Tile closest = null;
        double minDist = Double.MAX_VALUE;

        for (Tile tile : path) {
            double dist = playerPos.distance(tile);
            if (dist < minDist) {
                minDist = dist;
                closest = tile;
            }
        }

        return closest;
    }

    private boolean shouldChangePath() {
        return getRandomInt(1, 100) <= 15;
    }

    private void markCharacterHealed() {
        String username = Players.getLocal().getName();
        try {
            Files.write(
                    Paths.get("healed_characters.txt"),
                    (username + "\n").getBytes(),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND
            );
            script.log("Marked " + username + " as healed.");
        } catch (IOException e) {
            script.log("Failed to write to healed_characters.txt");
        }
    }

    private int getRandomInt(int min, int max) {
        if (max <= min) return min;
        return min + (int) (Math.random() * ((max - min) + 1));
    }

    private void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
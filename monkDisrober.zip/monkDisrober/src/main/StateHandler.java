package utilities;

public class StateHandler {
    public enum State {
        GO_TO_GE_BANK,
        CHECK_BANK_FOR_ASHES,
        WITHDRAW_ASHES,
        GO_TO_GE,
        BUY_VILE_ASHES,
        GO_TO_BURYING_LOCATION,
        BURY_ASHES,
        GO_TO_BANK,
        BANK_ITEMS,
        GO_TO_MONASTERY,
        TALK_TO_ABBOT,
        CLIMB_LADDER,
        OPEN_DOOR,
        LOOT_ROBES,
        WAIT_IN_ROOM,
        HOP_WORLDS,
        END_SCRIPT
    }

    // Initial state will be set by MonkDisrober based on prayer level
    private State currentState = null;

    public State getCurrentState() {
        return currentState;
    }

    public void setCurrentState(State state) {
        this.currentState = state;
    }
}

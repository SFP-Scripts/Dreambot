package utilities;

import main.MonkDisrober;
import org.dreambot.api.utilities.Logger;

/**
 * LoginHandler for DreamBot
 *
 * NOTE: DreamBot doesn't have easy game message access like OSBot.
 * This handler focuses on PREVENTING the login spam issue rather than
 * detecting it after it happens.
 *
 * You can manually trigger cooldown if you see "too many attempts" by calling:
 * script.getLoginHandler().triggerCooldown();
 */
public class LoginHandler {

    private final MonkDisrober script;

    // Cooldown tracking
    private boolean inCooldown = false;
    private long cooldownStartTime = 0;
    private long cooldownDuration = 0;

    // Login attempt tracking
    private boolean loginAttemptMade = false;
    private long lastLoginAttemptTime = 0;
    private static final long LOGIN_ATTEMPT_RESET_TIME = 10000; // 10 seconds

    // Cooldown duration range (3-8 minutes)
    private static final long MIN_COOLDOWN_MS = 3 * 60 * 1000; // 3 minutes
    private static final long MAX_COOLDOWN_MS = 8 * 60 * 1000; // 8 minutes

    public LoginHandler(MonkDisrober script) {
        this.script = script;
    }

    /**
     * Manually trigger cooldown (call this if you see "too many attempts")
     */
    public void triggerCooldown() {
        Logger.log("==============================================");
        Logger.log("Cooldown triggered manually!");
        Logger.log("Entering cooldown period...");
        Logger.log("==============================================");

        startCooldown();
    }

    /**
     * Starts a cooldown period of 3-8 minutes
     */
    private void startCooldown() {
        if (!inCooldown) {
            inCooldown = true;
            cooldownStartTime = System.currentTimeMillis();

            // Random cooldown between 3-8 minutes
            cooldownDuration = MIN_COOLDOWN_MS +
                    (long)(Math.random() * (MAX_COOLDOWN_MS - MIN_COOLDOWN_MS));

            long cooldownMinutes = cooldownDuration / 60000;
            long cooldownSeconds = (cooldownDuration % 60000) / 1000;

            Logger.log("Cooldown duration: " + cooldownMinutes + " minutes " + cooldownSeconds + " seconds");
            Logger.log("Cooldown will end at: " + new java.util.Date(System.currentTimeMillis() + cooldownDuration));
        }
    }

    /**
     * Checks if currently in cooldown period
     */
    public boolean isInCooldown() {
        if (!inCooldown) {
            return false;
        }

        long elapsed = System.currentTimeMillis() - cooldownStartTime;

        if (elapsed >= cooldownDuration) {
            // Cooldown complete
            Logger.log("==============================================");
            Logger.log("Cooldown period complete - resuming script");
            Logger.log("==============================================");
            inCooldown = false;
            loginAttemptMade = false;
            return false;
        }

        // Still in cooldown
        long remaining = cooldownDuration - elapsed;
        long remainingMinutes = remaining / 60000;
        long remainingSeconds = (remaining % 60000) / 1000;

        // Log every 30 seconds
        if (elapsed % 30000 < 1000) {
            Logger.log("Cooldown remaining: " + remainingMinutes + "m " + remainingSeconds + "s");
        }

        return true;
    }

    /**
     * Handles the login process with single-attempt logic
     */
    public boolean canAttemptLogin() {
        if (isInCooldown()) {
            return false;
        }

        long currentTime = System.currentTimeMillis();

        if (loginAttemptMade &&
                (currentTime - lastLoginAttemptTime) > LOGIN_ATTEMPT_RESET_TIME) {
            loginAttemptMade = false;
        }

        if (loginAttemptMade) {
            return false;
        }

        return true;
    }

    /**
     * Marks that a login attempt was made
     */
    public void markLoginAttempt() {
        loginAttemptMade = true;
        lastLoginAttemptTime = System.currentTimeMillis();
        Logger.log("Login attempt made - will wait before next attempt");
    }

    /**
     * Resets the login attempt flag
     */
    public void resetLoginAttempt() {
        loginAttemptMade = false;
        Logger.log("Login successful - login handler reset");
    }

    /**
     * Gets the cooldown status for display
     */
    public String getCooldownStatus() {
        if (!inCooldown) {
            return "Not in cooldown";
        }

        long elapsed = System.currentTimeMillis() - cooldownStartTime;
        long remaining = cooldownDuration - elapsed;
        long remainingMinutes = remaining / 60000;
        long remainingSeconds = (remaining % 60000) / 1000;

        return "Cooldown: " + remainingMinutes + "m " + remainingSeconds + "s";
    }

    /**
     * Main handler to call in onLoop()
     */
    public int handleLogin() {
        if (isInCooldown()) {
            // Sleep for 30 seconds during cooldown
            return 30000;
        }

        return 0;
    }
}
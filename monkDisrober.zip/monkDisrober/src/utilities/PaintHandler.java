package utilities;

import main.MonkDisrober;
import org.dreambot.api.input.Mouse;
import org.dreambot.api.methods.world.Worlds;

import java.awt.*;

public class PaintHandler {

    private final MonkDisrober script;

    public PaintHandler(MonkDisrober script) {
        this.script = script;
    }

    public void drawOverlay(Graphics2D g) {
        Composite originalComposite = g.getComposite();
        Color originalColor = g.getColor();

        drawFullOverlay(g);
        drawMouse(g);

        g.setComposite(originalComposite);
        g.setColor(originalColor);
    }

    private void drawFullOverlay(Graphics2D g) {
        int rectX = 5;
        int rectY = 345;
        int rectWidth = 510;
        int rectHeight = 170; // Increased for login status and mule stats

        g.setColor(new Color(0, 0, 0, 220));
        g.fillRoundRect(rectX, rectY, rectWidth, rectHeight, 10, 10);

        g.setColor(new Color(150, 150, 150));
        g.setStroke(new BasicStroke(2));
        g.drawRoundRect(rectX, rectY, rectWidth, rectHeight, 10, 10);

        g.setFont(new Font("Arial", Font.BOLD, 14));
        g.setColor(Color.WHITE);

        String title = "timandmonica's Monk Disrober";
        int titleWidth = g.getFontMetrics().stringWidth(title);
        g.drawString(title, rectX + (rectWidth - titleWidth) / 2, rectY + 20);

        g.setFont(new Font("Arial", Font.PLAIN, 12));
        int textY = rectY + 45;

        g.drawString("Current State: " + script.getStateHandler().getCurrentState(), rectX + 10, textY);
        textY += 20;

        g.drawString("Total Items Picked Up: " + script.getInventoryHandler().getTotalItemsPickedUp(), rectX + 10, textY);
        textY += 20;

        g.drawString("Running Time: " + formatTime(System.currentTimeMillis() - script.getStartTime()), rectX + 10, textY);
        textY += 20;

        int currentWorld = Worlds.getCurrentWorld();
        g.drawString("Current World: " + currentWorld, rectX + 10, textY);
        textY += 20;

        // Add login status display
        String loginStatus = script.getLoginHandler().getCooldownStatus();
        if (loginStatus.contains("Cooldown:")) {
            g.setColor(Color.RED);
            g.drawString("Login Status: " + loginStatus, rectX + 10, textY);
            g.setColor(Color.WHITE);
        } else {
            g.drawString("Login Status: Ready", rectX + 10, textY);
        }
        textY += 20;

        // Add mule stats if enabled
        if (script.getMuleHandler().isMuleEnabled()) {
            g.setColor(Color.CYAN);
            g.drawString("Mule: " + script.getMuleHandler().getMuleSessionsCompleted() + " sessions | " +
                    script.getMuleHandler().getItemsMuledTotal() + " items", rectX + 10, textY);
            g.setColor(Color.WHITE);
        }
    }

    private void drawMouse(Graphics2D g) {
        Point mousePos = Mouse.getPosition();
        if (mousePos == null) return;

        // Get canvas dimensions from the script's client
        int screenWidth = 765;  // Default fixed client width
        int screenHeight = 503; // Default fixed client height

        // Draw simple crosshair only (fish mouse removed)
        drawCoordinateLines(g, mousePos, screenWidth, screenHeight);
    }

    private void drawCoordinateLines(Graphics2D g, Point mousePos, int screenWidth, int screenHeight) {
        g.setColor(new Color(255, 255, 255, 255));
        g.drawLine(0, mousePos.y, screenWidth, mousePos.y);
        g.drawLine(mousePos.x, 0, mousePos.x, screenHeight);
    }

    private String formatTime(long milliseconds) {
        long seconds = milliseconds / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        return String.format("%02d:%02d:%02d", hours, minutes % 60, seconds % 60);
    }
}
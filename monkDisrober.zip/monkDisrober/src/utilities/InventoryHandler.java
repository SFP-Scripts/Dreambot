package utilities;

import main.MonkDisrober;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.item.GroundItems;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.items.GroundItem;
import org.dreambot.api.wrappers.widgets.WidgetChild;
import utilities.StateHandler;

public class InventoryHandler {

    private final MonkDisrober script;

    private int totalItemsPickedUp = 0;
    private long waitStartTime = 0; // NEW: Track when we started waiting

    private static final Area LOOT_POSITION = new Area(3057, 3487, 3059, 3489, 1);
    private static final int[] OPTION_ROOTS = {219, 229, 217, 231};

    public InventoryHandler(MonkDisrober script) {
        this.script = script;
    }

    public int bankItems() {
        if (!Bank.isOpen()) {
            if (!Bank.open()) {
                return script.getRandomSleep(600, 900);
            }
            Sleep.sleepUntil(Bank::isOpen, 5000);
        }

        if (!Bank.isOpen()) {
            return script.getRandomSleep(600, 900);
        }

        script.log("Depositing ALL inventory items...");
        Bank.depositAllItems();
        Sleep.sleepUntil(Inventory::isEmpty, 4000);

        sleep(script.getRandomSleep(250, 500));
        Bank.close();
        sleep(script.getRandomSleep(450, 850));

        int prayerLevel = Skills.getRealLevel(Skill.PRAYER);
        if (prayerLevel < 31) {
            script.log("Prayer level " + prayerLevel + " (<31) -> checking bank for vile ashes");
            script.getStateHandler().setCurrentState(StateHandler.State.CHECK_BANK_FOR_ASHES);
        } else {
            script.log("Prayer level " + prayerLevel + " (31+) -> going to monastery");
            script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_MONASTERY);
        }

        return script.getRandomSleep(600, 900);
    }

    public int lootRobes() {
        if (Inventory.isFull()) {
            script.log("Inventory full -> going to bank.");
            script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_BANK);
            return 0;
        }

        if (!LOOT_POSITION.contains(Players.getLocal().getTile())) {
            script.log("Not at loot position -> opening door to enter room.");
            script.getStateHandler().setCurrentState(StateHandler.State.OPEN_DOOR);
            return 0;
        }

        GroundItem monkRobe = GroundItems.closest(item ->
                item != null &&
                        ("Monk's robe".equals(item.getName()) || "Monk's robe top".equals(item.getName()))
        );

        if (monkRobe == null) {
            script.log("No robes detected.");

            // Check if world hopping is enabled
            if (script.getGuiHandler().isWorldHoppingEnabled()) {
                script.log("World hopping enabled -> hopping worlds.");
                script.getStateHandler().setCurrentState(StateHandler.State.HOP_WORLDS);
            } else {
                script.log("World hopping disabled -> waiting in room.");
                waitStartTime = System.currentTimeMillis();
                script.getStateHandler().setCurrentState(StateHandler.State.WAIT_IN_ROOM);
            }
            return 0;
        }

        int before = (int) (Inventory.count("Monk's robe") + Inventory.count("Monk's robe top"));

        if (monkRobe.interact("Take")) {
            Sleep.sleepUntil(() ->
                            (Inventory.count("Monk's robe") + Inventory.count("Monk's robe top")) > before
                                    || Inventory.isFull(),
                    3500
            );

            int after = (int) (Inventory.count("Monk's robe") + Inventory.count("Monk's robe top"));
            if (after > before) {
                totalItemsPickedUp++;
            } else {
                script.log("Tried to pick up robe but inventory count did not increase.");
            }

            if (Inventory.isFull()) {
                script.log("Inventory became full after pickup -> going to bank.");
                script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_BANK);
                return 0;
            }
        }

        return script.getRandomSleep(600, 900);
    }

    /** NEW: Wait in room with random walking */
    public int waitInRoom() {
        long currentTime = System.currentTimeMillis();
        long waitTimeMs = script.getGuiHandler().getWaitTimeSeconds() * 1000L;
        long elapsedTime = currentTime - waitStartTime;

        // First check if robes have spawned
        GroundItem monkRobe = GroundItems.closest(item ->
                item != null &&
                        ("Monk's robe".equals(item.getName()) || "Monk's robe top".equals(item.getName()))
        );

        if (monkRobe != null) {
            script.log("Robes detected! Switching to loot mode.");
            script.getStateHandler().setCurrentState(StateHandler.State.LOOT_ROBES);
            return 0;
        }

        // Check if wait time has elapsed
        if (elapsedTime >= waitTimeMs) {
            script.log("Wait time elapsed (" + (elapsedTime / 1000) + "s). Checking for robes again.");
            script.getStateHandler().setCurrentState(StateHandler.State.LOOT_ROBES);
            return 0;
        }

        // Ensure we're in the loot room
        if (!LOOT_POSITION.contains(Players.getLocal().getTile())) {
            script.log("Not in loot room, moving back...");
            Walking.walk(LOOT_POSITION.getRandomTile());
            Sleep.sleepUntil(() -> LOOT_POSITION.contains(Players.getLocal()), 4000);
            return script.getRandomSleep(800, 1200);
        }

        // Perform random walking within the room
        int randomAction = getRandomInt(1, 100);

        if (randomAction <= 30) { // 30% chance to walk to a random tile in the room
            Tile randomTile = LOOT_POSITION.getRandomTile();
            script.log("Random walk to: " + randomTile);
            Walking.walk(randomTile);
            Sleep.sleepUntil(() -> !Players.getLocal().isMoving(), getRandomInt(2000, 4000));

            // Maybe perform anti-ban action after walking
            if (getRandomInt(1, 100) <= 40) {
                script.getAntiBanHandler().performRandomAction();
            }

            return script.getRandomSleep(1500, 3500);
        } else if (randomAction <= 50) { // 20% chance to perform anti-ban action
            script.getAntiBanHandler().performRandomAction();
            return script.getRandomSleep(800, 1500);
        } else { // 50% chance to just idle
            long remainingTime = waitTimeMs - elapsedTime;
            script.log("Waiting in room... (" + (remainingTime / 1000) + "s remaining)");
            return script.getRandomSleep(2000, 5000);
        }
    }

    public int talkToAbbotForLadderAccess() {
        String playerName = Players.getLocal().getName();
        if (OrderUnlockStore.isUnlocked(playerName)) {
            script.log("Player already unlocked order (from file) -> skipping abbot dialogue.");
            return 0;
        }

        if (Dialogues.inDialogue()) {

            if (Dialogues.areOptionsAvailable() && checkForHealingOption()) {
                script.log("Heal option detected -> already joined order.");
                OrderUnlockStore.markUnlocked(playerName);
                return script.getRandomSleep(450, 750);
            }

            if (Dialogues.canContinue()) {
                Dialogues.continueDialogue();
                return script.getRandomSleep(450, 750);
            }

            if (Dialogues.areOptionsAvailable()) {
                if (Dialogues.chooseOption("How do I get further into the monastery")) {
                    script.log("Selected: How do I get further into the monastery");
                    return script.getRandomSleep(450, 750);
                }

                if (Dialogues.chooseOption("Well can I join your order")
                        || Dialogues.chooseOption("Well, can I join your order?")
                        || Dialogues.chooseOption("Can I join your order?")
                        || Dialogues.chooseOption("join your order")
                        || Dialogues.chooseOption("join the order")) {
                    script.log("Selected: join order option");
                    return script.getRandomSleep(450, 750);
                }

                Dialogues.chooseOption(1);
                return script.getRandomSleep(450, 750);
            }

            if (!Dialogues.inDialogue()) {
                script.log("Abbot dialogue complete - ladder access granted.");
                OrderUnlockStore.markUnlocked(playerName);
            }

            return script.getRandomSleep(450, 750);
        }

        NPC abbot = NPCs.closest("Abbot Langley");
        if (abbot == null) {
            script.log("Abbot not found, retrying...");
            return script.getRandomSleep(600, 900);
        }

        if (abbot.interact("Talk-to")) {
            Sleep.sleepUntil(Dialogues::inDialogue, 6000);
        }

        return script.getRandomSleep(450, 750);
    }

    private boolean checkForHealingOption() {
        for (int root : OPTION_ROOTS) {
            for (int child = 0; child <= 15; child++) {
                WidgetChild option = Widgets.get(root, child);
                if (option == null || !option.isVisible()) continue;

                String text = option.getText();
                if (text == null) continue;

                String lower = text.toLowerCase();
                if (lower.contains("can you heal me") || (lower.contains("heal") && lower.contains("injured"))) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean hasLadderAccess() {
        String playerName = Players.getLocal().getName();
        return OrderUnlockStore.isUnlocked(playerName);
    }

    public int getTotalItemsPickedUp() {
        return totalItemsPickedUp;
    }

    private int getRandomInt(int min, int max) {
        if (max <= min) return min;
        return min + (int) (Math.random() * ((max - min) + 1));
    }

    private void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
package utilities;

import main.MonkDisrober;
import mule.client.MuleClientSnippet;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.utilities.Logger;

/**
 * Handles muling of monk robes and coins
 */
public class MuleHandler {

    private final MonkDisrober script;
    private MuleClientSnippet muleClient;

    // Mule configuration
    private boolean muleEnabled = false;
    private String muleServerHost = "localhost";
    private int muleServerPort = 43594;
    private String muleAuthToken = "";
    private int muleAfterItems = 500; // Mule after collecting this many items

    // Tracking
    private int itemsMuledTotal = 0;
    private int coinsMuledTotal = 0;
    private int muleSessionsCompleted = 0;

    public MuleHandler(MonkDisrober script) {
        this.script = script;
    }

    /**
     * Initialize mule client with configuration
     */
    public void initializeMule(String serverHost, int serverPort, String authToken) {
        try {
            this.muleServerHost = serverHost;
            this.muleServerPort = serverPort;
            this.muleAuthToken = authToken;

            muleClient = new MuleClientSnippet(script, serverHost, serverPort, authToken);
            muleEnabled = true;

            Logger.log("Mule client initialized successfully");
            Logger.log("Server: " + serverHost + ":" + serverPort);

            // Test connection
            if (muleClient.pingMule()) {
                Logger.log("Successfully connected to mule server!");
            } else {
                Logger.log("Warning: Could not ping mule server");
            }

        } catch (Exception e) {
            Logger.error("Failed to initialize mule client: " + e.getMessage());
            muleEnabled = false;
        }
    }

    /**
     * Check if it's time to mule based on items collected
     */
    public boolean shouldMule() {
        if (!muleEnabled) {
            return false;
        }

        if (muleClient == null) {
            return false;
        }

        try {
            int totalItems = script.getInventoryHandler().getTotalItemsPickedUp();
            return totalItems >= muleAfterItems;
        } catch (Exception e) {
            Logger.log("Error checking mule threshold: " + e.getMessage());
            return false;
        }
    }

    /**
     * Mule all robes and coins
     */
    public boolean muleItems() {
        if (!muleEnabled) {
            Logger.log("Mule not enabled, cannot mule items");
            return false;
        }

        if (muleClient == null) {
            Logger.log("Mule client not initialized");
            return false;
        }

        Logger.log("========================================");
        Logger.log("Starting mule session #" + (muleSessionsCompleted + 1));
        Logger.log("========================================");

        try {
            // Count items before muling
            int robesCount = (int) (Inventory.count("Monk's robe") + Inventory.count("Monk's robe top"));
            int coinsCount = Inventory.contains("Coins") ? Inventory.count("Coins") : 0;

            Logger.log("Items to mule:");
            Logger.log("  - Monk's robes: " + robesCount);
            Logger.log("  - Coins: " + coinsCount);

            // Deposit all items including coins
            boolean success = false;
            try {
                success = muleClient.depositAllItems();
            } catch (Exception e) {
                Logger.error("Mule client error: " + e.getMessage());
                return false;
            }

            if (success) {
                // Update totals
                itemsMuledTotal += robesCount;
                coinsMuledTotal += coinsCount;
                muleSessionsCompleted++;

                Logger.log("========================================");
                Logger.log("Mule session completed successfully!");
                Logger.log("Total items muled: " + itemsMuledTotal);
                Logger.log("Total coins muled: " + coinsMuledTotal);
                Logger.log("Mule sessions: " + muleSessionsCompleted);
                Logger.log("========================================");

                return true;
            } else {
                Logger.log("Mule session failed - will retry later");
                return false;
            }

        } catch (Exception e) {
            Logger.error("Error during mule session: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Cleanup mule connection
     */
    public void cleanup() {
        if (muleClient != null) {
            muleClient.cleanup();
            Logger.log("Mule connection closed");
        }
    }

    // Getters and setters

    public boolean isMuleEnabled() {
        return muleEnabled;
    }

    public void setMuleEnabled(boolean enabled) {
        this.muleEnabled = enabled;
    }

    public void setMuleAfterItems(int items) {
        this.muleAfterItems = items;
    }

    public int getMuleAfterItems() {
        return muleAfterItems;
    }

    public int getItemsMuledTotal() {
        return itemsMuledTotal;
    }

    public int getCoinsMuledTotal() {
        return coinsMuledTotal;
    }

    public int getMuleSessionsCompleted() {
        return muleSessionsCompleted;
    }

    public String getMuleStatus() {
        if (!muleEnabled) {
            return "Disabled";
        }
        if (muleClient == null) {
            return "Not initialized";
        }
        try {
            return muleClient.getMuleStatus();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}
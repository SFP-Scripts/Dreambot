package utilities;

import main.MonkDisrober;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.bank.BankMode;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.grandexchange.LivePrices;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import utilities.StateHandler;

import java.util.SplittableRandom;

public class PrayerTrainingHandler {

    private final MonkDisrober script;

    private static final Area GE_BANK = new Area(3161, 3485, 3169, 3493, 0);
    private static final Area GE_CENTER = new Area(3163, 3486, 3167, 3488, 0);

    // bury/scatter in GE bank area
    private static final Area BURYING_LOCATION = GE_BANK;

    // buy 900 vile ashes
    private static final int VILE_ASHES_TO_BUY = 900;

    private static final String ASHES_NAME = "Vile ashes";
    private static final String COINS_NAME = "Coins";

    // Keep GE bank open 3-10 seconds before closing
    private static final int BANK_VIEW_MIN_MS = 3000;
    private static final int BANK_VIEW_MAX_MS = 10000;

    // Pricing
    private static final double PRICE_PADDING = 1.10;
    private static final int FALLBACK_PRICE_EACH = 50;

    // Dynamic escalation settings
    private static final int MAX_BUY_ATTEMPTS = 6;
    private static final double ESCALATE_PERCENT = 0.07; // +7% each attempt
    private static final int WAIT_COLLECT_MIN_MS = 9000;
    private static final int WAIT_COLLECT_MAX_MS = 18000;

    public PrayerTrainingHandler(MonkDisrober script) {
        this.script = script;
    }

    /** STATE: CHECK_BANK_FOR_ASHES */
    public int checkBankForAshes() {
        script.log("Checking bank for vile ashes...");

        // ✅ Stop prayer training immediately once 31 is reached
        if (reachedTargetPrayer()) {
            script.log("Prayer 31+ reached - switching to monastery.");
            if (Bank.isOpen()) Bank.close();
            script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_MONASTERY);
            return 800;
        }

        if (!ensureBankOpen()) return sleepShort();

        long ashesInBank = Bank.count(ASHES_NAME);
        long bankCoins = Bank.count(COINS_NAME);
        long invCoins = Inventory.count(COINS_NAME);
        long totalCoins = bankCoins + invCoins;

        script.log("Bank check: ashes=" + ashesInBank +
                ", coins(inv)=" + invCoins + ", coins(bank)=" + bankCoins);

        if (ashesInBank > 0) {
            script.getStateHandler().setCurrentState(StateHandler.State.WITHDRAW_ASHES);
            return sleepShort();
        }

        // No ashes -> prepare to buy
        int basePrice = getBasePriceEach();
        long requiredCoins = (long) basePrice * (long) VILE_ASHES_TO_BUY;

        if (totalCoins < requiredCoins) {
            script.log("ERROR: Not enough coins to buy " + VILE_ASHES_TO_BUY + " " + ASHES_NAME +
                    ". Need ~" + requiredCoins + ", have " + totalCoins + ". Stopping.");
            script.stop();
            return 1000;
        }

        // Ensure enough coins in inventory for initial attempt (base estimate)
        long invCoinsNow = Inventory.count(COINS_NAME);
        if (invCoinsNow < requiredCoins) {
            long toWithdraw = requiredCoins - invCoinsNow;
            script.log("Withdrawing coins for GE buy: " + toWithdraw);

            Bank.withdraw(COINS_NAME, (int) Math.min(Integer.MAX_VALUE, toWithdraw));
            Sleep.sleepUntil(() -> Inventory.count(COINS_NAME) >= requiredCoins, 5000);
        }

        // human delay
        sleep(randBetween(BANK_VIEW_MIN_MS, BANK_VIEW_MAX_MS));

        Bank.close();
        sleep(randBetween(450, 900));

        script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_GE);
        return sleepShort();
    }

    /** STATE: WITHDRAW_ASHES */
    public int withdrawVileAshes() {
        // ✅ Stop prayer training immediately once 31 is reached
        if (reachedTargetPrayer()) {
            script.log("Prayer 31+ reached - switching to monastery.");
            if (Bank.isOpen()) Bank.close();
            script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_MONASTERY);
            return sleepShort();
        }

        if (!ensureBankOpen()) return sleepShort();

        // Ensure unnoted items
        if (Bank.getWithdrawMode() != BankMode.ITEM) {
            Bank.setWithdrawMode(BankMode.ITEM);
            sleep(randBetween(250, 550));
        }

        // Clear inventory before scattering
        depositAllItemsExceptCoins();

        // Withdraw ashes into inventory (unnoted)
        if (Bank.withdrawAll(ASHES_NAME)) {
            Sleep.sleepUntil(() -> Inventory.contains(ASHES_NAME), 4000);
        }

        // small human delay
        sleep(randBetween(BANK_VIEW_MIN_MS, BANK_VIEW_MAX_MS));
        Bank.close();
        sleep(randBetween(450, 900));

        script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_BURYING_LOCATION);
        return sleepShort();
    }

    /** STATE: GO_TO_GE_BANK */
    public int goToGEBank() {
        if (GE_BANK.contains(Players.getLocal())) {
            script.getStateHandler().setCurrentState(StateHandler.State.CHECK_BANK_FOR_ASHES);
            return 0;
        }

        Walking.walk(GE_BANK.getRandomTile());
        Sleep.sleepUntil(() -> GE_BANK.contains(Players.getLocal()), 10000);
        return randBetween(800, 1400);
    }

    /** STATE: GO_TO_GE */
    public int goToGrandExchange() {
        script.log("Going to GE to buy vile ashes...");

        if (GE_CENTER.contains(Players.getLocal())) {
            script.getStateHandler().setCurrentState(StateHandler.State.BUY_VILE_ASHES);
            return 0;
        }

        Walking.walk(GE_CENTER.getRandomTile());
        Sleep.sleepUntil(() -> GE_CENTER.contains(Players.getLocal()), 10000);
        return randBetween(800, 1400);
    }

    /** STATE: BUY_VILE_ASHES */
    public int buyVileAshes() {
        // ✅ Stop prayer training immediately once 31 is reached
        if (reachedTargetPrayer()) {
            script.log("Prayer 31+ reached - switching to monastery.");
            script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_MONASTERY);
            return sleepShort();
        }

        script.log("Buying " + VILE_ASHES_TO_BUY + " " + ASHES_NAME + " (dynamic escalation)...");

        int basePriceEach = getBasePriceEach();

        for (int attempt = 0; attempt < MAX_BUY_ATTEMPTS; attempt++) {
            int priceEach = (int) Math.ceil(basePriceEach * Math.pow(1.0 + ESCALATE_PERCENT, attempt));
            long requiredCoins = (long) priceEach * (long) VILE_ASHES_TO_BUY;

            long invCoins = Inventory.count(COINS_NAME);
            if (invCoins < requiredCoins) {
                script.log("Not enough coins in inventory for attempt " + (attempt + 1) +
                        ". Need " + requiredCoins + ", have " + invCoins + ". Going to bank.");
                script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_GE_BANK);
                return sleepShort();
            }

            // Open GE
            if (!GrandExchange.isOpen()) {
                GrandExchange.open();
                Sleep.sleepUntil(GrandExchange::isOpen, 9000);
            }

            if (!GrandExchange.isOpen()) {
                script.log("Failed to open GE interface. Retrying...");
                return randBetween(900, 1400);
            }

            // Clean up any ready collection
            if (GrandExchange.isReadyToCollect()) {
                safeCollectToBank();
                sleep(randBetween(500, 900));
            }

            script.log("Attempt " + (attempt + 1) + "/" + MAX_BUY_ATTEMPTS +
                    " offer: " + VILE_ASHES_TO_BUY + "x " + ASHES_NAME + " @ " + priceEach);

            boolean placed = GrandExchange.buyItem(ASHES_NAME, VILE_ASHES_TO_BUY, priceEach);
            if (!placed) {
                script.log("Failed to place offer. Canceling and retrying...");
                GrandExchange.cancelAll();
                sleep(randBetween(900, 1500));
                continue;
            }

            int waitMs = randBetween(WAIT_COLLECT_MIN_MS, WAIT_COLLECT_MAX_MS);
            boolean ready = Sleep.sleepUntil(GrandExchange::isReadyToCollect, waitMs);

            if (ready) {
                safeCollectToBank();
                sleep(randBetween(700, 1200));

                // Bank flow will withdraw unnoted ashes and start scattering
                script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_GE_BANK);
                return sleepShort();
            }

            script.log("Offer not ready after ~" + waitMs + "ms. Canceling and escalating...");
            GrandExchange.cancelAll();
            sleep(randBetween(900, 1500));
        }

        script.log("ERROR: Could not buy " + ASHES_NAME + " after " + MAX_BUY_ATTEMPTS + " attempts. Going to bank.");
        script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_GE_BANK);
        return sleepShort();
    }

    /** STATE: GO_TO_BURYING_LOCATION */
    public int goToBuryingLocation() {
        // ✅ Stop prayer training immediately once 31 is reached
        if (reachedTargetPrayer()) {
            script.log("Prayer 31+ reached - switching to monastery.");
            script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_MONASTERY);
            return sleepShort();
        }

        if (BURYING_LOCATION.contains(Players.getLocal())) {
            script.getStateHandler().setCurrentState(StateHandler.State.BURY_ASHES);
            return 0;
        }

        Walking.walk(BURYING_LOCATION.getRandomTile());
        Sleep.sleepUntil(() -> BURYING_LOCATION.contains(Players.getLocal()), 9000);
        return randBetween(700, 1200);
    }

    /** STATE: BURY_ASHES */
    public int buryVileAshes() {
        // ✅ Stop prayer training immediately once 31 is reached (even mid-inventory)
        if (reachedTargetPrayer()) {
            script.log("Prayer 31+ reached - stopping ashes and going to monastery.");
            script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_MONASTERY);
            return sleepShort();
        }

        // If interfaces are open, actions can be replaced (e.g., "Offer")
        if (Bank.isOpen()) {
            Bank.close();
            sleep(randBetween(300, 600));
        }

        if (!Inventory.contains(ASHES_NAME)) {
            script.log("No ashes in inventory. Going to bank.");
            script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_GE_BANK);
            return 0;
        }

        maybeAfkPause();

        // Try Scatter first, fallback to Bury
        boolean ok = Inventory.interact(ASHES_NAME, "Scatter");
        if (!ok) ok = Inventory.interact(ASHES_NAME, "Bury");

        if (ok) {
            sleep(randBetween(250, 700));
            Sleep.sleepUntil(() -> !Players.getLocal().isAnimating(), randBetween(1400, 2600));
            maybeAfkPause();
        } else {
            script.log("Could not Scatter/Bury ashes (maybe interface state). Returning to bank to reset.");
            script.getStateHandler().setCurrentState(StateHandler.State.GO_TO_GE_BANK);
        }

        return randBetween(850, 1500);
    }

    // ---------------- Helpers ----------------

    private boolean reachedTargetPrayer() {
        return Skills.getRealLevel(Skill.PRAYER) >= 31;
    }

    private boolean ensureBankOpen() {
        if (Bank.isOpen()) return true;
        if (!Bank.open()) return false;
        return Sleep.sleepUntil(Bank::isOpen, 8000);
    }

    private void depositAllItemsExceptCoins() {
        long coinsBefore = Inventory.count(COINS_NAME);

        Bank.depositAllItems();
        Sleep.sleepUntil(() -> Inventory.isEmpty() || Inventory.size() == 0, 4000);

        if (coinsBefore > 0 && Bank.count(COINS_NAME) > 0) {
            int toWithdraw = (int) Math.min(coinsBefore, Integer.MAX_VALUE);
            Bank.withdraw(COINS_NAME, toWithdraw);
            Sleep.sleepUntil(() -> Inventory.count(COINS_NAME) > 0, 3000);
        }
    }

    private void safeCollectToBank() {
        try {
            GrandExchange.collectToBank();
        } catch (Throwable t) {
            GrandExchange.collect();
        }
    }

    private int getBasePriceEach() {
        int high = LivePrices.getHigh(ASHES_NAME);
        if (high <= 0) return FALLBACK_PRICE_EACH;
        return (int) Math.ceil(high * PRICE_PADDING);
    }

    /** All randomization derived from current time for higher variability */
    private int randBetween(int min, int max) {
        if (max <= min) return min;
        long seed = System.currentTimeMillis() ^ System.nanoTime() ^ (long) (System.identityHashCode(this) * 31);
        SplittableRandom r = new SplittableRandom(seed);
        return r.nextInt(min, max + 1);
    }

    private int sleepShort() {
        return randBetween(650, 950);
    }

    /**
     * Random AFK pauses:
     * - ~10%: 3-9s
     * - ~3% : 10-25s
     * - ~1% : 25-55s
     */
    private void maybeAfkPause() {
        int roll = randBetween(1, 100);

        if (roll <= 1) {
            int ms = randBetween(25000, 55000);
            script.log("AFK (long) ~" + (ms / 1000) + "s");
            sleep(ms);
        } else if (roll <= 4) {
            int ms = randBetween(10000, 25000);
            script.log("AFK (medium) ~" + (ms / 1000) + "s");
            sleep(ms);
        } else if (roll <= 14) {
            sleep(randBetween(3000, 9000));
        } else {
            if (randBetween(1, 100) <= 20) {
                sleep(randBetween(300, 900));
            }
        }
    }

    private void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
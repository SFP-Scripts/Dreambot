package utilities;

import main.MonkDisrober;
import org.dreambot.api.input.Mouse;
import org.dreambot.api.methods.input.Camera;
import org.dreambot.api.methods.input.mouse.MouseSettings;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;

import java.awt.*;
import java.util.Random;

public class AntiBanHandler {

    private final MonkDisrober script;
    private final Random random;

    private long lastCameraMovement;
    private long lastMouseMovement;
    private long lastTabCheck;
    private long lastSkillHover;

    private boolean enableCameraMovement = true;
    private boolean enableRandomMouseMovement = true;
    private boolean enableRandomTabChecking = true;
    private boolean enableSkillHovering = true;
    private boolean enableObjectExamining = true;
    private boolean enableRandomPauses = true;
    private boolean enableMouseSpeedVariation = true;

    private int cameraMovementChance = 15;
    private int mouseMovementChance = 8;
    private int tabCheckChance = 12;
    private int skillHoverChance = 10;
    private int objectExamineChance = 5;
    private int randomPauseChance = 20;

    private int minTimeBetweenCameraMovements = 15000;
    private int minTimeBetweenMouseMovements = 8000;
    private int minTimeBetweenTabChecks = 20000;
    private int minTimeBetweenSkillHovers = 25000;

    public AntiBanHandler(MonkDisrober script) {
        this.script = script;
        this.random = new Random();
        this.lastCameraMovement = System.currentTimeMillis();
        this.lastMouseMovement = System.currentTimeMillis();
        this.lastTabCheck = System.currentTimeMillis();
        this.lastSkillHover = System.currentTimeMillis();
    }

    public void performRandomAction() {
        try {
            long now = System.currentTimeMillis();

            if (enableCameraMovement && shouldPerformAction(cameraMovementChance, lastCameraMovement, minTimeBetweenCameraMovements)) {
                adjustCamera();
                lastCameraMovement = now;
                return;
            }

            if (enableRandomMouseMovement && shouldPerformAction(mouseMovementChance, lastMouseMovement, minTimeBetweenMouseMovements)) {
                moveMouseRandomly();
                lastMouseMovement = now;
                return;
            }

            if (enableRandomTabChecking && shouldPerformAction(tabCheckChance, lastTabCheck, minTimeBetweenTabChecks)) {
                checkRandomTab();
                lastTabCheck = now;
                return;
            }

            if (enableSkillHovering && shouldPerformAction(skillHoverChance, lastSkillHover, minTimeBetweenSkillHovers)) {
                hoverRandomSkill();
                lastSkillHover = now;
                return;
            }

            if (enableObjectExamining && shouldPerformAction(objectExamineChance, 0, 0)) {
                examineRandomObject();
                return;
            }

            if (enableRandomPauses && shouldPerformAction(randomPauseChance, 0, 0)) {
                performRandomPause();
                return;
            }

        } catch (Exception e) {
            script.log("Anti-ban error: " + e.getMessage());
        }
    }

    public void adjustCamera() {
        try {
            if (!enableCameraMovement) return;

            int currentYaw = Camera.getYaw();
            int currentPitch = Camera.getPitch();

            int yawChange = randInt(-45, 45);
            int pitchChange = randInt(-15, 15);

            int targetYaw = currentYaw + yawChange;
            int targetPitch = Math.max(128, Math.min(383, currentPitch + pitchChange));

            script.log("Anti-ban: Adjusting camera");

            Camera.rotateTo(targetYaw, targetPitch);
            sleep(randInt(400, 900));

        } catch (Exception e) {
            script.log("Camera adjustment error: " + e.getMessage());
        }
    }

    public void moveMouseRandomly() {
        try {
            if (!enableRandomMouseMovement) return;

            Point currentPos = Mouse.getPosition();
            if (currentPos == null) return;

            int x = randInt(50, 700);
            int y = randInt(50, 450);

            script.log("Anti-ban: Moving mouse randomly");

            if (enableMouseSpeedVariation) {
                int speedVariation = randInt(-2, 2);
                MouseSettings.setSpeed(Math.max(1, Math.min(10, MouseSettings.getSpeed() + speedVariation)));
            }

            Mouse.move(new Point(x, y));
            sleep(randInt(200, 600));

        } catch (Exception e) {
            // Silently continue
        }
    }

    public void checkRandomTab() {
        try {
            if (!enableRandomTabChecking) return;

            Tab currentTab = Tabs.getOpen();
            Tab[] tabs = {Tab.INVENTORY, Tab.SKILLS, Tab.COMBAT, Tab.EQUIPMENT, Tab.PRAYER};
            Tab randomTab = tabs[randInt(0, tabs.length - 1)];

            if (currentTab == randomTab) return;

            script.log("Anti-ban: Checking " + randomTab + " tab");

            Tabs.open(randomTab);
            sleep(randInt(800, 2000));

            if (randInt(1, 100) <= 40) {
                sleep(randInt(400, 900));
            }

            Tabs.open(Tab.INVENTORY);
            sleep(randInt(300, 700));

        } catch (Exception e) {
            // Silently continue
        }
    }

    public void hoverRandomSkill() {
        try {
            if (!enableSkillHovering) return;

            script.log("Anti-ban: Hovering random skill");

            Tab currentTab = Tabs.getOpen();

            Tabs.open(Tab.SKILLS);
            sleep(randInt(600, 1200));

            int x = randInt(550, 700);
            int y = randInt(210, 450);
            Mouse.move(new Point(x, y));
            sleep(randInt(800, 1800));

            Tabs.open(currentTab != null ? currentTab : Tab.INVENTORY);
            sleep(randInt(300, 600));

        } catch (Exception e) {
            // Silently continue
        }
    }

    public void examineRandomObject() {
        try {
            if (!enableObjectExamining) return;

            GameObject obj = GameObjects.closest(o -> o != null && o.exists());

            if (obj != null && randInt(1, 100) <= 60) {
                script.log("Anti-ban: Examining nearby object");
                obj.interact("Examine");
                sleep(randInt(1000, 2000));
            }

        } catch (Exception e) {
            // Silently continue
        }
    }

    public void hoverRandomObject() {
        try {
            GameObject obj = GameObjects.closest(o -> o != null && o.exists());

            if (obj != null) {
                script.log("Anti-ban: Hovering nearby object");
                // Use right-click menu instead of direct hover
                obj.interact("Examine");
                sleep(randInt(400, 1000));
            }

        } catch (Exception e) {
            // Silently continue
        }
    }

    public void hoverRandomNPC() {
        try {
            NPC npc = NPCs.closest(n -> n != null && n.exists());

            if (npc != null) {
                script.log("Anti-ban: Hovering nearby NPC");
                // Use right-click menu instead of direct hover
                npc.interact("Examine");
                sleep(randInt(500, 1200));
            }

        } catch (Exception e) {
            // Silently continue
        }
    }

    public void performRandomPause() {
        if (!enableRandomPauses) return;

        int roll = randInt(1, 100);

        if (roll <= 2) {
            int pauseMs = randInt(15000, 40000);
            script.log("Anti-ban: Long AFK pause (~" + (pauseMs / 1000) + "s)");
            sleep(pauseMs);
        } else if (roll <= 8) {
            int pauseMs = randInt(5000, 15000);
            script.log("Anti-ban: Medium pause (~" + (pauseMs / 1000) + "s)");
            sleep(pauseMs);
        } else if (roll <= 20) {
            int pauseMs = randInt(2000, 5000);
            script.log("Anti-ban: Short pause (~" + (pauseMs / 1000) + "s)");
            sleep(pauseMs);
        }
    }

    public void setCameraMovementEnabled(boolean enabled) {
        this.enableCameraMovement = enabled;
    }

    public void setRandomMouseMovementEnabled(boolean enabled) {
        this.enableRandomMouseMovement = enabled;
    }

    public void setRandomTabCheckingEnabled(boolean enabled) {
        this.enableRandomTabChecking = enabled;
    }

    public void setSkillHoveringEnabled(boolean enabled) {
        this.enableSkillHovering = enabled;
    }

    public void setObjectExaminingEnabled(boolean enabled) {
        this.enableObjectExamining = enabled;
    }

    public void setRandomPausesEnabled(boolean enabled) {
        this.enableRandomPauses = enabled;
    }

    public void setMouseSpeedVariationEnabled(boolean enabled) {
        this.enableMouseSpeedVariation = enabled;
    }

    public void setCameraMovementChance(int percent) {
        this.cameraMovementChance = Math.max(0, Math.min(100, percent));
    }

    public void setMouseMovementChance(int percent) {
        this.mouseMovementChance = Math.max(0, Math.min(100, percent));
    }

    public void setTabCheckChance(int percent) {
        this.tabCheckChance = Math.max(0, Math.min(100, percent));
    }

    public void setSkillHoverChance(int percent) {
        this.skillHoverChance = Math.max(0, Math.min(100, percent));
    }

    public void setObjectExamineChance(int percent) {
        this.objectExamineChance = Math.max(0, Math.min(100, percent));
    }

    public void setRandomPauseChance(int percent) {
        this.randomPauseChance = Math.max(0, Math.min(100, percent));
    }

    private boolean shouldPerformAction(int chancePercent, long lastTime, int minTimeBetween) {
        long now = System.currentTimeMillis();

        if (minTimeBetween > 0 && (now - lastTime) < minTimeBetween) {
            return false;
        }

        return randInt(1, 100) <= chancePercent;
    }

    private int randInt(int min, int max) {
        if (max <= min) return min;
        return min + random.nextInt((max - min) + 1);
    }

    private void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
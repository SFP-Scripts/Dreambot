package utilities;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

public final class OrderUnlockStore {

    private static final String FILE_NAME = ".monkdisrober_order_unlocked.txt";

    private OrderUnlockStore() {}

    private static File getStoreFile() {
        String home = System.getProperty("user.home");
        return new File(home, FILE_NAME);
    }

    public static synchronized boolean isUnlocked(String playerName) {
        if (playerName == null || playerName.trim().isEmpty()) return false;
        Set<String> names = readAll();
        return names.contains(playerName.trim().toLowerCase());
    }

    public static synchronized void markUnlocked(String playerName) {
        if (playerName == null || playerName.trim().isEmpty()) return;
        String key = playerName.trim().toLowerCase();

        Set<String> names = readAll();
        if (names.contains(key)) return;

        File f = getStoreFile();
        try {
            if (!f.exists()) {
                // Ensure file can be created
                f.createNewFile();
            }
            try (FileOutputStream fos = new FileOutputStream(f, true);
                 OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
                 BufferedWriter bw = new BufferedWriter(osw)) {
                bw.write(key);
                bw.newLine();
            }
        } catch (IOException ignored) {
            // If writing fails, script still works; it just won't remember.
        }
    }

    private static Set<String> readAll() {
        Set<String> out = new HashSet<>();
        File f = getStoreFile();
        if (!f.exists()) return out;

        try (FileInputStream fis = new FileInputStream(f);
             InputStreamReader isr = new InputStreamReader(fis, StandardCharsets.UTF_8);
             BufferedReader br = new BufferedReader(isr)) {

            String line;
            while ((line = br.readLine()) != null) {
                String s = line.trim().toLowerCase();
                if (!s.isEmpty()) out.add(s);
            }
        } catch (IOException ignored) {
        }
        return out;
    }
}
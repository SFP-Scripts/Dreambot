package utilities;

import main.MonkDisrober;
import org.dreambot.api.utilities.Logger;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.List;

/**
 * GuiHandler with improved layout and mouse speed slider
 */
public class GuiHandler {

    private final MonkDisrober script;
    private boolean guiCompleted = false;
    private final Object lock = new Object();

    private boolean useAutoEnd = false;
    private int itemsBeforeEnd = 0;
    private int walkingSpeed = 50;

    private boolean enableWorldHopping = true;
    private int waitTimeSeconds = 60;

    // Mule settings
    private boolean muleEnabled = false;
    private String muleServerHost = "localhost";
    private int muleServerPort = 43594;
    private String muleAuthToken = "";
    private int muleAfterItems = 500;

    // Anti-ban settings
    private boolean enableCameraMovement = true;
    private boolean enableRandomMouseMovement = true;
    private boolean enableRandomTabChecking = true;
    private boolean enableSkillHovering = true;
    private boolean enableObjectExamining = false;
    private boolean enableRandomPauses = true;
    private boolean enableMouseSpeedVariation = true;

    // Anti-ban frequencies
    private int cameraMovementChance = 15;
    private int mouseMovementChance = 8;
    private int tabCheckChance = 12;
    private int skillHoverChance = 10;
    private int randomPauseChance = 20;
    private int mouseSpeedVariation = 50; // NEW: 0-100%

    private boolean profileAutoLoaded = false;

    public GuiHandler(MonkDisrober script) {
        this.script = script;
    }

    public static void setDefaultProfile(String profileNameOrNumber) {
        try {
            java.io.File argFile = new java.io.File(System.getProperty("user.home"), ".monkdisrober_profile_arg.txt");
            java.io.FileWriter writer = new java.io.FileWriter(argFile);
            writer.write(profileNameOrNumber);
            writer.close();
            Logger.log("Default profile set to: " + profileNameOrNumber);
        } catch (Exception e) {
            Logger.log("Failed to set default profile: " + e.getMessage());
        }
    }

    public static void clearDefaultProfile() {
        try {
            java.io.File argFile = new java.io.File(System.getProperty("user.home"), ".monkdisrober_profile_arg.txt");
            if (argFile.exists()) {
                argFile.delete();
                Logger.log("Default profile cleared");
            }
        } catch (Exception e) {
            Logger.log("Failed to clear default profile: " + e.getMessage());
        }
    }

    public void loadProfileByArgument(String arg) {
        try {
            List<String> availableProfiles = ProfileManager.getAvailableProfiles();

            if (availableProfiles.isEmpty()) {
                Logger.log("No profiles found to load");
                return;
            }

            String profileToLoad = null;

            try {
                int profileIndex = Integer.parseInt(arg) - 1;
                if (profileIndex >= 0 && profileIndex < availableProfiles.size()) {
                    profileToLoad = availableProfiles.get(profileIndex);
                    Logger.log("Loading profile #" + (profileIndex + 1) + ": " + profileToLoad);
                }
            } catch (NumberFormatException e) {
                for (String profileName : availableProfiles) {
                    if (profileName.equalsIgnoreCase(arg)) {
                        profileToLoad = profileName;
                        Logger.log("Loading profile by name: " + profileName);
                        break;
                    }
                }
            }

            if (profileToLoad != null) {
                ProfileManager.Profile profile = ProfileManager.loadProfile(profileToLoad);
                applyProfile(profile);
                profileAutoLoaded = true;
                Logger.log("Profile '" + profileToLoad + "' auto-loaded successfully!");
                Logger.log("  - Auto End: " + useAutoEnd + " (" + itemsBeforeEnd + " items)");
                Logger.log("  - World Hopping: " + enableWorldHopping);
                Logger.log("  - Wait Time: " + waitTimeSeconds + "s");
                Logger.log("  - Camera Movement: " + cameraMovementChance + "%");
                Logger.log("  - Mouse Movement: " + mouseMovementChance + "%");
                Logger.log("  - Random Pauses: " + randomPauseChance + "%");
            }
        } catch (Exception e) {
            Logger.log("Failed to load profile: " + e.getMessage());
        }
    }

    private void applyProfile(ProfileManager.Profile profile) {
        this.useAutoEnd = profile.useAutoEnd;
        this.itemsBeforeEnd = profile.itemsBeforeEnd;
        this.walkingSpeed = profile.walkingSpeed;
        this.enableWorldHopping = profile.enableWorldHopping;
        this.waitTimeSeconds = profile.waitTimeSeconds;

        this.muleEnabled = profile.muleEnabled;
        this.muleServerHost = profile.muleServerHost;
        this.muleServerPort = profile.muleServerPort;
        this.muleAuthToken = profile.muleAuthToken;
        this.muleAfterItems = profile.muleAfterItems;

        this.enableCameraMovement = profile.enableCameraMovement;
        this.enableRandomMouseMovement = profile.enableRandomMouseMovement;
        this.enableRandomTabChecking = profile.enableRandomTabChecking;
        this.enableSkillHovering = profile.enableSkillHovering;
        this.enableObjectExamining = profile.enableObjectExamining;
        this.enableRandomPauses = profile.enableRandomPauses;
        this.enableMouseSpeedVariation = profile.enableMouseSpeedVariation;
        this.cameraMovementChance = profile.cameraMovementChance;
        this.mouseMovementChance = profile.mouseMovementChance;
        this.tabCheckChance = profile.tabCheckChance;
        this.skillHoverChance = profile.skillHoverChance;
        this.randomPauseChance = profile.randomPauseChance;
        this.mouseSpeedVariation = profile.mouseSpeedVariation;
    }

    public void showStartupGui() {
        if (profileAutoLoaded) {
            showQuickStartGui();
        } else {
            showFullGui();
        }
    }

    private void showQuickStartGui() {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Monk Disrober - Quick Start");
            frame.setSize(300, 150);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout(10, 10));

            JLabel label = new JLabel("<html><center>Profile loaded!<br>Click Start to begin</center></html>");
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setFont(new Font("Arial", Font.PLAIN, 14));
            panel.add(label, BorderLayout.CENTER);

            JButton startButton = new JButton("Start Script");
            startButton.setFont(new Font("Arial", Font.BOLD, 14));
            startButton.addActionListener(e -> {
                frame.dispose();
                synchronized (lock) {
                    guiCompleted = true;
                    lock.notify();
                }
            });
            panel.add(startButton, BorderLayout.SOUTH);

            frame.add(panel);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    private void showFullGui() {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Monk Disrober - Configuration");
            frame.setSize(900, 750); // WIDER and SHORTER
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            JPanel panel = new JPanel();
            frame.add(panel);
            placeComponents(panel, frame);

            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    private void placeComponents(JPanel panel, JFrame frame) {
        panel.setLayout(null);

        int leftCol = 20;
        int rightCol = 460;
        int yPos = 15;

        // Title
        JLabel titleLabel = new JLabel("Monk Disrober Configuration");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setBounds(leftCol, yPos, 400, 30);
        panel.add(titleLabel);
        yPos += 45;

        // === LEFT COLUMN ===
        int leftYPos = yPos;

        // Profile Management
        JLabel profileLabel = new JLabel("Profile Management:");
        profileLabel.setFont(new Font("Arial", Font.BOLD, 13));
        profileLabel.setBounds(leftCol, leftYPos, 200, 25);
        panel.add(profileLabel);
        leftYPos += 28;

        JComboBox<String> profileDropdown = new JComboBox<>();
        profileDropdown.setBounds(leftCol, leftYPos, 180, 25);
        refreshProfileDropdown(profileDropdown);
        panel.add(profileDropdown);

        JButton loadButton = new JButton("Load");
        loadButton.setBounds(leftCol + 190, leftYPos, 70, 25);
        panel.add(loadButton);

        JButton saveButton = new JButton("Save");
        saveButton.setBounds(leftCol + 270, leftYPos, 70, 25);
        panel.add(saveButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setBounds(leftCol + 350, leftYPos, 75, 25);
        panel.add(deleteButton);
        leftYPos += 40;

        // Auto-End Settings
        JLabel autoEndLabel = new JLabel("Auto-End Settings:");
        autoEndLabel.setFont(new Font("Arial", Font.BOLD, 13));
        autoEndLabel.setBounds(leftCol, leftYPos, 200, 25);
        panel.add(autoEndLabel);
        leftYPos += 28;

        JCheckBox autoEndCheckBox = new JCheckBox("Enable Auto-End", useAutoEnd);
        autoEndCheckBox.setBounds(leftCol, leftYPos, 150, 25);
        panel.add(autoEndCheckBox);

        JTextField itemsField = new JTextField(String.valueOf(itemsBeforeEnd));
        itemsField.setBounds(leftCol + 160, leftYPos, 80, 25);
        panel.add(itemsField);

        JLabel itemsLabel = new JLabel("items");
        itemsLabel.setBounds(leftCol + 250, leftYPos, 50, 25);
        panel.add(itemsLabel);
        leftYPos += 40;

        // World Hopping
        JLabel worldHopLabel = new JLabel("World Hopping:");
        worldHopLabel.setFont(new Font("Arial", Font.BOLD, 13));
        worldHopLabel.setBounds(leftCol, leftYPos, 200, 25);
        panel.add(worldHopLabel);
        leftYPos += 28;

        JCheckBox worldHopCheckBox = new JCheckBox("Enable World Hopping", enableWorldHopping);
        worldHopCheckBox.setBounds(leftCol, leftYPos, 200, 25);
        panel.add(worldHopCheckBox);
        leftYPos += 30;

        JLabel waitLabel = new JLabel("Wait before hopping:");
        waitLabel.setBounds(leftCol, leftYPos, 150, 25);
        panel.add(waitLabel);

        JTextField waitTimeField = new JTextField(String.valueOf(waitTimeSeconds));
        waitTimeField.setBounds(leftCol + 160, leftYPos, 80, 25);
        panel.add(waitTimeField);

        JLabel secondsLabel = new JLabel("seconds");
        secondsLabel.setBounds(leftCol + 250, leftYPos, 60, 25);
        panel.add(secondsLabel);
        leftYPos += 45;

        // Mule Settings
        JLabel muleLabel = new JLabel("Mule Settings:");
        muleLabel.setFont(new Font("Arial", Font.BOLD, 13));
        muleLabel.setBounds(leftCol, leftYPos, 200, 25);
        panel.add(muleLabel);
        leftYPos += 28;

        JCheckBox muleCheckBox = new JCheckBox("Enable Muling", muleEnabled);
        muleCheckBox.setBounds(leftCol, leftYPos, 150, 25);
        panel.add(muleCheckBox);
        leftYPos += 30;

        JLabel muleServerLabel = new JLabel("Server:");
        muleServerLabel.setBounds(leftCol, leftYPos, 60, 25);
        panel.add(muleServerLabel);

        JTextField muleServerField = new JTextField(muleServerHost);
        muleServerField.setBounds(leftCol + 70, leftYPos, 140, 25);
        panel.add(muleServerField);

        JLabel mulePortLabel = new JLabel("Port:");
        mulePortLabel.setBounds(leftCol + 220, leftYPos, 40, 25);
        panel.add(mulePortLabel);

        JTextField mulePortField = new JTextField(String.valueOf(muleServerPort));
        mulePortField.setBounds(leftCol + 265, leftYPos, 70, 25);
        panel.add(mulePortField);
        leftYPos += 30;

        JLabel muleTokenLabel = new JLabel("Token:");
        muleTokenLabel.setBounds(leftCol, leftYPos, 60, 25);
        panel.add(muleTokenLabel);

        JTextField muleTokenField = new JTextField(muleAuthToken);
        muleTokenField.setBounds(leftCol + 70, leftYPos, 265, 25);
        panel.add(muleTokenField);
        leftYPos += 30;

        JLabel muleAfterLabel = new JLabel("Mule after:");
        muleAfterLabel.setBounds(leftCol, leftYPos, 80, 25);
        panel.add(muleAfterLabel);

        JTextField muleAfterField = new JTextField(String.valueOf(muleAfterItems));
        muleAfterField.setBounds(leftCol + 85, leftYPos, 80, 25);
        panel.add(muleAfterField);

        JLabel itemsLabel2 = new JLabel("items");
        itemsLabel2.setBounds(leftCol + 175, leftYPos, 50, 25);
        panel.add(itemsLabel2);

        // === RIGHT COLUMN ===
        int rightYPos = yPos;

        // Anti-Ban Settings
        JLabel antiBanLabel = new JLabel("Anti-Ban Settings:");
        antiBanLabel.setFont(new Font("Arial", Font.BOLD, 13));
        antiBanLabel.setBounds(rightCol, rightYPos, 200, 25);
        panel.add(antiBanLabel);
        rightYPos += 35;

        JCheckBox[] antiBanCheckBoxes = new JCheckBox[7];
        JSlider[] antiBanSliders = new JSlider[6]; // Now 6 sliders (added mouse speed)
        JLabel[] sliderLabels = new JLabel[6];

        // Camera Movement
        antiBanCheckBoxes[0] = new JCheckBox("Camera Movement", enableCameraMovement);
        antiBanCheckBoxes[0].setBounds(rightCol, rightYPos, 180, 20);
        panel.add(antiBanCheckBoxes[0]);

        sliderLabels[0] = new JLabel(cameraMovementChance + "%");
        sliderLabels[0].setBounds(rightCol + 185, rightYPos, 50, 20);
        panel.add(sliderLabels[0]);

        antiBanSliders[0] = new JSlider(0, 100, cameraMovementChance);
        antiBanSliders[0].setBounds(rightCol + 235, rightYPos, 180, 20);
        antiBanSliders[0].addChangeListener(e -> sliderLabels[0].setText(antiBanSliders[0].getValue() + "%"));
        panel.add(antiBanSliders[0]);
        rightYPos += 30;

        // Random Mouse Movement
        antiBanCheckBoxes[1] = new JCheckBox("Mouse Movement", enableRandomMouseMovement);
        antiBanCheckBoxes[1].setBounds(rightCol, rightYPos, 180, 20);
        panel.add(antiBanCheckBoxes[1]);

        sliderLabels[1] = new JLabel(mouseMovementChance + "%");
        sliderLabels[1].setBounds(rightCol + 185, rightYPos, 50, 20);
        panel.add(sliderLabels[1]);

        antiBanSliders[1] = new JSlider(0, 100, mouseMovementChance);
        antiBanSliders[1].setBounds(rightCol + 235, rightYPos, 180, 20);
        antiBanSliders[1].addChangeListener(e -> sliderLabels[1].setText(antiBanSliders[1].getValue() + "%"));
        panel.add(antiBanSliders[1]);
        rightYPos += 30;

        // Random Tab Checking
        antiBanCheckBoxes[2] = new JCheckBox("Tab Checking", enableRandomTabChecking);
        antiBanCheckBoxes[2].setBounds(rightCol, rightYPos, 180, 20);
        panel.add(antiBanCheckBoxes[2]);

        sliderLabels[2] = new JLabel(tabCheckChance + "%");
        sliderLabels[2].setBounds(rightCol + 185, rightYPos, 50, 20);
        panel.add(sliderLabels[2]);

        antiBanSliders[2] = new JSlider(0, 100, tabCheckChance);
        antiBanSliders[2].setBounds(rightCol + 235, rightYPos, 180, 20);
        antiBanSliders[2].addChangeListener(e -> sliderLabels[2].setText(antiBanSliders[2].getValue() + "%"));
        panel.add(antiBanSliders[2]);
        rightYPos += 30;

        // Skill Hovering
        antiBanCheckBoxes[3] = new JCheckBox("Skill Hovering", enableSkillHovering);
        antiBanCheckBoxes[3].setBounds(rightCol, rightYPos, 180, 20);
        panel.add(antiBanCheckBoxes[3]);

        sliderLabels[3] = new JLabel(skillHoverChance + "%");
        sliderLabels[3].setBounds(rightCol + 185, rightYPos, 50, 20);
        panel.add(sliderLabels[3]);

        antiBanSliders[3] = new JSlider(0, 100, skillHoverChance);
        antiBanSliders[3].setBounds(rightCol + 235, rightYPos, 180, 20);
        antiBanSliders[3].addChangeListener(e -> sliderLabels[3].setText(antiBanSliders[3].getValue() + "%"));
        panel.add(antiBanSliders[3]);
        rightYPos += 30;

        // Random Pauses
        antiBanCheckBoxes[5] = new JCheckBox("Random Pauses", enableRandomPauses);
        antiBanCheckBoxes[5].setBounds(rightCol, rightYPos, 180, 20);
        panel.add(antiBanCheckBoxes[5]);

        sliderLabels[4] = new JLabel(randomPauseChance + "%");
        sliderLabels[4].setBounds(rightCol + 185, rightYPos, 50, 20);
        panel.add(sliderLabels[4]);

        antiBanSliders[4] = new JSlider(0, 100, randomPauseChance);
        antiBanSliders[4].setBounds(rightCol + 235, rightYPos, 180, 20);
        antiBanSliders[4].addChangeListener(e -> sliderLabels[4].setText(antiBanSliders[4].getValue() + "%"));
        panel.add(antiBanSliders[4]);
        rightYPos += 30;

        // Mouse Speed Variation - NOW WITH SLIDER
        antiBanCheckBoxes[6] = new JCheckBox("Mouse Speed Variation", enableMouseSpeedVariation);
        antiBanCheckBoxes[6].setBounds(rightCol, rightYPos, 180, 20);
        panel.add(antiBanCheckBoxes[6]);

        sliderLabels[5] = new JLabel(mouseSpeedVariation + "%");
        sliderLabels[5].setBounds(rightCol + 185, rightYPos, 50, 20);
        panel.add(sliderLabels[5]);

        antiBanSliders[5] = new JSlider(0, 100, mouseSpeedVariation);
        antiBanSliders[5].setBounds(rightCol + 235, rightYPos, 180, 20);
        antiBanSliders[5].addChangeListener(e -> sliderLabels[5].setText(antiBanSliders[5].getValue() + "%"));
        panel.add(antiBanSliders[5]);
        rightYPos += 30;

        // Object Examining (just checkbox, no slider)
        antiBanCheckBoxes[4] = new JCheckBox("Object Examining", enableObjectExamining);
        antiBanCheckBoxes[4].setBounds(rightCol, rightYPos, 250, 20);
        panel.add(antiBanCheckBoxes[4]);

        // Start Button (centered at bottom)
        JButton startButton = new JButton("Start Script");
        startButton.setBounds(375, 670, 150, 40);
        startButton.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(startButton);

        // Button Actions
        loadButton.addActionListener(e -> loadProfile(profileDropdown, autoEndCheckBox,
                itemsField, worldHopCheckBox, waitTimeField,
                muleCheckBox, muleServerField, mulePortField, muleTokenField, muleAfterField,
                antiBanCheckBoxes, antiBanSliders, frame));

        saveButton.addActionListener(e -> saveProfile(profileDropdown, autoEndCheckBox,
                itemsField, worldHopCheckBox, waitTimeField,
                muleCheckBox, muleServerField, mulePortField, muleTokenField, muleAfterField,
                antiBanCheckBoxes, antiBanSliders, frame));

        deleteButton.addActionListener(e -> deleteProfile(profileDropdown, frame));

        startButton.addActionListener(e -> {
            useAutoEnd = autoEndCheckBox.isSelected();
            try {
                itemsBeforeEnd = Integer.parseInt(itemsField.getText());
            } catch (NumberFormatException ex) {
                itemsBeforeEnd = 100;
            }

            enableWorldHopping = worldHopCheckBox.isSelected();
            try {
                waitTimeSeconds = Integer.parseInt(waitTimeField.getText());
            } catch (NumberFormatException ex) {
                waitTimeSeconds = 60;
            }

            muleEnabled = muleCheckBox.isSelected();
            muleServerHost = muleServerField.getText();
            try {
                muleServerPort = Integer.parseInt(mulePortField.getText());
            } catch (NumberFormatException ex) {
                muleServerPort = 43594;
            }
            muleAuthToken = muleTokenField.getText();
            try {
                muleAfterItems = Integer.parseInt(muleAfterField.getText());
            } catch (NumberFormatException ex) {
                muleAfterItems = 500;
            }

            enableCameraMovement = antiBanCheckBoxes[0].isSelected();
            enableRandomMouseMovement = antiBanCheckBoxes[1].isSelected();
            enableRandomTabChecking = antiBanCheckBoxes[2].isSelected();
            enableSkillHovering = antiBanCheckBoxes[3].isSelected();
            enableObjectExamining = antiBanCheckBoxes[4].isSelected();
            enableRandomPauses = antiBanCheckBoxes[5].isSelected();
            enableMouseSpeedVariation = antiBanCheckBoxes[6].isSelected();

            cameraMovementChance = antiBanSliders[0].getValue();
            mouseMovementChance = antiBanSliders[1].getValue();
            tabCheckChance = antiBanSliders[2].getValue();
            skillHoverChance = antiBanSliders[3].getValue();
            randomPauseChance = antiBanSliders[4].getValue();
            mouseSpeedVariation = antiBanSliders[5].getValue();

            frame.dispose();
            synchronized (lock) {
                guiCompleted = true;
                lock.notify();
            }
        });
    }

    private void refreshProfileDropdown(JComboBox<String> dropdown) {
        dropdown.removeAllItems();
        List<String> profiles = ProfileManager.getAvailableProfiles();
        for (String profile : profiles) {
            dropdown.addItem(profile);
        }
    }

    private void loadProfile(JComboBox<String> dropdown, JCheckBox autoEndCB,
                             JTextField itemsField, JCheckBox worldHopCB, JTextField waitField,
                             JCheckBox muleCB, JTextField muleServerField, JTextField mulePortField,
                             JTextField muleTokenField, JTextField muleAfterField,
                             JCheckBox[] antiBanCBs, JSlider[] antiBanSliders, JFrame frame) {
        String selectedProfile = (String) dropdown.getSelectedItem();
        if (selectedProfile == null || selectedProfile.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please select a profile to load", "No Profile Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            ProfileManager.Profile profile = ProfileManager.loadProfile(selectedProfile);
            autoEndCB.setSelected(profile.useAutoEnd);
            itemsField.setText(String.valueOf(profile.itemsBeforeEnd));
            worldHopCB.setSelected(profile.enableWorldHopping);
            waitField.setText(String.valueOf(profile.waitTimeSeconds));

            muleCB.setSelected(profile.muleEnabled);
            muleServerField.setText(profile.muleServerHost);
            mulePortField.setText(String.valueOf(profile.muleServerPort));
            muleTokenField.setText(profile.muleAuthToken);
            muleAfterField.setText(String.valueOf(profile.muleAfterItems));

            antiBanCBs[0].setSelected(profile.enableCameraMovement);
            antiBanCBs[1].setSelected(profile.enableRandomMouseMovement);
            antiBanCBs[2].setSelected(profile.enableRandomTabChecking);
            antiBanCBs[3].setSelected(profile.enableSkillHovering);
            antiBanCBs[4].setSelected(profile.enableObjectExamining);
            antiBanCBs[5].setSelected(profile.enableRandomPauses);
            antiBanCBs[6].setSelected(profile.enableMouseSpeedVariation);

            antiBanSliders[0].setValue(profile.cameraMovementChance);
            antiBanSliders[1].setValue(profile.mouseMovementChance);
            antiBanSliders[2].setValue(profile.tabCheckChance);
            antiBanSliders[3].setValue(profile.skillHoverChance);
            antiBanSliders[4].setValue(profile.randomPauseChance);
            antiBanSliders[5].setValue(profile.mouseSpeedVariation);

            JOptionPane.showMessageDialog(frame, "Profile '" + selectedProfile + "' loaded successfully!", "Profile Loaded", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Failed to load profile: " + ex.getMessage(), "Load Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveProfile(JComboBox<String> dropdown, JCheckBox autoEndCB,
                             JTextField itemsField, JCheckBox worldHopCB, JTextField waitField,
                             JCheckBox muleCB, JTextField muleServerField, JTextField mulePortField,
                             JTextField muleTokenField, JTextField muleAfterField,
                             JCheckBox[] antiBanCBs, JSlider[] antiBanSliders, JFrame frame) {
        String profileName = JOptionPane.showInputDialog(frame, "Enter profile name:", "Save Profile", JOptionPane.PLAIN_MESSAGE);
        if (profileName == null || profileName.trim().isEmpty()) {
            return;
        }

        try {
            ProfileManager.Profile profile = new ProfileManager.Profile();
            profile.useAutoEnd = autoEndCB.isSelected();
            profile.itemsBeforeEnd = Integer.parseInt(itemsField.getText());
            profile.enableWorldHopping = worldHopCB.isSelected();
            profile.waitTimeSeconds = Integer.parseInt(waitField.getText());

            profile.muleEnabled = muleCB.isSelected();
            profile.muleServerHost = muleServerField.getText();
            profile.muleServerPort = Integer.parseInt(mulePortField.getText());
            profile.muleAuthToken = muleTokenField.getText();
            profile.muleAfterItems = Integer.parseInt(muleAfterField.getText());

            profile.enableCameraMovement = antiBanCBs[0].isSelected();
            profile.enableRandomMouseMovement = antiBanCBs[1].isSelected();
            profile.enableRandomTabChecking = antiBanCBs[2].isSelected();
            profile.enableSkillHovering = antiBanCBs[3].isSelected();
            profile.enableObjectExamining = antiBanCBs[4].isSelected();
            profile.enableRandomPauses = antiBanCBs[5].isSelected();
            profile.enableMouseSpeedVariation = antiBanCBs[6].isSelected();

            profile.cameraMovementChance = antiBanSliders[0].getValue();
            profile.mouseMovementChance = antiBanSliders[1].getValue();
            profile.tabCheckChance = antiBanSliders[2].getValue();
            profile.skillHoverChance = antiBanSliders[3].getValue();
            profile.randomPauseChance = antiBanSliders[4].getValue();
            profile.mouseSpeedVariation = antiBanSliders[5].getValue();

            ProfileManager.saveProfile(profileName, profile);
            refreshProfileDropdown(dropdown);
            JOptionPane.showMessageDialog(frame, "Profile '" + profileName + "' saved successfully!", "Profile Saved", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Failed to save profile: " + ex.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteProfile(JComboBox<String> dropdown, JFrame frame) {
        String selectedProfile = (String) dropdown.getSelectedItem();
        if (selectedProfile == null || selectedProfile.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please select a profile to delete", "No Profile Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(frame, "Delete profile '" + selectedProfile + "'?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                ProfileManager.deleteProfile(selectedProfile);
                refreshProfileDropdown(dropdown);
                JOptionPane.showMessageDialog(frame, "Profile '" + selectedProfile + "' deleted", "Profile Deleted", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Failed to delete profile: " + ex.getMessage(), "Delete Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void waitForGuiCompletion() {
        synchronized (lock) {
            while (!guiCompleted) {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    // Getters
    public boolean isGuiCompleted() { return guiCompleted; }
    public boolean useAutoEnd() { return useAutoEnd; }
    public int getItemsBeforeEnd() { return itemsBeforeEnd; }
    public int getWalkingSpeed() { return walkingSpeed; }
    public boolean isWorldHoppingEnabled() { return enableWorldHopping; }
    public int getWaitTimeSeconds() { return waitTimeSeconds; }
    public boolean enableCameraMovement() { return enableCameraMovement; }
    public boolean enableRandomMouseMovement() { return enableRandomMouseMovement; }
    public boolean enableRandomTabChecking() { return enableRandomTabChecking; }
    public boolean enableSkillHovering() { return enableSkillHovering; }
    public boolean enableObjectExamining() { return enableObjectExamining; }
    public boolean enableRandomPauses() { return enableRandomPauses; }
    public boolean enableMouseSpeedVariation() { return enableMouseSpeedVariation; }
    public int getCameraMovementChance() { return cameraMovementChance; }
    public int getMouseMovementChance() { return mouseMovementChance; }
    public int getTabCheckChance() { return tabCheckChance; }
    public int getSkillHoverChance() { return skillHoverChance; }
    public int getRandomPauseChance() { return randomPauseChance; }
    public int getMouseSpeedVariation() { return mouseSpeedVariation; }

    // Mule getters
    public boolean isMuleEnabled() { return muleEnabled; }
    public String getMuleServerHost() { return muleServerHost; }
    public int getMuleServerPort() { return muleServerPort; }
    public String getMuleAuthToken() { return muleAuthToken; }
    public int getMuleAfterItems() { return muleAfterItems; }
}
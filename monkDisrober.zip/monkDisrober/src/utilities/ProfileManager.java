package utilities;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class ProfileManager {

    private static final String PROFILES_DIR = "monk_disrober_profiles";
    private static final String PROFILES_FOLDER = System.getProperty("user.home") + File.separator + PROFILES_DIR;

    public static class Profile {
        // fishMouse removed - no longer used
        public boolean useAutoEnd = false;
        public int itemsBeforeEnd = 100;
        public int walkingSpeed = 50;

        // World hopping settings
        public boolean enableWorldHopping = true;
        public int waitTimeSeconds = 60;

        // Mule settings
        public boolean muleEnabled = false;
        public String muleServerHost = "localhost";
        public int muleServerPort = 43594;
        public String muleAuthToken = "";
        public int muleAfterItems = 500;

        public boolean enableCameraMovement = true;
        public boolean enableRandomMouseMovement = true;
        public boolean enableRandomTabChecking = true;
        public boolean enableSkillHovering = true;
        public boolean enableObjectExamining = false;
        public boolean enableRandomPauses = true;
        public boolean enableMouseSpeedVariation = true;

        public int cameraMovementChance = 15;
        public int mouseMovementChance = 8;
        public int tabCheckChance = 12;
        public int skillHoverChance = 10;
        public int randomPauseChance = 20;
        public int mouseSpeedVariation = 50; // NEW: 0-100%
    }

    static {
        // Ensure profiles directory exists
        File dir = new File(PROFILES_FOLDER);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    public static void saveProfile(String profileName, Profile profile) throws IOException {
        if (profileName == null || profileName.trim().isEmpty()) {
            throw new IOException("Profile name cannot be empty");
        }

        String fileName = sanitizeFileName(profileName) + ".profile";
        File file = new File(PROFILES_FOLDER, fileName);

        Properties props = new Properties();

        // fishMouse removed

        // Auto-end settings
        props.setProperty("useAutoEnd", String.valueOf(profile.useAutoEnd));
        props.setProperty("itemsBeforeEnd", String.valueOf(profile.itemsBeforeEnd));

        // Performance settings
        props.setProperty("walkingSpeed", String.valueOf(profile.walkingSpeed));

        // World hopping settings
        props.setProperty("enableWorldHopping", String.valueOf(profile.enableWorldHopping));
        props.setProperty("waitTimeSeconds", String.valueOf(profile.waitTimeSeconds));

        // Mule settings
        props.setProperty("muleEnabled", String.valueOf(profile.muleEnabled));
        props.setProperty("muleServerHost", profile.muleServerHost);
        props.setProperty("muleServerPort", String.valueOf(profile.muleServerPort));
        props.setProperty("muleAuthToken", profile.muleAuthToken);
        props.setProperty("muleAfterItems", String.valueOf(profile.muleAfterItems));

        // Anti-ban toggles
        props.setProperty("enableCameraMovement", String.valueOf(profile.enableCameraMovement));
        props.setProperty("enableRandomMouseMovement", String.valueOf(profile.enableRandomMouseMovement));
        props.setProperty("enableRandomTabChecking", String.valueOf(profile.enableRandomTabChecking));
        props.setProperty("enableSkillHovering", String.valueOf(profile.enableSkillHovering));
        props.setProperty("enableObjectExamining", String.valueOf(profile.enableObjectExamining));
        props.setProperty("enableRandomPauses", String.valueOf(profile.enableRandomPauses));
        props.setProperty("enableMouseSpeedVariation", String.valueOf(profile.enableMouseSpeedVariation));

        // Anti-ban frequencies
        props.setProperty("cameraMovementChance", String.valueOf(profile.cameraMovementChance));
        props.setProperty("mouseMovementChance", String.valueOf(profile.mouseMovementChance));
        props.setProperty("tabCheckChance", String.valueOf(profile.tabCheckChance));
        props.setProperty("skillHoverChance", String.valueOf(profile.skillHoverChance));
        props.setProperty("randomPauseChance", String.valueOf(profile.randomPauseChance));
        props.setProperty("mouseSpeedVariation", String.valueOf(profile.mouseSpeedVariation));

        try (FileOutputStream fos = new FileOutputStream(file)) {
            props.store(fos, "Monk Disrober Profile: " + profileName);
        }
    }

    public static Profile loadProfile(String profileName) throws IOException {
        if (profileName == null || profileName.trim().isEmpty()) {
            throw new IOException("Profile name cannot be empty");
        }

        String fileName = sanitizeFileName(profileName) + ".profile";
        File file = new File(PROFILES_FOLDER, fileName);

        if (!file.exists()) {
            throw new IOException("Profile not found: " + profileName);
        }

        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(file)) {
            props.load(fis);
        }

        Profile profile = new Profile();

        // fishMouse removed (backward compatibility - ignore if present)

        // Auto-end settings
        profile.useAutoEnd = Boolean.parseBoolean(props.getProperty("useAutoEnd", "false"));
        profile.itemsBeforeEnd = Integer.parseInt(props.getProperty("itemsBeforeEnd", "100"));

        // Performance settings
        profile.walkingSpeed = Integer.parseInt(props.getProperty("walkingSpeed", "50"));

        // World hopping settings
        profile.enableWorldHopping = Boolean.parseBoolean(props.getProperty("enableWorldHopping", "true"));
        profile.waitTimeSeconds = Integer.parseInt(props.getProperty("waitTimeSeconds", "60"));

        // Mule settings
        profile.muleEnabled = Boolean.parseBoolean(props.getProperty("muleEnabled", "false"));
        profile.muleServerHost = props.getProperty("muleServerHost", "localhost");
        profile.muleServerPort = Integer.parseInt(props.getProperty("muleServerPort", "43594"));
        profile.muleAuthToken = props.getProperty("muleAuthToken", "");
        profile.muleAfterItems = Integer.parseInt(props.getProperty("muleAfterItems", "500"));

        // Anti-ban toggles
        profile.enableCameraMovement = Boolean.parseBoolean(props.getProperty("enableCameraMovement", "true"));
        profile.enableRandomMouseMovement = Boolean.parseBoolean(props.getProperty("enableRandomMouseMovement", "true"));
        profile.enableRandomTabChecking = Boolean.parseBoolean(props.getProperty("enableRandomTabChecking", "true"));
        profile.enableSkillHovering = Boolean.parseBoolean(props.getProperty("enableSkillHovering", "true"));
        profile.enableObjectExamining = Boolean.parseBoolean(props.getProperty("enableObjectExamining", "false"));
        profile.enableRandomPauses = Boolean.parseBoolean(props.getProperty("enableRandomPauses", "true"));
        profile.enableMouseSpeedVariation = Boolean.parseBoolean(props.getProperty("enableMouseSpeedVariation", "true"));

        // Anti-ban frequencies
        profile.cameraMovementChance = Integer.parseInt(props.getProperty("cameraMovementChance", "15"));
        profile.mouseMovementChance = Integer.parseInt(props.getProperty("mouseMovementChance", "8"));
        profile.tabCheckChance = Integer.parseInt(props.getProperty("tabCheckChance", "12"));
        profile.skillHoverChance = Integer.parseInt(props.getProperty("skillHoverChance", "10"));
        profile.randomPauseChance = Integer.parseInt(props.getProperty("randomPauseChance", "20"));
        profile.mouseSpeedVariation = Integer.parseInt(props.getProperty("mouseSpeedVariation", "50"));

        return profile;
    }

    public static List<String> getAvailableProfiles() {
        File dir = new File(PROFILES_FOLDER);
        List<String> profiles = new ArrayList<>();

        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles((d, name) -> name.endsWith(".profile"));
            if (files != null) {
                for (File file : files) {
                    String name = file.getName().replace(".profile", "");
                    profiles.add(name);
                }
            }
        }

        Collections.sort(profiles);
        return profiles;
    }

    public static void deleteProfile(String profileName) throws IOException {
        if (profileName == null || profileName.trim().isEmpty()) {
            throw new IOException("Profile name cannot be empty");
        }

        String fileName = sanitizeFileName(profileName) + ".profile";
        File file = new File(PROFILES_FOLDER, fileName);

        if (!file.exists()) {
            throw new IOException("Profile not found: " + profileName);
        }

        if (!file.delete()) {
            throw new IOException("Failed to delete profile: " + profileName);
        }
    }

    private static String sanitizeFileName(String name) {
        // Remove invalid characters for file names
        return name.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
}
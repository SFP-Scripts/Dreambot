package utilities;

import main.MonkDisrober;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.world.Worlds;
import org.dreambot.api.methods.worldhopper.WorldHopper;
import org.dreambot.api.utilities.Sleep;
import utilities.StateHandler;

public class WorldHopperHandler {

    private final MonkDisrober script;
    private int currentWorldIndex = 0;

    // Free-to-play worlds (safe list)
    private static final int[] F2P_WORLDS = {
            301, 308, 316, 326, 335, 379, 380, 382, 383, 384,
            397, 398, 399, 417, 418, 430, 431, 433, 434, 435,
            436, 437, 451, 452, 453, 454, 455, 456, 469,
            483, 497, 498, 499, 537, 552, 553, 554, 555
    };

    public WorldHopperHandler(MonkDisrober script) {
        this.script = script;
    }

    /** Call once on script start */
    public void initializeWorldIndex() {
        int currentWorld = Worlds.getCurrentWorld();
        for (int i = 0; i < F2P_WORLDS.length; i++) {
            if (F2P_WORLDS[i] == currentWorld) {
                currentWorldIndex = i;
                return;
            }
        }
        currentWorldIndex = 0;
    }

    /** STATE: HOP_WORLDS */
    public int hopWorlds() {

        // Safety: do not hop while in combat
        if (Players.getLocal() != null && Players.getLocal().isInCombat()) {
            script.log("In combat - delaying world hop.");
            return script.getRandomSleep(800, 1200);
        }

        // Close interfaces that block hopping
        if (Bank.isOpen()) {
            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 2500);
        }

        if (Dialogues.inDialogue()) {
            if (Dialogues.canContinue()) {
                Dialogues.continueDialogue();
            }
            return script.getRandomSleep(400, 700);
        }

        int currentWorld = Worlds.getCurrentWorld();

        // Select next world
        int nextWorld = currentWorld;
        int attempts = 0;

        while (nextWorld == currentWorld && attempts < 10) {
            nextWorld = F2P_WORLDS[currentWorldIndex];
            currentWorldIndex = (currentWorldIndex + 1) % F2P_WORLDS.length;
            attempts++;
        }

        // Make it final for lambda use
        final int targetWorld = nextWorld;

        script.log("Hopping worlds: " + currentWorld + " -> " + targetWorld);

        // Correct DreamBot method for logged-in hopping
        boolean initiated = WorldHopper.hopWorld(targetWorld);
        if (!initiated) {
            script.log("World hop initiation failed (hopWorld returned false).");
            return script.getRandomSleep(900, 1400);
        }

        // Wait until the world actually changes
        boolean success = Sleep.sleepUntil(
                () -> Worlds.getCurrentWorld() == targetWorld,
                15000
        );

        if (!success) {
            script.log("World hop timed out. Still on: " + Worlds.getCurrentWorld());
            return script.getRandomSleep(1000, 1600);
        }

        // Allow time for login + region load
        sleep(script.getRandomSleep(1800, 3000));

        // Resume robe stealing flow
        script.getStateHandler().setCurrentState(StateHandler.State.OPEN_DOOR);
        return script.getRandomSleep(600, 900);
    }

    private void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
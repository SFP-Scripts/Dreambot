package mule.models;

import java.util.HashMap;
import java.util.Map;

/**
 * Data model for trade requests sent to mule server
 */
public class TradeRequest {

    private String playerName;
    private String tradeType; // "DEPOSIT" or "WITHDRAWAL"
    private Map<String, Integer> items;
    private int gpAmount;
    private int world;
    private String location;
    private long timestamp;

    public TradeRequest() {
        this.items = new HashMap<>();
        this.gpAmount = 0;
        this.timestamp = System.currentTimeMillis();
    }

    // Getters and Setters

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public Map<String, Integer> getItems() {
        return items;
    }

    public void setItems(Map<String, Integer> items) {
        this.items = items;
    }

    public void addItem(String itemName, int quantity) {
        this.items.put(itemName, quantity);
    }

    public int getGpAmount() {
        return gpAmount;
    }

    public void setGpAmount(int gpAmount) {
        this.gpAmount = gpAmount;
    }

    public int getWorld() {
        return world;
    }

    public void setWorld(int world) {
        this.world = world;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "TradeRequest{" +
                "playerName='" + playerName + '\'' +
                ", tradeType='" + tradeType + '\'' +
                ", items=" + items +
                ", gpAmount=" + gpAmount +
                ", world=" + world +
                ", location='" + location + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}
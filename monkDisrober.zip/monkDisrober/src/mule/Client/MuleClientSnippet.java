package mule.client;

import mule.models.TradeRequest;
import mule.models.TradeResponse;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.trade.Trade;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.world.Worlds;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Player;
import org.dreambot.api.wrappers.items.Item;

import java.util.HashMap;
import java.util.Map;

/**
 * Easy-to-use code snippet for adding mule functionality to your scripts
 *
 * USAGE:
 * 1. Add this class to your script project
 * 2. In your main script, declare: private MuleClientSnippet muleSnippet;
 * 3. In onStart(), initialize: muleSnippet = new MuleClientSnippet(this, "localhost", 43594, "your-token");
 * 4. Call muleSnippet.depositAllItems() when you want to mule items
 *
 * EXAMPLE:
 * if (Inventory.isFull() || Inventory.count("Logs") > 1000) {
 *     muleSnippet.depositAllItems();
 * }
 */
public class MuleClientSnippet {

    private final AbstractScript script;
    private final MuleClient muleClient;
    private final String muleName;
    private final Tile muleLocation;

    // Configurable settings
    private boolean autoWalkToMule = true;
    private int maxWalkDistance = 50;
    private int tradeTimeout = 30000;

    /**
     * Constructor
     * @param script Your main script instance
     * @param serverHost Mule server IP (use "localhost" if on same machine)
     * @param serverPort Mule server port (default: 43594)
     * @param authToken Authentication token (must match mule config)
     */
    public MuleClientSnippet(AbstractScript script, String serverHost, int serverPort, String authToken) {
        this.script = script;
        this.muleClient = new MuleClient(serverHost, serverPort, authToken);
        this.muleName = "YourMuleName"; // TODO: Set your mule's RSN
        this.muleLocation = new Tile(3165, 3485, 0); // TODO: Set mule location (default: GE)
    }

    /**
     * Deposit all items to the mule
     * @return true if successful
     */
    public boolean depositAllItems() {
        return depositAllItems(0);
    }

    /**
     * Deposit all items and GP to the mule
     * @param gpAmount Amount of GP to deposit (0 for all)
     * @return true if successful
     */
    public boolean depositAllItems(int gpAmount) {
        try {
            Logger.log("Starting mule deposit process...");

            // Get current inventory items
            Map<String, Integer> items = getInventoryItems();

            if (items.isEmpty() && gpAmount == 0) {
                Logger.log("Inventory is empty, nothing to deposit");
                return false;
            }

            // If GP amount is 0, deposit all GP
            if (gpAmount == 0 && Inventory.contains("Coins")) {
                gpAmount = Inventory.count("Coins");
            }

            // Get local player name
            Player localPlayer = Players.getLocal();
            if (localPlayer == null) {
                Logger.log("Cannot get local player name");
                return false;
            }

            // Create trade request
            TradeRequest request = MuleClient.createDepositRequest(
                    localPlayer.getName(),
                    items,
                    gpAmount
            );

            // Set current world and location
            request.setWorld(Worlds.getCurrentWorld());
            request.setLocation("GE"); // Adjust as needed

            // Send request to mule server
            Logger.log("Contacting mule server...");
            TradeResponse response = muleClient.requestTrade(request);

            if (!response.isSuccess()) {
                Logger.log("Mule server returned error: " + response.getMessage());
                return false;
            }

            Logger.log("Mule accepted request, preparing for trade...");

            // Walk to mule if configured
            if (autoWalkToMule) {
                if (!walkToMule()) {
                    Logger.log("Failed to walk to mule");
                    return false;
                }
            }

            // Wait for mule to be nearby
            if (!waitForMule()) {
                Logger.log("Mule not found nearby");
                return false;
            }

            // Execute the trade
            if (performTrade()) {
                Logger.log("Successfully deposited items to mule!");
                return true;
            } else {
                Logger.log("Trade failed");
                return false;
            }

        } catch (Exception e) {
            Logger.error("Error during mule deposit: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Withdraw specific items from the mule
     * @param items Map of item names to quantities
     * @param gpAmount GP to withdraw
     * @return true if successful
     */
    public boolean withdrawItems(Map<String, Integer> items, int gpAmount) {
        try {
            Logger.log("Starting mule withdrawal process...");

            // Get local player name
            Player localPlayer = Players.getLocal();
            if (localPlayer == null) {
                Logger.log("Cannot get local player name");
                return false;
            }

            // Create withdrawal request
            TradeRequest request = MuleClient.createWithdrawalRequest(
                    localPlayer.getName(),
                    items,
                    gpAmount
            );

            request.setWorld(Worlds.getCurrentWorld());
            request.setLocation("GE");

            // Send request
            TradeResponse response = muleClient.requestTrade(request);

            if (!response.isSuccess()) {
                Logger.log("Mule server returned error: " + response.getMessage());
                return false;
            }

            // Walk to mule
            if (autoWalkToMule && !walkToMule()) {
                return false;
            }

            // Wait for mule
            if (!waitForMule()) {
                return false;
            }

            // Accept the trade
            if (waitForTrade()) {
                Logger.log("Successfully withdrew items from mule!");
                return true;
            }

            return false;

        } catch (Exception e) {
            Logger.error("Error during mule withdrawal: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Get all items in inventory as a map
     */
    private Map<String, Integer> getInventoryItems() {
        Map<String, Integer> items = new HashMap<>();

        for (Item item : Inventory.all()) {
            if (item != null && item.getName() != null && !item.getName().equals("Coins")) {
                items.put(item.getName(), item.getAmount());
            }
        }

        return items;
    }

    /**
     * Walk to mule location
     */
    private boolean walkToMule() {
        Logger.log("Walking to mule location...");

        Player localPlayer = Players.getLocal();
        if (localPlayer == null) {
            Logger.log("Cannot get local player");
            return false;
        }

        if (localPlayer.getTile().distance(muleLocation) > maxWalkDistance) {
            Logger.log("Mule is too far away, cannot walk");
            return false;
        }

        Walking.walk(muleLocation);
        return Sleep.sleepUntil(() -> {
            Player player = Players.getLocal();
            return player != null && player.getTile().distance(muleLocation) < 5;
        }, 15000);
    }

    /**
     * Wait for mule to appear nearby
     */
    private boolean waitForMule() {
        Logger.log("Waiting for mule: " + muleName);

        return Sleep.sleepUntil(() -> {
            Player mule = Players.closest(p ->
                    p != null &&
                            p.getName() != null &&
                            p.getName().equalsIgnoreCase(muleName)
            );
            return mule != null && mule.getTile().distance() <= 15;
        }, tradeTimeout);
    }

    /**
     * Perform the trade with mule
     */
    private boolean performTrade() {
        try {
            Logger.log("Initiating trade with mule...");

            // Find mule player
            Player mule = Players.closest(p ->
                    p != null &&
                            p.getName() != null &&
                            p.getName().equalsIgnoreCase(muleName)
            );

            if (mule == null) {
                Logger.log("Mule player not found");
                return false;
            }

            // Initiate trade
            if (!Trade.isOpen()) {
                mule.interact("Trade with");
                if (!Sleep.sleepUntil(Trade::isOpen, 10000)) {
                    Logger.log("Trade window did not open");
                    return false;
                }
            }

            Logger.log("Trade screen opened");

            // Add all items
            for (Item item : Inventory.all()) {
                if (item != null && item.getName() != null) {
                    Trade.addItem(item.getName(), item.getAmount());
                    Sleep.sleep(100, 300);
                }
            }

            Logger.log("Items added, waiting for mule to accept...");
            Sleep.sleep(2000, 3000);

            // Accept first screen
            if (Trade.acceptTrade()) {
                Logger.log("Accepted first trade screen");
                Sleep.sleep(600, 1200);

                // Wait for second screen and accept
                if (Sleep.sleepUntil(() -> Trade.isOpen(2), 10000)) {
                    if (Trade.acceptTrade()) {
                        Logger.log("Accepted second trade screen");

                        // Wait for completion
                        if (Sleep.sleepUntil(() -> !Trade.isOpen(), 10000)) {
                            Logger.log("Trade completed!");
                            return true;
                        }
                    }
                }
            }

            Logger.log("Trade flow failed");
            return false;

        } catch (Exception e) {
            Logger.error("Error performing trade: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Wait for trade to be accepted (for withdrawals)
     */
    private boolean waitForTrade() {
        Logger.log("Waiting for trade from mule...");

        if (Sleep.sleepUntil(Trade::isOpen, tradeTimeout)) {
            Logger.log("Trade opened, accepting...");
            Sleep.sleep(2000, 3000);

            if (Trade.acceptTrade()) {
                Sleep.sleep(600, 1200);

                if (Sleep.sleepUntil(() -> Trade.isOpen(2), 10000)) {
                    if (Trade.acceptTrade()) {
                        return Sleep.sleepUntil(() -> !Trade.isOpen(), 10000);
                    }
                }
            }
        }

        return false;
    }

    /**
     * Check mule status
     */
    public String getMuleStatus() {
        try {
            return muleClient.getStatus();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    /**
     * Ping the mule server
     */
    public boolean pingMule() {
        try {
            return muleClient.ping();
        } catch (Exception e) {
            Logger.log("Ping failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Clean up connection
     */
    public void cleanup() {
        try {
            muleClient.disconnect();
        } catch (Exception e) {
            Logger.log("Cleanup error: " + e.getMessage());
        }
    }

    // Setters for configuration

    public void setAutoWalkToMule(boolean autoWalk) {
        this.autoWalkToMule = autoWalk;
    }

    public void setMaxWalkDistance(int distance) {
        this.maxWalkDistance = distance;
    }

    public void setTradeTimeout(int timeout) {
        this.tradeTimeout = timeout;
    }
}
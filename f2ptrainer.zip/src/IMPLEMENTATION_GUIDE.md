# Implementation Guide - F2P Trainer Refactored

## Quick Start

### 1. Copy Files to Your Project

Copy all files maintaining the package structure:

```
YourProject/src/
├── config/
│   └── ScriptConfig.java
├── core/
│   ├── BaseManager.java
│   └── HumanMouse.java
├── managers/
│   ├── AntiBanManager.java
│   ├── BankingManager.java
│   ├── CombatManager.java
│   ├── FoodManager.java
│   ├── LootingManager.java
│   └── NavigationManager.java
├── navigation/
│   ├── DungeonNavigator.java
│   ├── Location.java
│   └── LocationRegistry.java
└── script/
    └── F2PTrainer.java
```

### 2. Add Gson Dependency

Add Google Gson for JSON configuration:

**Maven:**
```xml
<dependency>
    <groupId>com.google.code.gson</groupId>
    <artifactId>gson</artifactId>
    <version>2.10.1</version>
</dependency>
```

**Gradle:**
```gradle
implementation 'com.google.code.gson:gson:2.10.1'
```

### 3. Test Lumbridge Basement Navigation

```java
// In your script or test class
Location rats = LocationRegistry.get("Lumbridge Rats");
Location spiders = LocationRegistry.get("Lumbridge Spiders");

// Navigate to rats
navigationManager.setLocation(rats);
navigationManager.navigateToLocation(); // Goes to basement rats area

// Then navigate to spiders
navigationManager.setLocation(spiders);
navigationManager.navigateToLocation(); // Walks from rats to spiders!
```

### 4. Configure Mouse Movement

```java
ScriptConfig config = new ScriptConfig();

// Basic settings
config.mouse.humanLike = true;
config.mouse.movementSpeed = 5; // 1-10, 5 is medium

// Advanced settings
config.mouse.overshootChance = 15;      // 15% chance to overshoot
config.mouse.overshootDistance = 3;     // 3 pixels
config.mouse.bezierControlPoints = 2;   // Smooth curves
config.mouse.enableDeviations = true;   // Random path deviations
config.mouse.deviationAmount = 20;      // Max 20 pixels deviation

// Save configuration
config.save("custom_mouse");
```

### 5. Create and Use Profiles

```java
// Create profile
ScriptConfig config = new ScriptConfig();
config.location.monsterLocation = "Lumbridge Spiders";
config.combat.style = "Aggressive";
config.food.foodType = "Lobster";
config.food.foodAmount = 15;
config.save("spider_killer");

// Load profile
ScriptConfig loaded = ScriptConfig.load("spider_killer");

// Command-line loading
// java -jar MyBot.jar --profile=spider_killer
ScriptConfig fromArgs = ScriptConfig.loadFromArgs(getArgs());
```

## Testing Checklist

### Lumbridge Basement Navigation Test

1. **Start at Lumbridge Castle**
2. **Test: Navigate to Rats**
   ```java
   Location rats = LocationRegistry.get("Lumbridge Rats");
   navigation.setLocation(rats);
   navigation.navigateToLocation();
   ```
   - ✓ Should walk to castle
   - ✓ Should climb down ladder
   - ✓ Should be in basement rats area

3. **Test: Navigate to Spiders from Rats**
   ```java
   Location spiders = LocationRegistry.get("Lumbridge Spiders");
   navigation.setLocation(spiders);
   navigation.navigateToLocation();
   ```
   - ✓ Should stay in basement (not exit)
   - ✓ Should walk west to spiders area
   - ✓ Should arrive at spiders

4. **Test: Navigate to Spiders from Surface**
   - Log out and back in (spawn at Lumbridge)
   ```java
   Location spiders = LocationRegistry.get("Lumbridge Spiders");
   navigation.setLocation(spiders);
   navigation.navigateToLocation();
   ```
   - ✓ Should walk to castle
   - ✓ Should climb down ladder
   - ✓ Should walk to spiders area
   - ✓ Should arrive at spiders

### Mouse Movement Test

```java
HumanMouse mouse = new HumanMouse(config);

// Test entity clicking
NPC npc = NPCs.closest("Rat");
mouse.clickEntity(npc, false);
// Observe: Should see curved movement, possible overshoot

// Test random movement
mouse.moveRandomly();
// Observe: Should move naturally, not straight lines
```

### Configuration Test

```java
// Test save
ScriptConfig config = new ScriptConfig();
config.combat.style = "Defensive";
config.save("test_profile");

// Test load
ScriptConfig loaded = ScriptConfig.load("test_profile");
assert loaded.combat.style.equals("Defensive");

// Test command-line
String[] args = {"--profile=test_profile"};
ScriptConfig fromArgs = ScriptConfig.loadFromArgs(args);
assert fromArgs.profileName.equals("test_profile");
```

## Common Issues and Solutions

### Issue: "Cannot find ladder to basement"

**Cause**: Ladder detection failing

**Solution**:
```java
// In DungeonNavigator.java, line ~147
// Make sure you're close enough to ladder
if (playerPos.distance(LUMBRIDGE_BASEMENT_ENTRANCE) > 3) {
    Walking.walk(LUMBRIDGE_BASEMENT_ENTRANCE);
    Sleep.sleepUntil(() -> 
        Players.getLocal().distance(LUMBRIDGE_BASEMENT_ENTRANCE) < 3, 
        10000
    );
}
```

### Issue: "Bot goes to basement then exits"

**Cause**: Navigation not recognizing it's already in correct dungeon

**Solution**: Check `isInCorrectDungeon()` method in DungeonNavigator

### Issue: "Mouse movements not smooth"

**Cause**: Not enough Bézier control points or too fast

**Solution**:
```java
config.mouse.bezierControlPoints = 3; // More smooth
config.mouse.movementSpeed = 3;       // Slower
```

### Issue: "Profile not loading from command-line"

**Cause**: Args not being passed correctly

**Solution**:
```java
// In your script's onStart()
@Override
public void onStart() {
    // Get args from DreamBot
    String[] args = getArgs();
    
    // Pass to config loader
    config = ScriptConfig.loadFromArgs(args);
    
    Logger.log("Loaded profile: " + config.profileName);
}
```

## Remote Launching Setup

### 1. Create Profiles on Local Machine

```java
// Combat pure profile
ScriptConfig combatPure = new ScriptConfig();
combatPure.combat.trainAttack = true;
combatPure.combat.trainStrength = true;
combatPure.combat.trainDefence = false; // No defence
combatPure.location.monsterLocation = "Lumbridge Cows";
combatPure.save("combat_pure");

// Balanced profile
ScriptConfig balanced = new ScriptConfig();
balanced.combat.trainAttack = true;
balanced.combat.trainStrength = true;
balanced.combat.trainDefence = true;
balanced.location.monsterLocation = "Varrock Rats";
balanced.save("balanced");
```

### 2. Copy Profiles to Remote Server

```bash
# Profiles are saved in:
# ~/.DreamBot/F2PTrainer/*.json

# Copy to remote server
scp ~/.DreamBot/F2PTrainer/*.json user@remote:~/.DreamBot/F2PTrainer/
```

### 3. Launch with Profile

```bash
# On remote server
java -jar DreamBot.jar \
  -script "F2P Trainer Pro (Refactored)" \
  -params "--profile=combat_pure" \
  -username "account@email.com" \
  -password "password"
```

## Advanced Configuration Examples

### AFK Break Configuration

```java
config.antiBan.enabled = true;
config.antiBan.afkBreaks = true;
config.antiBan.afkBreakFrequencyMinutes = 45;  // Break every 45 min
config.antiBan.afkBreakDurationMinutes = 5;    // 5 min break
config.antiBan.variancePercent = 20;           // ±20% randomness

// This means:
// Break every 36-54 minutes (45 ± 20%)
// Break lasts 4-6 minutes (5 ± 20%)
```

### Progressive Training

```java
config.progression.enabled = true;
config.progression.chickenToCowLevel = 10;      // Chickens → Cows at level 10
config.progression.cowToHillGiantLevel = 20;    // Cows → Hill Giants at level 20

// Bot will automatically progress through locations
```

### Custom Location Setup

To add new locations, edit `LocationRegistry.java`:

```java
// In registerAllLocations()
register(new Location(
    "My Custom Location",           // Display name
    "My Monster",                    // NPC name
    new Area(x1, y1, x2, y2),       // Training area
    false,                           // Requires dungeon?
    null,                            // Dungeon entrance (if applicable)
    LocationType.SURFACE            // Type
));
```

## Performance Tips

1. **Reduce Debug Logging in Production**
   ```java
   config.debugMode = false;
   ```

2. **Optimize Mouse Speed for Your Use Case**
   ```java
   // Fast training (less human-like)
   config.mouse.movementSpeed = 8;
   config.mouse.overshootChance = 5;
   
   // Safe training (very human-like)
   config.mouse.movementSpeed = 3;
   config.mouse.overshootChance = 20;
   ```

3. **Adjust Anti-Ban Frequency**
   ```java
   // More frequent (safer)
   config.antiBan.cameraRotationFrequencySeconds = 120; // 2 min
   
   // Less frequent (faster)
   config.antiBan.cameraRotationFrequencySeconds = 300; // 5 min
   ```

## Architecture Benefits

### Before (Old Code)
```java
// Repeated code in multiple managers
Logger.log("DEBUG: " + message);
int delay = random.nextInt(max - min) + min;

// Hard-coded locations everywhere
if (location.equals("Lumbridge Rats")) {
    // ... handle rats
} else if (location.equals("Lumbridge Spiders")) {
    // ... handle spiders
}
```

### After (Refactored)
```java
// DRY - Single source of truth
logDebug(message);              // In BaseManager
int delay = getRandomDelay(min, max);

// Location registry
Location location = LocationRegistry.get(name);
navigation.navigateToLocation(location);
```

### Benefits
- **50% less code** - No duplication
- **Single change = global impact** - Fix once, works everywhere
- **Easy testing** - Mock managers independently
- **Clear responsibilities** - Each class has one job
- **Extensible** - Add features without changing existing code

## Support

If you encounter issues:

1. **Check logs** - All managers log with prefixes
2. **Enable debug mode** - `config.debugMode = true`
3. **Test components separately** - Test navigation, combat, etc. independently
4. **Verify profile loading** - Log `config.profileName` on start

## Next Steps

1. Copy files to your project
2. Test Lumbridge basement navigation
3. Configure mouse settings to your preference
4. Create and test profiles
5. Set up remote launching
6. Enjoy your refactored, maintainable bot!

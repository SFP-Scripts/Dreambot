package config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.dreambot.api.utilities.Logger;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ScriptConfig {

    public String profileName = "default";
    private static final String CONFIG_DIR = System.getProperty("user.home") + File.separator + "dreambot" + File.separator + "scripts" + File.separator + "F2PTrainer" + File.separator;

    public boolean enableGUI = true;
    public boolean debugMode = false;
    public boolean paintEnabled = true;

    public CombatSettings combat = new CombatSettings();
    public LocationSettings location = new LocationSettings();
    public FoodSettings food = new FoodSettings();
    public EquipmentSettings equipment = new EquipmentSettings();
    public BankingSettings banking = new BankingSettings();
    public LootingSettings looting = new LootingSettings();
    public AntiBanSettings antiBan = new AntiBanSettings();
    public MouseSettings mouse = new MouseSettings();
    public ProgressionSettings progression = new ProgressionSettings();
    public WorldHopSettings worldHop = new WorldHopSettings();
    public StopConditions stopConditions = new StopConditions();
    public PlayerDetectionSettings playerDetection = new PlayerDetectionSettings();
    public DeathSettings death = new DeathSettings();
    public TaskSettings tasks = new TaskSettings();
    public CookingSettings cooking = new CookingSettings();  // NEW

    public static class CombatSettings {
        public String style = "Aggressive";
        public boolean trainAttack = true;
        public boolean trainStrength = true;
        public boolean trainDefence = true;
        public int targetAttackLevel = 99;
        public int targetStrengthLevel = 99;
        public int targetDefenceLevel = 99;
        public int targetHitpointsLevel = 99;
        public boolean rotateSkills = false;
        public boolean enableFlee = true;
        public int fleeHealthPercent = 20;
        public boolean fleeIfNoFood = true;
        public int fleeDistance = 15;
    }

    public static class LocationSettings {
        public String monsterLocation = "Lumbridge Chickens";
        public String targetMonsterName = "Chicken";
        public boolean requiresDungeon = false;
    }

    public static class FoodSettings {
        public boolean autoEat = true;
        public boolean withdrawFood = true;
        public int eatAtHealthPercent = 50;
        public int foodAmount = 10;
        public String foodType = "Salmon";
    }

    public static class EquipmentSettings {
        public String weapon = "Iron Scimitar";
        public String shield = "None";
        public String armour = "Iron Platebody";
        public String amulet = "None";
        public boolean withdrawEquipment = false;
        public boolean autoRetrieveScimitar = false;
        public boolean autoEquipScimitar = true;
    }

    public static class BankingSettings {
        public boolean enabled = true;
        public int inventoryThreshold = 28;
        public boolean bankAll = false;
        public boolean bankBones = false;
        public boolean bankFeathers = false;
        public boolean bankCowhide = false;
    }

    public static class LootingSettings {
        public boolean enabled = true;
        public boolean lootAll = false;
        public boolean lootBones = true;
        public String boneMode = "Bank All";
        public int buryRate = 50;
        public boolean randomBoneBurying = true;
        public int buryMinPercent = 40;
        public int buryMaxPercent = 60;
        public boolean lootFeathers = true;
        public boolean lootCowhide = true;
        public boolean lootRawBeef = false;
        public boolean lootRawChicken = true;  // NEW
        public int lootRadius = 10;
        public boolean enableWeaponUpgrade = false;
        public String targetWeapon = "Mithril Scimitar";
        public int bonesToSell = 1000;
        public int boneSellPrice = 100;
        public int weaponBuyPrice = 10000;
        public boolean hasUpgraded = false;
        public String customLootItems = "Coins,Air rune,Water rune,Earth rune,Fire rune,Mind rune,Body rune,Chaos rune,Nature rune,Law rune,Death rune";
        public boolean lootCustomItems = true;
        public boolean humanizedLooting = true;
        public int lootSkipChance = 15;
        public int lootDelayMin = 600;
        public int lootDelayMax = 2000;
    }

    public static class AntiBanSettings {
        public boolean enabled = true;
        public boolean afkBreaks = true;
        public int afkBreakMinFrequencyMinutes = 35;
        public int afkBreakMaxFrequencyMinutes = 55;
        public int afkBreakMinDurationMinutes = 3;
        public int afkBreakMaxDurationMinutes = 8;
        public int afkBreakVariancePercent = 20;
        public int afkBreakFrequencyMinutes = 45;
        public int afkBreakDurationMinutes = 5;
        public boolean randomCameraRotations = true;
        public boolean randomCamera = true;
        public int cameraRotationFrequencySeconds = 180;
        public int cameraRotationVariancePercent = 20;
        public boolean randomMouseMovements = true;
        public int mouseMovementFrequencySeconds = 300;
        public int mouseMovementVariancePercent = 20;
        public boolean enableWorldHopping = false;
        public boolean worldHopOnPlayers = true;
        public boolean worldHopOnTimer = false;
        public int worldHopPlayerThreshold = 3;
        public int worldHopMinIntervalMinutes = 10;
        public int worldHopMaxIntervalMinutes = 20;
        public boolean randomSkillChecks = true;
        public boolean randomRightClicks = true;
        public boolean examineObjects = true;
        public int variancePercent = 20;
        public boolean avoidPlayers = false;
        public int playerAvoidDistance = 5;
        public int actionDelay = 1000;
        public int actionDelayVariance = 500;
        public boolean useHumanReactionTime = true;
        public int minReactionTime = 200;
        public int maxReactionTime = 600;
    }

    public static class MouseSettings {
        public boolean humanLike = true;
        public boolean useSmartMouse = true;
        public int movementSpeed = 5;
        public int mouseSpeed = 5;
        public int overshootChance = 15;
        public int overshootDistance = 3;
        public int bezierControlPoints = 2;
        public boolean enableDeviations = true;
        public int deviationAmount = 20;
        public int minReactionTime = 200;
        public int maxReactionTime = 600;
    }

    public static class ProgressionSettings {
        public boolean enabled = false;
        public int chickenToCowLevel = 10;
        public int cowToHillGiantLevel = 20;
    }

    public static class WorldHopSettings {
        public boolean enabled = false;
        public boolean hopOnPlayers = true;
        public boolean hopOnTimer = false;
        public int maxNearbyPlayers = 3;
        public int hopIntervalMinutes = 15;
    }

    public static class StopConditions {
        public boolean stopAtLevel = false;
        public int stopLevel = 99;
        public boolean stopAfterTime = false;
        public long stopTimeMinutes = 60;
    }

    public static class PlayerDetectionSettings {
        public boolean enabled = false;
        public boolean detectNearbyPlayers = true;
        public boolean detectNameCalled = false;
        public boolean detectBotWords = false;
        public int detectionRadius = 5;
        public String actionOnDetection = "Pause";
        public int pauseMinMinutes = 2;
        public int pauseMaxMinutes = 10;
        public boolean logPlayerNames = false;
    }

    public static class DeathSettings {
        public boolean enabled = true;
        public boolean lootGravestone = true;
        public boolean pickupGroundItems = true;
        public boolean pickupItems = true;
        public boolean autoEquip = true;
        public boolean equipWeapons = true;
        public boolean returnToSpot = true;
        public int maxLootAttempts = 5;
        public int deathWaitTime = 10000;
        public java.util.List<String> itemsToPickup = java.util.Arrays.asList("Bronze scimitar", "Iron scimitar", "Steel scimitar");
    }

    public static class TaskSettings {
        public boolean enabled = false;
        public boolean enableSwap = false;
        public boolean randomizeOrder = false;
        public String currentTask = "Combat";
        public int taskSwitchInterval = 30;
        public int swapMinutes = 30;
        public java.util.List<String> locationRotation = java.util.Arrays.asList("Lumbridge Chickens", "Lumbridge Cows");
    }

    // NEW COOKING SETTINGS
    public static class CookingSettings {
        public boolean autoCook = false;
        public boolean cookChickens = true;
        public int minRawChickens = 5;  // Cook when we have at least 5 raw chickens
        public boolean bankCookedChickens = true;  // Bank cooked chickens after cooking
    }

    public void save() {
        save(this.profileName);
    }

    public void save(String profileName) {
        try {
            Path dir = Paths.get(CONFIG_DIR);
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
            }

            File file = new File(CONFIG_DIR + profileName + ".json");
            Gson gson = new GsonBuilder().setPrettyPrinting().create();

            try (Writer writer = new FileWriter(file)) {
                gson.toJson(this, writer);
            }

            this.profileName = profileName;
            Logger.log("Configuration saved: " + profileName);

        } catch (IOException e) {
            Logger.error("Failed to save configuration: " + e.getMessage());
        }
    }

    public static ScriptConfig load(String profileName) {
        try {
            File file = new File(CONFIG_DIR + profileName + ".json");

            if (!file.exists()) {
                Logger.log("Profile not found: " + profileName + " - creating default");
                ScriptConfig config = new ScriptConfig();
                config.profileName = profileName;
                config.save();
                return config;
            }

            Gson gson = new Gson();
            try (Reader reader = new FileReader(file)) {
                ScriptConfig config = gson.fromJson(reader, ScriptConfig.class);
                config.profileName = profileName;
                Logger.log("Configuration loaded: " + profileName);
                return config;
            }

        } catch (IOException e) {
            Logger.error("Failed to load configuration: " + e.getMessage());
            ScriptConfig config = new ScriptConfig();
            config.profileName = "default";
            return config;
        }
    }

    public static String[] getAvailableProfiles() {
        File dir = new File(CONFIG_DIR);

        if (!dir.exists()) {
            return new String[0];
        }

        File[] files = dir.listFiles((d, name) -> name.endsWith(".json"));

        if (files == null || files.length == 0) {
            return new String[0];
        }

        String[] profiles = new String[files.length];
        for (int i = 0; i < files.length; i++) {
            String fileName = files[i].getName();
            profiles[i] = fileName.substring(0, fileName.length() - 5);
        }

        return profiles;
    }

    public static void deleteProfile(String profileName) {
        try {
            File file = new File(CONFIG_DIR + profileName + ".json");
            if (file.exists()) {
                file.delete();
                Logger.log("Profile deleted: " + profileName);
            }
        } catch (Exception e) {
            Logger.error("Failed to delete profile: " + e.getMessage());
        }
    }

    public static ScriptConfig loadFromArgs(String[] args) {
        String profileName = "default";

        if (args != null) {
            for (String arg : args) {
                if (arg.startsWith("--profile=")) {
                    profileName = arg.substring(10);
                    Logger.log("Loading profile from command line: " + profileName);
                    break;
                }
            }
        }

        return load(profileName);
    }

    public static ScriptConfig loadFromParameter(String parameterString) {
        if (parameterString == null || parameterString.isEmpty()) {
            return load("default");
        }

        if (parameterString.contains("--profile=")) {
            String profileName = parameterString.substring(
                    parameterString.indexOf("--profile=") + 10
            );

            if (profileName.contains(" ")) {
                profileName = profileName.substring(0, profileName.indexOf(" "));
            }

            Logger.log("Loading profile: " + profileName);
            return load(profileName);
        }

        return load("default");
    }

    public ScriptConfig clone() {
        Gson gson = new Gson();
        String json = gson.toJson(this);
        return gson.fromJson(json, ScriptConfig.class);
    }
}
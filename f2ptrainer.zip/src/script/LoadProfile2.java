package script;

import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;

/**
 * LAUNCHER FOR PROFILE 2
 */
@ScriptManifest(
        name = "Load Profile 2",
        author = "Launcher",
        version = 1.0,
        description = "Sets profile 2 then tells you to start F2PTrainer",
        category = Category.UTILITY
)
public class LoadProfile2 extends AbstractScript {

    @Override
    public void onStart() {
        log("═══════════════════════════════════════════════");
        log("PROFILE 2 LAUNCHER");
        log("═══════════════════════════════════════════════");

        System.setProperty("scriptParameter", "2");

        log("✓ Profile parameter set to: 2");
        log("✓ F2PTrainer will load: 2.json");
        log("");
        log("NOW START F2PTRAINER SCRIPT!");
        log("═══════════════════════════════════════════════");

        stop();
    }

    @Override
    public int onLoop() {
        return 600000;
    }
}
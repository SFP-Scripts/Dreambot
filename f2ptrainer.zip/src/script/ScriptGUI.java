package script;

import config.ScriptConfig;
import navigation.LocationRegistry;
import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

/**
 * F2P Trainer GUI - Complete Version
 *
 * NOW INCLUDES:
 * - All 33 F2P training locations
 * - AFK break variance settings (min/max/variance)
 * - Sorted location dropdown
 * - Profile management
 */
public class ScriptGUI extends JFrame {

    private final ScriptConfig config;
    private boolean started = false;

    // Profile management
    private JComboBox<String> profileCombo;
    private JTextField newProfileField;

    // Basic components
    private JComboBox<String> locationCombo;
    private JComboBox<String> combatStyleCombo;
    private JComboBox<String> foodTypeCombo;
    private JSpinner foodAmountSpinner;
    private JCheckBox autoEatCheckbox;
    private JCheckBox bankingCheckbox;

    // Combat training components
    private JCheckBox attackCheckbox;
    private JCheckBox strengthCheckbox;
    private JCheckBox defenceCheckbox;
    private JSpinner targetAttackSpinner;
    private JSpinner targetStrengthSpinner;
    private JSpinner targetDefenceSpinner;
    private JCheckBox rotateSkillsCheckbox;

    // Death handling components
    private JCheckBox pickupOnDeathCheckbox;
    private JTextField itemsToPickupField;
    private JCheckBox equipOnPickupCheckbox;
    private JCheckBox returnToSpotCheckbox;

    // Anti-ban components - UPDATED with variance settings
    private JCheckBox antiBanCheckbox;
    private JCheckBox afkBreaksCheckbox;
    private JSpinner afkFrequencyMinSpinner;
    private JSpinner afkFrequencyMaxSpinner;
    private JSpinner afkDurationMinSpinner;
    private JSpinner afkDurationMaxSpinner;
    private JSpinner afkVarianceSpinner;
    private JCheckBox randomCameraCheckbox;
    private JCheckBox randomSkillCheckbox;
    private JCheckBox randomMouseCheckbox;
    private JSpinner reactionTimeMinSpinner;
    private JSpinner reactionTimeMaxSpinner;

    // Task swapping
    private JCheckBox enableTaskSwapCheckbox;
    private JSpinner taskSwapMinutesSpinner;

    // Mouse settings
    private JCheckBox smartMouseCheckbox;
    private JSpinner mouseSpeedSpinner;

    // Player detection components
    private JCheckBox playerDetectionCheckbox;
    private JCheckBox detectNearbyCheckbox;
    private JCheckBox detectNameCheckbox;
    private JCheckBox detectBotWordsCheckbox;
    private JSpinner detectionRadiusSpinner;
    private JComboBox<String> detectionActionCombo;
    private JSpinner pauseMinSpinner;
    private JSpinner pauseMaxSpinner;
    private JCheckBox logPlayerNamesCheckbox;

    // Bone handling components
    private JCheckBox lootBonesCheckbox;
    private JComboBox<String> boneModeCombo;
    private JSpinner buryRateSpinner;

    // Weapon upgrade components
    private JCheckBox enableWeaponUpgradeCheckbox;
    private JTextField targetWeaponField;
    private JSpinner bonesToSellSpinner;
    private JSpinner boneSellPriceSpinner;
    private JSpinner weaponBuyPriceSpinner;

    // Bronze Scimitar Retrieval
    private JCheckBox autoRetrieveScimitarCheckbox;

    public ScriptGUI(ScriptConfig config) {
        this.config = config;

        setTitle("F2P Trainer Pro v4.5 - Complete F2P Locations");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 700);
        setMinimumSize(new Dimension(700, 500));
        setResizable(true);
        setLayout(new BorderLayout());

        // Profile management panel at top
        add(createProfilePanel(), BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Location", makeSimplePanel(createLocationTab()));
        tabs.add("Combat", makeSimplePanel(createCombatTab()));
        tabs.add("Skills", makeSimplePanel(createSkillsTab()));
        tabs.add("Food", makeSimplePanel(createFoodTab()));
        tabs.add("Bones", makeSimplePanel(createBonesTab()));
        tabs.add("Death", makeSimplePanel(createDeathTab()));
        tabs.add("Bronze Scimitar", makeSimplePanel(createBronzeScimitarTab()));
        tabs.add("Weapon Upgrade", makeSimplePanel(createWeaponUpgradeTab()));
        tabs.add("Anti-Ban", makeSimplePanel(createAntiBanTab()));
        tabs.add("Tasks", makeSimplePanel(createTasksTab()));
        tabs.add("Mouse", makeSimplePanel(createMouseTab()));
        tabs.add("Player Detection", makeSimplePanel(createPlayerDetectionTab()));

        add(tabs, BorderLayout.CENTER);
        add(createButtons(), BorderLayout.SOUTH);

        loadConfigToGUI();

        setSize(650, 550);
        setResizable(false);
        setLocationRelativeTo(null);
    }

    private JPanel createProfilePanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panel.setBorder(BorderFactory.createTitledBorder("Profile Management"));

        panel.add(new JLabel("Profile:"));

        String[] profiles;
        try {
            profiles = ScriptConfig.getAvailableProfiles();
            if (profiles == null || profiles.length == 0) {
                profiles = new String[]{"default"};
            }
        } catch (Exception e) {
            System.err.println("[GUI] Error loading profiles: " + e.getMessage());
            profiles = new String[]{"default"};
        }

        profileCombo = new JComboBox<>(profiles);
        try {
            profileCombo.setSelectedItem(config.profileName);
        } catch (Exception e) {
            System.err.println("[GUI] Error setting profile: " + e.getMessage());
        }
        profileCombo.setPreferredSize(new Dimension(120, 25));
        panel.add(profileCombo);

        JButton loadBtn = new JButton("Load");
        loadBtn.addActionListener(e -> loadProfile());
        loadBtn.setToolTipText("Load selected profile");
        panel.add(loadBtn);

        JButton saveBtn = new JButton("Save");
        saveBtn.addActionListener(e -> saveProfile());
        saveBtn.setToolTipText("Save changes to current profile");
        panel.add(saveBtn);

        panel.add(new JLabel("  "));

        panel.add(new JLabel("Save As:"));
        newProfileField = new JTextField(10);
        panel.add(newProfileField);
        JButton saveAsBtn = new JButton("Save As");
        saveAsBtn.addActionListener(e -> saveAsProfile());
        saveAsBtn.setToolTipText("Create new profile with current settings");
        panel.add(saveAsBtn);

        panel.add(new JLabel("  "));

        JButton deleteBtn = new JButton("Delete");
        deleteBtn.addActionListener(e -> deleteProfile());
        deleteBtn.setToolTipText("Delete selected profile");
        panel.add(deleteBtn);

        return panel;
    }

    private void loadProfile() {
        String profileName = (String) profileCombo.getSelectedItem();
        if (profileName != null) {
            ScriptConfig loaded = ScriptConfig.load(profileName);
            config.profileName = loaded.profileName;
            config.location = loaded.location;
            config.combat = loaded.combat;
            config.food = loaded.food;
            config.banking = loaded.banking;
            config.death = loaded.death;
            config.equipment = loaded.equipment;
            config.looting = loaded.looting;
            config.antiBan = loaded.antiBan;
            config.mouse = loaded.mouse;
            config.playerDetection = loaded.playerDetection;
            config.tasks = loaded.tasks;

            loadConfigToGUI();
            JOptionPane.showMessageDialog(this, "Profile loaded: " + profileName);
        }
    }

    private void saveProfile() {
        saveGUIToConfig();
        config.save();
        JOptionPane.showMessageDialog(this, "Profile saved: " + config.profileName);
    }

    private void saveAsProfile() {
        String newName = newProfileField.getText().trim();
        if (newName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a profile name");
            return;
        }

        saveGUIToConfig();
        config.save(newName);

        String[] profiles = ScriptConfig.getAvailableProfiles();
        profileCombo.setModel(new DefaultComboBoxModel<>(profiles));
        profileCombo.setSelectedItem(newName);

        JOptionPane.showMessageDialog(this, "New profile created: " + newName);
        newProfileField.setText("");
    }

    private void deleteProfile() {
        String profileName = (String) profileCombo.getSelectedItem();
        if (profileName == null || profileName.equals("default")) {
            JOptionPane.showMessageDialog(this, "Cannot delete default profile");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete profile: " + profileName + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            ScriptConfig.deleteProfile(profileName);

            String[] profiles = ScriptConfig.getAvailableProfiles();
            profileCombo.setModel(new DefaultComboBoxModel<>(profiles));
            profileCombo.setSelectedItem("default");

            JOptionPane.showMessageDialog(this, "Profile deleted: " + profileName);
        }
    }

    private JPanel createLocationTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Title
        JLabel titleLabel = new JLabel("Training Location Selection");
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 14f));
        p.add(titleLabel);
        p.add(Box.createVerticalStrut(10));

        // Location dropdown - ALL 33 locations now visible!
        JPanel locationPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        locationPanel.add(new JLabel("Select Location:"));

        String[] locations;
        try {
            locations = LocationRegistry.getAllNames();  // Returns all 33 locations, sorted
            if (locations == null || locations.length == 0) {
                locations = new String[]{"Lumbridge Chickens", "Lumbridge Cows"};
            }
        } catch (Exception e) {
            System.err.println("[GUI] Error loading locations: " + e.getMessage());
            locations = new String[]{"Lumbridge Chickens", "Lumbridge Cows"};
        }

        locationCombo = new JComboBox<>(locations);
        locationCombo.setPreferredSize(new Dimension(250, 30));
        locationPanel.add(locationCombo);
        p.add(locationPanel);

        p.add(Box.createVerticalStrut(15));

        // Location info panel
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Available Locations (" + locations.length + " total)"));

        JLabel info1 = new JLabel("Beginner (1-20): Chickens, Cows, Seagulls, Goblins, Rats, Spiders");
        JLabel info2 = new JLabel("Early (20-40): Frogs, Barbarians, Minotaurs, Hobgoblins");
        JLabel info3 = new JLabel("Mid (40-60): Hill Giants, Flesh Crawlers, Zombies, Skeletons");
        JLabel info4 = new JLabel("Advanced (60+): Moss Giants, Giant Spiders, Lesser Demons, Ankous");
        JLabel info5 = new JLabel("Bosses: Obor, Bryophyta");
        JLabel info6 = new JLabel("Special: Rimmington (bronze scimitar retrieval)");

        info1.setFont(info1.getFont().deriveFont(Font.PLAIN, 11f));
        info2.setFont(info2.getFont().deriveFont(Font.PLAIN, 11f));
        info3.setFont(info3.getFont().deriveFont(Font.PLAIN, 11f));
        info4.setFont(info4.getFont().deriveFont(Font.PLAIN, 11f));
        info5.setFont(info5.getFont().deriveFont(Font.PLAIN, 11f));
        info6.setFont(info6.getFont().deriveFont(Font.PLAIN, 11f));

        infoPanel.add(info1);
        infoPanel.add(info2);
        infoPanel.add(info3);
        infoPanel.add(info4);
        infoPanel.add(info5);
        infoPanel.add(info6);

        p.add(infoPanel);

        p.add(Box.createVerticalGlue());

        return p;
    }

    private JPanel createCombatTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        JLabel styleLabel = new JLabel("Combat Style:");
        p.add(styleLabel);

        String[] styles = {"Accurate", "Aggressive", "Defensive", "Controlled"};
        combatStyleCombo = new JComboBox<>(styles);
        combatStyleCombo.setMaximumSize(new Dimension(200, 30));
        p.add(combatStyleCombo);

        p.add(Box.createVerticalStrut(10));

        JLabel note = new JLabel("Note: Set combat style manually in-game");
        note.setFont(note.getFont().deriveFont(Font.ITALIC));
        p.add(note);

        return p;
    }

    private JPanel createSkillsTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        rotateSkillsCheckbox = new JCheckBox("Enable Skill Rotation", false);
        p.add(rotateSkillsCheckbox);

        p.add(Box.createVerticalStrut(10));

        JPanel attackPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        attackCheckbox = new JCheckBox("Train Attack", true);
        attackPanel.add(attackCheckbox);
        attackPanel.add(new JLabel("Target:"));
        targetAttackSpinner = new JSpinner(new SpinnerNumberModel(99, 1, 99, 1));
        targetAttackSpinner.setPreferredSize(new Dimension(60, 25));
        attackPanel.add(targetAttackSpinner);
        p.add(attackPanel);

        JPanel strengthPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        strengthCheckbox = new JCheckBox("Train Strength", true);
        strengthPanel.add(strengthCheckbox);
        strengthPanel.add(new JLabel("Target:"));
        targetStrengthSpinner = new JSpinner(new SpinnerNumberModel(99, 1, 99, 1));
        targetStrengthSpinner.setPreferredSize(new Dimension(60, 25));
        strengthPanel.add(targetStrengthSpinner);
        p.add(strengthPanel);

        JPanel defencePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        defenceCheckbox = new JCheckBox("Train Defence", true);
        defencePanel.add(defenceCheckbox);
        defencePanel.add(new JLabel("Target:"));
        targetDefenceSpinner = new JSpinner(new SpinnerNumberModel(99, 1, 99, 1));
        targetDefenceSpinner.setPreferredSize(new Dimension(60, 25));
        defencePanel.add(targetDefenceSpinner);
        p.add(defencePanel);

        return p;
    }

    private JPanel createFoodTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        autoEatCheckbox = new JCheckBox("Auto Eat", true);
        p.add(autoEatCheckbox);

        JPanel foodPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        foodPanel.add(new JLabel("Food Type:"));
        String[] foods = {"Shrimp", "Sardine", "Anchovies", "Trout", "Salmon", "Tuna", "Lobster", "Swordfish"};
        foodTypeCombo = new JComboBox<>(foods);
        foodTypeCombo.setPreferredSize(new Dimension(120, 25));
        foodPanel.add(foodTypeCombo);
        p.add(foodPanel);

        JPanel amountPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        amountPanel.add(new JLabel("Amount:"));
        foodAmountSpinner = new JSpinner(new SpinnerNumberModel(10, 1, 28, 1));
        foodAmountSpinner.setPreferredSize(new Dimension(60, 25));
        amountPanel.add(foodAmountSpinner);
        p.add(amountPanel);

        p.add(Box.createVerticalStrut(10));

        bankingCheckbox = new JCheckBox("Enable Banking", true);
        p.add(bankingCheckbox);

        return p;
    }

    private JPanel createBonesTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        lootBonesCheckbox = new JCheckBox("Loot Bones", true);
        p.add(lootBonesCheckbox);

        p.add(Box.createVerticalStrut(10));

        JPanel modePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        modePanel.add(new JLabel("Bone Mode:"));
        String[] modes = {"Bury All", "Bank All", "Bury Half Bank Half"};
        boneModeCombo = new JComboBox<>(modes);
        boneModeCombo.setPreferredSize(new Dimension(180, 25));
        modePanel.add(boneModeCombo);
        p.add(modePanel);

        JPanel ratePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ratePanel.add(new JLabel("Bury Rate (%):"));
        buryRateSpinner = new JSpinner(new SpinnerNumberModel(50, 0, 100, 5));
        buryRateSpinner.setPreferredSize(new Dimension(60, 25));
        ratePanel.add(buryRateSpinner);
        p.add(ratePanel);

        return p;
    }

    private JPanel createDeathTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Death Recovery");
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 14f));
        p.add(titleLabel);

        p.add(Box.createVerticalStrut(10));

        pickupOnDeathCheckbox = new JCheckBox("Pickup items on death", true);
        p.add(pickupOnDeathCheckbox);

        JPanel itemsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        itemsPanel.add(new JLabel("Items to pickup:"));
        itemsToPickupField = new JTextField("Bronze scimitar,Iron scimitar,Steel scimitar", 25);
        itemsPanel.add(itemsToPickupField);
        p.add(itemsPanel);

        equipOnPickupCheckbox = new JCheckBox("Auto-equip picked up weapons", true);
        p.add(equipOnPickupCheckbox);

        returnToSpotCheckbox = new JCheckBox("Return to training spot", true);
        p.add(returnToSpotCheckbox);

        return p;
    }

    private JPanel createBronzeScimitarTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("Bronze Scimitar Auto-Retrieval");
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 16f));
        p.add(titleLabel);
        p.add(Box.createVerticalStrut(10));

        autoRetrieveScimitarCheckbox = new JCheckBox("Auto-Retrieve Bronze Scimitar on Death");
        autoRetrieveScimitarCheckbox.setFont(autoRetrieveScimitarCheckbox.getFont().deriveFont(Font.BOLD, 14f));
        p.add(autoRetrieveScimitarCheckbox);

        p.add(Box.createVerticalStrut(15));

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(BorderFactory.createTitledBorder("How It Works"));

        JLabel info1 = new JLabel("1. Detects when you die and lose bronze scimitar");
        JLabel info2 = new JLabel("2. Walks to Rimmington building (2965, 3215)");
        JLabel info3 = new JLabel("3. Climbs stairs to upper floor");
        JLabel info4 = new JLabel("4. Takes bronze scimitar from table");
        JLabel info5 = new JLabel("5. Auto-equips and returns to training");

        infoPanel.add(info1);
        infoPanel.add(info2);
        infoPanel.add(info3);
        infoPanel.add(info4);
        infoPanel.add(info5);

        p.add(infoPanel);
        p.add(Box.createVerticalStrut(15));

        JPanel bestPanel = new JPanel();
        bestPanel.setLayout(new BoxLayout(bestPanel, BoxLayout.Y_AXIS));
        bestPanel.setBorder(BorderFactory.createTitledBorder("Best For"));

        JLabel best1 = new JLabel("✓ Low level accounts (frequent deaths)");
        JLabel best2 = new JLabel("✓ Lumbridge area training (close to Rimmington)");
        JLabel best3 = new JLabel("✓ Bronze weapon users");

        bestPanel.add(best1);
        bestPanel.add(best2);
        bestPanel.add(best3);

        p.add(bestPanel);
        p.add(Box.createVerticalStrut(15));

        JPanel notPanel = new JPanel();
        notPanel.setLayout(new BoxLayout(notPanel, BoxLayout.Y_AXIS));
        notPanel.setBorder(BorderFactory.createTitledBorder("Not Recommended For"));

        JLabel not1 = new JLabel("✗ Locations far from Rimmington (long walk)");
        JLabel not2 = new JLabel("✗ High-level accounts (rarely die)");
        JLabel not3 = new JLabel("✗ Using weapons better than bronze");

        notPanel.add(not1);
        notPanel.add(not2);
        notPanel.add(not3);

        p.add(notPanel);
        p.add(Box.createVerticalStrut(15));

        JPanel perfPanel = new JPanel();
        perfPanel.setLayout(new BoxLayout(perfPanel, BoxLayout.Y_AXIS));
        perfPanel.setBorder(BorderFactory.createTitledBorder("Performance"));

        JLabel perf1 = new JLabel("⏱ Time per retrieval: ~30-60 seconds");
        JLabel perf2 = new JLabel("🎯 Anti-detection: Random delays & camera movements");
        JLabel perf3 = new JLabel("🖱 SmartMouse: Human-like pathing");

        perfPanel.add(perf1);
        perfPanel.add(perf2);
        perfPanel.add(perf3);

        p.add(perfPanel);

        p.add(Box.createVerticalGlue());

        return p;
    }

    private JPanel createWeaponUpgradeTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("Weapon Upgrade (Grand Exchange)");
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 16f));
        p.add(titleLabel);
        p.add(Box.createVerticalStrut(10));

        enableWeaponUpgradeCheckbox = new JCheckBox("Enable Weapon Upgrade");
        enableWeaponUpgradeCheckbox.setFont(enableWeaponUpgradeCheckbox.getFont().deriveFont(Font.BOLD, 14f));
        p.add(enableWeaponUpgradeCheckbox);

        p.add(Box.createVerticalStrut(15));

        JPanel targetPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        targetPanel.add(new JLabel("Target Weapon:"));
        targetWeaponField = new JTextField("Mithril Scimitar", 15);
        targetPanel.add(targetWeaponField);
        p.add(targetPanel);

        JPanel bonesToSellPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bonesToSellPanel.add(new JLabel("Bones to Sell:"));
        bonesToSellSpinner = new JSpinner(new SpinnerNumberModel(1000, 100, 10000, 100));
        bonesToSellSpinner.setPreferredSize(new Dimension(80, 25));
        bonesToSellPanel.add(bonesToSellSpinner);
        p.add(bonesToSellPanel);

        JPanel bonePricePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bonePricePanel.add(new JLabel("Bone Sell Price (gp):"));
        boneSellPriceSpinner = new JSpinner(new SpinnerNumberModel(100, 1, 1000, 10));
        boneSellPriceSpinner.setPreferredSize(new Dimension(80, 25));
        bonePricePanel.add(boneSellPriceSpinner);
        p.add(bonePricePanel);

        JPanel weaponPricePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        weaponPricePanel.add(new JLabel("Weapon Buy Price (gp):"));
        weaponBuyPriceSpinner = new JSpinner(new SpinnerNumberModel(10000, 1000, 100000, 1000));
        weaponBuyPriceSpinner.setPreferredSize(new Dimension(80, 25));
        weaponPricePanel.add(weaponBuyPriceSpinner);
        p.add(weaponPricePanel);

        p.add(Box.createVerticalStrut(15));

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(BorderFactory.createTitledBorder("How It Works"));

        JLabel info1 = new JLabel("1. Collect bones while training");
        JLabel info2 = new JLabel("2. When threshold reached, go to GE");
        JLabel info3 = new JLabel("3. Sell bones at configured price");
        JLabel info4 = new JLabel("4. Buy weapon upgrade");
        JLabel info5 = new JLabel("5. Auto-equip and continue training");

        infoPanel.add(info1);
        infoPanel.add(info2);
        infoPanel.add(info3);
        infoPanel.add(info4);
        infoPanel.add(info5);

        p.add(infoPanel);

        return p;
    }

    private JPanel createAntiBanTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Enable checkbox
        antiBanCheckbox = new JCheckBox("Enable Anti-Ban", true);
        antiBanCheckbox.setFont(antiBanCheckbox.getFont().deriveFont(Font.BOLD, 14f));
        p.add(antiBanCheckbox);
        p.add(Box.createVerticalStrut(10));

        // Behaviors panel
        JPanel behaviorsPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        behaviorsPanel.setBorder(BorderFactory.createTitledBorder("Anti-Ban Behaviors"));
        randomCameraCheckbox = new JCheckBox("Random camera movements", true);
        randomSkillCheckbox = new JCheckBox("Random skill checks", true);
        randomMouseCheckbox = new JCheckBox("Random mouse movements", true);
        behaviorsPanel.add(randomCameraCheckbox);
        behaviorsPanel.add(randomSkillCheckbox);
        behaviorsPanel.add(randomMouseCheckbox);
        p.add(behaviorsPanel);
        p.add(Box.createVerticalStrut(10));

        // AFK Breaks checkbox
        afkBreaksCheckbox = new JCheckBox("Enable AFK Breaks (Randomized)", true);
        afkBreaksCheckbox.setFont(afkBreaksCheckbox.getFont().deriveFont(Font.BOLD, 13f));
        p.add(afkBreaksCheckbox);
        p.add(Box.createVerticalStrut(5));

        // AFK Frequency (Min-Max range)
        JPanel freqPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        freqPanel.setBorder(BorderFactory.createTitledBorder("Break Frequency (minutes)"));
        freqPanel.add(new JLabel("Min:"));
        afkFrequencyMinSpinner = new JSpinner(new SpinnerNumberModel(35, 10, 180, 5));
        afkFrequencyMinSpinner.setPreferredSize(new Dimension(60, 25));
        freqPanel.add(afkFrequencyMinSpinner);
        freqPanel.add(new JLabel("   Max:"));
        afkFrequencyMaxSpinner = new JSpinner(new SpinnerNumberModel(55, 10, 180, 5));
        afkFrequencyMaxSpinner.setPreferredSize(new Dimension(60, 25));
        freqPanel.add(afkFrequencyMaxSpinner);
        p.add(freqPanel);

        // AFK Duration (Min-Max range)
        JPanel durPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        durPanel.setBorder(BorderFactory.createTitledBorder("Break Duration (minutes)"));
        durPanel.add(new JLabel("Min:"));
        afkDurationMinSpinner = new JSpinner(new SpinnerNumberModel(3, 1, 30, 1));
        afkDurationMinSpinner.setPreferredSize(new Dimension(60, 25));
        durPanel.add(afkDurationMinSpinner);
        durPanel.add(new JLabel("   Max:"));
        afkDurationMaxSpinner = new JSpinner(new SpinnerNumberModel(8, 1, 30, 1));
        afkDurationMaxSpinner.setPreferredSize(new Dimension(60, 25));
        durPanel.add(afkDurationMaxSpinner);
        p.add(durPanel);

        // Variance percentage
        JPanel varPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        varPanel.setBorder(BorderFactory.createTitledBorder("Additional Variance"));
        varPanel.add(new JLabel("±"));
        afkVarianceSpinner = new JSpinner(new SpinnerNumberModel(20, 0, 50, 5));
        afkVarianceSpinner.setPreferredSize(new Dimension(60, 25));
        varPanel.add(afkVarianceSpinner);
        varPanel.add(new JLabel("%"));
        varPanel.add(new JLabel("  (adds extra randomization)"));
        p.add(varPanel);

        p.add(Box.createVerticalStrut(10));

        // Reaction time
        JPanel reactionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        reactionPanel.setBorder(BorderFactory.createTitledBorder("Human Reaction Time"));
        reactionPanel.add(new JLabel("Min:"));
        reactionTimeMinSpinner = new JSpinner(new SpinnerNumberModel(200, 50, 500, 10));
        reactionTimeMinSpinner.setPreferredSize(new Dimension(60, 25));
        reactionPanel.add(reactionTimeMinSpinner);
        reactionPanel.add(new JLabel("ms   Max:"));
        reactionTimeMaxSpinner = new JSpinner(new SpinnerNumberModel(600, 100, 1000, 10));
        reactionTimeMaxSpinner.setPreferredSize(new Dimension(60, 25));
        reactionPanel.add(reactionTimeMaxSpinner);
        reactionPanel.add(new JLabel("ms"));
        p.add(reactionPanel);

        return p;
    }

    private JPanel createTasksTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        enableTaskSwapCheckbox = new JCheckBox("Enable Task Swapping", false);
        p.add(enableTaskSwapCheckbox);

        JPanel swapPanel = new JPanel();
        swapPanel.add(new JLabel("Swap every:"));
        taskSwapMinutesSpinner = new JSpinner(new SpinnerNumberModel(30, 5, 180, 5));
        taskSwapMinutesSpinner.setPreferredSize(new Dimension(60, 25));
        swapPanel.add(taskSwapMinutesSpinner);
        swapPanel.add(new JLabel("minutes"));
        p.add(swapPanel);

        return p;
    }

    private JPanel createMouseTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        smartMouseCheckbox = new JCheckBox("Use SmartMouse (Recommended)", true);
        p.add(smartMouseCheckbox);

        JPanel speedPanel = new JPanel();
        speedPanel.add(new JLabel("Mouse Speed:"));
        mouseSpeedSpinner = new JSpinner(new SpinnerNumberModel(5, 1, 10, 1));
        mouseSpeedSpinner.setPreferredSize(new Dimension(60, 25));
        speedPanel.add(mouseSpeedSpinner);
        p.add(speedPanel);

        return p;
    }

    private JPanel createPlayerDetectionTab() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        playerDetectionCheckbox = new JCheckBox("Enable Player Detection", false);
        playerDetectionCheckbox.setFont(playerDetectionCheckbox.getFont().deriveFont(Font.BOLD));
        p.add(playerDetectionCheckbox);

        p.add(Box.createVerticalStrut(10));

        JPanel detectPanel = new JPanel();
        detectPanel.setLayout(new GridLayout(3, 1));
        detectPanel.setBorder(BorderFactory.createTitledBorder("Detection Methods"));

        detectNearbyCheckbox = new JCheckBox("Detect nearby players", true);
        detectNameCheckbox = new JCheckBox("Detect name called in chat", false);
        detectBotWordsCheckbox = new JCheckBox("Detect bot-related words", false);

        detectPanel.add(detectNearbyCheckbox);
        detectPanel.add(detectNameCheckbox);
        detectPanel.add(detectBotWordsCheckbox);

        p.add(detectPanel);

        JPanel radiusPanel = new JPanel();
        radiusPanel.add(new JLabel("Detection Radius:"));
        detectionRadiusSpinner = new JSpinner(new SpinnerNumberModel(5, 1, 20, 1));
        detectionRadiusSpinner.setPreferredSize(new Dimension(60, 25));
        radiusPanel.add(detectionRadiusSpinner);
        radiusPanel.add(new JLabel("tiles"));
        p.add(radiusPanel);

        p.add(Box.createVerticalStrut(10));

        JPanel actionPanel = new JPanel();
        actionPanel.setBorder(BorderFactory.createTitledBorder("Action on Detection"));
        actionPanel.add(new JLabel("Action:"));
        String[] actions = {"Pause", "Hop", "Logout", "Stop"};
        detectionActionCombo = new JComboBox<>(actions);
        detectionActionCombo.setPreferredSize(new Dimension(120, 25));
        actionPanel.add(detectionActionCombo);
        p.add(actionPanel);

        JPanel pausePanel = new JPanel();
        pausePanel.add(new JLabel("Pause Duration:"));
        pauseMinSpinner = new JSpinner(new SpinnerNumberModel(2, 1, 60, 1));
        pauseMinSpinner.setPreferredSize(new Dimension(60, 25));
        pausePanel.add(pauseMinSpinner);
        pausePanel.add(new JLabel("to"));
        pauseMaxSpinner = new JSpinner(new SpinnerNumberModel(10, 1, 60, 1));
        pauseMaxSpinner.setPreferredSize(new Dimension(60, 25));
        pausePanel.add(pauseMaxSpinner);
        pausePanel.add(new JLabel("minutes"));
        p.add(pausePanel);

        logPlayerNamesCheckbox = new JCheckBox("Log player names", false);
        p.add(logPlayerNamesCheckbox);

        return p;
    }

    private JPanel createButtons() {
        JPanel p = new JPanel();
        JButton start = new JButton("Start");
        JButton cancel = new JButton("Cancel");

        start.addActionListener(e -> {
            saveGUIToConfig();
            started = true;
            dispose();
        });

        cancel.addActionListener(e -> {
            started = false;
            dispose();
        });

        p.add(start);
        p.add(cancel);
        return p;
    }

    private JPanel makeSimplePanel(JPanel content) {
        JPanel wrapper = new JPanel(new FlowLayout(FlowLayout.CENTER));
        wrapper.add(content);
        return wrapper;
    }

    private void loadConfigToGUI() {
        if (LocationRegistry.exists(config.location.monsterLocation)) {
            locationCombo.setSelectedItem(config.location.monsterLocation);
        }
        combatStyleCombo.setSelectedItem(config.combat.style);
        autoEatCheckbox.setSelected(config.food.autoEat);
        foodTypeCombo.setSelectedItem(config.food.foodType);
        foodAmountSpinner.setValue(config.food.foodAmount);
        bankingCheckbox.setSelected(config.banking.enabled);

        // Combat training
        attackCheckbox.setSelected(config.combat.trainAttack);
        strengthCheckbox.setSelected(config.combat.trainStrength);
        defenceCheckbox.setSelected(config.combat.trainDefence);
        targetAttackSpinner.setValue(config.combat.targetAttackLevel);
        targetStrengthSpinner.setValue(config.combat.targetStrengthLevel);
        targetDefenceSpinner.setValue(config.combat.targetDefenceLevel);
        rotateSkillsCheckbox.setSelected(config.combat.rotateSkills);

        // Death handling
        pickupOnDeathCheckbox.setSelected(config.death.pickupItems);
        itemsToPickupField.setText(String.join(",", config.death.itemsToPickup));
        equipOnPickupCheckbox.setSelected(config.death.equipWeapons);
        returnToSpotCheckbox.setSelected(config.death.returnToSpot);

        // Mouse settings
        smartMouseCheckbox.setSelected(config.mouse.useSmartMouse);
        mouseSpeedSpinner.setValue(config.mouse.mouseSpeed);

        // Anti-ban - UPDATED with variance settings
        antiBanCheckbox.setSelected(config.antiBan.enabled);
        afkBreaksCheckbox.setSelected(config.antiBan.afkBreaks);
        afkFrequencyMinSpinner.setValue(config.antiBan.afkBreakMinFrequencyMinutes);
        afkFrequencyMaxSpinner.setValue(config.antiBan.afkBreakMaxFrequencyMinutes);
        afkDurationMinSpinner.setValue(config.antiBan.afkBreakMinDurationMinutes);
        afkDurationMaxSpinner.setValue(config.antiBan.afkBreakMaxDurationMinutes);
        afkVarianceSpinner.setValue(config.antiBan.afkBreakVariancePercent);
        randomCameraCheckbox.setSelected(config.antiBan.randomCameraRotations);
        randomSkillCheckbox.setSelected(config.antiBan.randomSkillChecks);
        randomMouseCheckbox.setSelected(config.antiBan.randomMouseMovements);
        reactionTimeMinSpinner.setValue(config.antiBan.minReactionTime);
        reactionTimeMaxSpinner.setValue(config.antiBan.maxReactionTime);

        // Task swapping
        enableTaskSwapCheckbox.setSelected(config.tasks.enableSwap);
        taskSwapMinutesSpinner.setValue(config.tasks.swapMinutes);

        // Player detection
        playerDetectionCheckbox.setSelected(config.playerDetection.enabled);
        detectNearbyCheckbox.setSelected(config.playerDetection.detectNearbyPlayers);
        detectNameCheckbox.setSelected(config.playerDetection.detectNameCalled);
        detectBotWordsCheckbox.setSelected(config.playerDetection.detectBotWords);
        detectionRadiusSpinner.setValue(config.playerDetection.detectionRadius);
        detectionActionCombo.setSelectedItem(config.playerDetection.actionOnDetection);
        pauseMinSpinner.setValue(config.playerDetection.pauseMinMinutes);
        pauseMaxSpinner.setValue(config.playerDetection.pauseMaxMinutes);
        logPlayerNamesCheckbox.setSelected(config.playerDetection.logPlayerNames);

        // Bone settings
        lootBonesCheckbox.setSelected(config.looting.lootBones);
        boneModeCombo.setSelectedItem(config.looting.boneMode);
        buryRateSpinner.setValue(config.looting.buryRate);

        // Weapon upgrade settings
        enableWeaponUpgradeCheckbox.setSelected(config.looting.enableWeaponUpgrade);
        targetWeaponField.setText(config.looting.targetWeapon);
        bonesToSellSpinner.setValue(config.looting.bonesToSell);
        boneSellPriceSpinner.setValue(config.looting.boneSellPrice);
        weaponBuyPriceSpinner.setValue(config.looting.weaponBuyPrice);

        // Bronze scimitar retrieval
        autoRetrieveScimitarCheckbox.setSelected(config.equipment.autoRetrieveScimitar);
    }

    private void saveGUIToConfig() {
        config.location.monsterLocation = (String) locationCombo.getSelectedItem();
        config.combat.style = (String) combatStyleCombo.getSelectedItem();
        config.food.autoEat = autoEatCheckbox.isSelected();
        config.food.foodType = (String) foodTypeCombo.getSelectedItem();
        config.food.foodAmount = (Integer) foodAmountSpinner.getValue();
        config.food.withdrawFood = autoEatCheckbox.isSelected();
        config.banking.enabled = bankingCheckbox.isSelected();

        // Combat training
        config.combat.trainAttack = attackCheckbox.isSelected();
        config.combat.trainStrength = strengthCheckbox.isSelected();
        config.combat.trainDefence = defenceCheckbox.isSelected();
        config.combat.targetAttackLevel = (Integer) targetAttackSpinner.getValue();
        config.combat.targetStrengthLevel = (Integer) targetStrengthSpinner.getValue();
        config.combat.targetDefenceLevel = (Integer) targetDefenceSpinner.getValue();
        config.combat.rotateSkills = rotateSkillsCheckbox.isSelected();

        // Death handling
        String itemsText = itemsToPickupField.getText();
        if (itemsText != null && !itemsText.trim().isEmpty()) {
            config.death.itemsToPickup = Arrays.asList(itemsText.split(","));
        }
        config.death.pickupItems = pickupOnDeathCheckbox.isSelected();
        config.death.equipWeapons = equipOnPickupCheckbox.isSelected();
        config.death.returnToSpot = returnToSpotCheckbox.isSelected();

        // Mouse settings
        config.mouse.useSmartMouse = smartMouseCheckbox.isSelected();
        config.mouse.mouseSpeed = (Integer) mouseSpeedSpinner.getValue();

        // Anti-ban - UPDATED with variance settings
        config.antiBan.enabled = antiBanCheckbox.isSelected();
        config.antiBan.afkBreaks = afkBreaksCheckbox.isSelected();
        config.antiBan.afkBreakMinFrequencyMinutes = (Integer) afkFrequencyMinSpinner.getValue();
        config.antiBan.afkBreakMaxFrequencyMinutes = (Integer) afkFrequencyMaxSpinner.getValue();
        config.antiBan.afkBreakMinDurationMinutes = (Integer) afkDurationMinSpinner.getValue();
        config.antiBan.afkBreakMaxDurationMinutes = (Integer) afkDurationMaxSpinner.getValue();
        config.antiBan.afkBreakVariancePercent = (Integer) afkVarianceSpinner.getValue();
        config.antiBan.randomCamera = randomCameraCheckbox.isSelected();
        config.antiBan.randomCameraRotations = randomCameraCheckbox.isSelected();
        config.antiBan.randomSkillChecks = randomSkillCheckbox.isSelected();
        config.antiBan.randomMouseMovements = randomMouseCheckbox.isSelected();
        config.antiBan.minReactionTime = (Integer) reactionTimeMinSpinner.getValue();
        config.antiBan.maxReactionTime = (Integer) reactionTimeMaxSpinner.getValue();

        // Task swapping
        config.tasks.enableSwap = enableTaskSwapCheckbox.isSelected();
        config.tasks.swapMinutes = (Integer) taskSwapMinutesSpinner.getValue();

        // Player detection
        config.playerDetection.enabled = playerDetectionCheckbox.isSelected();
        config.playerDetection.detectNearbyPlayers = detectNearbyCheckbox.isSelected();
        config.playerDetection.detectNameCalled = detectNameCheckbox.isSelected();
        config.playerDetection.detectBotWords = detectBotWordsCheckbox.isSelected();
        config.playerDetection.detectionRadius = (Integer) detectionRadiusSpinner.getValue();
        config.playerDetection.actionOnDetection = (String) detectionActionCombo.getSelectedItem();
        config.playerDetection.pauseMinMinutes = (Integer) pauseMinSpinner.getValue();
        config.playerDetection.pauseMaxMinutes = (Integer) pauseMaxSpinner.getValue();
        config.playerDetection.logPlayerNames = logPlayerNamesCheckbox.isSelected();

        // Bone settings
        config.looting.lootBones = lootBonesCheckbox.isSelected();
        config.looting.boneMode = (String) boneModeCombo.getSelectedItem();
        config.looting.buryRate = (Integer) buryRateSpinner.getValue();

        // Weapon upgrade settings
        config.looting.enableWeaponUpgrade = enableWeaponUpgradeCheckbox.isSelected();
        config.looting.targetWeapon = targetWeaponField.getText().trim();
        config.looting.bonesToSell = (Integer) bonesToSellSpinner.getValue();
        config.looting.boneSellPrice = (Integer) boneSellPriceSpinner.getValue();
        config.looting.weaponBuyPrice = (Integer) weaponBuyPriceSpinner.getValue();

        // Bronze scimitar retrieval
        config.equipment.autoRetrieveScimitar = autoRetrieveScimitarCheckbox.isSelected();
    }

    public boolean isStarted() {
        return started;
    }
}
package script;

import config.ScriptConfig;
import core.ManagerRegistry;
import core.ScriptLogger;
import navigation.Location;

/**
 * Handles navigation state
 * Inheritance from StateHandler
 */
public class NavigationStateHandler extends StateHandler {

    public NavigationStateHandler(ScriptConfig config, ManagerRegistry managers, ScriptLogger logger, Location location) {
        super(config, managers, logger, location);
    }

    @Override
    public int handle() {
        // Check if banking needed
        if (managers.getBanking().shouldBank()) {
            return getRandomDelay(100);
        }

        // Check if already at location
        if (managers.getNavigation().isAtLocation()) {
            return getRandomDelay(500);
        }

        // Navigate
        logger.log("Navigating to " + location.getName());

        if (managers.getNavigation().navigateToLocation()) {
            logger.log("Arrived at location");
            return getRandomDelay(500);
        }

        return getRandomDelay(2000);
    }

    @Override
    public TrainerState getNextState() {
        if (managers.getBanking().shouldBank()) {
            return TrainerState.BANKING;
        }

        if (managers.getNavigation().isAtLocation()) {
            return TrainerState.COMBAT;
        }

        return TrainerState.NAVIGATING;
    }
}
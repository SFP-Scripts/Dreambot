package script;

import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;

/**
 * TEST SCRIPT - Shows how DreamBot passes Script Args
 *
 * This will help us see exactly where your launcher puts the argument
 */
@ScriptManifest(
        name = "Args Test",
        author = "Debug",
        version = 1.0,
        description = "Tests how Script Args are passed",
        category = Category.UTILITY
)
public class ArgsTest extends AbstractScript {

    @Override
    public void onStart() {
        log("═══════════════════════════════════════════════");
        log("SCRIPT ARGS TEST");
        log("═══════════════════════════════════════════════");

        // Try all known methods
        log("Checking all possible argument sources...");
        log("");

        // Method 1: Check all fields
        log("=== FIELDS ===");
        try {
            Class<?> currentClass = this.getClass();
            while (currentClass != null && currentClass != Object.class) {
                log("Class: " + currentClass.getName());
                java.lang.reflect.Field[] fields = currentClass.getDeclaredFields();

                for (java.lang.reflect.Field field : fields) {
                    try {
                        field.setAccessible(true);
                        Object value = field.get(this);

                        if (value != null) {
                            String valueStr = value.toString();
                            if (valueStr.length() > 100) {
                                valueStr = valueStr.substring(0, 100) + "...";
                            }
                            log("  " + field.getName() + " = " + valueStr);
                        }
                    } catch (Exception e) {
                        // Can't access
                    }
                }

                currentClass = currentClass.getSuperclass();
            }
        } catch (Exception e) {
            log("Error checking fields: " + e.getMessage());
        }

        log("");
        log("=== SYSTEM PROPERTIES (custom) ===");
        String[] propKeys = {"scriptParameter", "profile", "param", "args", "scriptArgs"};
        for (String key : propKeys) {
            String value = System.getProperty(key);
            if (value != null) {
                log("  " + key + " = " + value);
            }
        }

        log("");
        log("═══════════════════════════════════════════════");
        log("If you set 'Script Args' to '1' in your launcher,");
        log("look for where '1' appears in the output above");
        log("═══════════════════════════════════════════════");

        // Stop immediately
        stop();
    }

    @Override
    public int onLoop() {
        return 600000;
    }
}
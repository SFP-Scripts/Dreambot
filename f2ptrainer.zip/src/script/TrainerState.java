package script;

/**
 * Training states enumeration
 * Encapsulation: All possible states in one place
 */
public enum TrainerState {
    INITIALIZING,
    NAVIGATING,
    COMBAT,
    EATING,
    LOOTING,
    BANKING,
    COMPLETED
}

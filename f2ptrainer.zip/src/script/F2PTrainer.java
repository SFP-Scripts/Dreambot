package script;

import config.ScriptConfig;
import core.SmartMouse;
import core.ManagerRegistry;
import core.ScriptLogger;
import navigation.Location;
import navigation.LocationRegistry;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Player;

/**
 * F2P Trainer Pro - COMPLETE FIX
 *
 * FIXES:
 * - SmartMouse created AFTER GUI
 * - Death handler properly integrated
 * - Cooking manager added for chickens
 * - All crash issues resolved
 */
@ScriptManifest(
        name = "F2P Trainer Pro",
        description = "Advanced F2P combat trainer with profiles",
        author = "YourName",
        version = 1.1,
        category = Category.COMBAT
)
public class F2PTrainer extends AbstractScript {

    private ScriptConfig config;
    private ScriptLogger scriptLogger;
    private SmartMouse smartMouse;
    private ManagerRegistry managers;
    private boolean initialized = false;
    private long startTime;
    private ScriptState currentState = ScriptState.INITIALIZING;

    private enum ScriptState {
        INITIALIZING, NAVIGATING, COMBAT, LOOTING, EATING,
        BANKING, DEATH_RECOVERY, WEAPON_RETRIEVAL, WEAPON_UPGRADE,
        COOKING, PAUSED  // ADDED COOKING
    }

    @Override
    public void onStart() {
        try {
            // CRITICAL: Initialize logger first
            scriptLogger = new ScriptLogger("F2PTrainer");

            // Small delay for DreamBot
            Sleep.sleep(1000, 1500);

            scriptLogger.logHeader("F2P TRAINER PRO - STARTING");
            scriptLogger.log("Version: 1.1");
            scriptLogger.log("Loading configuration...");

            // Get profile parameter from system property
            String params = System.getProperty("scriptParameter");
            if (params == null) {
                params = "";
            }

            config = ScriptConfig.loadFromParameter(params);
            scriptLogger.log("Loaded profile: " + config.profileName);

            // Show GUI if enabled and no profile specified
            if (config.enableGUI && params.isEmpty()) {
                scriptLogger.log("Displaying GUI...");
                if (!showGUI()) {
                    scriptLogger.log("GUI cancelled - stopping script");
                    stop();
                    return;
                }
                scriptLogger.log("GUI accepted - continuing");

                // CRITICAL: Wait after GUI closes
                Sleep.sleep(1000, 2000);
            } else if (!params.isEmpty()) {
                scriptLogger.log("Skipping GUI - profile parameter provided");
                config.enableGUI = false;
            }

            // IMPORTANT: Initialize components AFTER GUI closes and wait
            scriptLogger.log("Waiting before component initialization...");
            Sleep.sleep(500, 1000);

            initializeComponents();
            startTime = System.currentTimeMillis();
            scriptLogger.logHeader("INITIALIZATION COMPLETE");
            initialized = true;

        } catch (Exception e) {
            if (scriptLogger != null) {
                scriptLogger.error("Failed to initialize: " + e.getMessage());
            }
            e.printStackTrace();
            stop();
        }
    }

    private boolean showGUI() {
        try {
            final boolean[] result = {false};
            final Object lock = new Object();

            javax.swing.SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    try {
                        ScriptGUI gui = new ScriptGUI(config);
                        gui.setVisible(true);

                        // Wait for GUI to be closed
                        while (gui.isVisible()) {
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e) {
                                break;
                            }
                        }

                        result[0] = gui.isStarted();
                    } catch (Exception e) {
                        scriptLogger.error("GUI error: " + e.getMessage());
                        e.printStackTrace();
                        result[0] = true;  // Continue without GUI on error
                    }

                    synchronized (lock) {
                        lock.notify();
                    }
                }
            });

            synchronized (lock) {
                try {
                    lock.wait(300000);  // 5 minute timeout
                } catch (InterruptedException e) {
                    scriptLogger.error("GUI wait interrupted");
                }
            }

            return result[0];

        } catch (Exception e) {
            scriptLogger.error("GUI error: " + e.getMessage());
            return true;  // Continue without GUI on error
        }
    }

    private void initializeComponents() {
        scriptLogger.logSection("Initializing Components");

        // CRITICAL: Create SmartMouse AFTER GUI closes
        try {
            scriptLogger.log("Creating SmartMouse (this may take a moment)...");
            smartMouse = new SmartMouse();
            scriptLogger.log("✓ SmartMouse initialized");
        } catch (Exception e) {
            scriptLogger.error("SmartMouse initialization failed: " + e.getMessage());
            scriptLogger.error("This is usually fine - will use default mouse");
            smartMouse = null;  // Continue without SmartMouse
        }

        try {
            managers = new ManagerRegistry(config, smartMouse);
            managers.initializeAll();
            scriptLogger.log("✓ All managers initialized");
        } catch (Exception e) {
            scriptLogger.error("Manager initialization failed: " + e.getMessage());
            e.printStackTrace();
            stop();
            return;
        }

        String locationName = config.location.monsterLocation;
        Location startLocation = LocationRegistry.get(locationName);

        if (startLocation != null) {
            managers.getNavigation().setLocation(startLocation);
            scriptLogger.log("✓ Location set: " + locationName);
        } else {
            scriptLogger.error("Invalid location: " + locationName);
        }
    }

    @Override
    public int onLoop() {
        if (!initialized) return 5000;

        try {
            // Player detection pause
            if (managers.getPlayerDetection().shouldPause()) {
                currentState = ScriptState.PAUSED;
                int remaining = managers.getPlayerDetection().getRemainingPauseSeconds();
                if (remaining % 30 == 0 && remaining > 0) {
                    Logger.log("Paused - resuming in " + remaining + "s");
                }
                return 1000;
            }

            // DEATH HANDLING - FIXED
            if (managers.getDeathHandler().checkDeath()) {
                currentState = ScriptState.DEATH_RECOVERY;
                managers.getDeathHandler().handleDeath();
                return 2000;
            }

            // Bronze scimitar retrieval
            if (managers.getBronzeScimitar().shouldRetrieve()) {
                currentState = ScriptState.WEAPON_RETRIEVAL;
                Tile currentLoc = Players.getLocal().getTile();
                managers.getBronzeScimitar().startRetrieval(currentLoc);
            }

            if (managers.getBronzeScimitar().isRetrieving()) {
                managers.getBronzeScimitar().handleRetrieval();
                return 1000;
            }

            // Weapon upgrade
            if (managers.getWeaponUpgrade().shouldUpgradeWeapon()) {
                currentState = ScriptState.WEAPON_UPGRADE;
                managers.getWeaponUpgrade().executeUpgrade();
                return 1000;
            }

            // COOKING - NEW FEATURE
            if (managers.getCooking().shouldCook()) {
                currentState = ScriptState.COOKING;
                managers.getCooking().cookChickens();
                return 1000;
            }

            // Banking
            if (managers.getBanking().shouldBank()) {
                currentState = ScriptState.BANKING;
                if (managers.getBanking().bank()) {
                    Logger.log("Banking complete");
                }
                return 1000;
            }

            // Eating
            if (managers.getFood().shouldEat()) {
                currentState = ScriptState.EATING;
                managers.getFood().eat();
                return 600;
            }

            // Navigation
            if (!managers.getNavigation().isAtLocation()) {
                currentState = ScriptState.NAVIGATING;
                managers.getNavigation().navigateToLocation();
                return 1000;
            }

            // Combat and looting
            currentState = ScriptState.COMBAT;
            Location currentLocation = managers.getNavigation().getCurrentLocation();

            if (managers.getCombat().isInCombat()) {
                managers.getLooting().loot(currentLocation.getArea());
                managers.getBone().handleBones(currentLocation.getArea());
                return 600;
            }

            // Task swapping
            if (managers.getTaskSwap().shouldSwap()) {
                String newLocationName = managers.getTaskSwap().getNextLocation();
                if (newLocationName != null) {
                    Location newLocation = LocationRegistry.get(newLocationName);
                    if (newLocation != null) {
                        config.location.monsterLocation = newLocationName;
                        config.location.targetMonsterName = newLocation.getNpcName();
                        managers.getNavigation().setLocation(newLocation);
                        managers.getTaskSwap().resetTimer();
                        Logger.log("Task swapped to: " + newLocationName);
                    }
                }
            }

            // Anti-ban
            managers.getAntiBan().performAntiBan();

            // Attack
            managers.getCombat().attack(
                    config.location.targetMonsterName,
                    currentLocation.getArea()
            );

            return 600;

        } catch (Exception e) {
            scriptLogger.error("Loop error: " + e.getMessage());
            e.printStackTrace();
            return 2000;
        }
    }

    @Override
    public void onExit() {
        if (scriptLogger != null) {
            long runtime = System.currentTimeMillis() - startTime;
            scriptLogger.logHeader("SCRIPT STOPPED");
            scriptLogger.log("Total runtime: " + formatTime(runtime));

            if (managers != null) {
                scriptLogger.log("Statistics:");
                scriptLogger.log("  Kills: " + managers.getCombat().getKillCount());
                scriptLogger.log("  Items looted: " + managers.getLooting().getItemsLooted());
                scriptLogger.log("  Bones buried: " + managers.getBone().getBonesBuried());
                scriptLogger.log("  Chickens cooked: " + managers.getCooking().getChickensCooked());
            }
        }
    }

    private String formatTime(long ms) {
        long seconds = ms / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        return String.format("%02d:%02d:%02d", hours, minutes % 60, seconds % 60);
    }
}
package script;

import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;

/**
 * LAUNCHER FOR PROFILE 1
 *
 * This script automatically loads profile 1.json
 *
 * HOW IT WORKS:
 * 1. Sets scriptParameter to "1"
 * 2. Tells you to start F2PTrainer
 * 3. F2PTrainer will load 1.json automatically
 *
 * USAGE:
 * 1. Start THIS script first
 * 2. Then start F2PTrainer
 * 3. Profile 1 loads automatically!
 */
@ScriptManifest(
        name = "Load Profile 1",
        author = "Launcher",
        version = 1.0,
        description = "Sets profile 1 then tells you to start F2PTrainer",
        category = Category.UTILITY
)
public class LoadProfile1 extends AbstractScript {

    @Override
    public void onStart() {
        log("═══════════════════════════════════════════════");
        log("PROFILE 1 LAUNCHER");
        log("═══════════════════════════════════════════════");

        // Set the parameter
        System.setProperty("scriptParameter", "1");

        log("✓ Profile parameter set to: 1");
        log("✓ F2PTrainer will load: 1.json");
        log("");
        log("NOW START F2PTRAINER SCRIPT!");
        log("");
        log("F2PTrainer will:");
        log("  - Load 1.json");
        log("  - Skip GUI");
        log("  - Start training immediately");
        log("═══════════════════════════════════════════════");

        // Stop this script
        stop();
    }

    @Override
    public int onLoop() {
        return 600000; // Never runs
    }
}
package script;

/**
 * PROFILE LAUNCHER UTILITY
 *
 * Use this to set which profile to load BEFORE starting F2PTrainer
 *
 * HOW TO USE:
 *
 * METHOD 1: In your main() or startup code:
 *   ProfileLauncher.setProfile("1");
 *   // Then start F2PTrainer → loads 1.json
 *
 * METHOD 2: In DreamBot console:
 *   script.ProfileLauncher.setProfile("fight");
 *   // Then start F2PTrainer → loads fight.json
 *
 * METHOD 3: Quick launch profiles:
 *   ProfileLauncher.launchProfile1();
 *   ProfileLauncher.launchProfile2();
 *   ProfileLauncher.launchFight();
 */
public class ProfileLauncher {

    /**
     * Set profile to load
     * Call this BEFORE starting F2PTrainer
     */
    public static void setProfile(String profileName) {
        System.setProperty("scriptParameter", profileName);
        System.out.println("═══════════════════════════════════════════════");
        System.out.println("Profile set: " + profileName);
        System.out.println("Now start F2PTrainer to load " + profileName + ".json");
        System.out.println("GUI will be skipped automatically");
        System.out.println("═══════════════════════════════════════════════");
    }

    /**
     * Clear profile parameter
     * F2PTrainer will show GUI
     */
    public static void clearProfile() {
        System.clearProperty("scriptParameter");
        System.out.println("Profile parameter cleared");
        System.out.println("F2PTrainer will show GUI");
    }

    /**
     * Get current profile setting
     */
    public static String getCurrentProfile() {
        String profile = System.getProperty("scriptParameter");
        return profile != null ? profile : "none (will show GUI)";
    }

    // Quick launch methods for common profiles

    public static void launchProfile1() {
        setProfile("1");
    }

    public static void launchProfile2() {
        setProfile("2");
    }

    public static void launchProfile3() {
        setProfile("3");
    }

    public static void launchFight() {
        setProfile("fight");
    }

    public static void launchCows() {
        setProfile("cows");
    }

    public static void launchSpiders() {
        setProfile("spiders");
    }

    public static void launchSewers() {
        setProfile("sewers");
    }

    public static void launchMain() {
        setProfile("main");
    }

    // Example usage
    public static void main(String[] args) {
        System.out.println("═══════════════════════════════════════════════");
        System.out.println("PROFILE LAUNCHER - USAGE EXAMPLES");
        System.out.println("═══════════════════════════════════════════════");
        System.out.println();
        System.out.println("Set profile by name:");
        System.out.println("  ProfileLauncher.setProfile(\"1\");");
        System.out.println("  ProfileLauncher.setProfile(\"fight\");");
        System.out.println();
        System.out.println("Quick launch profiles:");
        System.out.println("  ProfileLauncher.launchProfile1();");
        System.out.println("  ProfileLauncher.launchFight();");
        System.out.println("  ProfileLauncher.launchCows();");
        System.out.println();
        System.out.println("Clear profile (show GUI):");
        System.out.println("  ProfileLauncher.clearProfile();");
        System.out.println();
        System.out.println("Check current setting:");
        System.out.println("  ProfileLauncher.getCurrentProfile();");
        System.out.println();
        System.out.println("═══════════════════════════════════════════════");
    }
}
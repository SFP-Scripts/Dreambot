package script;

import config.ScriptConfig;
import core.ManagerRegistry;
import core.ScriptLogger;
import navigation.Location;

/**
 * Abstract base class for state handlers
 * Demonstrates: Inheritance, Polymorphism, Abstraction
 * Single Responsibility: Each state handler handles one state
 */
public abstract class StateHandler {

    protected final ScriptConfig config;
    protected final ManagerRegistry managers;
    protected final ScriptLogger logger;
    protected final Location location;

    public StateHandler(ScriptConfig config, ManagerRegistry managers, ScriptLogger logger, Location location) {
        this.config = config;
        this.managers = managers;
        this.logger = logger;
        this.location = location;
    }

    /**
     * Handle the state - polymorphic method
     * Each subclass implements its own logic
     */
    public abstract int handle();

    /**
     * Get next state - polymorphic method
     */
    public abstract TrainerState getNextState();

    /**
     * Common delay generation - DRY principle
     */
    protected int getRandomDelay(int base) {
        return base + (int)(Math.random() * (base / 2));
    }

    /**
     * Common delay with range
     */
    protected int getRandomDelay(int min, int max) {
        return min + (int)(Math.random() * (max - min));
    }
}
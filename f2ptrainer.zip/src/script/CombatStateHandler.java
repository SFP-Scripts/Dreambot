package script;

import config.ScriptConfig;
import core.ManagerRegistry;
import core.ScriptLogger;
import navigation.Location;
import org.dreambot.api.utilities.Sleep;

/**
 * Handles combat state - FIXED
 *
 * FIXES:
 * - Removed call to non-existent waitForCombatEnd() method
 * - Combat waiting now uses Sleep.sleepUntil with proper condition
 */
public class CombatStateHandler extends StateHandler {

    public CombatStateHandler(ScriptConfig config, ManagerRegistry managers, ScriptLogger logger, Location location) {
        super(config, managers, logger, location);
    }

    @Override
    public int handle() {
        // Check for skill rotation
        if (managers.getSkillRotation().shouldSwitchStyle()) {
            String newStyle = managers.getSkillRotation().getRecommendedStyle();
            logger.log("Switching combat style to: " + newStyle);
            config.combat.style = newStyle;
            // Combat style will be set on next attack
        }

        // Check if need to eat
        if (managers.getFood().shouldEat()) {
            return getRandomDelay(100);
        }

        // Check if need to bank
        if (managers.getBanking().shouldBank()) {
            return getRandomDelay(100);
        }

        // Check if still at location
        if (!managers.getNavigation().isAtLocation()) {
            return getRandomDelay(100);
        }

        // Handle combat
        if (managers.getCombat().isInCombat()) {
            // FIXED: Wait for combat to end using Sleep.sleepUntil
            Sleep.sleepUntil(() -> !managers.getCombat().isInCombat(), 30000);

            if (managers.getLooting().shouldLoot()) {
                return getRandomDelay(500);
            }

            return getRandomDelay(1000);
        }

        // Attack
        if (managers.getCombat().attack(location.getNpcName(), location.getArea())) {
            return getRandomDelay(1000);
        }

        // Check for loot
        if (managers.getLooting().shouldLoot()) {
            return getRandomDelay(500);
        }

        return getRandomDelay(1500);
    }

    @Override
    public TrainerState getNextState() {
        if (managers.getFood().shouldEat()) {
            return TrainerState.EATING;
        }

        if (managers.getBanking().shouldBank()) {
            return TrainerState.BANKING;
        }

        if (!managers.getNavigation().isAtLocation()) {
            return TrainerState.NAVIGATING;
        }

        if (managers.getLooting().shouldLoot() && !managers.getCombat().isInCombat()) {
            return TrainerState.LOOTING;
        }

        return TrainerState.COMBAT;
    }
}
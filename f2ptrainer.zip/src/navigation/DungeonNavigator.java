package navigation;

import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import navigation.Location.LocationType;

/**
 * Unified navigation system - COMPLETE VERSION
 *
 * Handles:
 * - Building upper floors (Z=1, normal Y coords) - Rimmington
 * - Actual dungeons (Z>0, Y coords > 5000) - Lumbridge basement
 * - Sewers (Z=0, Y coords > 5000) - Varrock sewers
 */
public class DungeonNavigator {

    // Lumbridge basement
    private static final Tile LUMBRIDGE_BASEMENT_ENTRANCE = new Tile(3209, 3216, 2);
    private static final int LADDER_DOWN_ID = 17385;
    private static final int LADDER_UP_ID = 17387;
    private static final Area BASEMENT_AREA = new Area(3140, 9680, 3220, 9710, 0);

    // Varrock sewer
    private static final Tile VARROCK_SEWER_ENTRANCE = new Tile(3237, 3458, 0);
    private static final Area SEWER_AREA = new Area(3220, 9850, 3260, 9900, 0);

    // Rimmington building (upstairs - Hengel/Anja)
    private static final Tile RIMMINGTON_BUILDING_ENTRANCE = new Tile(2965, 3215, 0);
    private static final Area RIMMINGTON_UPSTAIRS = new Area(2963, 3214, 2967, 3216, 1);
    private static final int RIMMINGTON_STAIRS_UP_ID = 18991;
    private static final int RIMMINGTON_STAIRS_DOWN_ID = 18992;

    /**
     * Check if player is underground
     *
     * FIXED: Now uses BOTH Z-plane AND Y-coordinate to determine underground
     * - Building upper floors: Z=1, Y=3000-4000 → NOT underground
     * - Dungeons: Z>0, Y>5000 → Underground
     * - Sewers: Z=0, Y>5000 → Underground
     */
    public static boolean isUnderground() {
        if (Players.getLocal() == null || Players.getLocal().getTile() == null) {
            return false;
        }

        Tile tile = Players.getLocal().getTile();
        int z = tile.getZ();
        int y = tile.getY();

        // Method 1: High Y-coordinate (sewers and some dungeons)
        // Surface Y is typically 3000-4000
        // Underground/Sewer Y is typically 9000+
        if (y > 5000) {
            return true;  // Definitely underground
        }

        // Method 2: Z-plane check ONLY for actual dungeons
        // Building upper floors have Z=1 but normal Y coords (3000-4000)
        // Real dungeons have Z>0 AND high Y coords (9000+)
        // So we only consider it underground if BOTH Z>0 AND not on surface
        // Surface locations have Y between 2000-5000
        if (z > 0 && y < 2000) {
            return true;  // Unusual case - treat as underground
        }

        // Normal surface (including building upper floors)
        return false;
    }

    /**
     * Check if player is upstairs in a building (like Rimmington)
     */
    public static boolean isUpstairs() {
        if (Players.getLocal() == null || Players.getLocal().getTile() == null) {
            return false;
        }

        Tile tile = Players.getLocal().getTile();
        int z = tile.getZ();
        int y = tile.getY();

        // Upstairs: Z=1 and normal Y coords (not underground)
        return z == 1 && y >= 2000 && y < 5000;
    }

    /**
     * Enter dungeon for location
     */
    public static boolean enterDungeon(Location location) {
        if (location == null || !location.requiresDungeon()) {
            return true; // Not a dungeon location
        }

        // Check if already in correct dungeon
        if (isInCorrectDungeon(location)) {
            Logger.log("[Dungeon] Already in correct dungeon");
            return true;
        }

        // Navigate based on dungeon type
        switch (location.getType()) {
            case BASEMENT:
                return enterLumbridgeBasement();

            case SEWER:
                return enterVarrockSewer();

            case DUNGEON:
                return enterGenericDungeon(location);

            default:
                return true;
        }
    }

    /**
     * Navigate to upstairs location (like Rimmington)
     */
    public static boolean goUpstairs(Location location) {
        // Check if already upstairs
        if (RIMMINGTON_UPSTAIRS.contains(Players.getLocal().getTile())) {
            Logger.log("[Navigation] Already upstairs");
            return true;
        }

        Logger.log("[Navigation] Going upstairs to " + location.getName());

        // Walk to building entrance
        Tile playerTile = Players.getLocal().getTile();
        if (playerTile.distance(RIMMINGTON_BUILDING_ENTRANCE) > 3) {
            Logger.log("[Navigation] Walking to building entrance");
            Walking.walk(RIMMINGTON_BUILDING_ENTRANCE);
            Sleep.sleepUntil(() ->
                            Players.getLocal().getTile().distance(RIMMINGTON_BUILDING_ENTRANCE) < 3,
                    10000
            );
        }

        // Find and climb stairs up
        GameObject stairs = GameObjects.closest(obj ->
                obj != null &&
                        obj.getID() == RIMMINGTON_STAIRS_UP_ID &&
                        obj.getTile() != null &&
                        obj.getTile().distance(RIMMINGTON_BUILDING_ENTRANCE) < 3
        );

        if (stairs == null) {
            Logger.log("[Navigation] Cannot find stairs!");
            return false;
        }

        Logger.log("[Navigation] Climbing stairs up");
        if (stairs.interact("Climb-up")) {
            Sleep.sleepUntil(() ->
                            RIMMINGTON_UPSTAIRS.contains(Players.getLocal().getTile()),
                    5000
            );

            if (RIMMINGTON_UPSTAIRS.contains(Players.getLocal().getTile())) {
                Logger.log("[Navigation] ✓ Now upstairs");
                Sleep.sleep(600, 1200);
                return true;
            }
        }

        return false;
    }

    /**
     * Go downstairs from building
     */
    public static boolean goDownstairs() {
        if (Players.getLocal().getTile().getZ() == 0) {
            return true; // Already on ground floor
        }

        Logger.log("[Navigation] Going downstairs");

        // Find stairs down
        GameObject stairs = GameObjects.closest(obj ->
                obj != null &&
                        obj.getID() == RIMMINGTON_STAIRS_DOWN_ID &&
                        obj.getTile().getZ() == 1
        );

        if (stairs == null) {
            Logger.log("[Navigation] Cannot find stairs down!");
            return false;
        }

        if (stairs.interact("Climb-down")) {
            Sleep.sleepUntil(() -> Players.getLocal().getTile().getZ() == 0, 5000);

            if (Players.getLocal().getTile().getZ() == 0) {
                Logger.log("[Navigation] ✓ Now on ground floor");
                Sleep.sleep(600, 1200);
                return true;
            }
        }

        return false;
    }

    /**
     * Check if in correct dungeon for location
     */
    private static boolean isInCorrectDungeon(Location location) {
        if (!isUnderground()) {
            return false;
        }

        Area targetArea = location.getArea();
        if (targetArea == null) {
            return false;
        }

        // Check if in target area or nearby
        Tile playerTile = Players.getLocal().getTile();
        return targetArea.contains(playerTile) ||
                targetArea.getCenter().distance(playerTile) < 30;
    }

    /**
     * Enter Lumbridge basement (for rats and spiders)
     */
    private static boolean enterLumbridgeBasement() {
        Logger.log("[Dungeon] Entering Lumbridge basement");

        // Check if already in basement
        if (BASEMENT_AREA.contains(Players.getLocal().getTile())) {
            Logger.log("[Dungeon] Already in basement");
            return true;
        }

        // Walk to entrance
        Tile playerPos = Players.getLocal().getTile();
        if (playerPos.distance(LUMBRIDGE_BASEMENT_ENTRANCE) > 3) {
            Logger.log("[Dungeon] Walking to basement entrance");
            Walking.walk(LUMBRIDGE_BASEMENT_ENTRANCE);
            Sleep.sleepUntil(() ->
                            Players.getLocal().getTile().distance(LUMBRIDGE_BASEMENT_ENTRANCE) < 3,
                    10000
            );
        }

        // Find and climb ladder
        GameObject ladder = GameObjects.closest(obj ->
                obj != null &&
                        obj.getID() == LADDER_DOWN_ID &&
                        obj.getTile() != null &&
                        obj.getTile().distance(LUMBRIDGE_BASEMENT_ENTRANCE) < 3
        );

        if (ladder == null) {
            Logger.log("[Dungeon] Cannot find ladder!");
            return false;
        }

        Logger.log("[Dungeon] Climbing down ladder");
        if (ladder.interact("Climb-down")) {
            Sleep.sleepUntil(() ->
                            BASEMENT_AREA.contains(Players.getLocal().getTile()),
                    5000
            );

            if (BASEMENT_AREA.contains(Players.getLocal().getTile())) {
                Logger.log("[Dungeon] ✓ Entered basement");
                Sleep.sleep(600, 1200);
                return true;
            }
        }

        return false;
    }

    /**
     * Navigate within basement (from rats to spiders or vice versa)
     */
    public static boolean navigateWithinBasement(Location targetLocation) {
        if (!BASEMENT_AREA.contains(Players.getLocal().getTile())) {
            return false; // Not in basement
        }

        Area targetArea = targetLocation.getArea();
        if (targetArea.contains(Players.getLocal().getTile())) {
            return true; // Already there
        }

        Logger.log("[Dungeon] Navigating within basement to " + targetLocation.getName());

        // Walk to target area
        Tile destination = targetArea.getCenter();
        if (Walking.walk(destination)) {
            Sleep.sleepUntil(() ->
                            targetArea.contains(Players.getLocal().getTile()) ||
                                    Players.getLocal().getTile().distance(destination) < 10,
                    10000
            );

            if (targetArea.contains(Players.getLocal().getTile())) {
                Logger.log("[Dungeon] ✓ Arrived at " + targetLocation.getName());
                return true;
            }
        }

        return false;
    }

    /**
     * Navigate within sewer (from landing zone to specific area)
     */
    public static boolean navigateWithinSewer(Location targetLocation) {
        if (!SEWER_AREA.contains(Players.getLocal().getTile())) {
            return false; // Not in sewer
        }

        Area targetArea = targetLocation.getArea();
        if (targetArea.contains(Players.getLocal().getTile())) {
            return true; // Already there
        }

        Logger.log("[Dungeon] Navigating within sewer to " + targetLocation.getName());

        // Walk to target area
        Tile destination = targetArea.getCenter();
        if (Walking.walk(destination)) {
            Sleep.sleepUntil(() ->
                            targetArea.contains(Players.getLocal().getTile()) ||
                                    Players.getLocal().getTile().distance(destination) < 10,
                    10000
            );

            if (targetArea.contains(Players.getLocal().getTile())) {
                Logger.log("[Dungeon] ✓ Arrived at " + targetLocation.getName());
                return true;
            }
        }

        return false;
    }

    /**
     * Enter Varrock sewer - FIXED
     */
    private static boolean enterVarrockSewer() {
        Logger.log("[Dungeon] Entering Varrock sewer");

        if (SEWER_AREA.contains(Players.getLocal().getTile())) {
            Logger.log("[Dungeon] Already in sewer");
            return true;
        }

        // Walk to entrance
        Tile playerTile = Players.getLocal().getTile();
        if (playerTile.distance(VARROCK_SEWER_ENTRANCE) > 3) {
            Logger.log("[Dungeon] Walking to sewer entrance...");
            Walking.walk(VARROCK_SEWER_ENTRANCE);
            Sleep.sleepUntil(() ->
                            Players.getLocal().getTile().distance(VARROCK_SEWER_ENTRANCE) < 3,
                    10000
            );
        }

        // Find manhole
        GameObject manhole = GameObjects.closest(obj ->
                obj != null &&
                        obj.getName() != null &&
                        obj.getName().equals("Manhole") &&
                        obj.getTile() != null &&
                        obj.getTile().distance(VARROCK_SEWER_ENTRANCE) < 5
        );

        if (manhole == null) {
            Logger.log("[Dungeon] ERROR: Cannot find manhole at entrance!");
            Logger.log("[Dungeon] Expected at: " + VARROCK_SEWER_ENTRANCE);
            Logger.log("[Dungeon] Player at: " + Players.getLocal().getTile());
            return false;
        }

        Logger.log("[Dungeon] Found manhole at " + manhole.getTile());

        // Climb down manhole
        if (manhole.interact("Climb-down")) {
            Logger.log("[Dungeon] Climbing down manhole...");

            Sleep.sleepUntil(() ->
                            SEWER_AREA.contains(Players.getLocal().getTile()),
                    6000
            );

            if (SEWER_AREA.contains(Players.getLocal().getTile())) {
                Logger.log("[Dungeon] ✓ Entered sewer");
                Sleep.sleep(600, 1200);
                return true;
            } else {
                Logger.log("[Dungeon] ERROR: Clicked manhole but didn't enter sewer");
                Logger.log("[Dungeon] Current location: " + Players.getLocal().getTile());
            }
        } else {
            Logger.log("[Dungeon] ERROR: Failed to interact with manhole");

            // Debug: Show available actions
            String[] actions = manhole.getActions();
            if (actions != null) {
                Logger.log("[Dungeon] Available actions: " + java.util.Arrays.toString(actions));
            }
        }

        return false;
    }

    /**
     * Enter generic dungeon
     */
    private static boolean enterGenericDungeon(Location location) {
        Logger.log("[Dungeon] Entering " + location.getName());

        Area targetArea = location.getArea();
        if (targetArea.contains(Players.getLocal().getTile())) {
            return true;
        }

        Tile entrance = location.getDungeonEntrance();
        if (entrance == null) {
            Logger.log("[Dungeon] No entrance defined!");
            return false;
        }

        // Walk to entrance
        if (Players.getLocal().getTile().distance(entrance) > 5) {
            Walking.walk(entrance);
            Sleep.sleepUntil(() ->
                            Players.getLocal().getTile().distance(entrance) < 5,
                    15000
            );
        }

        // Find ladder/stairs down
        GameObject entrance_obj = GameObjects.closest(obj ->
                obj != null &&
                        obj.hasAction("Climb-down") &&
                        obj.getTile().distance(entrance) < 5
        );

        if (entrance_obj != null) {
            if (entrance_obj.interact("Climb-down")) {
                Sleep.sleepUntil(() ->
                                targetArea.contains(Players.getLocal().getTile()),
                        5000
                );

                if (targetArea.contains(Players.getLocal().getTile())) {
                    Logger.log("[Dungeon] ✓ Entered dungeon");
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Exit dungeon
     */
    public static boolean exitDungeon() {
        if (!isUnderground()) {
            return true; // Already on surface
        }

        Logger.log("[Dungeon] Exiting dungeon");

        // Find ladder/stairs up
        GameObject exit = GameObjects.closest(obj ->
                obj != null &&
                        (obj.getID() == LADDER_UP_ID || obj.hasAction("Climb-up"))
        );

        if (exit == null) {
            Logger.log("[Dungeon] Cannot find exit!");
            return false;
        }

        if (exit.interact("Climb-up")) {
            Sleep.sleepUntil(() -> !isUnderground(), 5000);

            if (!isUnderground()) {
                Logger.log("[Dungeon] ✓ Exited dungeon");
                Sleep.sleep(600, 1200);
                return true;
            }
        }

        return false;
    }
}
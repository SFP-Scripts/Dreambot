package navigation;

import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import navigation.Location.LocationType;

import java.util.HashMap;
import java.util.Map;

/**
 * FINAL F2P Location Registry - Only Verified Working Locations
 *
 * REMOVED: Varrock Sewer Rats (too complex, bot gets stuck)
 * USE INSTEAD: Lumbridge Swamp Rats (surface, easy, reliable)
 *
 * All coordinates verified and tested
 */
public class LocationRegistry {

    private static final Map<String, Location> locations = new HashMap<>();

    static {
        registerAllLocations();
    }

    private static void registerAllLocations() {
        // ═══════════════════════════════════════════════════════════
        // BEGINNER LOCATIONS (Level 1-20)
        // ═══════════════════════════════════════════════════════════

        // Lumbridge Chickens
        register(new Location(
                "Lumbridge Chickens",
                "Chicken",
                new Area(3174, 3278, 3196, 3300, 0)
        ));

        // Lumbridge Cows
        register(new Location(
                "Lumbridge Cows",
                "Cow",
                new Area(3240, 3254, 3265, 3300, 0)
        ));

        // Port Sarim Seagulls
        register(new Location(
                "Port Sarim Seagulls",
                "Seagull",
                new Area(3021, 3234, 3048, 3258, 0)
        ));

        // Lumbridge Goblins
        register(new Location(
                "Lumbridge Goblins",
                "Goblin",
                new Area(3243, 3244, 3252, 3251, 0)
        ));

        // Lumbridge Swamp Giant Rats (RECOMMENDED for rats - surface, easy)
        register(new Location(
                "Lumbridge Swamp Rats",
                "Giant rat",
                new Area(3224, 3154, 3245, 3172, 0)
        ));

        // Lumbridge Castle Rats (Basement)
        register(new Location(
                "Lumbridge Castle Rats",
                "Rat",
                new Area(3198, 9684, 3211, 9699, 0),
                true,
                new Tile(3209, 3216, 2),
                LocationType.BASEMENT
        ));

        // Lumbridge Castle Spiders (Basement)
        register(new Location(
                "Lumbridge Castle Spiders",
                "Spider",
                new Area(3144, 9684, 3188, 9703, 0),
                true,
                new Tile(3209, 3216, 2),
                LocationType.BASEMENT
        ));

        // ═══════════════════════════════════════════════════════════
        // EARLY TRAINING LOCATIONS (Level 20-40)
        // ═══════════════════════════════════════════════════════════

        // Lumbridge Swamp Giant Frogs
        register(new Location(
                "Lumbridge Swamp Frogs",
                "Giant frog",
                new Area(3186, 3148, 3202, 3173, 0)
        ));

        // Barbarian Village
        register(new Location(
                "Barbarian Village",
                "Barbarian",
                new Area(3070, 3415, 3090, 3430, 0)
        ));

        // Edgeville Barbarians
        register(new Location(
                "Edgeville Barbarians",
                "Barbarian",
                new Area(3095, 3430, 3110, 3445, 0)
        ));

        // Stronghold Level 1 - Minotaurs
        register(new Location(
                "Stronghold Minotaurs",
                "Minotaur",
                new Area(1856, 5246, 1918, 5308, 0),
                true,
                new Tile(3081, 3421, 0),
                LocationType.DUNGEON
        ));

        // Goblin Village
        register(new Location(
                "Goblin Village",
                "Goblin",
                new Area(2954, 3495, 2963, 3506, 0)
        ));

        // Hobgoblins - Crafting Guild
        register(new Location(
                "Crafting Guild Hobgoblins",
                "Hobgoblin",
                new Area(2925, 3283, 2945, 3304, 0)
        ));

        // ═══════════════════════════════════════════════════════════
        // MID-LEVEL LOCATIONS (Level 40-60)
        // ═══════════════════════════════════════════════════════════

        // Hill Giants - Edgeville Dungeon
        register(new Location(
                "Edgeville Hill Giants",
                "Hill Giant",
                new Area(3095, 9823, 3120, 9854, 0),
                true,
                new Tile(3096, 3468, 0),
                LocationType.DUNGEON
        ));

        // Stronghold Level 2 - Flesh Crawlers
        register(new Location(
                "Stronghold Flesh Crawlers",
                "Flesh Crawler",
                new Area(2019, 5215, 2085, 5279, 0),
                true,
                new Tile(3081, 3421, 0),
                LocationType.DUNGEON
        ));

        // Stronghold Level 2 - Zombies
        register(new Location(
                "Stronghold Zombies",
                "Zombie",
                new Area(2019, 5215, 2085, 5279, 0),
                true,
                new Tile(3081, 3421, 0),
                LocationType.DUNGEON
        ));

        // ═══════════════════════════════════════════════════════════
        // VARROCK SEWER LOCATIONS (Working ones only)
        // ═══════════════════════════════════════════════════════════

        // Varrock Sewer - Moss Giants (best F2P XP, 60 HP)
        register(new Location(
                "Varrock Sewer Moss Giants",
                "Moss giant",
                new Area(3145, 9870, 3180, 9900, 0),
                true,
                new Tile(3237, 3458, 0),
                LocationType.SEWER
        ));

        // Varrock Sewer - Skeletons
        register(new Location(
                "Varrock Sewer Skeletons",
                "Skeleton",
                new Area(3244, 9880, 3254, 9892, 0),
                true,
                new Tile(3237, 3458, 0),
                LocationType.SEWER
        ));

        // Varrock Sewer - Zombies
        register(new Location(
                "Varrock Sewer Zombies",
                "Zombie",
                new Area(3228, 9888, 3240, 9900, 0),
                true,
                new Tile(3237, 3458, 0),
                LocationType.SEWER
        ));

        // ═══════════════════════════════════════════════════════════
        // ADVANCED LOCATIONS (Level 60+)
        // ═══════════════════════════════════════════════════════════

        // Giant Spiders - Stronghold Level 3
        register(new Location(
                "Stronghold Giant Spiders",
                "Giant spider",
                new Area(2110, 5275, 2175, 5330, 0),
                true,
                new Tile(3081, 3421, 0),
                LocationType.DUNGEON
        ));

        // Lesser Demons - Karamja Volcano
        register(new Location(
                "Karamja Lesser Demons",
                "Lesser demon",
                new Area(2828, 9549, 2866, 9595, 0),
                true,
                new Tile(2857, 3169, 0),
                LocationType.DUNGEON
        ));

        // Ankous - Stronghold Level 4
        register(new Location(
                "Stronghold Ankous",
                "Ankou",
                new Area(2375, 5223, 2431, 5281, 0),
                true,
                new Tile(3081, 3421, 0),
                LocationType.DUNGEON
        ));

        // ═══════════════════════════════════════════════════════════
        // SPECIAL LOCATIONS - RIMMINGTON
        // ═══════════════════════════════════════════════════════════

        // Rimmington - Hengel
        register(new Location(
                "Rimmington Hengel",
                "Hengel",
                new Area(2963, 3214, 2967, 3216, 1)
        ));

        // Rimmington - Anja (attacks BOTH Hengel & Anja)
        register(new Location(
                "Rimmington Anja",
                "Anja",
                new Area(2963, 3214, 2967, 3216, 1)
        ));

        // ═══════════════════════════════════════════════════════════
        // BOSS LOCATIONS
        // ═══════════════════════════════════════════════════════════

        // Obor - Hill Giant Boss
        register(new Location(
                "Obor Boss",
                "Obor",
                new Area(3093, 9819, 3121, 9849, 0),
                true,
                new Tile(3096, 3468, 0),
                LocationType.DUNGEON
        ));

        // Bryophyta - Moss Giant Boss
        register(new Location(
                "Bryophyta Boss",
                "Bryophyta",
                new Area(3145, 9870, 3180, 9900, 0),
                true,
                new Tile(3237, 3458, 0),
                LocationType.SEWER
        ));
    }

    private static void register(Location location) {
        locations.put(location.getName(), location);
    }

    public static Location get(String name) {
        return locations.get(name);
    }

    public static boolean exists(String name) {
        return locations.containsKey(name);
    }

    public static String[] getAllNames() {
        String[] names = locations.keySet().toArray(new String[0]);
        java.util.Arrays.sort(names);
        return names;
    }

    public static Map<String, Location> getAll() {
        return new HashMap<>(locations);
    }
}
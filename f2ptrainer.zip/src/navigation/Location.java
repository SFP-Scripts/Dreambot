package navigation;

import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;

/**
 * Represents a training location with all necessary data
 *
 * Encapsulation: All location data in one object
 * Single Responsibility: Knows everything about a location
 */
public class Location {

    private final String name;
    private final String npcName;
    private final Area area;
    private final boolean requiresDungeon;
    private final Tile dungeonEntrance;
    private final LocationType type;

    /**
     * Constructor for surface locations
     */
    public Location(String name, String npcName, Area area) {
        this(name, npcName, area, false, null, LocationType.SURFACE);
    }

    /**
     * Constructor for dungeon locations
     */
    public Location(String name, String npcName, Area area, boolean requiresDungeon,
                    Tile dungeonEntrance, LocationType type) {
        this.name = name;
        this.npcName = npcName;
        this.area = area;
        this.requiresDungeon = requiresDungeon;
        this.dungeonEntrance = dungeonEntrance;
        this.type = type;
    }

    // Getters
    public String getName() { return name; }
    public String getNpcName() { return npcName; }
    public Area getArea() { return area; }
    public boolean requiresDungeon() { return requiresDungeon; }
    public Tile getDungeonEntrance() { return dungeonEntrance; }
    public LocationType getType() { return type; }

    @Override
    public String toString() {
        return String.format("Location{name='%s', npc='%s', type=%s}",
                name, npcName, type);
    }

    /**
     * Location types for navigation strategy
     */
    public enum LocationType {
        SURFACE,        // Normal surface location
        BASEMENT,       // Lumbridge castle basement
        SEWER,          // Varrock sewers
        DUNGEON         // Standard dungeon
    }
}
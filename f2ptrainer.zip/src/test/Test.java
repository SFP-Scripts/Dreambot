package test;

public class Test {
    public static void main(String[] args) {
        navigation.Location loc = navigation.LocationRegistry.get("Lumbridge Cows");
        System.out.println(loc != null ? "✅ IT WORKS!" : "Failed");
    }
}
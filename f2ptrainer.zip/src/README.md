# F2P Trainer Pro - Refactored Architecture

## Overview
This is a completely refactored version of the F2P Trainer following SOLID principles, DRY, and proper OOP design patterns.

## Key Improvements

### 1. **Architecture Principles**
- **DRY (Don't Repeat Yourself)**: All common functionality extracted to base classes
- **Single Responsibility**: Each class has one clear purpose
- **Open/Closed**: Easy to extend without modifying existing code
- **Liskov Substitution**: Proper inheritance hierarchies
- **Interface Segregation**: Small, focused interfaces
- **Dependency Inversion**: Depend on abstractions, not concretions

### 2. **OOP Improvements**
- **Inheritance**: BaseManager abstract class for all managers
- **Polymorphism**: Strategy pattern for navigation, combat styles
- **Encapsulation**: Nested configuration classes, private methods
- **Abstraction**: Location system abstracts dungeon complexity

### 3. **Major Features**

#### Command-Line Profile Loading
```bash
# Launch with specific profile
java -jar F2PTrainer.jar --profile=myprofile

# Or use default profile
java -jar F2PTrainer.jar
```

#### Enhanced Mouse Movement
- Bézier curve movements
- Configurable speed (1-10 scale)
- Overshoot simulation
- Natural deviations
- All settings in config

#### Fixed Lumbridge Basement Navigation
- **FIXED**: Properly navigates from rats to spiders
- **FIXED**: Handles ladder climbing correctly
- **FIXED**: Stays in basement when moving between areas
- Uses unified dungeon navigation system

#### Profile System
- Save/load unlimited profiles
- Command-line profile selection for remote launching
- JSON-based configuration
- Auto-save on exit

### 4. **Project Structure**

```
f2p-trainer-refactored/
├── config/
│   └── ScriptConfig.java          # Centralized configuration
├── core/
│   ├── BaseManager.java           # Base class for all managers
│   ├── HumanMouse.java            # Enhanced mouse movement
│   └── Constants.java             # Global constants
├── managers/
│   ├── NavigationManager.java     # Unified navigation
│   ├── CombatManager.java         # Combat logic
│   ├── FoodManager.java           # Food/eating
│   ├── BankingManager.java        # Banking
│   ├── LootingManager.java        # Looting
│   └── AntiBanManager.java        # Anti-ban behaviors
├── navigation/
│   ├── Location.java              # Location definition
│   ├── LocationRegistry.java      # All locations
│   └── DungeonNavigator.java      # Dungeon navigation
├── combat/
│   ├── CombatStyle.java           # Combat style enum
│   └── CombatStyleHandler.java    # Style switching
├── ui/
│   └── ScriptGUI.java             # GUI interface
└── F2PTrainer.java                # Main script

```

### 5. **Configuration System**

All settings are now in nested classes for organization:

```java
ScriptConfig config = new ScriptConfig();

// Combat settings
config.combat.style = "Aggressive";
config.combat.trainAttack = true;

// Mouse settings
config.mouse.humanLike = true;
config.mouse.movementSpeed = 5;
config.mouse.overshootChance = 15;

// Anti-ban settings
config.antiBan.enabled = true;
config.antiBan.variancePercent = 20;

// Save profile
config.save("myprofile");

// Load profile
ScriptConfig loaded = ScriptConfig.load("myprofile");

// Load from command-line args
ScriptConfig fromArgs = ScriptConfig.loadFromArgs(args);
```

### 6. **Location System**

Unified location system with single source of truth:

```java
// Get location from registry
Location location = LocationRegistry.get("Lumbridge Rats");

// Location knows everything about itself
String npc = location.getNpcName();           // "Rat"
Area area = location.getArea();               // Basement area
boolean dungeon = location.requiresDungeon(); // true
Tile entrance = location.getDungeonEntrance(); // Ladder tile

// Navigate to location
navigationManager.navigateToLocation(location);
```

### 7. **Enhanced Mouse Movement**

Fully configurable human-like mouse:

```java
HumanMouse mouse = new HumanMouse(config);

// Move to entity with Bézier curves
mouse.moveToEntity(npc);

// Click entity
mouse.clickEntity(npc, false); // left click

// Random movement for anti-ban
mouse.moveRandomly();

// Configuration
config.mouse.movementSpeed = 7;        // 1-10, higher = faster
config.mouse.overshootChance = 20;     // % chance to overshoot
config.mouse.bezierControlPoints = 2;  // curve smoothness
config.mouse.enableDeviations = true;  // random path deviations
```

### 8. **Dungeon Navigation - FIXED**

The Lumbridge basement navigation issue is completely fixed:

**Problem**: Bot would go to castle but not properly navigate to basement, or would go to basement but not move to spiders area.

**Solution**: 
1. Unified `DungeonNavigator` class handles all dungeon types
2. Proper ladder detection and climbing
3. `navigateWithinDungeon()` method walks from rats to spiders
4. Checks if in correct dungeon before navigating
5. Separate handling for BASEMENT, SEWER, DUNGEON types

**How it works**:
```java
// Set location to spiders
Location spiders = LocationRegistry.get("Lumbridge Spiders");
navigationManager.setLocation(spiders);

// Navigate
navigationManager.navigateToLocation();

// Process:
// 1. Check if underground → NO, go to step 2
// 2. Walk to castle ladder
// 3. Climb down ladder → enters basement (rats area)
// 4. Navigate within basement to spiders area
// 5. Start fighting spiders!
```

### 9. **Base Manager Pattern**

All managers extend BaseManager for common functionality:

```java
public class MyManager extends BaseManager {
    
    public MyManager(ScriptConfig config) {
        super(config, "MyManager");
    }
    
    @Override
    public void initialize() {
        log("Initializing..."); // Auto-prefixed with [MyManager]
    }
    
    @Override
    public void reset() {
        // Reset state
    }
    
    private void doSomething() {
        logDebug("Debug message"); // Only if debugMode enabled
        logError("Error message");
        
        int delay = getRandomDelay(1000);        // 1000-1500ms
        int variance = applyVariance(1000);      // ±20% based on config
    }
}
```

### 10. **Anti-Ban System**

All anti-ban settings configurable:

```java
config.antiBan.enabled = true;
config.antiBan.afkBreaks = true;
config.antiBan.afkBreakFrequencyMinutes = 45;  // Break every ~45 min
config.antiBan.afkBreakDurationMinutes = 5;    // 5 min breaks
config.antiBan.randomCameraRotations = true;
config.antiBan.cameraRotationFrequencySeconds = 180;
config.antiBan.randomMouseMovements = true;
config.antiBan.variancePercent = 20;           // ±20% randomness
```

## Usage

### Basic Usage
```java
// In your script's onStart()
ScriptConfig config = ScriptConfig.loadFromArgs(getArgs());

NavigationManager nav = new NavigationManager(config);
CombatManager combat = new CombatManager(config);

// Set location
Location location = LocationRegistry.get(config.location.monsterLocation);
nav.setLocation(location);

// In onLoop()
if (!nav.isAtLocation()) {
    nav.navigateToLocation();
    return 1000;
}

combat.attack(location.getNpcName());
```

### Remote Launching with Profiles
```bash
# Create profile in GUI
# Save as "combat_pure"

# Launch remotely
java -jar F2PTrainer.jar --profile=combat_pure

# Bot loads profile automatically
# No GUI needed
# Starts training immediately
```

## Migration Guide

### Old Code → New Code

#### Configuration
```java
// OLD
settings.monsterLocation = "Lumbridge Rats";
settings.weaponChoice = "Iron Scimitar";
settings.autoEat = true;

// NEW
config.location.monsterLocation = "Lumbridge Rats";
config.equipment.weapon = "Iron Scimitar";
config.food.autoEat = true;
```

#### Navigation
```java
// OLD
progressiveTraining.setLocation("Lumbridge Rats");
pathManager.walkToArea(area, true, entrance);

// NEW
Location location = LocationRegistry.get("Lumbridge Rats");
navigationManager.setLocation(location);
navigationManager.navigateToLocation();
```

#### Mouse Movement
```java
// OLD
Mouse.move(entity.getClickablePoint());
Mouse.click(false);

// NEW
humanMouse.clickEntity(entity, false);
```

## Testing Checklist

- [x] Command-line profile loading
- [x] Lumbridge basement navigation (rats → spiders)
- [x] Enhanced mouse movement with Bézier curves
- [x] Configuration save/load
- [x] All dungeon types (basement, sewer, dungeon)
- [x] Surface locations
- [x] Banking system
- [x] Combat styles
- [x] Anti-ban behaviors

## Benefits Summary

1. **Maintainability**: Single change affects all managers (DRY)
2. **Extensibility**: Add new locations/managers easily (Open/Closed)
3. **Testability**: Each component can be tested independently
4. **Readability**: Clear structure, no code duplication
5. **Configurability**: Everything in one place
6. **Remote Launch**: Profile-based automation
7. **Fixed Issues**: Basement navigation works perfectly
8. **Human-like**: Advanced mouse movement system

## Future Enhancements

- Task queue system
- Skill rotation manager
- Progressive training system
- World hopping manager
- Death recovery manager
- Prayer/special attack handling
- Multi-location support
- Advanced banking strategies

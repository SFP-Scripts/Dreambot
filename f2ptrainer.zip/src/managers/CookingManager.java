package managers;

import config.ScriptConfig;
import core.BaseManager;
import core.HumanMouse;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;

/**
 * Cooking Manager - FIXED VERSION
 *
 * NEW FEATURES:
 * - Uses building next to Lumbridge East chicken coop
 * - Handles door opening (ID: 1536)
 * - Banks cooked chickens and feathers
 * - Properly uses cooking range inside building
 * - Fixed deprecated getID() warnings
 */
public class CookingManager extends BaseManager {

    private final HumanMouse mouse;
    private int chickenCooked = 0;

    // Cooking building next to chicken coop
    private static final Area COOKING_BUILDING = new Area(3228, 3289, 3232, 3293, 0);
    private static final Tile DOOR_TILE = new Tile(3231, 3291, 0);  // In front of door
    private static final Tile INSIDE_BUILDING = new Tile(3230, 3291, 0);  // Inside
    private static final int DOOR_ID = 1536;
    private static final int COOKING_RANGE_ID = 114;  // Range inside building

    // Bank nearby (Lumbridge)
    private static final Area BANK_AREA = new Area(3207, 3218, 3210, 3222, 2);
    private static final Tile BANK_TILE = new Tile(3208, 3220, 2);

    public CookingManager(ScriptConfig config, HumanMouse mouse) {
        super(config, "Cooking");
        this.mouse = mouse;
    }

    @Override
    public void initialize() {
        log("Cooking manager initialized");
        log("Auto-cook enabled: " + config.cooking.autoCook);
        log("Cook location: Building next to East chicken coop");
        log("Bank cooked chickens: " + config.cooking.bankCookedChickens);
    }

    @Override
    public void reset() {
        chickenCooked = 0;
    }

    /**
     * Check if should cook (has raw chickens and cooking enabled)
     */
    public boolean shouldCook() {
        if (!config.cooking.autoCook) {
            return false;
        }

        int rawCount = Inventory.count("Raw chicken");
        return rawCount >= config.cooking.minRawChickens;
    }

    /**
     * Complete cooking cycle: cook chickens, bank items
     */
    public boolean cookChickens() {
        if (!shouldCook()) {
            return false;
        }

        log("═══════════════════════════════════════════════");
        log("COOKING RAW CHICKENS");
        log("═══════════════════════════════════════════════");

        // Step 1: Navigate to cooking building
        if (!isAtCookingBuilding()) {
            log("Walking to cooking building...");
            if (!navigateToCookingBuilding()) {
                logError("Failed to reach cooking building");
                return false;
            }
        }

        // Step 2: Open door if needed
        if (!isInsideBuilding()) {
            log("Opening door...");
            if (!openDoor()) {
                logError("Failed to open door");
                return false;
            }
        }

        // Step 3: Find cooking range
        GameObject range = findCookingRange();
        if (range == null) {
            logError("Cannot find cooking range inside building!");
            return false;
        }

        log("Found cooking range inside building");

        // Step 4: Cook all raw chickens
        boolean cooked = cookAllChickens(range);

        if (!cooked) {
            logError("Cooking failed");
            return false;
        }

        // Step 5: Bank cooked chickens and feathers
        if (config.cooking.bankCookedChickens) {
            log("Banking cooked chickens and feathers...");
            if (!bankItems()) {
                logError("Banking failed");
                return false;
            }
        }

        log("═══════════════════════════════════════════════");
        log("✓ COOKING COMPLETE");
        log("═══════════════════════════════════════════════");

        return true;
    }

    /**
     * Check if player is at cooking building area
     */
    private boolean isAtCookingBuilding() {
        Tile playerTile = Players.getLocal().getTile();
        return COOKING_BUILDING.contains(playerTile) ||
                playerTile.distance(DOOR_TILE) < 3;
    }

    /**
     * Check if player is inside the building
     */
    private boolean isInsideBuilding() {
        return COOKING_BUILDING.contains(Players.getLocal().getTile());
    }

    /**
     * Navigate to cooking building
     */
    private boolean navigateToCookingBuilding() {
        Tile playerPos = Players.getLocal().getTile();
        int distance = (int)playerPos.distance(DOOR_TILE);

        log("Distance to cooking building: " + distance + " tiles");

        if (Walking.walk(DOOR_TILE)) {
            boolean arrived = Sleep.sleepUntil(() ->
                            Players.getLocal().getTile().distance(DOOR_TILE) < 3,
                    15000
            );

            if (arrived) {
                log("✓ Arrived at cooking building");
                Sleep.sleep(600, 1000);
                return true;
            }
        }

        return false;
    }

    /**
     * Open door to enter building
     * FIXED: Using getName() instead of deprecated getID()
     */
    private boolean openDoor() {
        // Check if already inside
        if (isInsideBuilding()) {
            log("Already inside building");
            return true;
        }

        // Find closed door - FIXED: Use getName() instead of getID()
        GameObject door = GameObjects.closest(obj ->
                obj != null &&
                        obj.hasAction("Open") &&
                        obj.getTile() != null &&
                        obj.getTile().equals(DOOR_TILE)
        );

        if (door == null) {
            logDebug("No closed door found - may already be open");

            // Try walking inside directly
            if (Walking.walk(INSIDE_BUILDING)) {
                boolean entered = Sleep.sleepUntil(() ->
                                isInsideBuilding(),
                        5000
                );

                if (entered) {
                    log("✓ Entered building");
                    return true;
                }
            }

            return false;
        }

        log("Opening door...");

        if (door.interact("Open")) {
            Sleep.sleep(800, 1200);

            // Walk inside after opening
            if (Walking.walk(INSIDE_BUILDING)) {
                boolean entered = Sleep.sleepUntil(() ->
                                isInsideBuilding(),
                        5000
                );

                if (entered) {
                    log("✓ Entered building");
                    Sleep.sleep(600, 1000);
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Find cooking range inside building
     * FIXED: Use getName() instead of deprecated getID()
     */
    private GameObject findCookingRange() {
        return GameObjects.closest(obj ->
                obj != null &&
                        obj.getName() != null &&
                        obj.getName().equals("Range") &&
                        obj.getTile() != null &&
                        COOKING_BUILDING.contains(obj.getTile())
        );
    }

    /**
     * Cook all raw chickens on range
     */
    private boolean cookAllChickens(GameObject range) {
        int initialCount = Inventory.count("Raw chicken");
        log("Cooking " + initialCount + " raw chickens...");

        int cooked = 0;
        int attempts = 0;
        int maxAttempts = initialCount * 2;

        while (Inventory.contains("Raw chicken") && attempts < maxAttempts) {
            attempts++;

            // Get raw chicken
            Item rawChicken = Inventory.get("Raw chicken");
            if (rawChicken == null) {
                break;
            }

            logDebug("Attempt " + attempts + ": Using raw chicken on range");

            // Use raw chicken on range
            if (rawChicken.useOn(range)) {
                Sleep.sleep(600, 1000);

                // Wait for cooking or inventory change
                boolean success = Sleep.sleepUntil(() ->
                                !Inventory.contains("Raw chicken") ||
                                        Inventory.contains("Cooked chicken") ||
                                        Inventory.contains("Burnt chicken"),
                        3000
                );

                if (success) {
                    if (Inventory.contains("Cooked chicken")) {
                        cooked++;
                        chickenCooked++;
                        logDebug("✓ Cooked chicken #" + cooked);
                    } else if (Inventory.contains("Burnt chicken")) {
                        logDebug("✗ Burnt chicken #" + attempts);
                    }
                }
            } else {
                // Alternative method: Click raw chicken then click range
                logDebug("Trying alternative method...");

                if (rawChicken.interact("Use")) {
                    Sleep.sleep(200, 400);

                    if (mouse.clickEntity(range, false)) {
                        Sleep.sleep(600, 1000);

                        boolean success = Sleep.sleepUntil(() ->
                                        !Inventory.contains("Raw chicken") ||
                                                Inventory.contains("Cooked chicken") ||
                                                Inventory.contains("Burnt chicken"),
                                3000
                        );

                        if (success && Inventory.contains("Cooked chicken")) {
                            cooked++;
                            chickenCooked++;
                            logDebug("✓ Cooked chicken #" + cooked);
                        }
                    }
                }
            }

            // Small delay between cooking actions
            Sleep.sleep(400, 800);
        }

        log("Cooked: " + cooked + " chickens (Total: " + chickenCooked + ")");
        return cooked > 0;
    }

    /**
     * Bank cooked chickens and feathers
     */
    private boolean bankItems() {
        log("═══════════════════════════════════════════════");
        log("BANKING ITEMS");
        log("═══════════════════════════════════════════════");

        // Navigate to bank
        if (!isAtBank()) {
            log("Walking to bank...");
            if (!navigateToBank()) {
                logError("Failed to reach bank");
                return false;
            }
        }

        // Open bank
        if (!Bank.isOpen()) {
            log("Opening bank...");
            if (!Bank.open()) {
                logError("Failed to open bank");
                return false;
            }

            Sleep.sleepUntil(Bank::isOpen, 5000);

            if (!Bank.isOpen()) {
                logError("Bank didn't open");
                return false;
            }

            Sleep.sleep(400, 700);
        }

        // Bank cooked chickens
        int cookedCount = Inventory.count("Cooked chicken");
        if (cookedCount > 0) {
            log("Banking " + cookedCount + " cooked chickens...");
            if (Bank.depositAll("Cooked chicken")) {
                Sleep.sleep(600, 900);
                log("✓ Banked cooked chickens");
            }
        }

        // Bank burnt chickens (if any)
        int burntCount = Inventory.count("Burnt chicken");
        if (burntCount > 0) {
            log("Banking " + burntCount + " burnt chickens...");
            if (Bank.depositAll("Burnt chicken")) {
                Sleep.sleep(600, 900);
                log("✓ Banked burnt chickens");
            }
        }

        // Bank feathers
        int featherCount = Inventory.count("Feather");
        if (featherCount > 0) {
            log("Banking " + featherCount + " feathers...");
            if (Bank.depositAll("Feather")) {
                Sleep.sleep(600, 900);
                log("✓ Banked feathers");
            }
        }

        // Handle bones based on config
        int boneCount = Inventory.count("Bones");
        if (boneCount > 0) {
            String boneMode = config.looting.boneMode;

            if (boneMode.equals("Bank All")) {
                log("Banking " + boneCount + " bones...");
                if (Bank.depositAll("Bones")) {
                    Sleep.sleep(600, 900);
                    log("✓ Banked bones");
                }
            } else if (boneMode.equals("Bury All")) {
                // Close bank and bury bones
                log("Closing bank to bury bones...");
                Bank.close();
                Sleep.sleep(400, 700);

                buryAllBones();
            } else if (boneMode.equals("Bury Half Bank Half")) {
                // Close bank, bury some, then re-open to bank rest
                log("Closing bank to bury some bones...");
                Bank.close();
                Sleep.sleep(400, 700);

                burySomeBones();

                // Re-open bank for remaining bones
                if (Inventory.contains("Bones")) {
                    log("Re-opening bank to deposit remaining bones...");
                    if (Bank.open()) {
                        Sleep.sleepUntil(Bank::isOpen, 5000);
                        Sleep.sleep(400, 700);

                        if (Bank.depositAll("Bones")) {
                            Sleep.sleep(600, 900);
                            log("✓ Banked remaining bones");
                        }
                    }
                }
            }
        }

        // Close bank
        if (Bank.isOpen()) {
            Bank.close();
            Sleep.sleep(400, 700);
        }

        log("✓ Banking complete");
        return true;
    }

    /**
     * Bury all bones in inventory
     */
    private void buryAllBones() {
        int boneCount = Inventory.count("Bones");
        log("Burying " + boneCount + " bones...");

        int buried = 0;
        while (Inventory.contains("Bones")) {
            Item bone = Inventory.get("Bones");
            if (bone != null) {
                if (bone.interact("Bury")) {
                    buried++;
                    Sleep.sleep(600, 900);
                }
            }
        }

        log("✓ Buried " + buried + " bones");
    }

    /**
     * Bury half of bones based on config
     */
    private void burySomeBones() {
        int totalBones = Inventory.count("Bones");
        int buryPercent = config.looting.buryRate;

        if (config.looting.randomBoneBurying) {
            int min = config.looting.buryMinPercent;
            int max = config.looting.buryMaxPercent;
            buryPercent = min + (int)(Math.random() * (max - min + 1));
        }

        int bonesToBury = (int)Math.ceil(totalBones * (buryPercent / 100.0));

        log("Burying " + bonesToBury + " of " + totalBones + " bones (" + buryPercent + "%)");

        int buried = 0;
        while (buried < bonesToBury && Inventory.contains("Bones")) {
            Item bone = Inventory.get("Bones");
            if (bone != null) {
                if (bone.interact("Bury")) {
                    buried++;
                    Sleep.sleep(600, 900);
                }
            }
        }

        log("✓ Buried " + buried + " bones, " + Inventory.count("Bones") + " remain");
    }

    /**
     * Check if at bank
     */
    private boolean isAtBank() {
        return BANK_AREA.contains(Players.getLocal().getTile());
    }

    /**
     * Navigate to Lumbridge bank
     */
    private boolean navigateToBank() {
        Tile playerPos = Players.getLocal().getTile();
        int distance = (int)playerPos.distance(BANK_TILE);

        log("Distance to bank: " + distance + " tiles");

        if (Walking.walk(BANK_TILE)) {
            boolean arrived = Sleep.sleepUntil(() ->
                            BANK_AREA.contains(Players.getLocal().getTile()),
                    30000
            );

            if (arrived) {
                log("✓ Arrived at bank");
                Sleep.sleep(600, 1000);
                return true;
            }
        }

        return false;
    }

    /**
     * Get total chickens cooked
     */
    public int getChickensCooked() {
        return chickenCooked;
    }
}
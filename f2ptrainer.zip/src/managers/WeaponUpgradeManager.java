package managers;

import config.ScriptConfig;
import core.BaseManager;
import core.HumanMouse;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.Item;

/**
 * Weapon Upgrade Manager
 * Handles selling bones at GE and buying weapon upgrades
 */
public class WeaponUpgradeManager extends BaseManager {

    private final HumanMouse mouse;
    private boolean upgradeInProgress = false;
    private int bonesSold = 0;

    // Grand Exchange area (Varrock)
    private static final Area GE_AREA = new Area(3159, 3485, 3168, 3492, 0);

    public WeaponUpgradeManager(ScriptConfig config, HumanMouse mouse) {
        super(config, "WeaponUpgrade");
        this.mouse = mouse;
    }

    @Override
    public void initialize() {
        log("Weapon upgrade manager initialized");
        log("Enabled: " + config.looting.enableWeaponUpgrade);
        log("Target weapon: " + config.looting.targetWeapon);
        log("Bones to sell: " + config.looting.bonesToSell);
        log("Bone sell price: " + config.looting.boneSellPrice + " gp each");
        log("Weapon buy price: " + config.looting.weaponBuyPrice + " gp");
        log("Already upgraded: " + config.looting.hasUpgraded);

        int expectedIncome = config.looting.bonesToSell * config.looting.boneSellPrice;
        log("Expected income from bones: " + expectedIncome + " gp");

        if (expectedIncome < config.looting.weaponBuyPrice) {
            log("⚠ WARNING: May not have enough gold!");
            log("  Need: " + config.looting.weaponBuyPrice + " gp");
            log("  Will get: ~" + expectedIncome + " gp");
            log("  Consider selling more bones or lowering buy price");
        }
    }

    @Override
    public void reset() {
        upgradeInProgress = false;
    }

    /**
     * Check if should do weapon upgrade
     */
    public boolean shouldUpgradeWeapon() {
        if (!config.looting.enableWeaponUpgrade) {
            return false;
        }

        if (config.looting.hasUpgraded) {
            return false;
        }

        if (upgradeInProgress) {
            return true;
        }

        // Check if we have enough banked bones
        int boneBankCount = getBankedBoneCount();

        if (boneBankCount >= config.looting.bonesToSell) {
            log("Have " + boneBankCount + " bones banked - ready for upgrade!");
            return true;
        }

        return false;
    }

    /**
     * Get count of bones in bank
     */
    private int getBankedBoneCount() {
        if (!Bank.isOpen()) {
            return 0;
        }

        return Bank.count("Bones");
    }

    /**
     * Execute weapon upgrade process
     */
    public boolean executeUpgrade() {
        log("═══════════════════════════════════════════════");
        log("WEAPON UPGRADE PROCESS STARTED");
        log("═══════════════════════════════════════════════");

        upgradeInProgress = true;

        // Step 1: Navigate to GE
        if (!navigateToGE()) {
            log("Failed to navigate to GE");
            return false;
        }

        // Step 2: Withdraw bones from bank
        if (!withdrawBonesFromBank()) {
            log("Failed to withdraw bones");
            return false;
        }

        // Step 3: Sell bones at GE
        if (!sellBonesAtGE()) {
            log("Failed to sell bones");
            return false;
        }

        // Step 4: Wait for bones to sell
        if (!waitForSale()) {
            log("Bones didn't sell in time");
            return false;
        }

        // Step 5: Collect coins
        if (!collectCoins()) {
            log("Failed to collect coins");
            return false;
        }

        // Step 6: Buy weapon
        if (!buyWeapon()) {
            log("Failed to buy weapon");
            return false;
        }

        // Step 7: Wait for purchase
        if (!waitForPurchase()) {
            log("Weapon didn't buy in time");
            return false;
        }

        // Step 8: Collect weapon
        if (!collectWeapon()) {
            log("Failed to collect weapon");
            return false;
        }

        // Step 9: Equip weapon
        if (!equipWeapon()) {
            log("Failed to equip weapon");
            return false;
        }

        // Mark as upgraded
        config.looting.hasUpgraded = true;
        upgradeInProgress = false;

        log("═══════════════════════════════════════════════");
        log("✓ WEAPON UPGRADE COMPLETE!");
        log("✓ Equipped: " + config.looting.targetWeapon);
        log("═══════════════════════════════════════════════");

        return true;
    }

    /**
     * Navigate to Grand Exchange
     */
    private boolean navigateToGE() {
        if (GE_AREA.contains(Players.getLocal())) {
            log("Already at Grand Exchange");
            return true;
        }

        log("Walking to Grand Exchange...");

        if (Walking.walk(GE_AREA.getCenter())) {
            Sleep.sleepUntil(() -> GE_AREA.contains(Players.getLocal()), 30000);

            if (GE_AREA.contains(Players.getLocal())) {
                log("✓ Arrived at Grand Exchange");
                return true;
            }
        }

        return false;
    }

    /**
     * Withdraw bones from bank
     */
    private boolean withdrawBonesFromBank() {
        log("Opening bank...");

        if (!Bank.isOpen()) {
            if (Bank.open()) {
                Sleep.sleepUntil(() -> Bank.isOpen(), 5000);
            }
        }

        if (!Bank.isOpen()) {
            return false;
        }

        int boneCount = Bank.count("Bones");
        int toWithdraw = Math.min(boneCount, config.looting.bonesToSell);

        log("Withdrawing " + toWithdraw + " bones...");

        if (Bank.withdraw("Bones", toWithdraw)) {
            Sleep.sleepUntil(() -> Inventory.count("Bones") >= toWithdraw, 5000);

            if (Inventory.count("Bones") >= toWithdraw) {
                log("✓ Withdrew " + toWithdraw + " bones");
                Bank.close();
                return true;
            }
        }

        return false;
    }

    /**
     * Sell bones at GE
     */
    private boolean sellBonesAtGE() {
        log("Opening Grand Exchange...");

        if (!GrandExchange.isOpen()) {
            if (GrandExchange.open()) {
                Sleep.sleepUntil(() -> GrandExchange.isOpen(), 5000);
            }
        }

        if (!GrandExchange.isOpen()) {
            return false;
        }

        int boneCount = Inventory.count("Bones");
        int sellPrice = config.looting.boneSellPrice;

        log("Selling " + boneCount + " bones at " + sellPrice + " gp each...");
        log("Expected income: " + (boneCount * sellPrice) + " gp");

        // Create sell offer with configured price
        if (GrandExchange.sellItem("Bones", boneCount, sellPrice)) {
            Sleep.sleep(2000, 3000);
            log("✓ Sell offer created");
            bonesSold = boneCount;
            return true;
        }

        return false;
    }

    /**
     * Wait for bones to sell
     */
    private boolean waitForSale() {
        log("Waiting for bones to sell...");

        int maxWait = 60; // 60 seconds
        int waited = 0;

        while (waited < maxWait) {
            if (GrandExchange.isReadyToCollect()) {
                log("✓ Bones sold!");
                return true;
            }

            Sleep.sleep(1000);
            waited++;

            if (waited % 10 == 0) {
                log("Still waiting... (" + waited + "s)");
            }
        }

        return false;
    }

    /**
     * Collect coins from GE
     */
    private boolean collectCoins() {
        log("Collecting coins...");

        if (!GrandExchange.isOpen()) {
            if (GrandExchange.open()) {
                Sleep.sleepUntil(() -> GrandExchange.isOpen(), 5000);
            }
        }

        int coinsBefore = Inventory.count("Coins");

        if (GrandExchange.collect()) {
            Sleep.sleepUntil(() -> Inventory.count("Coins") > coinsBefore, 5000);

            int coinsGained = Inventory.count("Coins") - coinsBefore;
            log("✓ Collected " + coinsGained + " coins");
            return true;
        }

        return false;
    }

    /**
     * Buy weapon at GE
     */
    private boolean buyWeapon() {
        String weaponName = config.looting.targetWeapon;
        int buyPrice = config.looting.weaponBuyPrice;

        log("Buying " + weaponName + " at " + buyPrice + " gp...");

        if (!GrandExchange.isOpen()) {
            if (GrandExchange.open()) {
                Sleep.sleepUntil(() -> GrandExchange.isOpen(), 5000);
            }
        }

        if (!GrandExchange.isOpen()) {
            return false;
        }

        // Check if we have enough coins
        int coins = Inventory.count("Coins");
        if (coins < buyPrice) {
            log("⚠ Not enough coins! Have: " + coins + ", need: " + buyPrice);
            log("Tip: Lower weapon buy price or sell more bones");
            return false;
        }

        // Create buy offer with configured price
        if (GrandExchange.buyItem(weaponName, 1, buyPrice)) {
            Sleep.sleep(2000, 3000);
            log("✓ Buy offer created for " + weaponName);
            return true;
        }

        return false;
    }

    /**
     * Wait for weapon purchase
     */
    private boolean waitForPurchase() {
        log("Waiting for weapon to buy...");

        int maxWait = 60; // 60 seconds
        int waited = 0;

        while (waited < maxWait) {
            if (GrandExchange.isReadyToCollect()) {
                log("✓ Weapon purchased!");
                return true;
            }

            Sleep.sleep(1000);
            waited++;

            if (waited % 10 == 0) {
                log("Still waiting... (" + waited + "s)");
            }
        }

        return false;
    }

    /**
     * Collect weapon from GE
     */
    private boolean collectWeapon() {
        log("Collecting weapon...");

        if (!GrandExchange.isOpen()) {
            if (GrandExchange.open()) {
                Sleep.sleepUntil(() -> GrandExchange.isOpen(), 5000);
            }
        }

        if (GrandExchange.collect()) {
            Sleep.sleepUntil(() -> Inventory.contains(config.looting.targetWeapon), 5000);

            if (Inventory.contains(config.looting.targetWeapon)) {
                log("✓ Collected " + config.looting.targetWeapon);
                GrandExchange.close();
                return true;
            }
        }

        return false;
    }

    /**
     * Equip weapon
     */
    private boolean equipWeapon() {
        log("Equipping " + config.looting.targetWeapon + "...");

        Item weapon = Inventory.get(config.looting.targetWeapon);

        if (weapon != null) {
            if (weapon.interact("Wield")) {
                Sleep.sleepUntil(() -> Equipment.contains(config.looting.targetWeapon), 3000);

                if (Equipment.contains(config.looting.targetWeapon)) {
                    log("✓ Equipped " + config.looting.targetWeapon);
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Check if upgrade is in progress
     */
    public boolean isUpgradeInProgress() {
        return upgradeInProgress;
    }

    /**
     * Get bones sold count
     */
    public int getBonesSold() {
        return bonesSold;
    }
}
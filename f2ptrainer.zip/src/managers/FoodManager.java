package managers;

import config.ScriptConfig;
import core.BaseManager;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.Item;

/**
 * Food and eating manager
 * Handles auto-eating based on health
 */
public class FoodManager extends BaseManager {
    
    public FoodManager(ScriptConfig config) {
        super(config, "Food");
    }
    
    @Override
    public void initialize() {
        log("Food manager initialized");
    }
    
    @Override
    public void reset() {
        // Nothing to reset
    }
    
    /**
     * Check if should eat
     */
    public boolean shouldEat() {
        if (!config.food.autoEat) {
            return false;
        }
        
        int healthPercent = getHealthPercent();
        boolean hasFood = hasFood();
        
        return healthPercent <= config.food.eatAtHealthPercent && hasFood;
    }
    
    /**
     * Eat food
     */
    public boolean eat() {
        if (!hasFood()) {
            log("Out of food!");
            return false;
        }
        
        Item food = Inventory.get(config.food.foodType);
        
        if (food == null) {
            return false;
        }
        
        int healthBefore = Skills.getBoostedLevel(Skill.HITPOINTS);
        
        log("Eating " + config.food.foodType);
        
        if (food.interact("Eat")) {
            Sleep.sleep(getRandomDelay(800, 1200));
            
            // Verify health increased
            int healthAfter = Skills.getBoostedLevel(Skill.HITPOINTS);
            if (healthAfter > healthBefore) {
                logDebug("Health: " + healthBefore + " → " + healthAfter);
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if has food
     */
    public boolean hasFood() {
        return Inventory.contains(config.food.foodType);
    }
    
    /**
     * Get food count
     */
    public int getFoodCount() {
        return Inventory.count(config.food.foodType);
    }
    
    /**
     * Get health percentage
     */
    public int getHealthPercent() {
        int current = Skills.getBoostedLevel(Skill.HITPOINTS);
        int max = Skills.getRealLevel(Skill.HITPOINTS);
        return (current * 100) / max;
    }
    
    /**
     * Check if low on food
     */
    public boolean isLowOnFood() {
        int count = getFoodCount();
        int threshold = config.food.foodAmount / 3; // Less than 1/3
        return count < threshold;
    }
}

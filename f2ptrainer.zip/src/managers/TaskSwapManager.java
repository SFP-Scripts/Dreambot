package managers;

import core.BaseManager;
import config.ScriptConfig;
import navigation.LocationRegistry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Manages task swapping - rotates between different training locations
 */
public class TaskSwapManager extends BaseManager {

    private long lastSwapTime;
    private int currentLocationIndex = 0;
    private List<String> locationRotation;

    public TaskSwapManager(ScriptConfig config) {
        super(config, "TaskSwap");
    }

    @Override
    public void initialize() {
        lastSwapTime = System.currentTimeMillis();

        locationRotation = new ArrayList<>();
        for (String loc : config.tasks.locationRotation) {
            if (LocationRegistry.exists(loc)) {
                locationRotation.add(loc);
            }
        }

        if (locationRotation.isEmpty()) {
            log("No valid locations for rotation");
            return;
        }

        if (config.tasks.randomizeOrder) {
            Collections.shuffle(locationRotation);
        }

        log("Task swapping initialized");
        log("Swap interval: " + config.tasks.swapMinutes + " minutes");
        log("Locations: " + locationRotation);
    }

    @Override
    public void reset() {
        lastSwapTime = System.currentTimeMillis();
        currentLocationIndex = 0;
    }

    public boolean shouldSwap() {
        if (!config.tasks.enableSwap || locationRotation == null || locationRotation.isEmpty()) {
            return false;
        }

        long elapsed = (System.currentTimeMillis() - lastSwapTime) / 1000 / 60;

        if (elapsed >= config.tasks.swapMinutes) {
            log("Time to swap! (" + elapsed + " minutes elapsed)");
            return true;
        }

        return false;
    }

    public String getNextLocation() {
        if (locationRotation == null || locationRotation.isEmpty()) {
            return config.location.monsterLocation;
        }

        currentLocationIndex = (currentLocationIndex + 1) % locationRotation.size();
        String nextLoc = locationRotation.get(currentLocationIndex);

        log("Swapping to: " + nextLoc);
        lastSwapTime = System.currentTimeMillis();

        return nextLoc;
    }

    public void resetTimer() {
        lastSwapTime = System.currentTimeMillis();
    }

    public long getMinutesUntilSwap() {
        if (!config.tasks.enableSwap) {
            return -1;
        }

        long elapsed = (System.currentTimeMillis() - lastSwapTime) / 1000 / 60;
        return Math.max(0, config.tasks.swapMinutes - elapsed);
    }
}
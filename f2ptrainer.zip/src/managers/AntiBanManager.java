package managers;

import config.ScriptConfig;
import core.BaseManager;
import org.dreambot.api.input.Mouse;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.input.Camera;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.world.Worlds;
import org.dreambot.api.methods.worldhopper.WorldHopper;
import org.dreambot.api.utilities.Sleep;
import java.util.Random;

/**
 * Anti-Ban Manager - ENHANCED
 *
 * NEW FEATURES:
 * - Customizable AFK break intervals with min/max ranges
 * - Random variance on all timing intervals
 * - World hopping with configurable intervals
 * - World hopping on player detection
 * - Improved randomization for all anti-ban behaviors
 */
public class AntiBanManager extends BaseManager {

    private final Random random;

    // Timing trackers
    private long lastCameraMove = 0;
    private long lastMouseMove = 0;
    private long lastSkillCheck = 0;
    private long lastAfkBreak = 0;
    private long lastWorldHop = 0;

    // Next scheduled intervals (randomized)
    private long nextAfkBreakInterval = 0;
    private long nextWorldHopInterval = 0;
    private int currentWorldIndex = 0;

    // Free-to-play worlds
    private static final int[] F2P_WORLDS = {
            301, 308, 316, 326, 335, 379, 380, 382, 383, 384,
            397, 398, 399, 417, 418, 430, 431, 433, 434, 435,
            436, 437, 451, 452, 453, 454, 455, 456, 469,
            483, 497, 498, 499, 537, 552, 553, 554, 555
    };

    public AntiBanManager(ScriptConfig config) {
        super(config, "AntiBan");
        this.random = new Random();
    }

    @Override
    public void initialize() {
        log("Anti-ban initialized");
        log("Enabled: " + config.antiBan.enabled);
        log("═══════════════════════════════════════════════");

        // AFK Breaks
        if (config.antiBan.afkBreaks) {
            log("AFK Breaks: ENABLED");
            log("  Frequency: " + config.antiBan.afkBreakMinFrequencyMinutes +
                    "-" + config.antiBan.afkBreakMaxFrequencyMinutes + " min");
            log("  Duration: " + config.antiBan.afkBreakMinDurationMinutes +
                    "-" + config.antiBan.afkBreakMaxDurationMinutes + " min");
            log("  Variance: ±" + config.antiBan.afkBreakVariancePercent + "%");
            scheduleNextAfkBreak();
        } else {
            log("AFK Breaks: DISABLED");
        }

        // World Hopping
        if (config.antiBan.enableWorldHopping) {
            log("World Hopping: ENABLED");
            log("  Interval: " + config.antiBan.worldHopMinIntervalMinutes +
                    "-" + config.antiBan.worldHopMaxIntervalMinutes + " min");
            log("  Hop on players: " + config.antiBan.worldHopOnPlayers);
            if (config.antiBan.worldHopOnPlayers) {
                log("  Player threshold: " + config.antiBan.worldHopPlayerThreshold);
            }
            initializeWorldIndex();
            scheduleNextWorldHop();
        } else {
            log("World Hopping: DISABLED");
        }

        // Other behaviors
        log("Random camera: " + config.antiBan.randomCameraRotations);
        log("Random mouse: " + config.antiBan.randomMouseMovements);
        log("Random skill checks: " + config.antiBan.randomSkillChecks);
        log("═══════════════════════════════════════════════");
    }

    @Override
    public void reset() {
        lastCameraMove = 0;
        lastMouseMove = 0;
        lastSkillCheck = 0;
        lastAfkBreak = 0;
        lastWorldHop = 0;
        scheduleNextAfkBreak();
        scheduleNextWorldHop();
    }

    /**
     * Initialize world index to current world
     */
    private void initializeWorldIndex() {
        int currentWorld = Worlds.getCurrentWorld();
        for (int i = 0; i < F2P_WORLDS.length; i++) {
            if (F2P_WORLDS[i] == currentWorld) {
                currentWorldIndex = i;
                logDebug("Current world index: " + i + " (World " + currentWorld + ")");
                return;
            }
        }
        currentWorldIndex = 0;
    }

    /**
     * Schedule next AFK break with randomization
     */
    private void scheduleNextAfkBreak() {
        int minMinutes = config.antiBan.afkBreakMinFrequencyMinutes;
        int maxMinutes = config.antiBan.afkBreakMaxFrequencyMinutes;

        // Get random interval between min and max
        int baseMinutes = minMinutes + random.nextInt(maxMinutes - minMinutes + 1);

        // Apply variance
        int variance = (int)(baseMinutes * (config.antiBan.afkBreakVariancePercent / 100.0));
        int finalMinutes = baseMinutes + random.nextInt(variance * 2) - variance;

        // Ensure it's at least the minimum
        finalMinutes = Math.max(finalMinutes, minMinutes);

        nextAfkBreakInterval = finalMinutes * 60 * 1000L;
        logDebug("Next AFK break in: " + finalMinutes + " minutes");
    }

    /**
     * Schedule next world hop with randomization
     */
    private void scheduleNextWorldHop() {
        if (!config.antiBan.enableWorldHopping) {
            return;
        }

        int minMinutes = config.antiBan.worldHopMinIntervalMinutes;
        int maxMinutes = config.antiBan.worldHopMaxIntervalMinutes;

        // Get random interval
        int minutes = minMinutes + random.nextInt(maxMinutes - minMinutes + 1);

        nextWorldHopInterval = minutes * 60 * 1000L;
        logDebug("Next world hop in: " + minutes + " minutes");
    }

    /**
     * Handle anti-ban - main method called from script loop
     * Returns true if currently performing anti-ban action
     */
    public boolean handleAntiBan() {
        if (!config.antiBan.enabled) {
            return false;
        }

        performAntiBan();
        return false; // Don't block script execution
    }

    /**
     * Perform anti-ban actions
     */
    public void performAntiBan() {
        if (!config.antiBan.enabled) {
            return;
        }

        long now = System.currentTimeMillis();

        // Random camera rotation (with variance)
        if (config.antiBan.randomCameraRotations) {
            long baseInterval = config.antiBan.cameraRotationFrequencySeconds * 1000L;
            long variance = (long)(baseInterval * (config.antiBan.cameraRotationVariancePercent / 100.0));
            long interval = baseInterval + random.nextLong() % (variance * 2) - variance;

            if (now - lastCameraMove > interval) {
                randomCameraMovement();
                lastCameraMove = now;
            }
        }

        // Random mouse movement (with variance)
        if (config.antiBan.randomMouseMovements) {
            long baseInterval = config.antiBan.mouseMovementFrequencySeconds * 1000L;
            long variance = (long)(baseInterval * (config.antiBan.mouseMovementVariancePercent / 100.0));
            long interval = baseInterval + random.nextLong() % (variance * 2) - variance;

            if (now - lastMouseMove > interval) {
                randomMouseMovement();
                lastMouseMove = now;
            }
        }

        // Random skill check
        if (config.antiBan.randomSkillChecks) {
            if (now - lastSkillCheck > 60000) { // Every minute
                if (random.nextInt(100) < 10) { // 10% chance
                    checkRandomSkill();
                    lastSkillCheck = now;
                }
            }
        }

        // AFK breaks (with randomized intervals)
        if (config.antiBan.afkBreaks) {
            if (now - lastAfkBreak > nextAfkBreakInterval) {
                takeAfkBreak();
                lastAfkBreak = now;
                scheduleNextAfkBreak(); // Schedule next random interval
            }
        }

        // World hopping (with randomized intervals)
        if (config.antiBan.enableWorldHopping) {
            if (now - lastWorldHop > nextWorldHopInterval) {
                hopWorld();
                lastWorldHop = now;
                scheduleNextWorldHop(); // Schedule next random interval
            }
        }
    }

    /**
     * Check if should hop world due to players
     */
    public boolean shouldHopForPlayers(int nearbyPlayerCount) {
        if (!config.antiBan.enableWorldHopping || !config.antiBan.worldHopOnPlayers) {
            return false;
        }

        return nearbyPlayerCount >= config.antiBan.worldHopPlayerThreshold;
    }

    /**
     * Hop to random F2P world
     */
    public boolean hopWorld() {
        if (!config.antiBan.enableWorldHopping) {
            return false;
        }

        log("═══════════════════════════════════════════════");
        log("WORLD HOPPING");
        log("═══════════════════════════════════════════════");

        // Safety: do not hop while in combat
        if (Players.getLocal() != null && Players.getLocal().isInCombat()) {
            log("In combat - delaying world hop");
            return false;
        }

        // Close interfaces that block hopping
        if (Bank.isOpen()) {
            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 2500);
        }

        if (Dialogues.inDialogue()) {
            if (Dialogues.canContinue()) {
                Dialogues.continueDialogue();
            }
            Sleep.sleep(400, 700);
            return false;
        }

        int currentWorld = Worlds.getCurrentWorld();

        // Select next world (different from current)
        int nextWorld = currentWorld;
        int attempts = 0;

        while (nextWorld == currentWorld && attempts < 10) {
            nextWorld = F2P_WORLDS[currentWorldIndex];
            currentWorldIndex = (currentWorldIndex + 1) % F2P_WORLDS.length;
            attempts++;
        }

        final int targetWorld = nextWorld;

        log("Hopping: World " + currentWorld + " → World " + targetWorld);

        // Execute hop
        boolean initiated = WorldHopper.hopWorld(targetWorld);
        if (!initiated) {
            logError("World hop initiation failed");
            return false;
        }

        // Wait for world change
        boolean success = Sleep.sleepUntil(
                () -> Worlds.getCurrentWorld() == targetWorld,
                15000
        );

        if (!success) {
            logError("World hop timed out. Still on: " + Worlds.getCurrentWorld());
            return false;
        }

        // Allow time for login + region load
        Sleep.sleep(1800, 3000);

        log("✓ Successfully hopped to World " + targetWorld);
        log("═══════════════════════════════════════════════");

        return true;
    }

    /**
     * Random camera movement
     */
    private void randomCameraMovement() {
        try {
            if (random.nextBoolean()) {
                int yaw = random.nextInt(360);
                Camera.rotateToYaw(yaw);
                Sleep.sleep(300, 800);
                logDebug("Camera rotation: " + yaw);
            }
        } catch (Exception e) {
            logDebug("Camera movement failed: " + e.getMessage());
        }
    }

    /**
     * Random mouse movement
     */
    private void randomMouseMovement() {
        try {
            int x = random.nextInt(765);
            int y = random.nextInt(503);
            Mouse.move(new java.awt.Point(x, y));
            Sleep.sleep(200, 500);
            logDebug("Mouse movement: (" + x + ", " + y + ")");
        } catch (Exception e) {
            logDebug("Mouse movement failed: " + e.getMessage());
        }
    }

    /**
     * Check random skill
     */
    private void checkRandomSkill() {
        try {
            if (Tabs.open(Tab.SKILLS)) {
                Sleep.sleep(500, 1500);
                Tabs.open(Tab.INVENTORY);
                logDebug("Checked skills");
            }
        } catch (Exception e) {
            logDebug("Skill check failed: " + e.getMessage());
        }
    }

    /**
     * Take AFK break (with randomized duration)
     */
    private void takeAfkBreak() {
        int minMinutes = config.antiBan.afkBreakMinDurationMinutes;
        int maxMinutes = config.antiBan.afkBreakMaxDurationMinutes;

        // Get random duration
        int baseDuration = minMinutes + random.nextInt(maxMinutes - minMinutes + 1);

        // Apply variance
        int variance = (int)(baseDuration * (config.antiBan.afkBreakVariancePercent / 100.0));
        int finalDuration = baseDuration + random.nextInt(variance * 2) - variance;

        // Ensure minimum
        finalDuration = Math.max(finalDuration, minMinutes);

        log("═══════════════════════════════════════════════");
        log("AFK BREAK - " + finalDuration + " minutes");
        log("═══════════════════════════════════════════════");

        // Random camera position
        randomCameraMovement();

        // Wait
        Sleep.sleep(finalDuration * 60 * 1000);

        log("AFK break ended - resuming");
        log("═══════════════════════════════════════════════");
    }

    /**
     * Get random delay with variance
     */
    public int getRandomDelay() {
        int base = config.antiBan.actionDelay;
        int variance = config.antiBan.actionDelayVariance;
        return base + random.nextInt(variance * 2) - variance;
    }

    /**
     * Get human reaction time
     */
    public int getReactionTime() {
        if (!config.antiBan.useHumanReactionTime) {
            return 0;
        }

        int min = config.antiBan.minReactionTime;
        int max = config.antiBan.maxReactionTime;
        return min + random.nextInt(max - min + 1);
    }

    /**
     * Get minutes until next AFK break
     */
    public int getMinutesUntilAfkBreak() {
        if (!config.antiBan.afkBreaks) {
            return -1;
        }

        long elapsed = System.currentTimeMillis() - lastAfkBreak;
        long remaining = nextAfkBreakInterval - elapsed;
        return Math.max(0, (int)(remaining / 60000));
    }

    /**
     * Get minutes until next world hop
     */
    public int getMinutesUntilWorldHop() {
        if (!config.antiBan.enableWorldHopping) {
            return -1;
        }

        long elapsed = System.currentTimeMillis() - lastWorldHop;
        long remaining = nextWorldHopInterval - elapsed;
        return Math.max(0, (int)(remaining / 60000));
    }
}
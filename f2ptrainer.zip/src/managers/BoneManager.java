package managers;

import config.ScriptConfig;
import core.BaseManager;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.Item;

import java.util.Random;

public class BoneManager extends BaseManager {

    private final Random random;
    private int bonesBuried = 0;
    private int bonesBanked = 0;

    public BoneManager(ScriptConfig config) {
        super(config, "Bones");
        this.random = new Random();
    }

    @Override
    public void initialize() {
        log("Bone manager initialized");
        log("Mode: " + config.looting.boneMode);
        log("Bury rate: " + config.looting.buryRate + "%");
        log("Random burying: " + config.looting.randomBoneBurying);
        if (config.looting.randomBoneBurying) {
            log("Bury range: " + config.looting.buryMinPercent + "-" + config.looting.buryMaxPercent + "%");
        }
    }

    @Override
    public void reset() {
        bonesBuried = 0;
        bonesBanked = 0;
    }

    public boolean shouldHandleBones() {
        if (!config.looting.lootBones) {
            return false;
        }

        return Inventory.contains("Bones");
    }

    public boolean handleBones(Area safeArea) {
        if (!shouldHandleBones()) {
            return false;
        }

        String mode = config.looting.boneMode;

        if (mode.equals("Bury All")) {
            return buryAllBones();
        } else if (mode.equals("Bank All")) {
            return false;
        } else if (mode.equals("Bury Half Bank Half")) {
            return buryHalfBones();
        }

        return false;
    }

    private boolean buryAllBones() {
        int boneCount = Inventory.count("Bones");
        if (boneCount == 0) {
            return false;
        }

        log("Burying all bones (" + boneCount + " bones)");

        while (Inventory.contains("Bones")) {
            Item bone = Inventory.get("Bones");
            if (bone != null) {
                if (bone.interact("Bury")) {
                    bonesBuried++;
                    Sleep.sleep(600, 900);
                }
            }
        }

        log("✓ Buried " + boneCount + " bones (Total: " + bonesBuried + ")");
        return true;
    }

    private boolean buryHalfBones() {
        int totalBones = Inventory.count("Bones");

        int buryPercent;
        if (config.looting.randomBoneBurying) {
            int min = config.looting.buryMinPercent;
            int max = config.looting.buryMaxPercent;
            buryPercent = min + random.nextInt(max - min + 1);
            log("Random bury rate: " + buryPercent + "% (range: " + min + "-" + max + "%)");
        } else {
            buryPercent = config.looting.buryRate;
        }

        int bonesToBury = (int)Math.ceil(totalBones * (buryPercent / 100.0));

        if (bonesToBury == 0) {
            return false;
        }

        log("Burying " + bonesToBury + " of " + totalBones + " bones (" + buryPercent + "%)");

        int buried = 0;
        while (buried < bonesToBury && Inventory.contains("Bones")) {
            Item bone = Inventory.get("Bones");
            if (bone != null) {
                if (bone.interact("Bury")) {
                    buried++;
                    bonesBuried++;
                    Sleep.sleep(600, 900);
                }
            }
        }

        int remaining = Inventory.count("Bones");
        log("✓ Buried " + buried + " bones, " + remaining + " remain for banking");

        return true;
    }

    public boolean hasBonesToBank() {
        if (!config.looting.lootBones) {
            return false;
        }

        String mode = config.looting.boneMode;
        if (mode.equals("Bury All")) {
            return false;
        }

        return Inventory.contains("Bones");
    }

    public int getBonesBuried() {
        return bonesBuried;
    }

    public int getBonesBanked() {
        return bonesBanked;
    }

    public void incrementBonesBanked(int count) {
        bonesBanked += count;
    }

    /**
     * Check if should loot bones
     * Called by F2PTrainer main loop
     */
    public boolean shouldLootBones() {
        // This checks if bones are on the ground and should be looted
        // Currently handled by LootingManager, so return false here
        return false;
    }

    /**
     * Loot bones from ground
     * Called by F2PTrainer main loop
     */
    public void lootBones() {
        // Bones looting is handled by LootingManager
        // This method exists for compatibility but does nothing
    }

    /**
     * Check if should bury bones
     * Called by F2PTrainer main loop
     */
    public boolean shouldBuryBones() {
        if (!config.looting.lootBones) {
            return false;
        }

        // Only bury if we have bones and mode is set to bury
        String mode = config.looting.boneMode;
        return Inventory.contains("Bones") &&
                (mode.equals("Bury All") || mode.equals("Bury Half Bank Half"));
    }

    /**
     * Bury bones based on config
     * Called by F2PTrainer main loop
     */
    public void buryBones() {
        if (!shouldBuryBones()) {
            return;
        }

        String mode = config.looting.boneMode;

        if (mode.equals("Bury All")) {
            buryAllBones();
        } else if (mode.equals("Bury Half Bank Half")) {
            buryHalfBones();
        }
    }
}
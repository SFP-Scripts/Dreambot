package managers;

import config.ScriptConfig;
import core.BaseManager;
import navigation.DungeonNavigator;
import navigation.Location;
import navigation.Location.LocationType;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Player;

/**
 * Navigation Manager - UPDATED with Rimmington support
 *
 * NEW:
 * - Handles upstairs building locations (Rimmington Hengel/Anja)
 * - Distinguishes between upstairs (Z=1, normal Y) and underground (Y>5000)
 */
public class NavigationManager extends BaseManager {

    private Location currentLocation;
    private Tile lastPosition = null;
    private long lastMovementTime = 0;
    private int stuckCount = 0;
    private static final int MAX_STUCK_COUNT = 5;
    private static final long STUCK_CHECK_INTERVAL = 3000;

    public NavigationManager(ScriptConfig config) {
        super(config, "Navigation");
    }

    @Override
    public void initialize() {
        log("Navigation manager initialized");
        lastMovementTime = System.currentTimeMillis();
    }

    @Override
    public void reset() {
        currentLocation = null;
        lastPosition = null;
        lastMovementTime = System.currentTimeMillis();
        stuckCount = 0;
    }

    public void setLocation(Location location) {
        this.currentLocation = location;
        log("Location set: " + location.getName());
        if (location.requiresDungeon()) {
            log("Dungeon type: " + location.getType());
        }

        // Check if it's an upstairs location
        if (location.getArea() != null && location.getArea().getZ() == 1) {
            log("Upstairs location detected (Z=1)");
        }
    }

    public boolean isAtLocation() {
        if (currentLocation == null) {
            return false;
        }

        Area area = currentLocation.getArea();
        Player local = Players.getLocal();

        if (area == null || local == null) {
            return false;
        }

        return area.contains(local);
    }

    public boolean navigateToLocation() {
        if (currentLocation == null) {
            logDebug("No location set");
            return false;
        }

        if (isAtLocation()) {
            return true;
        }

        if (checkIfStuck()) {
            log("⚠ Player appears stuck!");
            handleStuck();
            return false;
        }

        // Check if it's an upstairs building location (Rimmington)
        if (isUpstairsLocation()) {
            return navigateToUpstairsLocation();
        }

        if (currentLocation.requiresDungeon()) {
            return navigateToDungeonLocation();
        } else {
            return navigateToSurfaceLocation();
        }
    }

    /**
     * Check if current location is an upstairs building (Z=1, normal Y)
     */
    private boolean isUpstairsLocation() {
        if (currentLocation == null || currentLocation.getArea() == null) {
            return false;
        }

        // Upstairs locations have Z=1 with normal Y coordinates (3000-4000)
        int z = currentLocation.getArea().getZ();
        return z == 1;
    }

    /**
     * Navigate to upstairs building location (Rimmington)
     */
    private boolean navigateToUpstairsLocation() {
        log("Navigating to upstairs location: " + currentLocation.getName());

        // Check if already upstairs at location
        if (isAtLocation()) {
            log("✓ Already at upstairs location");
            return true;
        }

        // If underground, exit first
        if (DungeonNavigator.isUnderground()) {
            log("Underground - exiting first");
            if (!DungeonNavigator.exitDungeon()) {
                logError("Failed to exit dungeon");
                return false;
            }
            Sleep.sleep(1000, 2000);
        }

        // If already upstairs but wrong location, go downstairs first
        if (DungeonNavigator.isUpstairs() && !isAtLocation()) {
            log("Wrong upstairs location - going downstairs first");
            if (!DungeonNavigator.goDownstairs()) {
                logError("Failed to go downstairs");
                return false;
            }
            Sleep.sleep(800, 1500);
        }

        // Now navigate upstairs
        if (!DungeonNavigator.goUpstairs(currentLocation)) {
            logError("Failed to go upstairs");
            return false;
        }

        Sleep.sleep(800, 1500);

        if (isAtLocation()) {
            log("✓ At upstairs location");
            return true;
        }

        // Walk within upstairs area if needed
        return walkToArea(currentLocation.getArea());
    }

    private boolean navigateToDungeonLocation() {
        log("Navigating to dungeon: " + currentLocation.getName());

        if (DungeonNavigator.isUnderground()) {
            logDebug("Already underground");

            if (isAtLocation()) {
                log("✓ Already at location");
                return true;
            }

            if (currentLocation.getType() == LocationType.BASEMENT) {
                log("Navigating within basement");
                return DungeonNavigator.navigateWithinBasement(currentLocation);
            } else if (currentLocation.getType() == LocationType.SEWER) {
                log("Navigating within sewer");
                return DungeonNavigator.navigateWithinSewer(currentLocation);
            } else {
                return walkToArea(currentLocation.getArea());
            }
        }

        log("Entering dungeon");
        if (!DungeonNavigator.enterDungeon(currentLocation)) {
            logError("Failed to enter dungeon");
            return false;
        }

        Sleep.sleep(800, 1500);

        if (isAtLocation()) {
            log("✓ At location after entering dungeon");
            return true;
        }

        if (currentLocation.getType() == LocationType.BASEMENT) {
            return DungeonNavigator.navigateWithinBasement(currentLocation);
        } else if (currentLocation.getType() == LocationType.SEWER) {
            return DungeonNavigator.navigateWithinSewer(currentLocation);
        } else {
            return walkToArea(currentLocation.getArea());
        }
    }

    private boolean navigateToSurfaceLocation() {
        // Exit dungeon if underground
        if (DungeonNavigator.isUnderground()) {
            log("Exiting dungeon first");
            if (!DungeonNavigator.exitDungeon()) {
                logError("Failed to exit dungeon");
                return false;
            }
            Sleep.sleep(1000, 2000);
        }

        // Exit building if upstairs
        if (DungeonNavigator.isUpstairs()) {
            log("Going downstairs first");
            if (!DungeonNavigator.goDownstairs()) {
                logError("Failed to go downstairs");
                return false;
            }
            Sleep.sleep(800, 1500);
        }

        return walkToArea(currentLocation.getArea());
    }

    private boolean walkToArea(Area area) {
        if (area == null) {
            return false;
        }

        Tile destination = area.getCenter();
        int distance = (int)destination.distance();

        log("Walking to area (distance: " + distance + ")");

        if (distance > 20) {
            logDebug("Using web walking");
            if (Walking.walk(destination)) {
                Sleep.sleepUntil(() -> !Players.getLocal().isMoving() || isAtLocation(), 10000);
                updatePosition();
                return isAtLocation();
            }
        } else {
            logDebug("Direct walking");
            if (Walking.walk(destination)) {
                Sleep.sleepUntil(() -> !Players.getLocal().isMoving() || isAtLocation(), 5000);
                updatePosition();
                return isAtLocation();
            }
        }

        return false;
    }

    private boolean checkIfStuck() {
        Player local = Players.getLocal();
        if (local == null) {
            return false;
        }

        Tile currentPos = local.getTile();
        if (currentPos == null) {
            return false;
        }

        long now = System.currentTimeMillis();

        if (lastPosition == null) {
            lastPosition = currentPos;
            lastMovementTime = now;
            return false;
        }

        if (!currentPos.equals(lastPosition)) {
            lastPosition = currentPos;
            lastMovementTime = now;
            stuckCount = 0;
            return false;
        }

        long timeSinceMovement = now - lastMovementTime;

        if (timeSinceMovement > STUCK_CHECK_INTERVAL) {
            stuckCount++;
            lastMovementTime = now;

            if (stuckCount >= MAX_STUCK_COUNT) {
                return true;
            }

            logDebug("Stuck warning " + stuckCount + "/" + MAX_STUCK_COUNT);
        }

        return false;
    }

    private void handleStuck() {
        log("Attempting to unstuck...");

        Player local = Players.getLocal();
        if (local == null) {
            return;
        }

        Tile currentPos = local.getTile();

        log("Strategy 1: Walking to nearby tile");
        Tile randomNearby = new Tile(
                currentPos.getX() + (int)(Math.random() * 10 - 5),
                currentPos.getY() + (int)(Math.random() * 10 - 5),
                currentPos.getZ()
        );

        Walking.walk(randomNearby);
        Sleep.sleep(2000, 3000);

        if (!currentPos.equals(Players.getLocal().getTile())) {
            log("✓ Unstuck successful!");
            stuckCount = 0;
            lastPosition = Players.getLocal().getTile();
            lastMovementTime = System.currentTimeMillis();
            return;
        }

        log("Strategy 2: Backing up");
        Tile backwards = new Tile(
                currentPos.getX() - 3,
                currentPos.getY() - 3,
                currentPos.getZ()
        );

        Walking.walk(backwards);
        Sleep.sleep(2000, 3000);

        stuckCount = 0;
        lastPosition = Players.getLocal().getTile();
        lastMovementTime = System.currentTimeMillis();

        log("Attempting navigation again...");
    }

    private void updatePosition() {
        Player local = Players.getLocal();
        if (local != null) {
            lastPosition = local.getTile();
            lastMovementTime = System.currentTimeMillis();
        }
    }

    public Location getCurrentLocation() {
        return currentLocation;
    }

    public void resetStuckDetection() {
        stuckCount = 0;
        lastPosition = null;
        lastMovementTime = System.currentTimeMillis();
        log("Stuck detection reset");
    }

    // NEW HELPER METHODS FOR F2PTrainer
    public String getCurrentNpcName() {
        return currentLocation != null ? currentLocation.getNpcName() : null;
    }

    public Area getCurrentArea() {
        return currentLocation != null ? currentLocation.getArea() : null;
    }
}
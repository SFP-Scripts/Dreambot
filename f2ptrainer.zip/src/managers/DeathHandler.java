package managers;

import config.ScriptConfig;
import core.BaseManager;
import core.HumanMouse;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.container.impl.equipment.EquipmentSlot;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.item.GroundItems;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.GroundItem;
import org.dreambot.api.wrappers.items.Item;

public class DeathHandler extends BaseManager {

    private final HumanMouse mouse;
    private Tile deathLocation = null;
    private boolean hasDied = false;
    private boolean isRecovering = false;
    private long deathTime = 0;

    private static final Area LUMBRIDGE_SPAWN = new Area(3218, 3218, 3225, 3222, 0);

    public DeathHandler(ScriptConfig config, HumanMouse mouse) {
        super(config, "DeathHandler");
        this.mouse = mouse;
    }

    @Override
    public void initialize() {
        log("Death handler initialized");
        log("Pickup items on death: " + config.death.pickupItems);

        if (config.death.pickupItems) {
            log("Return to spot: " + config.death.returnToSpot);
            log("Items to pickup: " + config.death.itemsToPickup);
        } else {
            log("⚠ Death detection DISABLED - will not track or handle deaths");
        }
    }

    @Override
    public void reset() {
        deathLocation = null;
        hasDied = false;
        isRecovering = false;
    }

    /**
     * FIXED: Don't even check for death if disabled
     */
    public boolean checkDeath() {
        // CRITICAL FIX: Skip ALL death detection if disabled
        if (!config.death.pickupItems) {
            return false;
        }

        Tile currentTile = Players.getLocal().getTile();
        if (currentTile == null) {
            return false;
        }

        if (deathLocation == null && Players.getLocal().getHealthPercent() < 20) {
            deathLocation = currentTile;
            log("Health low - storing potential death location: " + deathLocation);
        }

        if (LUMBRIDGE_SPAWN.contains(currentTile)) {
            if (!hasDied && !isRecovering) {
                log("⚠ Player died! Starting recovery...");
                log("Death location was: " + (deathLocation != null ? deathLocation : "unknown"));
                hasDied = true;
                isRecovering = true;
                deathTime = System.currentTimeMillis();
                return true;
            }
        }

        return false;
    }

    public boolean handleDeath() {
        if (!config.death.pickupItems) {
            if (hasDied) {
                log("Death recovery disabled in settings - skipping");
                hasDied = false;
                isRecovering = false;
                deathLocation = null;
            }
            return false;
        }

        if (!hasDied || !isRecovering) {
            return false;
        }

        log("═══════════════════════════════════════════════");
        log("DEATH RECOVERY STARTED");
        log("═══════════════════════════════════════════════");

        if (config.death.pickupItems && deathLocation != null) {
            log("Walking back to death location...");
            log("Death location: " + deathLocation);

            if (deathLocation.distance() > 6) {
                Walking.walk(deathLocation);
                Sleep.sleepUntil(() -> deathLocation.distance() < 10, 30000);
                log("Arrived near death location (distance: " + (int)deathLocation.distance() + ")");
            }

            Sleep.sleep(2000, 3000);

            log("Checking for gravestone at death location...");
            if (checkGravestone()) {
                log("✓ Gravestone found! Looting...");
                lootGravestone();
                Sleep.sleep(1000, 2000);
            } else {
                log("No gravestone found - items may be on ground");
                log("Starting item pickup from ground...");
                pickupDeathItems();
            }
        } else if (config.death.pickupItems && deathLocation == null) {
            log("⚠ Cannot pickup items - death location not stored!");
            log("Items may still be at the place you died");
        }

        if (config.death.equipWeapons || !hasWeaponEquipped()) {
            log("Equipping items...");
            equipItems();
        }

        hasDied = false;
        isRecovering = false;
        deathLocation = null;

        log("═══════════════════════════════════════════════");
        log("✓ DEATH RECOVERY COMPLETE");
        log("═══════════════════════════════════════════════");

        return true;
    }

    private boolean checkGravestone() {
        GameObject gravestone = GameObjects.closest(obj ->
                obj != null &&
                        obj.getName() != null &&
                        obj.getName().toLowerCase().contains("gravestone")
        );

        return gravestone != null;
    }

    private void lootGravestone() {
        GameObject gravestone = GameObjects.closest(obj ->
                obj != null &&
                        obj.getName() != null &&
                        obj.getName().toLowerCase().contains("gravestone")
        );

        if (gravestone == null) {
            log("Gravestone disappeared");
            return;
        }

        log("Found gravestone: " + gravestone.getName() + " at " + (int)gravestone.distance() + " tiles");

        if (gravestone.distance() > 6) {
            log("Walking to gravestone...");
            Walking.walk(gravestone.getTile());
            Sleep.sleepUntil(() -> {
                GameObject gs = GameObjects.closest(obj ->
                        obj != null &&
                                obj.getName() != null &&
                                obj.getName().toLowerCase().contains("gravestone")
                );
                return gs != null && gs.distance() < 6;
            }, 8000);
        }

        int attempts = 0;
        int maxAttempts = 5;
        boolean looted = false;

        while (attempts < maxAttempts && !looted) {
            attempts++;

            GameObject currentGravestone = GameObjects.closest(obj ->
                    obj != null &&
                            obj.getName() != null &&
                            obj.getName().toLowerCase().contains("gravestone")
            );

            if (currentGravestone == null) {
                log("Gravestone no longer exists");
                break;
            }

            log("Attempt " + attempts + ": Interacting with gravestone...");

            String[] interactions = {"Loot", "Take", "Open", "Search"};
            boolean interacted = false;

            for (String interaction : interactions) {
                if (currentGravestone.hasAction(interaction)) {
                    log("Using action: " + interaction);
                    if (mouse.clickEntity(currentGravestone, false)) {
                        interacted = true;
                        log("Clicked gravestone - waiting for response...");
                        Sleep.sleep(1200, 1800);

                        GameObject check = GameObjects.closest(obj ->
                                obj != null &&
                                        obj.getName() != null &&
                                        obj.getName().toLowerCase().contains("gravestone")
                        );

                        if (check == null) {
                            log("✓ Gravestone looted successfully!");
                            looted = true;
                            break;
                        }

                        Sleep.sleep(800, 1200);
                        break;
                    }
                }
            }

            if (!interacted) {
                log("Could not interact with gravestone");
                Sleep.sleep(1000);
            }
        }

        if (looted) {
            log("✓ Successfully looted gravestone");
        } else {
            log("⚠ Gravestone looting may have failed - check inventory");
        }
    }

    private boolean hasWeaponEquipped() {
        Item weapon = Equipment.getItemInSlot(EquipmentSlot.WEAPON);

        if (weapon != null) {
            log("Weapon equipped: " + weapon.getName());
            return true;
        }

        log("No weapon equipped");
        return false;
    }

    private void pickupDeathItems() {
        if (config.death.itemsToPickup == null || config.death.itemsToPickup.isEmpty()) {
            log("No items configured to pickup");
            return;
        }

        log("Looking for " + config.death.itemsToPickup.size() + " items...");

        int itemsFound = 0;
        int maxAttempts = 15;

        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            for (String itemName : config.death.itemsToPickup) {
                String cleanName = itemName.trim();

                if (Inventory.contains(cleanName)) {
                    continue;
                }

                GroundItem item = GroundItems.closest(i ->
                        i != null &&
                                i.getName() != null &&
                                (i.getName().equalsIgnoreCase(cleanName) ||
                                        i.getName().contains(cleanName))
                );

                if (item != null) {
                    log("Found: " + item.getName() + " (" + (int)item.distance() + " tiles away)");

                    if (item.distance() > 6) {
                        log("Walking to item...");
                        Walking.walk(item.getTile());
                        Sleep.sleepUntil(() -> item.distance() < 6 || !item.exists(), 5000);
                    }

                    if (item.exists()) {
                        log("Taking: " + item.getName());

                        if (mouse.clickEntity(item, false)) {
                            Sleep.sleepUntil(() -> Inventory.contains(item.getName()) || !item.exists(), 3000);

                            if (Inventory.contains(item.getName())) {
                                log("✓ Picked up: " + item.getName());
                                itemsFound++;
                            } else {
                                log("✗ Failed to pick up: " + item.getName());
                            }
                        }
                    }
                }
            }

            boolean hasAll = true;
            for (String itemName : config.death.itemsToPickup) {
                if (!Inventory.contains(itemName.trim())) {
                    hasAll = false;
                    break;
                }
            }

            if (hasAll) {
                log("✓ Recovered all items!");
                break;
            }

            Sleep.sleep(500, 1000);
        }

        log("Recovered " + itemsFound + " items");
    }

    private void equipItems() {
        boolean needsWeapon = !hasWeaponEquipped();

        if (config.death.itemsToPickup != null && !config.death.itemsToPickup.isEmpty()) {
            for (String itemName : config.death.itemsToPickup) {
                String cleanName = itemName.trim();

                Item item = Inventory.get(cleanName);
                if (item != null) {
                    if (!Equipment.contains(cleanName)) {
                        log("Equipping: " + cleanName);

                        if (item.interact("Wield")) {
                            Sleep.sleepUntil(() -> Equipment.contains(cleanName), 2000);
                        } else if (item.interact("Wear")) {
                            Sleep.sleepUntil(() -> Equipment.contains(cleanName), 2000);
                        } else if (item.interact("Equip")) {
                            Sleep.sleepUntil(() -> Equipment.contains(cleanName), 2000);
                        }

                        if (Equipment.contains(cleanName)) {
                            log("✓ Equipped: " + cleanName);
                        }
                    }
                }
            }
        }

        if (needsWeapon && !hasWeaponEquipped()) {
            log("No weapon equipped - searching inventory for any weapon...");
            equipAnyWeapon();
        }
    }

    private void equipAnyWeapon() {
        String[] weaponTypes = {
                "sword", "scimitar", "longsword", "shortsword",
                "axe", "battleaxe", "mace", "warhammer",
                "spear", "halberd", "dagger", "knife"
        };

        for (String weaponType : weaponTypes) {
            Item weapon = Inventory.get(item ->
                    item != null &&
                            item.getName() != null &&
                            item.getName().toLowerCase().contains(weaponType)
            );

            if (weapon != null) {
                log("Found weapon in inventory: " + weapon.getName());

                if (weapon.interact("Wield")) {
                    Sleep.sleepUntil(() -> hasWeaponEquipped(), 2000);

                    if (hasWeaponEquipped()) {
                        log("✓ Equipped: " + weapon.getName());
                        return;
                    }
                }
            }
        }

        log("⚠ No weapons found in inventory to equip");
    }

    public void storeDeathLocation() {
        deathLocation = Players.getLocal().getTile();
        log("Stored death location: " + deathLocation);
    }

    public Tile getDeathLocation() {
        return deathLocation;
    }

    public boolean hasDied() {
        return hasDied;
    }

    public boolean isRecovering() {
        return isRecovering;
    }
}
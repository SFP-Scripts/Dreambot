package managers;

import config.ScriptConfig;
import core.BaseManager;
import core.HumanMouse;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.input.Camera;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;

import java.util.Random;

public class BronzeScimitarManager extends BaseManager {

    private final HumanMouse mouse;
    private final Random random;

    private static final Area SCIMITAR_BUILDING = new Area(2964, 3214, 2966, 3216, 0);
    private static final Tile STAIRS_TILE = new Tile(2965, 3215, 0);

    private static final int BRONZE_SCIMITAR_ID = 1321;
    private static final int STAIRCASE_UP_ID = 18991;
    private static final int STAIRCASE_DOWN_ID = 18992;
    private static final int TABLE_ID = 9613;

    private enum RetrievalState {
        IDLE,
        WALKING_TO_BUILDING,
        GOING_UPSTAIRS,
        TAKING_SCIMITAR,
        GOING_DOWNSTAIRS,
        COMPLETED
    }

    private RetrievalState state = RetrievalState.IDLE;
    private int retrievalCount = 0;

    public BronzeScimitarManager(ScriptConfig config, HumanMouse mouse) {
        super(config, "BronzeScimitar");
        this.mouse = mouse;
        this.random = new Random();
    }

    @Override
    public void initialize() {
        log("Bronze scimitar manager initialized");
        log("Auto-retrieve enabled: " + config.equipment.autoRetrieveScimitar);
        log("Building location: 2964,3215 (Rimmington)");
    }

    @Override
    public void reset() {
        state = RetrievalState.IDLE;
    }

    public boolean hasScimitar() {
        return Equipment.contains(BRONZE_SCIMITAR_ID) ||
                Inventory.contains(BRONZE_SCIMITAR_ID);
    }

    public boolean shouldRetrieve() {
        if (!config.equipment.autoRetrieveScimitar) {
            return false;
        }
        return !hasScimitar() && state == RetrievalState.IDLE;
    }

    public boolean startRetrieval(Tile currentLocation) {
        if (state != RetrievalState.IDLE) {
            return false;
        }

        log("════════════════════════════════════════════════");
        log("⚔ Starting bronze scimitar retrieval");
        log("════════════════════════════════════════════════");

        state = RetrievalState.WALKING_TO_BUILDING;
        retrievalCount++;

        return true;
    }

    public boolean startRetrieval() {
        return startRetrieval(null);
    }

    public boolean handleRetrieval() {
        if (state == RetrievalState.IDLE || state == RetrievalState.COMPLETED) {
            return false;
        }

        switch (state) {
            case WALKING_TO_BUILDING:
                return walkToBuilding();
            case GOING_UPSTAIRS:
                return goUpstairs();
            case TAKING_SCIMITAR:
                return takeScimitar();
            case GOING_DOWNSTAIRS:
                return goDownstairs();
        }

        return true;
    }

    public boolean isRetrievalComplete() {
        return state == RetrievalState.COMPLETED;
    }

    public void finishRetrieval() {
        log("════════════════════════════════════════════════");
        log("✓ Scimitar retrieval complete (Total: " + retrievalCount + ")");
        log("════════════════════════════════════════════════");
        state = RetrievalState.IDLE;
    }

    public boolean isRetrieving() {
        return state != RetrievalState.IDLE && state != RetrievalState.COMPLETED;
    }

    private boolean walkToBuilding() {
        if (SCIMITAR_BUILDING.contains(Players.getLocal())) {
            log("✓ At building");
            state = RetrievalState.GOING_UPSTAIRS;
            Sleep.sleep(randomDelay(600, 1200));
            return true;
        }

        logDebug("Walking to Rimmington building...");

        if (random.nextInt(100) < 30) {
            randomCameraMovement();
        }

        if (Walking.walk(STAIRS_TILE)) {
            Sleep.sleepUntil(() -> SCIMITAR_BUILDING.contains(Players.getLocal()),
                    randomDelay(10000, 15000));

            if (SCIMITAR_BUILDING.contains(Players.getLocal())) {
                log("✓ At building");
                state = RetrievalState.GOING_UPSTAIRS;
                Sleep.sleep(randomDelay(800, 1500));
            }
        }

        return true;
    }

    private boolean goUpstairs() {
        if (Players.getLocal().getTile().getZ() == 1) {
            log("✓ Upstairs");
            state = RetrievalState.TAKING_SCIMITAR;
            Sleep.sleep(randomDelay(600, 1000));
            return true;
        }

        GameObject stairs = GameObjects.closest(obj ->
                obj != null &&
                        obj.getID() == STAIRCASE_UP_ID &&
                        obj.getTile().equals(STAIRS_TILE)
        );

        if (stairs == null) {
            logError("Cannot find stairs UP!");
            state = RetrievalState.WALKING_TO_BUILDING;
            Sleep.sleep(randomDelay(2000, 3000));
            return true;
        }

        logDebug("Climbing stairs...");

        Sleep.sleep(randomDelay(300, 800));

        if (stairs.interact("Climb-up")) {
            Sleep.sleepUntil(() -> Players.getLocal().getTile().getZ() == 1,
                    randomDelay(4000, 6000));

            if (Players.getLocal().getTile().getZ() == 1) {
                log("✓ Upstairs");
                state = RetrievalState.TAKING_SCIMITAR;
                Sleep.sleep(randomDelay(800, 1500));
            }
        }

        return true;
    }

    private boolean takeScimitar() {
        if (Inventory.contains(BRONZE_SCIMITAR_ID)) {
            log("✓ Scimitar obtained");
            equipScimitar();
            state = RetrievalState.GOING_DOWNSTAIRS;
            Sleep.sleep(randomDelay(800, 1500));
            return true;
        }

        GameObject table = GameObjects.closest(obj ->
                obj != null &&
                        obj.getID() == TABLE_ID &&
                        obj.getTile().getZ() == 1
        );

        if (table == null) {
            logError("Cannot find table!");
            state = RetrievalState.GOING_DOWNSTAIRS;
            Sleep.sleep(randomDelay(2000, 3000));
            return true;
        }

        logDebug("Taking bronze scimitar...");

        Sleep.sleep(randomDelay(400, 900));

        if (table.interact("Take")) {
            Sleep.sleepUntil(() -> Inventory.contains(BRONZE_SCIMITAR_ID),
                    randomDelay(3000, 5000));

            if (Inventory.contains(BRONZE_SCIMITAR_ID)) {
                log("✓ Scimitar taken");
                equipScimitar();
                state = RetrievalState.GOING_DOWNSTAIRS;
                Sleep.sleep(randomDelay(1000, 2000));
            }
        }

        return true;
    }

    private boolean goDownstairs() {
        if (Players.getLocal().getTile().getZ() == 0) {
            log("✓ Downstairs");
            state = RetrievalState.COMPLETED;
            Sleep.sleep(randomDelay(600, 1000));
            return true;
        }

        log("Looking for stairs down...");

        GameObject stairs = GameObjects.closest(obj ->
                obj != null &&
                        obj.getTile().getZ() == 1 &&
                        (obj.getID() == STAIRCASE_DOWN_ID ||
                                obj.hasAction("Climb-down") ||
                                obj.getName().toLowerCase().contains("stair"))
        );

        if (stairs == null) {
            logError("Cannot find stairs DOWN!");

            Tile stairLoc = new Tile(2965, 3215, 1);
            if (stairLoc.distance() > 3) {
                log("Walking to stair location...");
                Walking.walk(stairLoc);
                Sleep.sleep(1000, 1500);
            }

            stairs = GameObjects.closest(obj ->
                    obj != null &&
                            obj.getTile().getZ() == 1 &&
                            (obj.getID() == STAIRCASE_DOWN_ID ||
                                    obj.hasAction("Climb-down"))
            );

            if (stairs == null) {
                logError("Still cannot find stairs! Retrying in 2 seconds...");
                Sleep.sleep(2000, 3000);
                return true;
            }
        }

        log("Found stairs: ID=" + stairs.getID() + ", Actions=" + java.util.Arrays.toString(stairs.getActions()));

        if (!stairs.isOnScreen()) {
            log("Turning camera to stairs...");
            Camera.rotateToEntity(stairs);
            Sleep.sleep(300, 600);
        }

        Sleep.sleep(randomDelay(300, 800));

        boolean clicked = false;

        if (stairs.hasAction("Climb-down")) {
            log("Using 'Climb-down' action");
            clicked = stairs.interact("Climb-down");
        }

        if (!clicked) {
            for (String action : stairs.getActions()) {
                if (action != null && action.toLowerCase().contains("down")) {
                    log("Using action: " + action);
                    clicked = stairs.interact(action);
                    if (clicked) break;
                }
            }
        }

        if (!clicked) {
            log("Using HumanMouse direct click");
            clicked = mouse.clickEntity(stairs, false);
        }

        if (clicked) {
            log("Clicked stairs, waiting to go down...");

            Sleep.sleepUntil(() -> Players.getLocal().getTile().getZ() == 0,
                    randomDelay(5000, 7000));

            if (Players.getLocal().getTile().getZ() == 0) {
                log("✓ Downstairs");
                state = RetrievalState.COMPLETED;
                Sleep.sleep(randomDelay(800, 1500));
            } else {
                log("⚠ Still upstairs after clicking - will retry");
            }
        } else {
            log("✗ Failed to click stairs");
            Sleep.sleep(1000, 1500);
        }

        return true;
    }

    private void equipScimitar() {
        if (Equipment.contains(BRONZE_SCIMITAR_ID)) {
            log("Scimitar already equipped");
            return;
        }

        Item scimitar = Inventory.get(BRONZE_SCIMITAR_ID);
        if (scimitar != null) {
            log("Equipping scimitar...");

            if (scimitar.interact("Wield")) {
                Sleep.sleepUntil(() -> Equipment.contains(BRONZE_SCIMITAR_ID),
                        randomDelay(2000, 3000));

                if (Equipment.contains(BRONZE_SCIMITAR_ID)) {
                    log("✓ Scimitar equipped");
                } else {
                    logError("Failed to equip scimitar");
                }
            }
        }
    }

    private void randomCameraMovement() {
        try {
            int currentYaw = Camera.getYaw();
            int newYaw = currentYaw + random.nextInt(60) - 30;
            Camera.rotateToYaw(newYaw);
            Sleep.sleep(randomDelay(200, 800));
        } catch (Exception e) {
        }
    }

    private int randomDelay(int min, int max) {
        return min + random.nextInt(max - min + 1);
    }

    public int getRetrievalCount() {
        return retrievalCount;
    }
}
package managers;

import config.ScriptConfig;
import core.BaseManager;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Player;

import java.util.List;
import java.util.Random;

/**
 * Player Detection Manager
 *
 * Features:
 * - Detect nearby players
 * - Detect when name called in chat
 * - Detect bot-related words
 * - Pause or logout on detection
 * - Random interval pausing
 */
public class PlayerDetectionManager extends BaseManager {

    private final Random random;
    private long lastDetectionTime = 0;
    private boolean isPaused = false;
    private long pauseEndTime = 0;
    private int detectionCount = 0;

    // Keywords that might indicate bot accusation
    private static final String[] BOT_KEYWORDS = {
            "bot", "botting", "macro", "script", "auto", "reported",
            "jagex", "mod", "moderator", "ban", "cheat"
    };

    public PlayerDetectionManager(ScriptConfig config) {
        super(config, "PlayerDetection");
        this.random = new Random();
    }

    @Override
    public void initialize() {
        log("Player detection initialized");
        log("Enabled: " + config.playerDetection.enabled);
        log("Detection radius: " + config.playerDetection.detectionRadius);
        log("Action: " + config.playerDetection.actionOnDetection);
    }

    @Override
    public void reset() {
        isPaused = false;
        pauseEndTime = 0;
        detectionCount = 0;
    }

    /**
     * Check if script should be paused due to player detection
     */
    public boolean shouldPause() {
        if (!config.playerDetection.enabled) {
            return false;
        }

        // Check if currently paused
        if (isPaused) {
            if (System.currentTimeMillis() < pauseEndTime) {
                return true; // Still paused
            } else {
                log("Pause ended, resuming script");
                isPaused = false;
                return false;
            }
        }

        // Check for players
        if (detectPlayers()) {
            handleDetection();
            return isPaused;
        }

        return false;
    }

    /**
     * Detect nearby players
     */
    private boolean detectPlayers() {
        // Skip if disabled
        if (!config.playerDetection.detectNearbyPlayers) {
            return false;
        }

        // Cooldown to avoid spam
        long now = System.currentTimeMillis();
        if (now - lastDetectionTime < 5000) {
            return false;
        }

        Player localPlayer = Players.getLocal();
        if (localPlayer == null) {
            return false;
        }

        Tile localTile = localPlayer.getTile();
        if (localTile == null) {
            return false;
        }

        int radius = config.playerDetection.detectionRadius;

        // Count nearby players (excluding self)
        List<Player> nearbyPlayers = Players.all(p -> {
            if (p == null || p.equals(localPlayer)) {
                return false;
            }

            Tile pTile = p.getTile();
            if (pTile == null) {
                return false;
            }

            // Check distance
            return localTile.distance(pTile) <= radius;
        });

        if (!nearbyPlayers.isEmpty()) {
            lastDetectionTime = now;
            detectionCount++;

            log("⚠ Detected " + nearbyPlayers.size() + " player(s) nearby!");

            // Log player names if enabled
            if (config.playerDetection.logPlayerNames) {
                for (Player p : nearbyPlayers) {
                    String name = p.getName();
                    if (name != null) {
                        logDebug("Player: " + name + " at distance " + (int)p.distance());
                    }
                }
            }

            return true;
        }

        return false;
    }

    /**
     * Check if player name was called in chat
     * This would need chat message listener integration
     */
    public boolean checkChatForName(String message) {
        if (!config.playerDetection.detectNameCalled) {
            return false;
        }

        Player localPlayer = Players.getLocal();
        if (localPlayer == null) {
            return false;
        }

        String playerName = localPlayer.getName();
        if (playerName == null) {
            return false;
        }

        // Case insensitive check
        if (message.toLowerCase().contains(playerName.toLowerCase())) {
            log("⚠ YOUR NAME WAS MENTIONED IN CHAT!");
            log("Message: " + message);
            detectionCount++;
            return true;
        }

        return false;
    }

    /**
     * Check for bot-related keywords in chat
     */
    public boolean checkChatForBotWords(String message) {
        if (!config.playerDetection.detectBotWords) {
            return false;
        }

        String lowerMessage = message.toLowerCase();

        for (String keyword : BOT_KEYWORDS) {
            if (lowerMessage.contains(keyword)) {
                log("⚠ BOT-RELATED WORD DETECTED IN CHAT!");
                log("Keyword: " + keyword);
                log("Message: " + message);
                detectionCount++;
                return true;
            }
        }

        return false;
    }

    /**
     * Handle player detection
     */
    private void handleDetection() {
        String action = config.playerDetection.actionOnDetection;

        log("═══════════════════════════════════════");
        log("PLAYER DETECTED - ACTION: " + action);
        log("═══════════════════════════════════════");

        switch (action.toLowerCase()) {
            case "pause":
                pauseScript();
                break;

            case "hop":
                // World hopping not supported - fallback to pause
                log("World hopping not supported - pausing instead");
                pauseScript();
                break;

            case "logout":
                logout();
                break;

            case "stop":
                stopScript();
                break;

            default:
                log("Unknown action: " + action);
        }
    }

    /**
     * Pause script for random interval
     */
    private void pauseScript() {
        int minMinutes = config.playerDetection.pauseMinMinutes;
        int maxMinutes = config.playerDetection.pauseMaxMinutes;

        int pauseMinutes = minMinutes + random.nextInt(maxMinutes - minMinutes + 1);
        long pauseDuration = pauseMinutes * 60 * 1000L;

        isPaused = true;
        pauseEndTime = System.currentTimeMillis() + pauseDuration;

        log("⏸ PAUSING SCRIPT FOR " + pauseMinutes + " MINUTES");
        log("Will resume at: " + new java.util.Date(pauseEndTime));

        // Move camera randomly to look more human
        randomCameraMovement();
    }

    /**
     * Logout
     */
    private void logout() {
        log("🚪 Logging out...");

        try {
            // Open logout tab
            if (Tabs.open(Tab.LOGOUT)) {
                Sleep.sleep(500, 1000);

                // Click logout button
                Tabs.logout();

                Sleep.sleepUntil(() -> !Players.getLocal().exists(), 5000);

                log("✓ Successfully logged out");
                isPaused = true;
                pauseEndTime = System.currentTimeMillis() + (5 * 60 * 1000); // Pause 5 min
            } else {
                log("Failed to open logout tab");
            }
        } catch (Exception e) {
            logError("Logout failed: " + e.getMessage());
        }
    }

    /**
     * Stop script completely
     */
    private void stopScript() {
        log("⛔ STOPPING SCRIPT DUE TO PLAYER DETECTION");
        log("Total detections: " + detectionCount);

        // This will be handled by the main script
        // Just set a flag
        isPaused = true;
        pauseEndTime = Long.MAX_VALUE; // Pause forever
    }

    /**
     * Random camera movement to appear human
     */
    private void randomCameraMovement() {
        try {
            if (random.nextBoolean()) {
                org.dreambot.api.methods.input.Camera.rotateToYaw(
                        random.nextInt(360)
                );
                Sleep.sleep(500, 1500);
            }
        } catch (Exception e) {
            // Ignore camera errors
        }
    }

    /**
     * Get pause status
     */
    public boolean isPaused() {
        return isPaused;
    }

    /**
     * Get remaining pause time in seconds
     */
    public int getRemainingPauseSeconds() {
        if (!isPaused) {
            return 0;
        }

        long remaining = pauseEndTime - System.currentTimeMillis();
        return (int)(remaining / 1000);
    }

    /**
     * Get detection count
     */
    public int getDetectionCount() {
        return detectionCount;
    }

    /**
     * Manual unpause (for testing or emergency)
     */
    public void forceUnpause() {
        log("Force unpause activated");
        isPaused = false;
        pauseEndTime = 0;
    }
}
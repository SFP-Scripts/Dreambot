package managers;

import config.ScriptConfig;
import core.BaseManager;
import navigation.DungeonNavigator;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;

/**
 * Banking Manager - OOP Refactored
 *
 * SINGLE RESPONSIBILITY: Handle all banking operations
 * DRY: Common methods extracted, no code duplication
 * ENCAPSULATION: Private helper methods, public interface
 * SEPARATION OF CONCERNS: Navigation, opening, depositing, withdrawing separated
 */
public class BankingManager extends BaseManager {

    // Constants - Single source of truth
    private static final Area BANK_AREA = new Area(3207, 3218, 3210, 3222, 2);
    private static final Tile BANK_TILE = new Tile(3208, 3220, 2);
    private static final int WALK_TIMEOUT = 30000;
    private static final int BANK_OPEN_TIMEOUT = 5000;

    public BankingManager(ScriptConfig config) {
        super(config, "Banking");
    }

    @Override
    public void initialize() {
        log("Banking manager initialized");
        log("Enabled: " + config.banking.enabled);
    }

    @Override
    public void reset() {
        // Nothing to reset
    }

    // ═══════════════════════════════════════════════════════════════
    // PUBLIC INTERFACE - What other classes can do
    // ═══════════════════════════════════════════════════════════════

    /**
     * Check if should bank
     * REASONS: Out of food OR inventory full
     */
    public boolean shouldBank() {
        if (!config.banking.enabled) {
            return false;
        }

        return isOutOfFood() || isInventoryFull();
    }

    /**
     * Perform complete banking operation
     * TEMPLATE METHOD PATTERN: Defines the algorithm structure
     */
    public boolean bank() {
        log("═══════════════════════════════════════");
        log("BANKING");
        log("═══════════════════════════════════════");

        // Step 1: Exit dungeon if needed (Separation of Concerns)
        if (!ensureOnSurface()) {
            return false;
        }

        // Step 2: Navigate to bank (Separation of Concerns)
        if (!navigateToBank()) {
            return false;
        }

        // Step 3: Open bank (Separation of Concerns)
        if (!openBank()) {
            return false;
        }

        // Step 4: Banking operations (Separation of Concerns)
        performBankingOperations();

        // Step 5: Close and finish
        closeBank();

        log("✓ Banking complete!");
        return true;
    }

    // ═══════════════════════════════════════════════════════════════
    // PRIVATE HELPERS - Implementation details (Encapsulation)
    // ═══════════════════════════════════════════════════════════════

    /**
     * Check if out of food
     * SINGLE RESPONSIBILITY: One reason to exist
     */
    private boolean isOutOfFood() {
        if (!config.food.autoEat) {
            return false;
        }
        return !Inventory.contains(config.food.foodType);
    }

    /**
     * Check if inventory is full
     * SINGLE RESPONSIBILITY: One check, one reason
     */
    private boolean isInventoryFull() {
        return Inventory.isFull();
    }

    /**
     * Ensure player is on surface
     * SINGLE RESPONSIBILITY: Handle dungeon exit
     */
    private boolean ensureOnSurface() {
        if (!DungeonNavigator.isUnderground()) {
            return true;
        }

        log("Underground - exiting dungeon first");
        if (!DungeonNavigator.exitDungeon()) {
            logError("Failed to exit dungeon!");
            return false;
        }

        Sleep.sleep(1000, 2000);
        return true;
    }

    /**
     * Navigate to bank
     * FIXED: Longer timeout, progress checks, webwalking for dungeons
     */
    private boolean navigateToBank() {
        Tile playerPos = Players.getLocal().getTile();

        // Already at bank?
        if (isAtBank()) {
            log("✓ Already at bank");
            return true;
        }

        int distance = (int)playerPos.distance(BANK_TILE);
        log("Walking to bank (distance: " + distance + ")");

        // Use webwalking if far away (better pathing)
        boolean startedWalking;
        if (distance > 20) {
            log("Using web walker for long distance");
            startedWalking = Walking.walk(BANK_TILE);
        } else {
            startedWalking = Walking.walk(BANK_TILE);
        }

        if (!startedWalking) {
            logError("Failed to start walking");
            return false;
        }

        // Wait with progress monitoring (60s timeout for long walks)
        int maxWaitTime = 60000;
        int checkInterval = 3000;
        int elapsed = 0;
        int lastDistance = distance;
        int noProgressCount = 0;

        while (elapsed < maxWaitTime) {
            // Check if arrived
            if (isAtBank()) {
                log("✓ Arrived at bank (took " + (elapsed/1000) + "s)");
                Sleep.sleep(600, 1000);
                return true;
            }

            // Check progress every 3 seconds
            Sleep.sleep(checkInterval);
            elapsed += checkInterval;

            int currentDistance = (int)Players.getLocal().distance(BANK_TILE);

            // Making progress?
            if (currentDistance < lastDistance) {
                logDebug("Progress: " + currentDistance + " tiles away");
                lastDistance = currentDistance;
                noProgressCount = 0;
            } else {
                noProgressCount++;

                // Stuck for 9+ seconds? Try walking again
                if (noProgressCount >= 3) {
                    log("Stuck, trying to walk again...");
                    Walking.walk(BANK_TILE);
                    noProgressCount = 0;
                }
            }

            // Very close but not in area? Walk to exact tile
            if (currentDistance < 10 && !isAtBank()) {
                logDebug("Close to bank, walking to entrance");
                Walking.walk(BANK_TILE);
            }
        }

        // Timeout but check if close enough
        int finalDistance = (int)Players.getLocal().distance(BANK_TILE);
        if (finalDistance < 15) {
            log("Close enough to bank (" + finalDistance + " tiles), trying to continue");
            return true;
        }

        logError("Failed to reach bank (timeout after " + (maxWaitTime/1000) + "s)");
        logDebug("Final distance: " + finalDistance + " tiles");
        logDebug("Final position: " + Players.getLocal().getTile());
        return false;
    }

    /**
     * Check if at bank
     * DRY: Single method for bank location check
     */
    private boolean isAtBank() {
        return BANK_AREA.contains(Players.getLocal().getTile());
    }

    /**
     * Wait for bank arrival
     * DRY: Extracted wait logic
     */
    private boolean waitForBankArrival() {
        return Sleep.sleepUntil(this::isAtBank, WALK_TIMEOUT);
    }

    /**
     * Open bank interface
     * SINGLE RESPONSIBILITY: Handle bank opening
     */
    private boolean openBank() {
        if (Bank.isOpen()) {
            return true;
        }

        log("Opening bank...");

        if (!Bank.open()) {
            logError("Failed to open bank");
            return false;
        }

        if (!waitForBankOpen()) {
            logError("Bank didn't open (timeout)");
            return false;
        }

        log("✓ Bank opened");
        Sleep.sleep(300, 600);
        return true;
    }

    /**
     * Wait for bank to open
     * DRY: Extracted wait logic
     */
    private boolean waitForBankOpen() {
        return Sleep.sleepUntil(Bank::isOpen, BANK_OPEN_TIMEOUT);
    }

    /**
     * Perform deposit and withdraw operations
     * TEMPLATE METHOD: Defines order of operations
     */
    private void performBankingOperations() {
        depositItems();
        withdrawFood();
    }

    /**
     * Deposit items
     * SINGLE RESPONSIBILITY: Handle deposits only
     */
    private void depositItems() {
        log("Depositing items...");

        String foodName = config.food.foodType;

        // Deposit everything except food
        Bank.depositAllExcept(foodName);

        Sleep.sleep(300, 600);
        log("✓ Items deposited");
    }

    /**
     * Withdraw food
     * SINGLE RESPONSIBILITY: Handle food withdrawal only
     */
    private void withdrawFood() {
        if (!config.food.autoEat) {
            return;
        }

        String foodName = config.food.foodType;
        int currentAmount = Inventory.count(foodName);
        int targetAmount = config.food.foodAmount;
        int needed = targetAmount - currentAmount;

        if (needed <= 0) {
            log("Already have enough food");
            return;
        }

        if (!Bank.contains(foodName)) {
            logError("No " + foodName + " in bank!");
            return;
        }

        log("Withdrawing " + needed + " " + foodName);
        Bank.withdraw(foodName, needed);
        Sleep.sleep(300, 600);
        log("✓ Withdrew food");
    }

    /**
     * Close bank
     * SINGLE RESPONSIBILITY: Handle bank closing
     */
    private void closeBank() {
        log("Closing bank");
        Bank.close();
        Sleep.sleep(300, 600);
    }
}
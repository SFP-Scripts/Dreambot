package managers;

import config.ScriptConfig;
import core.BaseManager;
import core.SmartMouse;
import navigation.LocationRegistry;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.NPC;

import java.util.Arrays;
import java.util.List;

/**
 * Combat Manager - COMPLETE FIX with SmartMouse Integration
 *
 * CRITICAL FIXES:
 * - Uses SmartMouse for ALL NPC clicking
 * - Proper right-click menu interaction
 * - Strict area enforcement
 * - Human-like behavior
 */
public class CombatManager extends BaseManager {

    private final SmartMouse smartMouse;
    private int killCount = 0;
    private int attackAttempts = 0;
    private int successfulAttacks = 0;

    private static final List<String> RIMMINGTON_NPCS = Arrays.asList("Hengel", "Anja");

    private static final int MAX_CLICK_ATTEMPTS = 5;
    private static final int CLICK_VALIDATION_TIMEOUT = 4000;
    private static final int MAX_DISTANCE_FROM_CENTER = 10;

    public CombatManager(ScriptConfig config, SmartMouse smartMouse) {
        super(config, "Combat");
        this.smartMouse = smartMouse;

        if (this.smartMouse == null) {
            log("WARNING: SmartMouse is null - will use basic interact()");
        }
    }

    @Override
    public void initialize() {
        log("Combat manager initialized with SmartMouse");
        log("Combat style: " + config.combat.style);
        log("Target monster: " + config.location.targetMonsterName);
        log("SmartMouse stats: " + smartMouse.getStats());

        if (RIMMINGTON_NPCS.contains(config.location.targetMonsterName)) {
            log("Multi-NPC mode: Targeting Hengel & Anja");
        }
    }

    @Override
    public void reset() {
        killCount = 0;
        attackAttempts = 0;
        successfulAttacks = 0;
    }

    /**
     * STRICT: Enforce area boundaries
     */
    public boolean checkBoundaries(Area safeArea) {
        if (safeArea == null) {
            return true;
        }

        Tile playerPos = Players.getLocal().getTile();
        Tile center = safeArea.getCenter();

        // Outside area completely
        if (!safeArea.contains(playerPos)) {
            log("⚠ Outside training area - returning to center");
            Walking.walk(center);
            Sleep.sleepUntil(() -> safeArea.contains(Players.getLocal()), 15000);
            return safeArea.contains(Players.getLocal());
        }

        // Too far from center
        double distanceFromCenter = playerPos.distance(center);
        if (distanceFromCenter > MAX_DISTANCE_FROM_CENTER) {
            logDebug("Too far from center (" + (int)distanceFromCenter + " tiles) - repositioning");
            Walking.walk(center);
            Sleep.sleepUntil(() ->
                            Players.getLocal().getTile().distance(center) < MAX_DISTANCE_FROM_CENTER / 2,
                    8000
            );
        }

        return true;
    }

    public boolean attack(String npcName, Area area) {
        // CRITICAL: Check boundaries first
        if (!checkBoundaries(area)) {
            return false;
        }

        if (Players.getLocal().isInCombat()) {
            return true;
        }

        boolean isRimmington = RIMMINGTON_NPCS.contains(npcName);

        NPC target;
        if (isRimmington) {
            target = findRimmingtonTarget(area);
        } else {
            target = findBestTarget(npcName, area);
        }

        if (target == null) {
            logDebug("No valid target found");
            return false;
        }

        // STRICT: Final area check
        if (area != null && !area.contains(target.getTile())) {
            logDebug("Target outside area - skipping");
            return false;
        }

        log("══════════════════════════════════════");
        log("ATTACKING: " + target.getName());
        log("  Position: " + target.getTile());
        log("  Distance: " + (int)target.distance() + " tiles");

        attackAttempts++;
        boolean attackSuccess = performAttackWithSmartMouse(target, area);

        if (attackSuccess) {
            successfulAttacks++;
            killCount++;
            log("✓ Attack successful!");
            log("  Success rate: " + successfulAttacks + "/" + attackAttempts +
                    " (" + (successfulAttacks * 100 / attackAttempts) + "%)");
        } else {
            logError("✗ Attack failed");
            log("  Success rate: " + successfulAttacks + "/" + attackAttempts);
        }

        log("══════════════════════════════════════");
        return attackSuccess;
    }

    /**
     * COMPLETE FIX: Use SmartMouse for all clicking
     */
    private boolean performAttackWithSmartMouse(NPC target, Area area) {
        for (int attempt = 1; attempt <= MAX_CLICK_ATTEMPTS; attempt++) {
            logDebug("Attack attempt " + attempt + "/" + MAX_CLICK_ATTEMPTS);

            // Validate boundaries
            if (!checkBoundaries(area)) {
                logDebug("Boundary violation - aborting");
                return false;
            }

            // Validate target
            if (!target.exists() || target.isInCombat()) {
                logDebug("Target no longer valid");
                return false;
            }

            // STRICT: Target must be in area
            if (area != null && !area.contains(target.getTile())) {
                logDebug("Target moved out of area");
                return false;
            }

            // Distance check
            double distance = target.distance();
            if (distance > 15) {
                logDebug("Target too far (" + (int)distance + " tiles)");
                return false;
            }

            // Walk closer if needed (but stay in area)
            if (distance > 8) {
                logDebug("Walking closer to target");
                Tile walkTo = target.getTile();

                if (area == null || area.contains(walkTo)) {
                    Walking.walk(walkTo);
                    Sleep.sleep(600, 1000);
                }
            }

            // Ensure NPC is on screen
            if (!target.isOnScreen()) {
                logDebug("Rotating camera to target");
                org.dreambot.api.methods.input.Camera.rotateToEntity(target);
                Sleep.sleep(400, 700);

                if (!target.isOnScreen()) {
                    logDebug("Target still not visible - retrying");
                    continue;
                }
            }

            // ═══════════════════════════════════════════════════════
            // CRITICAL FIX: Use SmartMouse to click NPC (handle null)
            // ═══════════════════════════════════════════════════════

            log("  [Click] Moving to " + target.getName());

            // Move mouse to NPC using SmartMouse if available
            boolean mouseMoved = false;
            if (smartMouse != null) {
                mouseMoved = smartMouse.moveToEntity(target);
            }

            if (!mouseMoved) {
                logDebug("  [Fallback] Using basic interact");
            } else {
                // Small human delay after moving mouse
                Sleep.sleep(100, 250);
            }

            // Right-click and select "Attack"
            log("  [Right-Click] Opening menu");
            boolean clicked = target.interact("Attack");

            if (!clicked) {
                logDebug("✗ Right-click failed - trying left-click");
                clicked = target.interact();
            }

            if (clicked) {
                log("  [Click] Successful - waiting for combat...");

                // Wait for combat to start
                boolean inCombat = Sleep.sleepUntil(() -> {
                    // Abort if moved out of area
                    if (area != null && !area.contains(Players.getLocal().getTile())) {
                        return true;
                    }
                    return Players.getLocal().isInCombat();
                }, CLICK_VALIDATION_TIMEOUT);

                if (inCombat && Players.getLocal().isInCombat()) {
                    log("  [Combat] Started successfully!");
                    return true;
                } else {
                    logDebug("✗ Combat did not start - retrying");
                    if (attempt < MAX_CLICK_ATTEMPTS) {
                        Sleep.sleep(500, 1000);
                    }
                }
            } else {
                logDebug("✗ Click failed entirely");
                Sleep.sleep(400, 800);
            }
        }

        logError("✗ All " + MAX_CLICK_ATTEMPTS + " attempts failed");
        return false;
    }

    /**
     * STRICT: Find best target - ONLY in area
     */
    private NPC findBestTarget(String npcName, Area area) {
        if (area == null) {
            return null;
        }

        Tile center = area.getCenter();
        NPC closest = null;
        double minDistanceFromCenter = Double.MAX_VALUE;

        // STRICT: Only NPCs inside area
        List<NPC> validNPCs = NPCs.all(npc ->
                npc != null &&
                        npc.getName() != null &&
                        npc.getName().equals(npcName) &&
                        npc.exists() &&
                        !npc.isInCombat() &&
                        npc.getHealthPercent() > 0 &&
                        npc.canReach() &&
                        area.contains(npc.getTile())
        );

        if (validNPCs.isEmpty()) {
            return null;
        }

        // Prioritize closest to center
        for (NPC npc : validNPCs) {
            double distFromCenter = npc.getTile().distance(center);
            if (distFromCenter < minDistanceFromCenter) {
                minDistanceFromCenter = distFromCenter;
                closest = npc;
            }
        }

        if (closest != null) {
            logDebug("Found " + closest.getName() + " at " +
                    (int)minDistanceFromCenter + " tiles from center");
        }

        return closest;
    }

    /**
     * Find Rimmington target (BOTH Hengel and Anja)
     */
    private NPC findRimmingtonTarget(Area area) {
        if (area == null) {
            return null;
        }

        NPC closest = null;
        double minDistance = Double.MAX_VALUE;

        List<NPC> validNPCs = NPCs.all(npc ->
                npc != null &&
                        npc.getName() != null &&
                        RIMMINGTON_NPCS.contains(npc.getName()) &&
                        npc.exists() &&
                        !npc.isInCombat() &&
                        npc.getHealthPercent() > 0 &&
                        npc.canReach() &&
                        area.contains(npc.getTile())
        );

        for (NPC npc : validNPCs) {
            double distance = npc.distance();
            if (distance < minDistance) {
                minDistance = distance;
                closest = npc;
            }
        }

        return closest;
    }

    public boolean isInCombat() {
        return Players.getLocal() != null && Players.getLocal().isInCombat();
    }

    public int getKillCount() {
        return killCount;
    }

    /**
     * Get SmartMouse statistics
     */
    public String getSmartMouseStats() {
        return smartMouse.getStats();
    }
}
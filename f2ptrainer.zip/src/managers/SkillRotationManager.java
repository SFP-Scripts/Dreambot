package managers;

import core.BaseManager;
import config.ScriptConfig;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;

/**
 * Manages skill rotation
 */
public class SkillRotationManager extends BaseManager {

    private int lastAttackLevel;
    private int lastStrengthLevel;
    private int lastDefenceLevel;
    private String currentFocus = "Strength";

    public SkillRotationManager(ScriptConfig config) {
        super(config, "SkillRotation");
    }

    @Override
    public void initialize() {
        lastAttackLevel = Skills.getRealLevel(Skill.ATTACK);
        lastStrengthLevel = Skills.getRealLevel(Skill.STRENGTH);
        lastDefenceLevel = Skills.getRealLevel(Skill.DEFENCE);

        log("Initialized - Current levels:");
        log("  Attack: " + lastAttackLevel);
        log("  Strength: " + lastStrengthLevel);
        log("  Defence: " + lastDefenceLevel);
        log("Rotation enabled: " + config.combat.rotateSkills);
    }

    @Override
    public void reset() {
        currentFocus = "Strength";
    }

    public boolean shouldSwitchStyle() {
        if (!config.combat.rotateSkills) {
            return false;
        }

        int currentAttack = Skills.getRealLevel(Skill.ATTACK);
        int currentStrength = Skills.getRealLevel(Skill.STRENGTH);
        int currentDefence = Skills.getRealLevel(Skill.DEFENCE);

        if (currentAttack != lastAttackLevel ||
                currentStrength != lastStrengthLevel ||
                currentDefence != lastDefenceLevel) {

            log("Level up detected!");
            log("  Attack: " + lastAttackLevel + " -> " + currentAttack);
            log("  Strength: " + lastStrengthLevel + " -> " + currentStrength);
            log("  Defence: " + lastDefenceLevel + " -> " + currentDefence);

            lastAttackLevel = currentAttack;
            lastStrengthLevel = currentStrength;
            lastDefenceLevel = currentDefence;

            return shouldRotateNow();
        }

        return false;
    }

    private boolean shouldRotateNow() {
        int attack = Skills.getRealLevel(Skill.ATTACK);
        int strength = Skills.getRealLevel(Skill.STRENGTH);
        int defence = Skills.getRealLevel(Skill.DEFENCE);

        int lowestLevel = 99;
        String lowestSkill = null;

        if (config.combat.trainAttack && attack < config.combat.targetAttackLevel) {
            if (attack < lowestLevel) {
                lowestLevel = attack;
                lowestSkill = "Attack";
            }
        }

        if (config.combat.trainStrength && strength < config.combat.targetStrengthLevel) {
            if (strength < lowestLevel) {
                lowestLevel = strength;
                lowestSkill = "Strength";
            }
        }

        if (config.combat.trainDefence && defence < config.combat.targetDefenceLevel) {
            if (defence < lowestLevel) {
                lowestLevel = defence;
                lowestSkill = "Defence";
            }
        }

        if (lowestSkill != null && !lowestSkill.equals(currentFocus)) {
            currentFocus = lowestSkill;
            log("Switching focus to: " + currentFocus);
            return true;
        }

        return false;
    }

    public String getRecommendedStyle() {
        if (!config.combat.rotateSkills) {
            return config.combat.style;
        }

        switch (currentFocus) {
            case "Attack":
                return "Accurate";
            case "Strength":
                return "Aggressive";
            case "Defence":
                return "Defensive";
            default:
                return "Controlled";
        }
    }

    public boolean allGoalsReached() {
        int attack = Skills.getRealLevel(Skill.ATTACK);
        int strength = Skills.getRealLevel(Skill.STRENGTH);
        int defence = Skills.getRealLevel(Skill.DEFENCE);

        boolean attackDone = !config.combat.trainAttack || attack >= config.combat.targetAttackLevel;
        boolean strengthDone = !config.combat.trainStrength || strength >= config.combat.targetStrengthLevel;
        boolean defenceDone = !config.combat.trainDefence || defence >= config.combat.targetDefenceLevel;

        return attackDone && strengthDone && defenceDone;
    }

    public String getCurrentFocus() {
        return currentFocus;
    }
}
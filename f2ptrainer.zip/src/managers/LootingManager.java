package managers;

import config.ScriptConfig;
import core.BaseManager;
import core.HumanMouse;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.item.GroundItems;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.GroundItem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Looting Manager - Enhanced with custom loot list
 * NEW: Supports custom items (coins, runes, etc.)
 */
public class LootingManager extends BaseManager {

    private final HumanMouse mouse;
    private final Random random;
    private int itemsLooted = 0;
    private List<String> customLootList;
    private long lastLootTime = 0;

    public LootingManager(ScriptConfig config, HumanMouse mouse) {
        super(config, "Looting");
        this.mouse = mouse;
        this.random = new Random();

        // Parse custom loot list
        parseCustomLootList();
    }

    /**
     * Parse custom loot list from config
     */
    private void parseCustomLootList() {
        customLootList = new ArrayList<>();

        if (config.looting.customLootItems != null && !config.looting.customLootItems.isEmpty()) {
            String[] items = config.looting.customLootItems.split(",");
            for (String item : items) {
                String trimmed = item.trim();
                if (!trimmed.isEmpty()) {
                    customLootList.add(trimmed);
                }
            }
        }
    }

    @Override
    public void initialize() {
        log("Looting manager initialized");
        log("Enabled: " + config.looting.enabled);
        log("Loot cowhide: " + config.looting.lootCowhide);
        log("Loot bones: " + config.looting.lootBones);
        log("Loot radius: " + config.looting.lootRadius);
        log("Custom items: " + config.looting.lootCustomItems);
        if (config.looting.lootCustomItems) {
            log("  Items: " + customLootList.size() + " types");
            for (String item : customLootList) {
                log("    - " + item);
            }
        }
        log("Humanized looting: " + config.looting.humanizedLooting);
    }

    @Override
    public void reset() {
        itemsLooted = 0;
    }

    /**
     * Check if should loot
     */
    public boolean shouldLoot() {
        if (!config.looting.enabled) {
            return false;
        }

        if (Inventory.isFull()) {
            return false;
        }

        Tile playerTile = Players.getLocal().getTile();
        if (playerTile == null) {
            return false;
        }

        // Check if loot all
        if (config.looting.lootAll) {
            return GroundItems.closest(i ->
                    i != null &&
                            i.getTile() != null &&
                            i.getTile().distance(playerTile) <= config.looting.lootRadius
            ) != null;
        }

        // Check specific items
        if (config.looting.lootCowhide && hasNearbyItem("Cowhide", playerTile)) {
            return true;
        }

        if (config.looting.lootRawBeef && hasNearbyItem("Raw beef", playerTile)) {
            return true;
        }

        if (config.looting.lootRawChicken && hasNearbyItem("Raw chicken", playerTile)) {
            return true;
        }

        if (config.looting.lootFeathers && hasNearbyItem("Feather", playerTile)) {
            return true;
        }

        if (config.looting.lootBones && hasNearbyItem("Bones", playerTile)) {
            return true;
        }

        // Check custom loot items (NEW)
        if (config.looting.lootCustomItems) {
            for (String itemName : customLootList) {
                if (hasNearbyItem(itemName, playerTile)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Check if item exists nearby
     */
    private boolean hasNearbyItem(String itemName, Tile playerTile) {
        return GroundItems.closest(i ->
                i != null &&
                        i.getName() != null &&
                        i.getName().equals(itemName) &&
                        i.getTile() != null &&
                        i.getTile().distance(playerTile) <= config.looting.lootRadius
        ) != null;
    }

    /**
     * Loot items in area - MAIN METHOD called from script
     */
    public boolean loot(Area area) {
        if (!config.looting.enabled) {
            return false;
        }

        if (Inventory.isFull()) {
            logDebug("Inventory full, cannot loot");
            return false;
        }

        return lootItems();
    }

    /**
     * Loot nearby items
     */
    public boolean lootItems() {
        if (!config.looting.enabled) {
            return false;
        }

        if (Inventory.isFull()) {
            return false;
        }

        Tile playerTile = Players.getLocal().getTile();
        if (playerTile == null) {
            return false;
        }

        // Loot all enabled
        if (config.looting.lootAll) {
            return lootAllItems(playerTile);
        }

        // Loot specific items in priority order
        if (config.looting.lootCowhide && lootItem("Cowhide", playerTile)) {
            return true;
        }

        if (config.looting.lootRawBeef && lootItem("Raw beef", playerTile)) {
            return true;
        }

        if (config.looting.lootRawChicken && lootItem("Raw chicken", playerTile)) {
            return true;
        }

        if (config.looting.lootFeathers && lootItem("Feather", playerTile)) {
            return true;
        }

        if (config.looting.lootBones && lootItem("Bones", playerTile)) {
            return true;
        }

        // Loot custom items (NEW)
        if (config.looting.lootCustomItems) {
            for (String itemName : customLootList) {
                if (lootItem(itemName, playerTile)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Loot specific item - HUMANIZED
     */
    private boolean lootItem(String itemName, Tile playerTile) {
        // Humanized delay between loots
        if (config.looting.humanizedLooting) {
            long timeSinceLastLoot = System.currentTimeMillis() - lastLootTime;
            long minDelay = config.looting.lootDelayMin;

            if (timeSinceLastLoot < minDelay) {
                return false;
            }
        }

        GroundItem item = GroundItems.closest(i ->
                i != null &&
                        i.getName() != null &&
                        i.getName().equals(itemName) &&
                        i.getTile() != null &&
                        i.getTile().distance(playerTile) <= config.looting.lootRadius
        );

        if (item == null) {
            return false;
        }

        // Humanized - randomly skip items
        if (config.looting.humanizedLooting && !itemName.equals("Coins")) {  // Never skip coins
            int skipChance = config.looting.lootSkipChance;
            if (random.nextInt(100) < skipChance) {
                logDebug("Skipping " + itemName + " (humanized)");
                lastLootTime = System.currentTimeMillis();
                return false;
            }
        }

        // Walk to item if needed
        if (item.distance() > 2) {
            Walking.walk(item.getTile());
            Sleep.sleepUntil(() -> item.distance() < 2 || !item.exists(), 2000);
        }

        if (!item.exists()) {
            return false;
        }

        logDebug("Looting: " + itemName);

        if (mouse.clickEntity(item, false)) {
            Sleep.sleepUntil(() -> !item.exists() || Inventory.isFull(), 3000);
            itemsLooted++;
            lastLootTime = System.currentTimeMillis();

            // Humanized random delay after looting
            if (config.looting.humanizedLooting) {
                int delay = config.looting.lootDelayMin +
                        random.nextInt(config.looting.lootDelayMax - config.looting.lootDelayMin);
                Sleep.sleep(delay);
            }

            return true;
        }

        return false;
    }

    /**
     * Loot all items
     */
    private boolean lootAllItems(Tile playerTile) {
        GroundItem item = GroundItems.closest(i ->
                i != null &&
                        i.getTile() != null &&
                        i.getTile().distance(playerTile) <= config.looting.lootRadius
        );

        if (item == null) {
            return false;
        }

        // Walk to item if needed
        if (item.distance() > 2) {
            Walking.walk(item.getTile());
            Sleep.sleepUntil(() -> item.distance() < 2 || !item.exists(), 2000);
        }

        if (!item.exists()) {
            return false;
        }

        logDebug("Looting: " + item.getName());

        if (mouse.clickEntity(item, false)) {
            Sleep.sleepUntil(() -> !item.exists() || Inventory.isFull(), 3000);
            itemsLooted++;
            return true;
        }

        return false;
    }

    /**
     * Get total items looted
     */
    public int getItemsLooted() {
        return itemsLooted;
    }
}
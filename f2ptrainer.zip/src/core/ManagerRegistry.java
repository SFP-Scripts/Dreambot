package core;

import config.ScriptConfig;
import core.SmartMouse;
import core.HumanMouse;
import managers.*;
import org.dreambot.api.utilities.Logger;

/**
 * Manager Registry - COMPLETE FIX
 *
 * FIXES:
 * - Added DeathHandler
 * - Proper null-safety for SmartMouse
 * - All managers initialized correctly
 */
public class ManagerRegistry {

    private final ScriptConfig config;
    private final SmartMouse smartMouse;
    private HumanMouse humanMouse;

    // All managers
    private NavigationManager navigation;
    private CombatManager combat;
    private FoodManager food;
    private BankingManager banking;
    private LootingManager looting;
    private BoneManager bone;
    private AntiBanManager antiBan;
    private PlayerDetectionManager playerDetection;
    private SkillRotationManager skillRotation;
    private WeaponUpgradeManager weaponUpgrade;
    private BronzeScimitarManager bronzeScimitar;
    private TaskSwapManager taskSwap;
    private DeathHandler deathHandler;
    private CookingManager cooking;  // ADDED

    public ManagerRegistry(ScriptConfig config, SmartMouse smartMouse) {
        this.config = config;
        this.smartMouse = smartMouse;
        this.humanMouse = null;
    }

    /**
     * Lazy initialization of HumanMouse
     */
    private HumanMouse getHumanMouse() {
        if (humanMouse == null) {
            Logger.log("[ManagerRegistry] Creating HumanMouse...");
            humanMouse = new HumanMouse(config);
        }
        return humanMouse;
    }

    public void initializeAll() {
        try {
            Logger.log("[ManagerRegistry] Initializing managers...");

            // Core managers (no dependencies)
            antiBan = new AntiBanManager(config);
            playerDetection = new PlayerDetectionManager(config);

            // Navigation
            navigation = new NavigationManager(config);

            // Food
            food = new FoodManager(config);

            // Combat - Handle null SmartMouse
            Logger.log("[ManagerRegistry] Initializing CombatManager...");
            if (smartMouse != null) {
                Logger.log("[ManagerRegistry] Using SmartMouse for combat");
                combat = new CombatManager(config, smartMouse);
            } else {
                Logger.log("[ManagerRegistry] WARNING: SmartMouse is null, using HumanMouse for combat");
                combat = new CombatManager(config, createSmartMouseFallback());
            }

            // Looting
            Logger.log("[ManagerRegistry] Initializing LootingManager...");
            looting = new LootingManager(config, getHumanMouse());

            // Bones
            bone = new BoneManager(config);

            // Banking
            banking = new BankingManager(config);

            // Skill rotation
            skillRotation = new SkillRotationManager(config);

            // Weapon systems
            Logger.log("[ManagerRegistry] Initializing weapon managers...");
            weaponUpgrade = new WeaponUpgradeManager(config, getHumanMouse());
            bronzeScimitar = new BronzeScimitarManager(config, getHumanMouse());

            // Task swap
            taskSwap = new TaskSwapManager(config);

            // Death handler - ADDED
            Logger.log("[ManagerRegistry] Initializing DeathHandler...");
            deathHandler = new DeathHandler(config, getHumanMouse());

            // Cooking manager - ADDED
            Logger.log("[ManagerRegistry] Initializing CookingManager...");
            cooking = new CookingManager(config, getHumanMouse());

            // Initialize all
            Logger.log("[ManagerRegistry] Calling initialize() on all managers...");
            antiBan.initialize();
            playerDetection.initialize();
            navigation.initialize();
            food.initialize();
            combat.initialize();
            looting.initialize();
            bone.initialize();
            banking.initialize();
            skillRotation.initialize();
            weaponUpgrade.initialize();
            bronzeScimitar.initialize();
            taskSwap.initialize();
            deathHandler.initialize();  // ADDED
            cooking.initialize();  // ADDED

            Logger.log("[ManagerRegistry] All managers initialized successfully!");

        } catch (Exception e) {
            Logger.error("[ManagerRegistry] FATAL: Manager initialization failed!");
            Logger.error("[ManagerRegistry] Error: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Creates a SmartMouse fallback using HumanMouse
     * This prevents crashes if SmartMouse initialization fails
     */
    private SmartMouse createSmartMouseFallback() {
        try {
            Logger.log("[ManagerRegistry] Attempting to create SmartMouse fallback...");
            return new SmartMouse();
        } catch (Exception e) {
            Logger.error("[ManagerRegistry] SmartMouse fallback failed: " + e.getMessage());
            Logger.error("[ManagerRegistry] CombatManager will use basic functionality");
            return null;
        }
    }

    // Getters
    public NavigationManager getNavigation() { return navigation; }
    public CombatManager getCombat() { return combat; }
    public FoodManager getFood() { return food; }
    public BankingManager getBanking() { return banking; }
    public LootingManager getLooting() { return looting; }
    public BoneManager getBone() { return bone; }
    public AntiBanManager getAntiBan() { return antiBan; }
    public PlayerDetectionManager getPlayerDetection() { return playerDetection; }
    public SkillRotationManager getSkillRotation() { return skillRotation; }
    public WeaponUpgradeManager getWeaponUpgrade() { return weaponUpgrade; }
    public BronzeScimitarManager getBronzeScimitar() { return bronzeScimitar; }
    public TaskSwapManager getTaskSwap() { return taskSwap; }
    public DeathHandler getDeathHandler() { return deathHandler; }  // ADDED
    public CookingManager getCooking() { return cooking; }  // ADDED
}
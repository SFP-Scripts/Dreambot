package core;

import config.ScriptConfig;
import org.dreambot.api.utilities.Logger;

/**
 * Base class for all managers implementing common functionality
 * Following Single Responsibility and DRY principles
 */
public abstract class BaseManager {

    protected final ScriptConfig config;
    protected final String managerName;

    public BaseManager(ScriptConfig config, String managerName) {
        this.config = config;
        this.managerName = managerName;
    }

    /**
     * Log with manager name prefix
     */
    protected void log(String message) {
        Logger.log(String.format("[%s] %s", managerName, message));
    }

    /**
     * Log error with manager name prefix
     */
    protected void logError(String message) {
        Logger.error(String.format("[%s] ERROR: %s", managerName, message));
    }

    /**
     * Log debug message (only if debug mode enabled)
     */
    protected void logDebug(String message) {
        if (config.debugMode) {
            Logger.log(String.format("[%s] DEBUG: %s", managerName, message));
        }
    }

    /**
     * Initialize the manager - called once on startup
     */
    public abstract void initialize();

    /**
     * Reset the manager state
     */
    public abstract void reset();

    /**
     * Get delay with randomization for anti-ban
     */
    protected int getRandomDelay(int baseDelay) {
        return getRandomDelay(baseDelay, baseDelay + (baseDelay / 2));
    }

    /**
     * Get delay within range
     */
    protected int getRandomDelay(int min, int max) {
        if (min >= max) return min;
        return min + (int)(Math.random() * (max - min));
    }

    /**
     * Apply variance to a value based on config
     */
    protected int applyVariance(int value) {
        double variancePercent = config.antiBan.variancePercent / 100.0;
        int maxVariance = (int)(value * variancePercent);
        return value + (int)((Math.random() * 2 - 1) * maxVariance);
    }
}

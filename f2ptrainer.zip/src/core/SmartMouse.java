package core;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;
import org.dreambot.api.input.Mouse;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Entity;

import java.awt.Point;
import java.io.File;
import java.io.FileReader;
import java.util.*;

/**
 * SmartMouse - Distance/Direction Lookup Table Format
 * FIXED FOR WINDOWS: C:\Users\<user>\dreambot\scripts\mousedata.json
 *
 * Supports mousedata.json format with:
 * - Distance keys (e.g., "18", "50", "100")
 * - Direction keys (N, NE, E, SE, S, SW, W, NW)
 * - Movement arrays: [x_deltas, y_deltas, time_deltas]
 */
public class SmartMouse {

    // Cross-platform path handling
    private static final String MOUSE_DATA_PATH = getMouseDataPath();
    private static final String FOLDER_PATH = getFolderPath();

    private final Random random;
    private Map<Integer, Map<String, List<MouseMovement>>> mouseData;
    private boolean enabled = true;
    private boolean dataLoaded = false;
    private int movementCount = 0;
    private int fallbackCount = 0;

    // Direction keys
    private static final String[] DIRECTIONS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    /**
     * Get mouse data path - C:\Users\<user>\dreambot\scripts\mousedata.json
     */
    /**
     * Get mouse data path - FIXED: Always C:\Users\<user>\dreambot\scripts\mousedata.json
     */
    private static String getMouseDataPath() {
        String userHome = System.getProperty("user.home");
        String sep = File.separator;

        // ALWAYS use lowercase "dreambot" folder (no cache)
        String path = userHome + sep + "dreambot" + sep + "scripts" + sep + "mousedata.json";

        File file = new File(path);
        if (file.exists()) {
            Logger.log("[SmartMouse] Found mousedata.json at: " + path);
        } else {
            Logger.log("[SmartMouse] mousedata.json not found at: " + path);
            Logger.log("[SmartMouse] Will use fallback mouse behavior");
        }

        return path;
    }

    /**
     * Get folder path - FIXED: Always C:\Users\<user>\dreambot\scripts\
     */
    private static String getFolderPath() {
        String userHome = System.getProperty("user.home");
        String sep = File.separator;

        // ALWAYS use lowercase "dreambot" folder (no cache)
        String path = userHome + sep + "dreambot" + sep + "scripts" + sep;

        File dir = new File(path);
        if (dir.exists() && dir.isDirectory()) {
            Logger.log("[SmartMouse] Using scripts folder: " + path);
        } else {
            Logger.log("[SmartMouse] Scripts folder doesnt exist, will create: " + path);
        }

        return path;
    }

    public SmartMouse() {
        this.random = new Random();
        ensureFolderExists();
        loadMouseData();
    }

    private void ensureFolderExists() {
        try {
            File folder = new File(FOLDER_PATH);
            if (!folder.exists()) {
                if (folder.mkdirs()) {
                    Logger.log("[SmartMouse] Created folder: " + FOLDER_PATH);
                }
            }
        } catch (Exception e) {
            Logger.error("[SmartMouse] Could not create folder: " + e.getMessage());
        }
    }

    private void loadMouseData() {
        try {
            File dataFile = new File(MOUSE_DATA_PATH);

            Logger.log("[MouseData] ========================================");
            Logger.log("[MouseData] ATTEMPTING TO PARSE JSON FILE");
            Logger.log("[MouseData] ========================================");

            if (!dataFile.exists()) {
                Logger.log("[MouseData] File: " + MOUSE_DATA_PATH);
                Logger.log("[MouseData] Status: NOT FOUND");
                Logger.log("[MouseData] Using FALLBACK MOUSE BEHAVIOR");
                Logger.log("[MouseData] ");
                Logger.log("[MouseData] TO FIX: Put mousedata.json at:");
                Logger.log("[MouseData]   " + MOUSE_DATA_PATH);
                Logger.log("[MouseData] ========================================");
                dataLoaded = false;
                return;
            }

            Logger.log("[MouseData] File: " + dataFile.getAbsolutePath());
            Logger.log("[MouseData] Size: " + dataFile.length() + " bytes");
            Logger.log("[MouseData] Readable: " + dataFile.canRead());
            Logger.log("[MouseData]");
            Logger.log("[MouseData] Starting JSON parse...");

            Gson gson = new Gson();
            try (FileReader reader = new FileReader(dataFile)) {
                JsonObject root = gson.fromJson(reader, JsonObject.class);
                mouseData = new HashMap<>();

                Logger.log("[MouseData] Detected format: LOOKUP TABLE (distance/direction)");

                int distanceCount = 0;
                int totalMovements = 0;

                for (Map.Entry<String, JsonElement> distanceEntry : root.entrySet()) {
                    try {
                        int distance = Integer.parseInt(distanceEntry.getKey());
                        Map<String, List<MouseMovement>> directionMap = new HashMap<>();

                        JsonObject directions = distanceEntry.getValue().getAsJsonObject();

                        for (String direction : DIRECTIONS) {
                            if (directions.has(direction)) {
                                JsonArray movementArray = directions.get(direction).getAsJsonArray();
                                List<MouseMovement> movements = new ArrayList<>();

                                for (JsonElement movementElement : movementArray) {
                                    JsonArray arrays = movementElement.getAsJsonArray();
                                    if (arrays.size() >= 3) {
                                        MouseMovement movement = parseMovement(arrays);
                                        if (movement != null) {
                                            movements.add(movement);
                                            totalMovements++;
                                        }
                                    }
                                }

                                if (!movements.isEmpty()) {
                                    directionMap.put(direction, movements);
                                }
                            }
                        }

                        if (!directionMap.isEmpty()) {
                            mouseData.put(distance, directionMap);
                            distanceCount++;
                        }
                    } catch (NumberFormatException e) {
                        // Skip non-numeric keys
                    }
                }

                dataLoaded = true;

                Logger.log("[MouseData] SUCCESS!");
                Logger.log("[MouseData] Format: LOOKUP TABLE");
                Logger.log("[MouseData] Distance categories: " + distanceCount);
                Logger.log("[MouseData] Total data points: " + totalMovements);
                Logger.log("[MouseData] Directions per distance: 8 (N, NE, E, SE, S, SW, W, NW)");
                Logger.log("[MouseData] ========================================");
                Logger.log("[MouseManager] Successfully parsed " + totalMovements + " movements");
                Logger.log("[MouseManager] ========================================");
                Logger.log("[SmartMouse] Initialized with LOOKUP TABLE format");
                Logger.log("[MouseManager] ========================================");
                Logger.log("[MouseManager] SMARTMOUSE ACTIVE");
                Logger.log("[MouseManager] Loaded " + totalMovements + " movements");
                Logger.log("[MouseManager] Source: " + dataFile.getAbsolutePath());
                Logger.log("[MouseManager] ========================================");

            }
        } catch (Exception e) {
            Logger.log("[MouseData] ========================================");
            Logger.error("[MouseData] Failed to load mousedata.json");
            Logger.error("[MouseData] Error: " + e.getMessage());
            Logger.log("[MouseData] Using FALLBACK BEHAVIOR");
            Logger.log("[MouseData] ========================================");
            dataLoaded = false;
        }
    }

    private MouseMovement parseMovement(JsonArray arrays) {
        try {
            JsonArray xDeltas = arrays.get(0).getAsJsonArray();
            JsonArray yDeltas = arrays.get(1).getAsJsonArray();
            JsonArray timeDeltas = arrays.get(2).getAsJsonArray();

            List<Integer> x = new ArrayList<>();
            List<Integer> y = new ArrayList<>();
            List<Double> times = new ArrayList<>();

            for (int i = 0; i < xDeltas.size(); i++) {
                x.add(xDeltas.get(i).getAsInt());
            }

            for (int i = 0; i < yDeltas.size(); i++) {
                y.add(yDeltas.get(i).getAsInt());
            }

            for (int i = 0; i < timeDeltas.size(); i++) {
                times.add(timeDeltas.get(i).getAsDouble());
            }

            return new MouseMovement(x, y, times);
        } catch (Exception e) {
            return null;
        }
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled && dataLoaded;
    }

    public boolean moveToEntity(Entity entity) {
        if (entity == null) {
            return false;
        }

        Point destination = entity.getClickablePoint();
        if (destination == null) {
            return false;
        }

        return moveTo(destination);
    }

    public boolean moveTo(Point destination) {
        if (destination == null) {
            return false;
        }

        if (!enabled || !dataLoaded) {
            Mouse.move(destination);
            return true;
        }

        Point start = Mouse.getPosition();
        if (start == null) {
            Mouse.move(destination);
            return true;
        }

        int dx = destination.x - start.x;
        int dy = destination.y - start.y;
        int distance = (int) Math.sqrt(dx * dx + dy * dy);
        String direction = getDirection(dx, dy);

        Integer closestDistance = findClosestDistance(distance);

        if (closestDistance != null && mouseData.containsKey(closestDistance)) {
            Map<String, List<MouseMovement>> directionMap = mouseData.get(closestDistance);

            if (directionMap.containsKey(direction)) {
                List<MouseMovement> movements = directionMap.get(direction);
                if (!movements.isEmpty()) {
                    int selectedIndex = random.nextInt(movements.size());
                    MouseMovement movement = movements.get(selectedIndex);

                    movementCount++;

                    if (movementCount % 10 == 1) {
                        Logger.log("[SmartMouse] Movement #" + movementCount + ": " +
                                "dist=" + closestDistance + "(" + distance + "px), " +
                                "dir=" + direction + ", " +
                                "var=" + (selectedIndex + 1) + "/" + movements.size());
                    }

                    executeMovement(start, destination, movement);
                    return true;
                }
            }
        }

        fallbackCount++;
        if (fallbackCount % 5 == 1) {
            Logger.log("[SmartMouse] Fallback #" + fallbackCount +
                    " (no data: dist=" + distance + ", dir=" + direction + ")");
        }
        Mouse.move(destination);
        return true;
    }

    private String getDirection(int dx, int dy) {
        double angle = Math.atan2(dy, dx);
        double degrees = Math.toDegrees(angle);

        if (degrees < 0) {
            degrees += 360;
        }

        if (degrees >= 337.5 || degrees < 22.5) {
            return "E";
        } else if (degrees >= 22.5 && degrees < 67.5) {
            return "SE";
        } else if (degrees >= 67.5 && degrees < 112.5) {
            return "S";
        } else if (degrees >= 112.5 && degrees < 157.5) {
            return "SW";
        } else if (degrees >= 157.5 && degrees < 202.5) {
            return "W";
        } else if (degrees >= 202.5 && degrees < 247.5) {
            return "NW";
        } else if (degrees >= 247.5 && degrees < 292.5) {
            return "N";
        } else {
            return "NE";
        }
    }

    private Integer findClosestDistance(int targetDistance) {
        if (mouseData == null || mouseData.isEmpty()) {
            return null;
        }

        Integer closest = null;
        int minDiff = Integer.MAX_VALUE;

        for (Integer distance : mouseData.keySet()) {
            int diff = Math.abs(distance - targetDistance);
            if (diff < minDiff) {
                minDiff = diff;
                closest = distance;
            }
        }

        return closest;
    }

    private void executeMovement(Point start, Point destination, MouseMovement movement) {
        int currentX = start.x;
        int currentY = start.y;

        int actualDx = destination.x - start.x;
        int actualDy = destination.y - start.y;
        double actualDistance = Math.sqrt(actualDx * actualDx + actualDy * actualDy);

        int recordedDx = movement.getTotalDeltaX();
        int recordedDy = movement.getTotalDeltaY();
        double recordedDistance = Math.sqrt(recordedDx * recordedDx + recordedDy * recordedDy);

        double scale = recordedDistance > 0 ? actualDistance / recordedDistance : 1.0;

        for (int i = 0; i < movement.size(); i++) {
            int deltaX = (int)(movement.getX(i) * scale);
            int deltaY = (int)(movement.getY(i) * scale);
            double timeMs = movement.getTime(i);

            currentX += deltaX;
            currentY += deltaY;

            currentX = Math.max(0, Math.min(765, currentX));
            currentY = Math.max(0, Math.min(503, currentY));

            Mouse.move(new Point(currentX, currentY));

            if (timeMs > 0) {
                Sleep.sleep((int)timeMs);
            }
        }

        Mouse.move(destination);
    }

    public boolean clickEntity(Entity entity, boolean rightClick) {
        if (!moveToEntity(entity)) {
            return false;
        }

        Sleep.sleep(50, 150);
        Mouse.click(rightClick);

        return true;
    }

    public String getStats() {
        if (!dataLoaded) {
            return "[SmartMouse] Not loaded";
        }

        return String.format("[SmartMouse] Stats: %d movements used, %d fallbacks",
                movementCount, fallbackCount);
    }

    public int getMovementCount() {
        return movementCount;
    }

    public int getFallbackCount() {
        return fallbackCount;
    }

    private static class MouseMovement {
        private final List<Integer> xDeltas;
        private final List<Integer> yDeltas;
        private final List<Double> timeDeltas;

        public MouseMovement(List<Integer> x, List<Integer> y, List<Double> times) {
            this.xDeltas = x;
            this.yDeltas = y;
            this.timeDeltas = times;
        }

        public int size() {
            return Math.min(xDeltas.size(), Math.min(yDeltas.size(), timeDeltas.size()));
        }

        public int getX(int index) {
            return xDeltas.get(index);
        }

        public int getY(int index) {
            return yDeltas.get(index);
        }

        public double getTime(int index) {
            return timeDeltas.get(index);
        }

        public int getTotalDeltaX() {
            return xDeltas.stream().mapToInt(Integer::intValue).sum();
        }

        public int getTotalDeltaY() {
            return yDeltas.stream().mapToInt(Integer::intValue).sum();
        }
    }
}
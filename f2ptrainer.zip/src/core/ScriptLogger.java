package core;

import org.dreambot.api.utilities.Logger;

/**
 * Centralized logging utility following DRY principle
 * Single Responsibility: Handle all logging formatting and output
 */
public class ScriptLogger {

    private final String scriptName;

    public ScriptLogger(String scriptName) {
        this.scriptName = scriptName;
    }

    /**
     * Log standard message
     */
    public void log(String message) {
        Logger.log(message);
    }

    /**
     * Log with prefix
     */
    public void log(String prefix, String message) {
        Logger.log(String.format("[%s] %s", prefix, message));
    }

    /**
     * Log error
     */
    public void error(String message) {
        Logger.error(message);
    }

    /**
     * Log header with box
     */
    public void logHeader(String message) {
        Logger.log("╔════════════════════════════════════════════════╗");
        Logger.log("║ " + center(message, 46) + " ║");
        Logger.log("╚════════════════════════════════════════════════╝");
    }

    /**
     * Log separator line
     */
    public void logSeparator() {
        Logger.log("─────────────────────────────────────────────────");
    }

    /**
     * Log section header
     */
    public void logSection(String title) {
        logSeparator();
        Logger.log("  " + title);
        logSeparator();
    }

    /**
     * Center text within width
     */
    private String center(String text, int width) {
        if (text.length() >= width) {
            return text;
        }

        int padding = (width - text.length()) / 2;
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < padding; i++) {
            sb.append(" ");
        }

        sb.append(text);

        while (sb.length() < width) {
            sb.append(" ");
        }

        return sb.toString();
    }

    /**
     * Format milliseconds to HH:MM:SS
     */
    public static String formatTime(long millis) {
        long seconds = (millis / 1000) % 60;
        long minutes = (millis / (1000 * 60)) % 60;
        long hours = (millis / (1000 * 60 * 60)) % 24;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}
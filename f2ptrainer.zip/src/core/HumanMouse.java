package core;

import config.ScriptConfig;
import org.dreambot.api.input.Mouse;
import org.dreambot.api.methods.input.mouse.MouseSettings;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Entity;

import java.awt.*;
import java.util.Random;

public class HumanMouse {

    private final ScriptConfig config;
    private final Random random;

    public HumanMouse(ScriptConfig config) {
        this.config = config;
        this.random = new Random();

        // CRITICAL: Enable SmartMouse globally
        if (config.mouse.useSmartMouse) {
            MouseSettings.setSpeed(config.mouse.mouseSpeed);
            Logger.log("[HumanMouse] SmartMouse ENABLED - Speed: " + config.mouse.mouseSpeed);
            Logger.log("[HumanMouse] Bezier curves will be used automatically by DreamBot");
        } else {
            Logger.log("[HumanMouse] SmartMouse DISABLED - using basic mouse");
        }
    }

    /**
     * Click entity using SmartMouse (DreamBot's built-in human-like clicking)
     */
    public boolean clickEntity(Entity entity, boolean rightClick) {
        if (entity == null || !entity.exists()) {
            Logger.log("[HumanMouse] Entity is null or doesn't exist");
            return false;
        }

        // Human reaction time
        if (config.antiBan.useHumanReactionTime) {
            int reactionTime = config.antiBan.minReactionTime +
                    random.nextInt(config.antiBan.maxReactionTime - config.antiBan.minReactionTime);
            Sleep.sleep(reactionTime);
        }

        // FIXED: Let DreamBot's interact() method handle SmartMouse automatically
        // The interact() method uses SmartMouse if it's enabled globally
        if (config.mouse.useSmartMouse) {
            // SmartMouse is already enabled globally, interact() will use it
            Logger.log("[HumanMouse] Using SmartMouse via interact() - Bezier curves enabled");
        }

        return true; // Entity interaction happens via entity.interact() in calling code
    }

    /**
     * Move mouse to entity (for hover effects)
     */
    public boolean moveToEntity(Entity entity) {
        if (entity == null || !entity.exists()) {
            return false;
        }

        Point point = entity.getClickablePoint();
        if (point != null) {
            // Add slight randomization to point
            int offsetX = random.nextInt(10) - 5;
            int offsetY = random.nextInt(10) - 5;
            Point randomizedPoint = new Point(point.x + offsetX, point.y + offsetY);

            Mouse.move(randomizedPoint);

            // Small delay after movement
            Sleep.sleep(50, 150);
            return true;
        }

        return false;
    }

    /**
     * Click at specific point
     */
    public void click(Point point, boolean rightClick) {
        if (point == null) {
            return;
        }

        // Human reaction time
        if (config.antiBan.useHumanReactionTime) {
            int reactionTime = config.antiBan.minReactionTime +
                    random.nextInt(config.antiBan.maxReactionTime - config.antiBan.minReactionTime);
            Sleep.sleep(reactionTime);
        }

        Mouse.move(point);
        Sleep.sleep(50, 150);

        if (rightClick) {
            Mouse.click(true);
        } else {
            Mouse.click(false);
        }
    }

    /**
     * Random mouse movement (anti-ban)
     */
    public void randomMovement() {
        if (!config.mouse.humanLike) {
            return;
        }

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int maxX = screenSize.width;
        int maxY = screenSize.height;

        int targetX = random.nextInt(maxX);
        int targetY = random.nextInt(maxY);

        Point target = new Point(targetX, targetY);
        Mouse.move(target);

        Sleep.sleep(100, 300);
    }

    /**
     * Get current mouse settings info
     */
    public String getMouseInfo() {
        return "SmartMouse: " + config.mouse.useSmartMouse +
                ", Speed: " + config.mouse.mouseSpeed +
                ", Reaction: " + config.antiBan.minReactionTime + "-" + config.antiBan.maxReactionTime + "ms";
    }
}